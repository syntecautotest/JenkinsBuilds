// Vector2d.h: interface for the CVector2d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VECTOR2D_H__9332EE01_CB7F_4EA7_A6BF_886C50BDAADC__INCLUDED_)
#define AFX_VECTOR2D_H__9332EE01_CB7F_4EA7_A6BF_886C50BDAADC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Tuple2d.h"

class UTILAPI CVector2d : public CTuple2d  
{
public:
	CVector2d();
	// Constructs and initializes a Vector2d to (0,0).

	CVector2d( double x, double y );
	// Constructs and initializes a Vector2d from the specified xy
	// coordinates.

	virtual ~CVector2d();
	// destructor

	int isZero( void );
	// query whether this vector is zero

	double length( void );
	// Returns the length of this vector.

	double lengthSquared( void );
	// Returns the squared length of this vector

	double dot( CVector2d &v );
	// Returns the dot product of this vector and vector v1.

	double cross( CVector2d &v );
	// return the cross product magnitude of vectors v1 and v2.
	// because the cross product of two dimension vector is always along
	// z axis, so this method will return the vector magnitude only.

	void rotateCCW90();
	// Sets the value of this vector to rotate CCW 90 degree of itself.

	void rotateCCW90( CVector2d &v );
	// Sets the value of this vector to rotate CCW 90 degree of vector v.

	double angle( CVector2d &v );
	// Returns the angle in radians between this vector and the vector
	// parameter; the return value is constrained to the range [0,PI].

	double CCWAngle( CVector2d &v );
	// Return the Counter-ClockWise angle from this vector and the vector v
	// range is [0, 2PI)

	double CWAngle( CVector2d &v );
	// Return the ClockWise angle from this vector and the vector v
	// range is [0, 2PI)

	void normalize( void );
	// Normalizes this vector in place.

	void normalize( CVector2d &v );
	// Sets the value of this vector to the normalization of vector v.

	CVector2d operator+(const CVector2d &v);
	// vector additive
	// return = this + v

	CVector2d operator-(const CVector2d &v);
	// vector substract
	// return = this - v

	CVector2d operator*(double alpha);
	// scalar multiply
	// return = alpha * this

	CVector2d operator/(double alpha);
	// scalar divide
	// return = this / alpha

	double operator*(const CVector2d &v);
	// inner product
	// return = inner_dot(this,v)
};

#endif // !defined(AFX_VECTOR2D_H__9332EE01_CB7F_4EA7_A6BF_886C50BDAADC__INCLUDED_)
