#if !defined(_LAQUEUE_H____INCLUDED_)
#define _LAQUEUE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_BUFFER_SIZE		( 60 )

class CLANodePool;

template <class T>
class CLAQueue
{
public:
	CLAQueue( INT nSize )
	// constructor
	{
		ASSERT( nSize > 0 );

		// to allocate queue data buffer, one more slot for queue full
		m_ppBuffer = NULL;
		SAFENEW( m_ppBuffer, T *[ nSize + 1 ] );

		// init object state
		m_nSize = nSize + 1;
		m_nHead = 0;
		m_nCount = 0;
	}

	CLAQueue( void )
	// constructor
	{
		m_nCount = 0;
		m_nHead = 0;

		m_ppBuffer = NULL;
		SAFENEW( m_ppBuffer, T *[ MAX_BUFFER_SIZE ] );
	}

	~CLAQueue(void)
	// destructor
	{
		SAFEDELETE_ARRAY( m_ppBuffer );
	}

public:
	BOOL isEmpty( void )
	// query whether queue is empty
	{
		return m_nCount == 0;
	}
	
	BOOL isFull( void )
	// query whether queue is full
	{
		ASSERT( m_nCount <= m_nSize - 1 );
		return m_nCount == m_nSize - 1;
	}
	
	void FreeAll( CLANodePool *pLAPool )
	// abort all query.
	{
		T *pNode;
		int nCount = m_nCount;
		for( int i = 0 ; i < nCount ; i++ ) {
			pNode = remove();
			pLAPool->FreeLANode( pNode );
		}
	}

	void SetSize( INT nSize )
	// set Queue Size
	{
		nSize = nSize + 1;
		
		if( m_nSize != nSize ) {

			m_cs.lock();

			m_nSize = nSize;
			m_nCount = 0;
			m_nHead = 0;

			m_cs.unlock();
		}
	}

	void SetCount( INT nCount )
	// set the number of node inside queue
	{
		if( m_nCount != nCount ) {

			m_cs.lock();
			m_nCount = nCount;
			m_cs.unlock();
		}
		
	}

	INT getCount( void )
	// return the number of node inside queue
	{
		ASSERT( m_nCount >= 0 );
		return m_nCount;
	}

	int getFreeCount( void )
	// return the number of free node inside queue
	{
		return m_nSize - m_nCount - 1;
	}

	void add( T *pNode )
	// add specified node into queue tail
	{
		ASSERT( isFull() == FALSE );
		ASSERT( pNode != NULL );

		m_cs.lock();

		int nTail = ( m_nHead + m_nCount ) % m_nSize;
		m_ppBuffer[ getTail( m_nHead + m_nCount ) ] = pNode;
		m_nCount++;

		m_cs.unlock();
	}

	T *remove( void )
	// remove and return head node.
	{
		ASSERT( isEmpty() == FALSE );

		m_cs.lock();

		T *pNode = m_ppBuffer[ m_nHead ];
		m_nHead = getTail( m_nHead + 1 );
		m_nCount--;

		m_cs.unlock();

		return pNode;
	}

	T *peek( INT nIndex )
	// to peek a node with specified index relative to queue head, index is 0 for head node.
	{
		ASSERT( nIndex >= 0 );

		// check over run
		if( nIndex >= m_nCount ) {
			return NULL;
		}

		return m_ppBuffer[ getTail( m_nHead + nIndex ) ];
	}

	T *rpeek( INT nIndex )
	// to peek a node with specified index relative to queue tail, index is 0 for tail node.
	{
		ASSERT( nIndex >= 0 );

		// check over run
		if( nIndex >= m_nCount ) {
			return NULL;
		}

		return m_ppBuffer[ getTail( m_nHead + m_nCount - nIndex - 1 ) ];
	}

	INT getTail( INT nInput ) 
	{
		if( nInput >= m_nSize ) {
			return nInput - m_nSize;
		}

		ASSERT( nInput >= 0 );
		return nInput;
	}

private:
	CRTMutex m_cs;
	// mutex for object state

	T **m_ppBuffer;
	// queue buffer

	INT m_nSize;
	// queue size

	INT m_nHead;
	// index of queue header

	INT m_nCount;
	// the number of node in this queue
};

#endif // !defined(_LAQUEUE_H____INCLUDED_)