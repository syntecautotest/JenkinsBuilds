// EventCPBase.h: interface for the CEventCPBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EVENTCPBASE_H__AC657485_C7C8_4318_98E1_008BB9E831D4__INCLUDED_)
#define AFX_EVENTCPBASE_H__AC657485_C7C8_4318_98E1_008BB9E831D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEventCPBase
{
public:
	CEventCPBase( int capacity = 1 );
	~CEventCPBase();

	void unadvise( DWORD dwCookie );

protected:
	DWORD base_advise( void *pListener );

	void fireEvent( int EventID, void *pParam );
	// fire specified event

private:
	struct TNode {
		void	*pListener;
		BOOL	bOccupied;
	};

	TNode *m_pListenerTable;
	int m_nListenerCount;
	int m_nCapacity;

	virtual void processEvent( int EventID, void *pListener, void *pParam ) = 0;
	// process event
};

#endif // !defined(AFX_EVENTCPBASE_H__AC657485_C7C8_4318_98E1_008BB9E831D4__INCLUDED_)
