// IUpdateDriver.h: interface for the ISriDriver class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_IUPDATEDRIVER_H____INCLUDED_)
#define _IUPDATEDRIVER_H____INCLUDED_

class IUpdateDriver
{
public:
	virtual ~IUpdateDriver( void ) {}
	// destructor

	virtual void IsDeviceInfoReady( BOOL &bReady ) = 0;
	// check whether device information is ready

	virtual void GetCountOfSynDevice( int &nCount ) = 0;
	// get counts of Syntec device which is supported for updating

	virtual void GetSynDeviceStationID( int nNo, int &nStationID ) = 0;
	// get station ID of Syntec Device

	virtual BOOL GetSynDeviceInfo( int nStationID, int &nType, void *pBuffer ) = 0;
	// get information of device level

	virtual BOOL GetSynModuleInfo( int nStationID, int nModuleNo, void *pBuffer ) = 0;
	// get information of module level

	virtual BOOL GetSynUnitInfo( int nStationID, int nModuleNo, int nUnitNo, void *pBuffer ) = 0;
	// get information of unit level

	virtual BOOL OpenBootMode( int nStationID, BOOL &bReady, BOOL &bAlarmFlag ) = 0;
	// connect boot mode

	virtual BOOL CloseBootMode( int nStationID, BOOL &bReady, BOOL &bAlarmFlag ) = 0;
	// disconnect boot mode

	virtual BOOL FileBurnIn( int nStationID, int nFileCounts, void *pBuffer, BOOL &bAlarmFlag ) = 0;
	// start to burn in a file

	virtual BOOL BurnInMonitor( int nStationID, BOOL &bFinished, long &nProgress, BOOL &bAlarmFlag ) = 0;
	// monitor the progress of file burning
};
#endif //(_IUPDATEDRIVER_H____INCLUDED_)
