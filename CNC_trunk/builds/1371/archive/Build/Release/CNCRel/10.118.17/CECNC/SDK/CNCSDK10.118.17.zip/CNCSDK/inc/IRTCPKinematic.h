// IRTCPKinematic.h: interface for the IRTCPKinematic class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IRTCPKinematic_H__INCLUDED_)
#define AFX_IRTCPKinematic_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IRTCPKinematic : public IKinematic
{
public:
	enum EConfigOfRTCPTx {
		ECRT_Normal = 1,
		ECRT_FixAngle = 2,
	};

public:
	virtual ~IRTCPKinematic( void ) {};
	// destructor

	virtual void setMechanism( IRTCPMechanism *pMechanism ) = 0;
	// set mechanism type of four or five axis

	virtual BOOL isSetMechanism( void ) = 0;
	// is mechanism type of four or five axis axis already setting?

	virtual void attach( INT nXAxisID, INT nYAxisID, INT nZAxisID, INT nMasterAxisID, INT nSlaveAxisID ) = 0;
	// set four or five axis axis index

	virtual void setType( INT nConfigOfTx ) = 0;
	// set Type: Normal or FixAngle

	virtual void setToolDirCtrl( BOOL bToolDirCtrl, DOUBLE RValue ) = 0;
	// enable/disable tool center point retention type tool axis direction control (typeII), G53.6
	// set distance from tool tip to rotation center, R_ in BLU

	virtual void setRotationAngleForFixAngleType( DOUBLE MasterAngle, DOUBLE SlaveAngle ) = 0;
	// set rotate angle for fix angle type
	// in BLU

	virtual void setRotationStartAngle( DOUBLE Position[] ) = 0;
	// set rotate start angle in BLU

	virtual void getRTCPAxisIndex( INT pRTCPAxisIndex[] ) = 0;
	// get RTCP axis id in a NUMOF_RTCP_AXIS-elements array
	// return -1 to unused elements

	virtual INT getMasterAxisIndex( void ) = 0;
	// get master axis id

	virtual INT getSlaveAxisIndex( void ) = 0;
	// get slave axis id

	// ask IRTCPMechanism function
	virtual INT getMechID( void ) = 0;
	// get RTCP kinematic mechanism ID number

	virtual INT getMechType( void ) = 0;
	// get RTCP kinematic mechanism type

	virtual INT GetToolAxisDirection( void ) = 0;
	// get tool axis direction

	virtual INT GetDirectionOfFirstRotationAxis( void ) = 0;
	// get the axis direction of the first rotation axis.

	virtual INT GetDirectionOfSecondRotationAxis( void ) = 0;
	// get the axis direction of the second rotation axis.

	virtual BOOL IsQuatIntMode( void ) = 0;
	// is Quaternion Interpolation Mode?

	virtual BOOL IsTableCrdSysFromZeroPos( void ) = 0;
	// is basic position of table coordinate system for RTCP from zero position?

	virtual INT IsAlarm( ERTCPState nType = RTCP_Off ) = 0;
	// is alarm?

	virtual void SetToolLength( DOUBLE ToolLength ) = 0;
	// set tool length
	// unit : BLU

	virtual INT ToolCoordDis( DOUBLE displacement[], DOUBLE position[] ) = 0;
	// get movement along tool coord

	virtual INT ComputeRotateAngleForToolDirCtrl( CVector3d FeedDirection, DOUBLE MCS[], DOUBLE &MasterAngle, DOUBLE &SlaveAngle, LONG type = 0 ) = 0;
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle for tool axis direction control, G53.1/G53.6

	virtual INT ComputeRotateAngleForRTCP( CVector3d FeedDirection, DOUBLE BCS[], DOUBLE &MasterAngle, DOUBLE &SlaveAngle ) = 0;
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle for move command on G43.5

	virtual void GetToolDirectionUnderWorkPieceCoord( DOUBLE position[], DOUBLE ToolDirect[] ) = 0;
	// tool direction under workpiece coord

	virtual void GetToolCoordSystem( DOUBLE position[], IRTCPMechanism::EToolCoordType type, DOUBLE RotAngle, CMatrix3d &ToolCoord ) = 0;
	// get tool coordinate system based on type

	virtual void ConvertToQuaternion( DOUBLE fromPos[], DOUBLE toPos[], TQuaternionInfo *pQInfo, TFiveAxisData *pFData ) = 0;
	// input (M1,S1) and (M2,S2) in 0.001deg(BLU), then convert to rotation matrix (Quaternion)

	virtual INT ConvertToMS( DOUBLE disp[], DOUBLE &CurQAngle, DOUBLE &MasterAngle, DOUBLE &SlaveAngle, TQuaternionInfo &QInfo, TFiveAxisData &FData ) = 0;
	// input all disp( include dTheta ) in radian(IU) and current (I,J,K),
	// then convert Quaternion to (dM,dS) in deg(IU) and write back to displacement.
	// return AlarmID

	virtual void CalcJointDir( DOUBLE JointDir[] , DOUBLE ToolTipDir[], DOUBLE ToolTipPosition[] ) {};
	// calculate joint feed direction
	// input: IU, output: IU
};

#endif
