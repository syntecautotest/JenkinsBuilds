#if !defined(_SERVOTUNINGDEF_H____INCLUDED_)
#define _SERVOTUNINGDEF_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define UNIT_USECtoSEC						( 1e-6 )
#define UNIT_MINtoSEC						( 60 )
#define VEL_GLITCH_PARAM_PosPeakHeight		( 0 )
#define VEL_GLITCH_PARAM_PosRiseTime		( 20 )
#define	VEL_GLITCH_PARAM_PosHoldTime		( 40 )
#define	VEL_GLITCH_PARAM_PosDecayTime		( 60 )
#define	VEL_GLITCH_PARAM_PosDelayTime		( 80 )
#define	VEL_GLITCH_PARAM_PosRiseType		( 100 )
#define	VEL_GLITCH_PARAM_NegPeakHeight		( 120 )
#define	VEL_GLITCH_PARAM_NegRiseTime		( 140 )
#define	VEL_GLITCH_PARAM_NegHoldTime		( 160 )
#define	VEL_GLITCH_PARAM_NegDecayTime		( 180 )
#define	VEL_GLITCH_PARAM_NegDelayTime		( 200 )
#define	VEL_GLITCH_PARAM_NegRiseType		( 220 )

struct TFrictionCoeff
{
	double StaticFricPos;
	double StaticFricNeg;
	double Reserved[ 6 ];
};

// data struct of driver simulator
struct TDrvSimuParam {
	double Ad[ 16 ];
	double Bd[ 12 ];
	double Cd[ 16 ];
	double Dd[ 12 ];
	double BLUtoDrvInput;
	double RatedTRQtoNM;
};

enum EFricComp {
	FRIC_OFF = -1,
	FRIC_POS,
	FRIC_VFF,
	FRIC_TFF,
};

// data struct of speed glitch compensation param, but only with one direction
struct TVFFParam {
	LONG	nPeakHeight;	// (um/sec)
	LONG	nRiseTime;		// (us)
	LONG	nHoldTime;		// (us)
	LONG	nDecayTime;		// (us)
	LONG	nDelayTime;		// (us)
	LONG	nRiseType;
	DOUBLE	RiseRatio;
	DOUBLE	DecayRatio;
};

#endif // _SERVOTUNINGDEF_H___INCLUDED_