// IServoSpdParamInterface.h : interface for the Spindle object in different class

#if !defined ( _AFX_ISERVOSPDPARAMINTERFACE_H__A91E0691_1C80_40db_9715_5805A245F3FF__INCLUDED_ )
#define _AFX_ISERVOSPDPARAMINTERFACE_H__A91E0691_1C80_40db_9715_5805A245F3FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class IServoSpdParamInterface
{
public:
	virtual ~IServoSpdParamInterface( void ){};
	// destructor

	virtual void PutSensorResolution( LONG nResolution, LONG nScale ) = 0;
	// set encoder resolution

	virtual void PutSyntecSOSOffset( LONG nOffset ) = 0;
	// set syntec s.o.s offset from syntec driver in 0.001 deg

	virtual void SyncParamResolution( void ) = 0;
	// set spindle parameters of encoder resolution

	virtual void notifyParamInitialized( void ) = 0;
	// notify param initialized
};

#endif
