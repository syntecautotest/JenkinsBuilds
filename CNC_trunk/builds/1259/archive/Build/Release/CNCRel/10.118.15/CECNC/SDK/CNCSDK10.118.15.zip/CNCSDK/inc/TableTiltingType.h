#if !defined(AFX_TABLETILTINGTYPE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_)
#define AFX_TABLETILTINGTYPE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_

class CTableTiltingType : public CFiveAxisMechanism
{
public:
	CTableTiltingType( INT nID );
	// constructor

	virtual ~CTableTiltingType( void );
	// destructor

	void SetOffset( double FirstOffset[], double SecondOffset[] );
	// FirstOffset = MasterToSlave
	// SecondOffset = MachineToMaster

	void UpdateConstOffset( void );
	// set const offset

	BOOL IsValidSetting( void );
	// is valid setting for five axis

	void Kinematic( CVector3d &ToolTipPosition, double MasterRotAngle, double SlaveRotAngle, const CVector3d &ControlPoint );
	// Kinematic transformation for Table Tilting Type Machine
	// Compute Tool Tip Position
	// unit : BLU
	// right hand side

	int InverseKinematic( const CVector3d &ToolTipPosition, double MasterRotAngle, double SlaveRotAngle, CVector3d &ControlPoint );
	// Inverse Kinmatic transformation for Table Tilting Type Machine
	// Compute  ControlPoint
	// unit : BLU
	// right hand side

	int InverseKinematic( CVector3d ToolTipPosition, CVector3d FeedDirection, double LastMasterRotAngle, double LastSlaveRotAngle, CVector3d &ControlPoint, double &MasterRotAngle, double &SlaveRotAngle, double ToolLength );
	// Inverse Kinmatic transformation for Table Tilting Type Machine
	// Given Tool Tip Position and Feed Direction and last rotate angle
	// Compute  ControlPoint and RotateAngle
	// unit : BLU
	// right hand side

	INT ComputeRotateAngle( CVector3d FeedDirection, DOUBLE LastMasterRotAngle, DOUBLE LastSlaveRotAngle, DOUBLE &MasterRotAngle, DOUBLE &SlaveRotAngle, EFiveAxSolType type = EST_ShortestDist );
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle
	// unit : BLU
	// right hand side

	void GetToolCoordUnderMachineCoord( double MasterAngle, double SlaveAngle, CMatrix3d &ToolCoord, EToolCoordType Type );
	// get tool coord
	// right hand side

	void MStoIJK( double MasterAngle, double SlaveAngle, CVector3d *RotAxis );
	// convert (M,S) to (I,J,K)
	// right hand side

private:
	void SetConstVecMachToMasterAndToolLen( void );
	// set constant vector from m_MachineToMaster and tool length

	void SetConstVecMachineToSlave( void );
	// set constant vector from machine to slave

private:
	CVector3d m_MasterToSlave;
	// the vector from master axis to slave axis

	CVector3d m_MachineToMaster;
	// the vector from Machine coordinate to master axis

	CVector3d m_ConstVecMachToMasterAndToolLen;
	// the constant vector from m_MachineToMaster and tool length

	CVector3d m_ConstVecMachineToSlave;
	// the constant vector from machine to slave
};
#endif
