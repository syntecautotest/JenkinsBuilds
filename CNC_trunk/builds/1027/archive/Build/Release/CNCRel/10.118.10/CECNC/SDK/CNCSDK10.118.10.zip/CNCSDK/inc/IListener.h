#if !defined(_ILISTENER_INCLUDE_)
#define _ILISTENER_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IListener
{
public:
	virtual ~IListener( void ) {}
	// destructor

	virtual void Trigger( TEvtInfo *pEvtArg, va_list var ) = 0;
	// trigger event
};

#endif // !defined(_ILISTENER_INCLUDE_)
