// Interpolator.h: interface for the CInterpolator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTERPOLATOR_H__499E55BB_CBC7_46F2_8890_95BAE8C057DD__INCLUDED_)
#define AFX_INTERPOLATOR_H__499E55BB_CBC7_46F2_8890_95BAE8C057DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CInterpolator : public ITrajInterpolator
{
protected:
	// the header of movement segment in queue
	struct TSegmentNode
	{
		int							fBreakable;
		double						MoveTime;
		CCJerkHelicalInt::TCtlBlk	CtlBlk;
	};

public:
	CInterpolator( int QueueSize, int StackSize );
	// 4 * 16 block + 4 tail * feedrate override ( 200% )
	// constructor

	friend void DumpDebugData( CInterpolator *pInterpolator, long *data );
	// open friend relationship to dump object state for debug purpose

	double QueryRemainTime( void );
	// query the total remain time, which includes
	// blocks in queue and block in process
	// Use threads: motion plan

	int GetFreeQueueSize( void );
	// this function must be call to check there are 
	// empty queue slot before call write-into functions.
	// Use threads: motion plan

	virtual void ConstantJerkPVTToEx( int fBreakble, double displacement, double from_velocity, double to_velocity, double time );
	// fBreakable       whether current command is breakable by any block in queue.
	//					that is, this command will automatically abort when there
	//					are new commands put into queue.	
	// displacement		position displacement
	// from_velocity	velocity at time 0
	// to_velocity		velocity at time T
	// time				block move time, that is, T.
	// Use threads: motion plan

	void ConstantJerkPVTTo( double displacement, double from_velocity, double to_velocity, double time );
	// displacement		position displacement
	// from_velocity	velocity at time 0
	// to_velocity		velocity at time T
	// time				block move time, that is, T.
	// Use threads: motion plan

	void ConstantJerkHelicalTo( double displacement,
								double from_angle, double to_angle,
								double from_omega, double to_omega,
								double from_radius, double to_radius,
								double transform[9], double time );
	// displacement		position displacement
	// from_angle		angle position at time 0
	// to_angle			angle position at time T
	// from_omega		angle velocity at time 0
	// to_omega			angle velocity at time T
	// from_radius		circlar arc radius at time 0
	// to_radius		circlar arc radius at time T
	// transform[9]		
	// time				block move time, that is, T.
	// Use threads: motion plan

	void DelayTimeTo( double time );
	// time				block move time, that is, T.
	// Use threads: motion plan

	void GetSegment( double TimeElapse, double *segment );
	// TimeElapse			current time base
	// segment				pointer to store buffer
	// Use threads: interpolation

	virtual void GetSegment( DOUBLE TimeElapse,
							DOUBLE *x_segment,
							DOUBLE *y_segment,
							DOUBLE *z_segment );
	// TimeElapse			current time base
	// x_segment			pointer to store x buffer
	// y_segmennt			pointer to store y buffer
	// z_segmennt			pointer to store z buffer
	// Use threads: interpolation

	double getVelocity( void );
	// get current velocity

	int IsIdle( void );
	// query whether the interpolator finished all interpolation task
	// Use threads: <= motion plan

	virtual void Abort( void );
	// abort current command execution

	virtual void Reset( void );
	// reset interpolator will empty command queue, and stop
	// running task
	// Use threads: <= motion plan

	void getCurrentVA( double &CurVel, double &CurAcc );
	// calculate CurrentVA

protected:

	CCJerkHelicalInt::TParam	HelParam;
	CCJerkLineInt::TParam		LineParam;

	double				m_velocity;
	// velocity

	double				m_LastTimeElapse;
	// record time elapse at last GetSegment call, this is variable
	// is for debug purpose
	
	int					m_fBreakable;
	// flag for whether current command is breakable?

	double				m_RemainTimeInQueue;
	// remain time in queue

	double				m_SegmentRemainTime;
	// the remain time of current executing segment

	double				m_SegmentMoveTime;
	// current segment move time

	CCJerkHelicalInt	m_awt;
	// Interpolator object for constant anglular jerk

	CAsynQueue			m_CommandQueue;
	// command queue
	// command queue record structure is
	//	
	//	Type			Description
	//	-----------		-----------------------------
	//	Integer			command mode ID
	//	flag			IsBreakable, TRUE for yes, FALSE for no.
	//	void *			control block,
	//
	// size of record = sizeof(int) +
	//				  sizeof(biggest control block)
	//

	CRTMutex m_cs;
	// object mutex

protected:
	virtual void init( void );
	// init interpolator
};

#endif // !defined(AFX_INTERPOLATOR_H__499E55BB_CBC7_46F2_8890_95BAE8C057DD__INCLUDED_)
