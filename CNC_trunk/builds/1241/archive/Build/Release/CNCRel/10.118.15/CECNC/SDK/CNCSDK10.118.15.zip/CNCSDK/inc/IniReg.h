// IniReg.h: interface for the CIniRegistry class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INIREG_H__4FBF2E21_72E0_11D2_A962_0080C8581E1B__INCLUDED_)
#define AFX_INIREG_H__4FBF2E21_72E0_11D2_A962_0080C8581E1B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CIniRegistry
{
public:
	enum EMaxBounds {
		LEN_IniKeyName = 32,
		SIZE_IniKeyTable = 800,
		SIZE_IniRegDB = 4,
		LEN_IniSectionName = 32,
		LEN_IniRegistryName = 32,
		LEN_IniValueBuffer = 256,
		LEN_Location = 256
	};

	struct TKeyNode {
		char			section[LEN_IniSectionName];
		char			key[LEN_IniKeyName];
		char			*value;
	};

	struct TRegistry {
		char			PathName[128];
		char			RegistryName[LEN_IniRegistryName];
		TKeyNode		KeyTable[SIZE_IniKeyTable];
		int				TableSize;
		int				fSorted;
		int				fDirty;
	};

public:
	CIniRegistry();
	virtual ~CIniRegistry();

	void Commit( void );
	// commit registry data into disk

	void setLocation( char *path );
	// set ini database location

	void setDefaultRegistryName( char *pRegistryName );
	// set default registry name

	void setDefaultSectionName( char *SectionName );
	// set default section name

	BOOL IsExist( char *RegistryName, char *section, char *key );
	// read a key from registry with write back when key not exist

	int ReadKey( char *RegistryName, char *section, char *key, char *pDefault, char *buffer, int nCount, BOOL bDefault = TRUE );
	// read a key from registry with write back when key not exist
	// return the read character count

	void WriteKey( char *RegistryName, char *section, char *key, char *value );
	// write a key into registry

	int ReadKeyInt( char *RegistryName, char *section, char *key, int nDefault, BOOL bDefault = TRUE );
	// read a key from registry with write back when key not exist

	void WriteKeyInt( char *RegistryName, char *section, char *key, int value );
	// write a key into registry

protected:

	char			m_DefSectionName[LEN_IniSectionName];
	// default section name

	void LoadFromFile( TRegistry *pRegistry, char *RegistryName );
	// load registry from .ini file

	void SaveToFile( TRegistry *pRegistry );
	// save registry into .ini file

	char *Trim( char *data );
	// trim leading and tailing space character

	void getRegFileName( char *RegistryName, char *buffer, unsigned count );
	// get ini registry filename

private:

	TRegistry		*m_IniRegDB[SIZE_IniRegDB];
	// ini registry database

	int				m_DBSize;
	// ini registry size

	char			m_Location[LEN_Location];
	// ini database location

	char			m_DefRegistryName[64];
	// default registry name

	void CheckSort( TRegistry *pRegistry );
	// check if the registry has been sorted or not, if not sort it

	char *Normalize( char *data, char *buffer, int count );
	// normal a identifier

	TKeyNode *NewKeyNode( TRegistry *pRegistry, char *section, char *key );
	// new a key node

	TRegistry *NewRegistry( void );
	// create a new empty registry database
	// return registry pointer for successful, return NULL for failure

	static int __cdecl KeyCompare( const void *elem1, const void *elem2 );
	// key compare function

	TKeyNode *AddKey( TRegistry *pRegistry, char *section, char *key, char *value );
	// add a key with (section,key,value)

	TRegistry *GetRegistry( char *RegistryName );
	// get a registry pointer from its name

	int PutValue( TKeyNode *pKeyNode, char *value );
	// put value into key node.
	// return TRUE when value been updated
	// return FALSE when value is not changed

	TKeyNode *DoLookup( TRegistry *pRegistry, char *section, char *key );
	// do lookup of specified (section,key)
};

#endif // !defined(AFX_INIREG_H__4FBF2E21_72E0_11D2_A962_0080C8581E1B__INCLUDED_)
