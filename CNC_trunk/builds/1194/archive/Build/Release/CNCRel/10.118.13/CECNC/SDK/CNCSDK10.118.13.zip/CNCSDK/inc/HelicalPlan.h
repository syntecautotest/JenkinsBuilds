// HelicalPlan.h: interface for the CHelicalPlan class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HELICALPLAN_H__0AF71193_14F6_4DFC_8D39_70F586D74F21__INCLUDED_)
#define AFX_HELICALPLAN_H__0AF71193_14F6_4DFC_8D39_70F586D74F21__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CInterpolator;

// Helical move motion planning class
// Please call IsReady() to make sure machine is ready before use
// CCWMoveTo(), CWMoveTo()
class CHelicalPlan  
{
public:
    CHelicalPlan();
	// constructor

	void AssociateInterpolator( CInterpolator *pInterpolator );
	// associate BSplinePlan object for output planning command
	// Use threads: constructor
	
    void setNormal(CVector3d &v);
	// set normal vector of arc plane
	// normal		normal vector, this vector needn't be
	//				a unit vector. default = ( 0,0,1 )
	// Use threads: motion plan

    double CCWMoveTo(CVector3d &vDisplacement,CVector3d &vCenter,double TM,double TA);
	// CounterClockwise arc move to
	// vDisplacement	displacement vector. in BLU.
	// vCenter			arc center vector, in BLU.
	// TM				movement time, in microsecond.
	// TA				acceleration time, in microsecond.
	// Use threads: motion plan

    double CWMoveTo(CVector3d &vDisplacement,CVector3d &vCenter,double TM,double TA);
	// Clockwise arc move to
	// vDisplacement	displacement vector. in BLU.
	// vCenter			arc center vector, in BLU.
	// TM				movement time, in microsecond.
	// TA				acceleration time, in microsecond.
	// Use threads: motion plan

	void CalculateLength( double *length, long ArcType, CVector3d &vDisplacement, CVector3d &vCenter );
	// calculate arc length
	// length			pointer to storage of arc length, in BLU.
	// ArcType			2 for CW Arc, 3 for CCW		
	// vDisplacement	displacement vector. in BLU.
	// vCenter			arc center vector, in BLU.
	// Use threads: motion plan

	int IsReady(void);
	// query whether the helical planner is ready to receive new
	// command ?
	// Use threads: >= motion plan

	void Reset( void );
	// reset this object
	// Use threads: <= motion plan

private:
	static const double EPSILON_MaxRadiusDiff;
	// epsilon amount for maxiimum radius difference

private:

	double GenerateCode( double Displacement, double Angle, double Radius, double TM, double TA );
	// generate interpolation movement command
	// Use threads: motion plan

	void CalculateAngle( double *angle, CVector3d &vNormal, CVector3d &vStart, CVector3d &vEnd );
	// calculate arc movement angle
	// Use threads: any

	void CalculateTransformMatrix( CVector3d &start, CVector3d &normal );
	// calculate linear transformation matrix, which map 
	// from 2D arc coordinate system to 3D world coordinate
	// system.
	// calculate transform matrix
	// T = [ S, N x S, N ]
	// because only the first two unit vectors are useful, so
	// only the first two be calculated.
	// Use threads: motion plan

    double HelicalTo(CVector3d &vDisplacement, CVector3d  &vCenter, CVector3d &vNormal, double TM, double TA);
	// comprehensive helical MoveTo() function,
	// CCWMoveTo() and CWMoveTo() both share this function.
	// Use threads: motion plan

	CInterpolator *m_pInterpolator;
	// for rough interpolation

	CVector3d m_Normal;
	// normal vector of arc plane

	double	m_Transform[9];	
	// linear transform matrix from 2D arc coordinate system
	// to 3D world coordinate system.

	CRTMutex m_cs;
	// mutex for object state consistent
};

#endif // !defined(AFX_HELICALPLAN_H__0AF71193_14F6_4DFC_8D39_70F586D74F21__INCLUDED_)
