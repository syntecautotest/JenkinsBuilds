// PLCDef.cpp: PLC relay singal input mode constant.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLCDEF_H__CF3EC1D4_354F_4fa1_93C7_21D8019644B2__INCLUDED_)
#define AFX_PLCDEF_H__CF3EC1D4_354F_4fa1_93C7_21D8019644B2__INCLUDED_

enum ERelayInputMode {
	RELAYINPUT_Normal = 0,
	RELAYINPUT_OneShot = 1,
	RELAYINPUT_Hold = 2,
	RELAYINPUT_SIZE,
};

#endif // !defined(AFX_PLCDEF_H__CF3EC1D4_354F_4fa1_93C7_21D8019644B2__INCLUDED_)
