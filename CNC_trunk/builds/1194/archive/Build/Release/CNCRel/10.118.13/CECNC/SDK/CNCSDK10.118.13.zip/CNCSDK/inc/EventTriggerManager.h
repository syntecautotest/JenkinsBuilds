#if !defined(_EVENTTRGMGR_INCLUDE_)
#define _EVENTTRGMGR_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEventTriggerGroup;
class IListener;
class CMixListener;

class CEvtTrgMgr
{
public:
	CEvtTrgMgr( void );
	// constructor

	virtual ~CEvtTrgMgr( void );
	// destructor

	BOOL RegisterEvt( INT nEvtID, INT nEvtArg1, IListener * pListener );
	// register single-event, type like: C0-on

	BOOL RegisterEvt( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg, IListener * pListener );
	// register mix-event, mix-event

	BOOL UnregisterEvt( INT nEvtID, INT nEvtArg, IListener * pListener );
	// unregister single-event, type like: C0-on

	BOOL UnregisterEvt( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg, IListener * pListener );
	// unregister mix-event

	void Trigger( INT nEvtID, TEvtInfo *pEvtArg, INT nStartIndex, INT nEndIndex, va_list var );
	// trigger when event is happened

private:
	void Init( void );
	// initial.

private:
	CMixListener *m_pMixListener;
	// mix-listener object

	CEventTriggerGroup *m_pEvtGroup[ COUNT_SINGLE_EVT + 1 ][ COUNT_SINGLE_EVT - COUNT_TMR_EVT + 1 ][ COUNT_SINGLE_EVT - COUNT_TMR_EVT + 1];
};
#endif // !defined(_EVENTTRGMGR_INCLUDE_)
