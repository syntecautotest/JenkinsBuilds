// CRobotInterpolator.h: interface for the CRobotInterpolator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ROBOTINTERPOLATOR_INCLUDED_)
#define _ROBOTINTERPOLATOR_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "QuickMatrixN.h"

#define NUMOF_INTBUFFER		( 2 )

class CRobotInterpolator : public ITrajInterpolator
{
public:
	CRobotInterpolator( void );
	// constructor

	~CRobotInterpolator( void );
	// destructor

	double QueryRemainTime( void );
	// query the total remain time, which includes
	// blocks in queue and block in process
	// Use threads: motion plan

	int GetFreeQueueSize( void );
	// this function must be call to check there are 
	// empty queue slot before call write-into functions.
	// Use threads: motion plan

	void processPVTSheetTo( TPVTSheet *Sheet, TInterpolationBlock *pIntBlock );
	// Sheet			one block PVT sheet
	// pIntBlock		interpolation block
	// ( Input, Output )
	// Use threads: Trajectory plan

	void processMOVCPVTSheetTo( double *CoordInfo, double *PointInfo, double *LengthInfo, TPVTSheet *Sheet, TInterpolationBlock *pIntBlock );
	// CoordInfo		coordinate frame
	// PointInfo		start / center / end point info in 2
	// LengthInfo		arc angle and geometry length
	// Sheet			one block PVT sheet
	// ( Input, Input, Input, Input, Output )
	// Use threads: Trajectory plan

	void ConstantJerkPVTToEx( int fBreakble, double displacement, double from_velocity, double to_velocity, double time );
	// fBreakable       whether current command is breakable by any block in queue.
	//					that is, this command will automatically abort when there
	//					are new commands put into queue.	
	// displacement		position displacement
	// from_velocity	velocity at time 0
	// to_velocity		velocity at time T
	// time				block move time, that is, T.
	// Use threads: motion plan

	void ConstantJerkPVTTo( double displacement, double from_velocity, double to_velocity, double time );
	// displacement		position displacement
	// from_velocity	velocity at time 0
	// to_velocity		velocity at time T
	// time				block move time, that is, T.
	// Use threads: motion plan

	void DelayTimeTo( double time );
	// time				block move time, that is, T.
	// Use threads: motion plan

	BOOL calcMOVJSegment( TRobotMicroCode *pCode, DOUBLE TimeElapse, DOUBLE Segment[] );
	// TimeElapse			current time base
	// Segment				pointer to store axis buffer
	// Use threads: interpolation
	// return TRUE when time elapse runs out

	BOOL calcMOVLSegment_QuatOri( TRobotMicroCode *pCode, DOUBLE TimeElapse, DOUBLE Segment[] );
	// robot orientation is quaternion interpolation
	// for those robot which orientation DOF is 1 or 3
	// TimeElapse			current time base
	// Segment				dx dy dz dtheta QAngle RotAxis[0] RotAxis[1] RotAxis[2]
	// return TRUE when time elapse runs out

	BOOL calcMOVLSegment_LinearOri( TRobotMicroCode *pCode, DOUBLE TimeElapse, DOUBLE Segment[] );
	// robot orientation is linear interpolation
	// for those robot which has only 2 DOF in orientation
	// TimeElapse			current time base
	// Segment				dx dy dz ( dA dB / dB dC / dA dC )
	// return TRUE when time elapse runs out

	double getVelocity( void );
	// get current velocity

	int IsIdle( void );
	// query whether the interpolator finished all interpolation task
	// Use threads: <= motion plan

	void Abort( void );
	// abort current command execution

	void Reset( void );
	// reset interpolator will empty command queue, and stop
	// running task
	// Use threads: <= motion plan

	void UpdateCurBlockAndBuffer( int nOpCode, TInterpolationBlock *IntBlock, BOOL bForward );
	// update current block and buffer

	void UpdateOvlBlockAndBuffer( int nOpCode, TInterpolationBlock *OvlIntBlock, BOOL bForward );
	// update overlap block and buffer

	DOUBLE getRemainTimeElapse( void );
	// return remain time elapse

private:
	void init( void );
	// init interpolator

	void initIntBuffer( int nOpCode, TInterpolationBlock *IntBlock, int nBuffIndex, BOOL bForward );
	// init interpolation buffer

	void GetSegment( TInterpolationBlock *IntBlock, DOUBLE &TimeElapse, DOUBLE *Segment );
	// Index				index of the buffer
	// IntBlock				pointer to interpolation block
	// TimeElapse			current time base
	// Segment				pointer to store length buffer
	// Use threads: interpolation

	void GetMovcSegment( TInterpolationBlock *IntBlock, DOUBLE &TimeElapse, DOUBLE *Segment );
	// Index				index of the buffer
	// IntBlock				pointer to interpolation block
	// TimeElapse			current time base
	// Segment				pointer to store length buffer
	// Use threads: interpolation

	void ExtractMovcInfo( int nIndex, TRobotSegmentNode *ptr, BOOL bFwd, BOOL bNodeFinished );
	// copy MOVC information

	void calcMovcMovementInWorld( TIntBuffer *pIntBuffer, double *Local_segment, double Segment[] );
	// convert movc movement from local to world

protected:
	CCJerkLineInt::TParam		m_LineParam;

	double				m_velocity;
	// velocity

	double				m_LastTimeElapse;
	// record time elapse at last GetSegment call, this is variable
	// is for debug purpose

	double				m_RemainTimeInQueue;
	// remain time in queue

	TIntBuffer m_Buffer[ NUMOF_INTBUFFER ];
	// buffer for interpolation to use
	// Buffer[ m_nCurBuffIndex ] : current block( the same as NowTapeHead in motion planner )
	// Buffer[ m_nOvlBuffIndex ] : block for overlapping to use

	CRTMutex m_cs;
	// object mutex

	TInterpolationBlock *m_CurIntBlock;
	TInterpolationBlock *m_OvlIntBlock;
	// current / overlap interpolation block

	int m_nCurBuffIndex;
	int m_nOvlBuffIndex;
	// current / overlap buffer index

	DOUBLE m_RemainTimeElapse;
	// remain time elapse
};
#endif // !defined(_ROBOTINTERPOLATOR_INCLUDED_)
