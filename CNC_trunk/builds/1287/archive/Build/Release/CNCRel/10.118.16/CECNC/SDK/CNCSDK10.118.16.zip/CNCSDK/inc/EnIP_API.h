// The EtherNet/IP API Declaration
#pragma once


extern "C" {

// Send the UDP broadcast message to get potential EnIP device from specific LAN port number.
// Note1: If success will record the device info into list, othrewise not.
// Note2: If nMaxRspDelay (unit: milliseconds) is value of 0 ms, then a default value of 2000 ms shall be used
//        If it is value of 1-500 ms, then a value of 500 ms shall be used
BOOL EnIP_Broadcast( /*In*/ UINT nLAN, /*Out*/ TEnIPDevInfoList &DevInfoList, /*In*/ USHORT nMaxRspDelay = 0 );

// To open the connection for specific EnIP device with TCP/IP
// Set device IPv4 address (Big Endian), and communication timeout value (unit: microsecond (us))
BOOL EnIP_Connection( /*In*/ ULONG nIPAddr, /*In*/ ULONG nTimeOut );

// Get device timeout value, unit: microsecond (us), from specific device IPv4 address (Big Endian)
ULONG EnIP_GetDeviceTimeOut( /*In*/ ULONG nIPAddr );

// Send EnIP explicit message request command to specific device IPv4 address (Big Endian)
// If success return control handle, otherwise return ENIP_ERROR_HANDLE
ENIP_HANDLE EnIP_SendExpMsgReq( /*In*/ ULONG nIPAddr, /*In*/ const TEnIPExpMsgReq &ReqInfo );

// Recv EnIP explicit message response data from specific handle
// Copy the response data into buffer and record information in RspInfo
EEnIPRecvState EnIP_RecvExpMsgRsp( /*In*/ ENIP_HANDLE hHandle, /*Out*/ void *pRspBuf, /*In*/ INT nMaxBufSize, /*Out*/ TEnIPExpMsgRsp &RspInfo );

// Abort EnIP explicit message request command from specific handle
// Note: If request was sent, then successful abort must wait until data receive finished or other errors occured,
// otherwise can not send next request or get current response during this time
void EnIP_AbortExpMsgReq( /*In*/ ENIP_HANDLE hHandle );

}
