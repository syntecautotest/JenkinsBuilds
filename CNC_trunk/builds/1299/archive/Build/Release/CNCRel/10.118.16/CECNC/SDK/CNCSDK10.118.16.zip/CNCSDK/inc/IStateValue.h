#if !defined(_ISTATEVALUE_H_INCLUDED_)
#define _ISTATEVALUE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class IStateValue
{
public:
	virtual ~IStateValue( void ) {}
	// destructor

	virtual BOOL ReadStateValue( INT nNo, TOcVariant *value ) = 0;
	// read state value
};

#endif