// FiveAxisMechanism.h: interface for the FiveAxisMechanism class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FIVEAXISMECHANISM_H_)
#define AFX_FIVEAXISMECHANISM_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFiveAxisMechanism : public IRTCPMechanism
{
public:
	CFiveAxisMechanism( INT nID );

	virtual ~CFiveAxisMechanism( void );
	// destructor

public:
	void SetToolAxisDirection( INT n, DOUBLE RA, DOUBLE RB );
	// 1:Positive X-Axis direction
	// 2:Positive Y-Axis direction
	// 3:Positive Z-Axis direction
	// unit : BLU
	// see Fanuc p540
	// parameter 19698 and 19699

	void SetDirectionOfFirstRotationAxis( INT type, DOUBLE RotationOffset[] );
	// set the axis direction of the first rotation axis.
	// type 1: On X-axis
	// type 2: On Y-axis
	// type 3: On Z-axis

	void SetDirectionOfSecondRotationAxis( INT type, DOUBLE RotationOffset[] );
	// set the axis direction of the second rotation axis.
	// type 1: On X-axis
	// type 2: On Y-axis
	// type 3: On Z-axis

	void SetRotationDirectionOfFirstRotationAxis( INT n );
	// 0:rule of right hand side
	// 1:rule of left hand side

	void SetRotationDirectionOfSecondRotationAxis( INT n );
	// 0:rule of right hand side
	// 1:rule of left hand side

	void SetRestrictOfFirstRotationAxis( DOUBLE Start, DOUBLE End );
	// set restriction of first rotation axis
	// unit : BLU
	// 0 ~ 2PI

	void SetRestrictOfSecondRotationAxis( DOUBLE Start, DOUBLE End );
	// set restriction of second rotation axis
	// unit : BLU
	// 0 ~ 2PI

	void SetToolHolderOffset( DOUBLE ToolHolderOffset );
	// set tool holder offset
	// unit : BLU

	void SetDefaultTCPIntMode( EIntMode bQuatInt );
	// set flag of default TCP Interpolation Mode

	void SetTCPTableCrdSys( ETableCoordSys nBasicPos );
	// set basic position of table coordinate system for RTCP

	void SetActiveToolLength( DOUBLE length );
	// set active tool length

	INT GetToolAxisDirection( void );
	// get tool axis direction

	INT GetDirectionOfFirstRotationAxis( void );
	// get the axis direction of the first rotation axis.

	INT GetDirectionOfSecondRotationAxis( void );
	// get the axis direction of the second rotation axis.

	BOOL IsQuatIntMode( void );
	// is Quaternion Interpolation Mode?

	BOOL IsTableCrdSysFromZeroPos( void );
	// is basic position of table coordinate system for RTCP from zero position?

	BOOL IsSetToolAxisDirection( void );
	// does set tool axis direction

	BOOL IsSetDirectionOfFirstRotationAxis( void );
	// does set direction of first rotation axis

	BOOL IsSetDirectionOfSecondRotationAxis( void );
	// does set direction of second rotation axis

	BOOL IsSameDirForFirstAndSecondRotAxis( void );
	// is same direction for first and second rotation axis

	BOOL IsSetRotationDirectionOfFirstRotationAxis( void );
	// does set rotation direction of first rotation axis

	BOOL IsSetRotationDirectionOfSecondRotationAxis( void );
	// does set rotation direction of second rotation axis

	BOOL IsAtPermissibleRangeForMasterAxis( DOUBLE &Angle );
	// is the angle at permissible range for Master Axis
	// Unit : BLU
	// -PI ~ PI
	// right hand side

	BOOL IsAtPermissibleRangeForSlaveAxis( DOUBLE &Angle );
	// is the angle at permissible range for Slave Axis
	// Unit : BLU
	// -PI ~ PI
	// right hand side

public:
	void setIUtoBLU_Rotary( DOUBLE IUtoBLU );
	// set IUtoBLU for rotary axes

	DOUBLE getIUtoBLU_Rotary( void );
	// get IUtoBLU for rotary axes

	INT getMechID( void );
	// get the ID of five axis mechanism

	INT getMechType( void );
	// get the type of five axis mechanism

	DOUBLE getMasterAxisAngleOffset( void );
	// get angle offset of master axis

	DOUBLE getSlaveAxisAngleOffset( void );
	// get angle offset of slave axis

	INT getRDOfFirst( void );
	// get rotation direction of first axis

	INT getRDOfSecond( void );
	// get rotation direction of second axis

	INT IsAlarm( void );
	// is alarm?

public:
	virtual void SetOffset( DOUBLE FirstOffset[], DOUBLE SecondOffset[] ) = 0;
	// set offset

	virtual void UpdateConstOffset( void ) = 0;
	// set const offset

	virtual BOOL IsValidSetting( void ) = 0;
	// is valid setting for five axis

	virtual void Kinematic( CVector3d &ToolTipPosition, DOUBLE MasterRotAngle, DOUBLE SlaveRotAngle, const CVector3d &ControlPoint ) = 0;
	// Kinematic transformation
	// Compute Tool Tip Position
	// unit : BLU
	// right hand side

	virtual INT InverseKinematic( const CVector3d &ToolTipPosition, DOUBLE MasterRotAngle, DOUBLE SlaveRotAngle, CVector3d &ControlPoint ) = 0;
	// Inverse Kinmatic transformation 
	// Compute ControlPoint
	// unit : BLU
	// right hand side

	virtual INT InverseKinematic( CVector3d ToolTipPosition, CVector3d FeedDirection, DOUBLE LastMasterRotAngle, DOUBLE LastSlaveRotAngle, CVector3d &ControlPoint, DOUBLE &MasterRotAngle, DOUBLE &SlaveRotAngle, DOUBLE ToolLength ) = 0;
	// Inverse Kinmatic transformation
	// Given Tool Tip Position and Feed Direction and last rotate angle
	// Compute Control point and RotateAngle
	// unit : BLU
	// right hand side

	virtual INT ComputeRotateAngle( CVector3d FeedDirection, DOUBLE LastMasterRotAngle, DOUBLE LastSlaveRotAngle, DOUBLE &MasterRotAngle, DOUBLE &SlaveRotAngle, EFiveAxSolType type = EST_ShortestDist ) = 0;
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle
	// unit : BLU
	// right hand side

	virtual void GetToolCoordUnderMachineCoord( DOUBLE MasterAngle, DOUBLE SlaveAngle, CMatrix3d &ToolCoord, EToolCoordType Type ) = 0;
	// get tool coord
	// right hand side

	virtual void MStoIJK( DOUBLE MasterAngle, DOUBLE SlaveAngle, CVector3d *RotAxis ) = 0;
	// convert (M,S) to (I,J,K)
	// right hand side

protected:
	INT m_nMechID;
	// five-axis mechanism ID

	DOUBLE m_IUtoBLU_Rotary;
	DOUBLE m_BLUtoIU_Rotary;
	// IU to BLU for rotary axes

	DOUBLE m_ActiveToolLength;
	// tool length;

	INT m_nOrganization;
	// Organization

	CVector3d m_ToolAxisDirection;
	// tool Axis direction

	CVector3d m_ToolAxisRightAngleDirection1;

	CVector3d m_ToolAxisRightAngleDirection2;

	INT m_nToolDirection;
	// 1: x-axis
	// 2: y-axis
	// 3: z-axis

	DOUBLE m_MasterAxisAngleOffset;

	DOUBLE m_SlaveAxisAngleOffset;

	CVector3d m_DirectOfFirstRotAxis;
	// the direction of first rotation axis

	CVector3d m_DirectOfSecondRotAxis;
	// the direction of second rotation axis

	INT m_DirectionOfFRA;
	// the direction of first rotation axis
	// 1:X axis   2:Y axis   3:Z axis

	INT m_DirectionOfSRA;
	// the direction of second rotation axis
	// 1:X axis   2:Y axis   3:Z axis

	INT m_nRDOfFirst;
	// rotation direction of first rotation
	// 1: CCW
	// -1: CW
	INT m_nRDOfSecond;
	// rotation direction of second rotation
	// 1: CCW
	// -1: CW

	DOUBLE m_FStart;
	// the start angle of permissible range for first rotation axis

	DOUBLE m_FEnd;
	// the end angle of permissible range for first rotation axis

	DOUBLE m_SStart;
	// the start angle of permissible range for second rotation axis

	DOUBLE m_SEnd;
	// the end angle of permissible range for second rotation axis

	DOUBLE m_ToolHolderOffset;
	// tool holder offset, BLU

	EIntMode m_DefaultTCPQuatInt;
	// flag of default TCP Interpolation Mode

	ETableCoordSys m_TableCoordSys;
	// basic position of table coordinate system for RTCP

protected:
	void SetMasterRotMatrix( DOUBLE MasterRotAngle, CMatrix3d &MasterRotMatrix );
	// set master rotation matrix
	// point orientation
	// unit : BLU
	// right hand side

	void SetSlaveRotMatrix( DOUBLE SlaveRotAngle, CMatrix3d &SlaveRotMatrix );
	// set slave rotation matrix
	// point orientation
	// unit : BLU
	// right hand side

	INT IJKtoMS( CVector3d FeedDirection, CVector3d ToolDirection, CVector3d DirectOfFirstRotAxis, CVector3d DirectOfSecondRotAxis, DOUBLE LastMasterRotAngle, DOUBLE LastSlaveRotAngle, DOUBLE &MRotAngle1, DOUBLE &SRotAngle1, DOUBLE &MRotAngle2, DOUBLE &SRotAngle2 );
	// i,j,k to rotate angle
	// unit : BLU
	// right hand side

	INT ChooseSolution( DOUBLE MRotAngle1, DOUBLE SRotAngle1, DOUBLE MRotAngle2, DOUBLE SRotAngle2, DOUBLE LastMasterRotAngle, DOUBLE LastSlaveRotAngle, DOUBLE &MasterRotAngle, DOUBLE &SlaveRotAngle, EFiveAxSolType type = EST_ShortestDist );
	// choose solution from (M1,S1) and (M2,S2)
	// unit : BLU
	// right hand side

private:	// common utility function for four Axis and 5 five Axis
	DOUBLE CorrespondingAngle( DOUBLE A, DOUBLE B );
	// return corresponding angle of A such that distance( A, B ) is the smallest
	// unit : BLU

	BOOL SolveQuadEq( DOUBLE A, DOUBLE B, DOUBLE C, DOUBLE &x1, DOUBLE &x2 );
	// return FALSE, if this equation has no real roots
	// return TRUE, if this equation has one or two roots
	// Ax^2 + Bx + C = 0

	DOUBLE Determinant( DOUBLE a11, DOUBLE a12, DOUBLE a21, DOUBLE a22 );
	// determinant

	void Permutation( INT type, INT Permutation[] );
	// permutation

	void ConvertAngleRange( DOUBLE &angle );
	// convert any angle to -PI ~ PI
	// unit : BLU

	void CalculateDirectionOfRotationAxis( DOUBLE DirectOfRotAxis[], DOUBLE RotationOffset[], INT Permutation[] );
	// calculate the direction of rotation axis.

	BOOL IsAtPermissibleRange( DOUBLE &Angle, DOUBLE start, DOUBLE end );
	// is the angle at permissible range
	// Unit : BLU
	// -PI ~ PI
	// right hand side

	INT ChooseShortestDist( DOUBLE MRotAngle1, DOUBLE SRotAngle1, DOUBLE MRotAngle2, DOUBLE SRotAngle2, DOUBLE LastMasterRotAngle, DOUBLE LastSlaveRotAngle, DOUBLE &MasterRotAngle, DOUBLE &SlaveRotAngle );
	// choose shortest distance solution from (M1,S1) and (M2,S2)
	// ruler : Master movement -> Slave movement
	// unit : BLU
	// right hand side

	INT ChooseMasterDirection( DOUBLE MRotAngle1, DOUBLE SRotAngle1, DOUBLE MRotAngle2, DOUBLE SRotAngle2, DOUBLE LastMasterRotAngle, DOUBLE LastSlaveRotAngle, DOUBLE &MasterRotAngle, DOUBLE &SlaveRotAngle, EFiveAxSolType type );
	// choose master rotary axis move toward positive direction solution from (M1,S1) and (M2,S2)
	// unit : BLU
	// right hand side
};

#endif	// FIVEAXISMECHANISM_H_
