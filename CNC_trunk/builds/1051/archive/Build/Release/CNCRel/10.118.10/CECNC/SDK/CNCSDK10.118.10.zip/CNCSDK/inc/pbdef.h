#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#if defined(UNDER_CE)

// SYSINTR_DEVICES is the base for any non-OAL system interrupts
#define SYSINTR_DEVICES     8

// SYSINTR_FIRMWARE is the base for any interrupts defined in the OAL
#define SYSINTR_FIRMWARE    (SYSINTR_DEVICES+8)

#define SYSINTR_MAX_DEVICES 32
#define SYSINTR_MAXIMUM     (SYSINTR_DEVICES+SYSINTR_MAX_DEVICES)

HINSTANCE LoadDriver( LPCWSTR lpszFileName );

BOOL InterruptInitialize(DWORD idInt, HANDLE hEvent, LPVOID pvData, DWORD cbData);
void InterruptDone(DWORD idInt);
void InterruptDisable(DWORD idInt);

int __cdecl _inp(unsigned short);
unsigned short __cdecl _inpw(unsigned short);
unsigned long __cdecl _inpd(unsigned short);

int __cdecl _outp(unsigned short, int);
unsigned short __cdecl _outpw(unsigned short, unsigned short);
unsigned long __cdecl _outpd(unsigned short, unsigned long);

DWORD SetProcPermissions(DWORD);
// This function sets the internal permissions bitmask for the current thread, thereby enabling
// access to the address space of another process.
// The returned DWORD specifies the old permissions.

DWORD GetCurrentPermissions(void);
// This function obtains the kernel's internal thread permissions bitmask for the current thread.
// The returned DWORD specifies the thread permissions.

LPVOID MapPtrToProcess(LPVOID lpv, HANDLE hProc);
// This function maps an unmapped pointer to a process.
// If successful, returns a mapped version of the lpv pointer; otherwise, the return value is NULL.

BOOL VirtualCopy(LPVOID lpvDest, LPVOID lpvSrc, DWORD cbSize, DWORD fdwProtect);
//This function dynamically maps a virtual address to a physical address by creating a new page-table entry. Terminate the mapping by calling VirtualFree.
//TRUE indicates success FALSE indicates failure. To get extended error information, call GetLastError. 

#endif // #if defined(UNDER_CE)

#ifdef __cplusplus
}
#endif 

