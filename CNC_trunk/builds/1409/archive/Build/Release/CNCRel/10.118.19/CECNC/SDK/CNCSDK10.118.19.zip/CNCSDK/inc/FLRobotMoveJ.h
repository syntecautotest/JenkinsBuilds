#if !defined(_CFLROBOTMOVEJ_H____INCLUDED_)
#define _CFLROBOTMOVEJ_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFLRobotMoveJ : public IRobotFeedLimit
{
public:
	CFLRobotMoveJ( void );
	// constructor

	~CFLRobotMoveJ( void );
	// destructor

public:
	void putMotionNode( TRobotMRP *pRobotMRP );
	// put motion node to feedlimit module

	void onMotionParamChanged( const TMotParamTable &MotParamTable );
	// on motion parameters changed

	void calcLength( TRobotMRP *pRobotMRP );
	// calculate block length.

	BOOL processMaxOverride( TRobotMRP *pRobotMRP, LONG nArg[ 2 ] );
	// process maximum override

public:
	void setRobotChannelCount( INT nNRobotChannel );
	// set number of robot axis channel

	void setChannelCount( INT nChannelCount );
	// set number of axis channel, including robot and external axis

protected:
	void calcMotionFeature( TRobotMRP *pRobotMRP );
	// calculate block motion feature.

	void estimateElapseTime( TRobotMRP *pRobotMRP );
	// estimate elapse time of pRobotMRP

private:
	void putMaxAxisFeedrate( const double AxFmax[] );
	// put maximum axis feedrate in IU / us

	void putMaxAxisAcceleration( const double AxAmax[] );
	// put maximum axis acceleration in IU / us ^ 2

	void putMaxAxisJerk( const double AxJmax[] );
	// put maximum axis jerk

private:
	void clampFeedrateByAxisLimit( TRobotMRP *pRobotMRP );
	// clamp feedrate by the max speed of each axis

	void clampBlockAccByAxisAcc( TRobotMRP *pRobotMRP );
	// clamp block acceleration by maximum axis acceleration

	void clampBlockJerk( TRobotMRP *pRobotMRP );
	// clamp block jerk by maximum jerk and maximum axis jerk

private:
	DOUBLE calcEqFeedrateByFJ( TRobotMRP *pRobotMRP );
	// calculate target feedrate according to FJ for robot joint

	DOUBLE calcEqFeedrateByFEJ( TRobotMRP *pRobotMRP );
	// calculate target feedrate according to FEJ for additional axes

protected:
	double m_MaxOverride;
	// max override

	TRobotMRP *m_pRobotMRP;
	// motion node

	INT m_nRobotChannelCount;
	// robot joint channel count

	INT m_nChannelCount;
	// channel count, including robot and external axis

	int m_nLimitingJoint;
	// the number of joint who clamps the Fclamp

	double m_AxFmax[ NUMOF_AXIS ];
	double m_AxAmax[ NUMOF_AXIS ];
	double m_AxJmax[ NUMOF_AXIS ];
	// Feedrate, Acceleration, Jerk for each axis
};
#endif // !defined(_CFLROBOTMOVEJ_H____INCLUDED_)
