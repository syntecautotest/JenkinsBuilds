// IntervalChecker.h: interface for the CIntervalChecker class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTERVALCHECKER_H__INCLUDED_)
#define AFX_INTERVALCHECKER_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum ECheckResult {
	ECR_Success = 0,
	ECR_Fail = 1,
	ECR_ExceedMax = 2,
	ECR_ExceedMin = 3,
};

class CIntervalChecker
{
public:
	CIntervalChecker( INT nStackLen, INT nValueMax, INT nValueMin );
	// constructs

	~CIntervalChecker( void );
	// destructs

	void RemoveAllInterval( void );
	// remove all intervals

	ECheckResult IsInInterval( LONG nNo );
	// check if number is inside intervals

	ECheckResult IsOutInterval( LONG nNo, LONG &nOverlapNo );
	// check if number is outside intervals

	ECheckResult IsOutInterval( LONG nStart, LONG nEnd, LONG &nOverlapStart, LONG &nOverlapEnd );
	// check if a interval is outside intervals

	void AddInterval( INT nStart, INT nEnd );
	// get last checking result

private:
	struct TInterval {
		LONG nStart;
		LONG nEnd;
	};

private:
	TInterval *m_pStack;
	// intervals

	LONG m_nMax;
	// maximum value of all intervals

	LONG m_nMin;
	// minimum value of all intervals

	INT m_nStackLegnth;
	// stack length

	INT m_nStackIndex;
	// stack index
};

#endif // !defined(AFX_INTERVALCHECKER_H__INCLUDED_)
