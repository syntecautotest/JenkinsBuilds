// ITrajectoryInt.h: interface for the ITrajectoryInt class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ITRAJECTORYINT_H__E7D8D513_1984_11D3_841D_0000E86B4150__INCLUDED_)
#define AFX_ITRAJECTORYINT_H__E7D8D513_1984_11D3_841D_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ITrajectoryInt
{
public:
	struct TCtlBlk {};

public:
	virtual ~ITrajectoryInt( void ) {}
	// destructor

	virtual void startBlock( TCtlBlk *block, int fBackward ) = 0;
	// issue control block to start excute
	// block		pointer to control block
	// fBackward	flag fto indicate backward interpolation

	virtual void getSegment( double time, double segment[] ) = 0;
	// calculate next move segment
	// time		current time base
	// segment	pointer to buffer for store movement
};

#endif // !defined(AFX_ITRAJECTORYINT_H__E7D8D513_1984_11D3_841D_0000E86B4150__INCLUDED_)
