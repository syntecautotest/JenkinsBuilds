#if !defined(AFX__IPHYSICALDRIVER_H__D8CFF4BF_81AC_4847_8853_465417944DC6__INCLUDED_)
#define AFX__IPHYSICALDRIVER_H__D8CFF4BF_81AC_4847_8853_465417944DC6__INCLUDED_

enum EPhyChType {
	EPCT_Svo,
	EPCT_DIO,
	EPCT_AIO,
	EPCT_DA,
};

class IPhysicalDriver
{
public:
	virtual ~IPhysicalDriver( void ) {};
	// destructor

	virtual void* CNCAPI GetPhyChannel( ECommType nCommType, EPhyChType nPhyChType, INT nPortID, INT nStation = 0, INT nSlot = 0 ) = 0;
	// To get the control of indicated physical channel.
};
#endif // AFX__IPHYSICALDRIVER_H__D8CFF4BF_81AC_4847_8853_465417944DC6__INCLUDED_
