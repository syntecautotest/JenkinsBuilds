#if !defined(AFX_ISERIALPARAMCHANNEL_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_)
#define AFX_ISERIALPARAMCHANNEL_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISerialParamChannel
{
public:
	virtual ~ISerialParamChannel( void ) {}
	// destructor

	virtual BOOL CNCAPI CNCDeviceIoControl( ULONG dwIoControlCode, void *lpArgBuf, UINT nArgBufSize ) = 0;
	// Device IO control, OCDevice interface
};

#endif // !defined(AFX_ISERIALPARAMCHANNEL_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_)
