// ISerialDevInfo.h: interface for the ISerialDevInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISERIALDEVINFO_H__E55CAC42_1547_4512_974E_0EA52B5E0D73__INCLUDED_)
#define AFX_ISERIALDEVINFO_H__E55CAC42_1547_4512_974E_0EA52B5E0D73__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISerialDevInfo
{
public:
	// destruction
	virtual ~ISerialDevInfo( void ) {};

	// get device info string data
	virtual BOOL GetDeviceInfo( EDeviceInfo eInfoType, CHAR *pInfoStr, LONG nSize ) = 0;
};
#endif // !defined(AFX_ISERIALDEVINFO_H__E55CAC42_1547_4512_974E_0EA52B5E0D73__INCLUDED_)
