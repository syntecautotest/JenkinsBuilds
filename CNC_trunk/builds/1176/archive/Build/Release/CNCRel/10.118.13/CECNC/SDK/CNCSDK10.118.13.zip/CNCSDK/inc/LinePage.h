// LinePage.h: interface for the CLinePage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINEPAGE_H__90F36328_FC27_4F36_9D4F_3176213CA2FC__INCLUDED_)
#define AFX_LINEPAGE_H__90F36328_FC27_4F36_9D4F_3176213CA2FC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ILineStore.h"

class CLinePage : public ILineStore
{
public:		// constructor and destructor
	CLinePage( long nPageTableLimit );
	CLinePage( long nPageTableLimit, long nInitPageTable );
	virtual ~CLinePage();

public:		// public function
	long getDataCount( void );
	// get number of line, which has data inside.

public:		// implement ILineStore interface
	int CNCAPI readLine( long lineno, void *buffer, int count );
	// return the data size copied, when count is 0,
	// then return the actual size of specified line

	int CNCAPI getLineInfo( long lineno, void **ppData );
	// to get specified line data buffer location and data size

	long CNCAPI getLineCount( void );
	// return the total line count

	void CNCAPI clearAll(void);
	// clear all content

	BOOL CNCAPI insert( long lineno, void *data, int size );
	// insert data before specified line number.
	// return TRUE, when successful, others, return FALSE.

	BOOL CNCAPI append( void *data, int size );
	// append specified data at the tail of whole data.

	BOOL CNCAPI deleteLine( long lineno );
	// delete specified line, this function will all behind line move
	// forward one line

	BOOL CNCAPI put( long lineno, void *data, int size );
	// put specified data into specified line

	BOOL CNCAPI erase( long lineno );
	// erase specified line data, this function just rease specified
	// line data, and no move behind line forward.

private:	// private helper function

	void expandPageTable( long lineno );
	// expand page table to have capacity to store specified line

private:	// private implement function
	enum EMaxBounds {
		SIZE_InitPageTable		= 64,
		MIN_PageTableInc		= 1024,
		MIN_DataBufferInc		= 16
	};
	// maximum bound constants

	struct TDataRecord {
		int		size;		// data size
		int		bsize;		// data buffer size
		char	lpData[1];	// node data header
	};

	struct TNode {
		TDataRecord	*pDataRecord;		// pointer to data buffer
	};

	TNode *m_PageTable;
	// page table

	long m_nPageTableLimit;
	// the page table size limit

	long m_TableSize;
	// page table size

	long m_linecount;
	// current data count in this page

	long m_datacount;
	// real line count, which has data inside.
};

#endif // !defined(AFX_LINEPAGE_H__90F36328_FC27_4F36_9D4F_3176213CA2FC__INCLUDED_)
