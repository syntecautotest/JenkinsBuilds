#if !defined(_OPALARMDEF_H__INCLUDED_)
#define _OPALARMDEF_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ALMID_OpNoDDAInterrupt						1
#define ALMID_OpParameterAccessFailure				2
#define ALMID_OpRegistryAccessFailure				3
#define ALMID_OpIOTransmitFailure					5
#define ALMID_OpFramCRCFailure						6
#define ALMID_OpLowMemory1M							7
#define ALMID_OpLowMemory100K						8
#define ALMID_OpInterpolationLossCountExceed		9
#define ALMID_OpModeGroupSetError					10
#define ALMID_OpHaltedPtOffsetError					11
#define ALMID_OpCFCardNumErr						12
#define ALMID_OpModelAndVerError					13
#define ALMID_OpIOOutputOverload					15
#define ALMID_OpLineTableSetError					16
#define ALMID_OpMPGParamSetError					17
#define ALMID_OpServoChannelIDErr					18
#define ALMID_OpCannotChangeG70G71					19
#define ALMID_OpMCodeSettingConflict				20
#define ALMID_OpRegistryLastData					21
#define ALMID_OpRegistryNewData						22
#define ALMID_OpRegistryPowerBreak					23
#define ALMID_OpRegistryWriteFail					24
#define ALMID_OpRegistryAccErr						25
#define ALMID_OpRegistryFaultErr					26
#define ALMID_OpNoSetAnyCoordActive					27
#define ALMID_OpChangeActiveCoordInRun				28
#define ALMID_OpOverSysCNCAxesNumber				29
#define ALMID_OpInMacroDebug						30
#define ALMID_OpGANTRYFuncNotEnabled				31
#define ALMID_OpKinematicsConflict					32
// Alarm ID = 33 ~ 40 is reserved
#define ALMID_OpECamLoadFileError					41
#define ALMID_OpECamBadXmlStyle						42
#define ALMID_OpECamTooManyGroups					43
#define ALMID_OpECamTooManyCurves					44
#define ALMID_OpECamUnreachableCurve				45
#define ALMID_OpECamAxisDoseNotExist				46
#define ALMID_OpECamIllegalRReg						47
#define ALMID_OpECamReloadFail						48
// Alarm ID = 49 is reserved
#define ALMID_OpSriErr								50
#define ALMID_OpM3IOCommErr							51
#define ALMID_OpM3IOErr								52
#define ALMID_OpSerialCommFailure					53
#define ALMID_OpMessageTimeOut						55
#define ALMID_OpNCRunIsDisabled						56
#define ALMID_OpManualCoordAndRTCPInhibit			57
#define ALMID_OpSystemInBurnInMode					58
#define ALMID_OpLoadMCIFileFailure					59
#define ALMID_OpM3DeviceSettingError				60
#define ALMID_OpExternalIODeviceErr					61
#define ALMID_OpIoMapXmlError						62
#define ALMID_OpIoMapSettingConflict				63
#define ALMID_OpIoMapSettingChanged					64
#define ALMID_OpLaserErr							65
#define ALMID_OpMultiAxisInCruiseCtrl				66
#define ALMID_OpRadioFreqDevErr						67
#define ALMID_OpNotSupportM3IOHardware				68
#define ALMID_OpExceedMaxNumOfSlave					69
#define ALMID_OpCtrlTypeNotSupport					70
#define ALMID_OpSvoPowerOff							71
#define ALMID_OpPowerOffAxisReturn					72
#define ALMID_OpToolCompensationModeChanged			73
#define ALMID_OpToolCompensationCleared				74
#define ALMID_OpRadioFreqKeyLost					75
#define ALMID_OpRadioFreqCRCError					76
#define ALMID_OpSerialParamAuthorityChanged			77
#define ALMID_OpUnexpectedError						78
#define ALMID_OpSpecConnectedDevNoExist				79
#define ALMID_OpDriverInitPreloadTimeout			80

#endif // !defined(_OPALARMDEF_H__INCLUDED_)
