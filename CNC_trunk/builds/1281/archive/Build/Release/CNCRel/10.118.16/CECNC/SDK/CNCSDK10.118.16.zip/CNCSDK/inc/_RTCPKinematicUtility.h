#if !defined(_RTCPKINEMATICUTILITY_H__INCLUDED_)
#define _RTCPKINEMATICUTILITY_H__INCLUDED_

#include "nstdlib.h"

// from Utility: mathematical tools
#include "ZMath.h"
#include "Point2d.h"
#include "Vector2d.h"
#include "Matrix2d.h"
#include "Point3d.h"
#include "Vector3d.h"
#include "Matrix3d.h"
#include "Tuple3d.h"
#include "MatrixN.h"
#include "QuickMatrixN.h"
#include "Quaternion.h"
#include "AxFrame.h"
#include "PolynomialRootSolver.h"

// from Utility
#include "AlarmDef.h"
#include "CommonStruct.h"

// from Operation
#include "_cncapi.h"

// from WinPal
#include "RTMutex.h"

// definition
#include "MotionPlanDef.h"
#include "RobotMotionDef.h"
#include "OpenCncDef.h"
#include "KinematicAlarmDef.h"
#include "KinematicsDef.h"
#include "KinematicsTypeDef.h"

// interface
#include "IKinematic.h"
#include "IRTCPMechanism.h"
#include "IRTCPKinematic.h"

// RTCP mechanism
#include "FiveAxisMechanism.h"
#include "FourAxisMechanism.h"
#include "SpindleTiltingType.h"
#include "TableTiltingType.h"
#include "MixTiltingType.h"
#include "SingleSpindleTiltingType.h"
#include "SingleTableTiltingType.h"

// RTCP Kinematic
#include "FiveAxis.h"
#include "FourAxis.h"
#include "RTCPManager.h"

#endif // !defined(_RTCPKINEMATICUTILITY_H__INCLUDED_)
