// HighPerformanceTimer.h: interface for the CHighPerformanceTimer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HighPerformanceTimer_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_)
#define AFX_HighPerformanceTimer_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"
#define AVGTIMES 100

class CHighPerformanceTimer
{
public:
	CHighPerformanceTimer( DWORD multiplier = 1e6 );
	// Constructs

	virtual ~CHighPerformanceTimer();
	// destructor

	void start();
	void start( LARGE_INTEGER nStart );
	// timer start

	double stop( void );
	// timer stop, return execute time

	double stop_start( void );
	// timer stop and start again, return execute time

	double peek( void );
	// peek timer

	LONGLONG now( void );
	// now

	long getMaximum( void );
	// get maximun timer value

	long getAverage( void );
	// get average timer value

	LARGE_INTEGER m_Start;
	LARGE_INTEGER m_Frequency;

private:
	double m_Maximum;
	double m_Average;

	BOOL m_InService;
	DWORD m_multiplier;			// multiplier for duration (1.0:sec; 1e3:ms; 1e6:us...)
	double m_overhead;		// overhead of duration computation
};

#endif // !defined(AFX_HighPerformanceTimer_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_)
