#if !defined(_KinematicsDef_H____INCLUDED_)
#define _KinematicsDef_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Tolreance for five axis kinematics transform choose solution
#define FIVEAXIS_SOL_TOL			( CZMath::EPSILON_double * 1.0e14 )
#define REACHABLE_EPSILON			( 1.0e-9 )

enum EFiveAxisSetting{
	FA_BASE = 0,
									// Pr--01
	FA_DOfTool = 2,					// Pr--02
	FA_RA,							// Pr--03
	FA_RB,							// Pr--04
	FA_DOfFirst,					// Pr--05
	FA_DOfSecond,					// Pr--06
	FA_RDOfFirst,					// Pr--07
	FA_RDOfSecond,					// Pr--08
	FA_FStartAngle,					// Pr--09
	FA_FEndAngle,					// Pr--10
	FA_SStartAngle,					// Pr--11
	FA_SEndAngle,					// Pr--12
	FA_ToolHolderOffset,			// Pr--13
									// Pr3014

	FA_FirstRotationOffsetA = 15,	// Pr--15
	FA_FirstRotationOffsetB,		// Pr--16
	FA_FirstRotationOffsetC,		// Pr--17
	FA_SecondRotationOffsetA,		// Pr--18
	FA_SecondRotationOffsetB,		// Pr--19
	FA_SecondRotationOffsetC,		// Pr--20

	FA_ToolHolderToSlaveX = 21,		// Pr--21
	FA_ToolHolderToSlaveY,			// Pr--22
	FA_ToolHolderToSlaveZ,			// Pr--23
	FA_SlaveToMasterX,				// Pr--24
	FA_SlaveToMasterY,				// Pr--25
	FA_SlaveToMasterZ,				// Pr--26

	FA_MasterToSlaveX = 31,			// Pr--31
	FA_MasterToSlaveY,				// Pr--32
	FA_MasterToSlaveZ,				// Pr--33
	FA_MachineToMasterX,			// Pr--34
	FA_MachineToMasterY,			// Pr--35
	FA_MachineToMasterZ,			// Pr--36

	FA_ToolHolderToMasterX = 41,	// Pr--41
	FA_ToolHolderToMasterY,			// Pr--42
	FA_ToolHolderToMasterZ,			// Pr--43
	FA_MachineToSlaveX,				// Pr--44
	FA_MachineToSlaveY,				// Pr--45
	FA_MachineToSlaveZ,				// Pr--46
									// Pr3051 ~ Pr3053
	FA_TCPIntMode = 54,				// Pr--54
	FA_TCPTableCrdSys,				// Pr--55
	FA_FINAL,
};

static const LONG RTCPParamBase[ SIZE_RTCPMechStore ] = { 3001, 3101, 5501, 5601 };

#endif //  !defined(_KinematicsDef_H____INCLUDED_)
