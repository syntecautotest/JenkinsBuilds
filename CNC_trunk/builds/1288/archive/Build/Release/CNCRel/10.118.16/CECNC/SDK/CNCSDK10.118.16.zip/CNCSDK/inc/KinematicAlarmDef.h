#if !defined(KINEMATICALARMDEF__INCLUDED_)
#define KINEMATICALARMDEF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// for RTCP kinematic transform
#define ALMID_CrdKinematicTransformBase				( 150 )
#define ALMID_CrdMasterRotAngleError				( 151 )
#define ALMID_CrdSlaveRotAngleError					( 152 )
#define ALMID_CrdNoSolutionForThisDirection			( 153 )
#define ALMID_CrdNoFiveAxisFunction					( 154 )
#define ALMID_CrdFiveAxisToolSettingError			( 155 )
#define ALMID_CrdFiveAxisAxisSettingError			( 156 )
#define ALMID_CrdFiveAxisToolandAxisSettingError	( 157 )
#define ALMID_CrdMSRotAngleInhibitInG43005Mode		( 158 )
#define ALMID_CrdInvalidToolVector					( 159 )
#define ALMID_CrdChangeMechInhibitInRTCPMode		( 160 )
#define ALMID_CrdNotEnableSelectMech				( 161 )
#define ALMID_CrdInvalidSettingOf4AxisMech			( 162 )

// for general kinematics transform
#define ALMID_CrdKinematicsAxisSettingError			( 250 )
#define ALMID_CrdRotDirOfRotAxNonSetting			( 251 )
#define ALMID_CrdGeneralXYTxIKFailed				( 252 )
#define ALMID_CrdInvalidParallelKinematicsConfig	( 253 )
#define ALMID_CrdParallelKinematicsFKFailed			( 254 )
#define ALMID_CrdParallelKinematicsIKFailed			( 255 )
#define ALMID_CrdParallelKinematicsFKSingular		( 256 )

#endif // !defined(KINEMATICALARMDEF__INCLUDED_)
