// MpHoming.h: interface for the CMpHoming class.
//
//////////////////////////////////////////////////////////////////////

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define TIMER_WAITSTOP		1000000L

class CMpHoming : public CHomeSearchCore
{
private:
	BOOL IsOnHomeDog( void ) { return FALSE; }
	// query whether current is above home dog
	// Use threads: <= interpolation

public:
	CMpHoming( IHomeSearchInfo *pHomeSearchInfo );
	// constructor

	~CMpHoming();
	// destructor

	void ConfigHoming( double Vmax, double Amax, double Jmax, BOOL bIsLinear, double Pitch );
	// configure skip travel

	void GetDisplacement( double elapse, double *Disp );
	// get displacement, unit: BLU
	// Use threads: interpolation.

	double GetRemainDisp( void );
	// get remain distance, unit: BLU
	// Use threads: interpolation.

	void ProcessHoming( double FirstDisp, double SecondDisp, double FisrtSpeed, double SecondSpeed,  double Stopdown );
	// process homing, unit: BLU, BLU/us

	void Abort( void );
	// abort

	void Reset( void );
	// clear internal state suddenly, this function is
	// usually used for emergency stop.
	// Use threads: <= house keeping

	BOOL IsIdle( void );
	// query whether it is idle

	BOOL TrajPlanTick( void );
	// trajectory plan tick

	BOOL IsHomeFound( void );
	// ishome found

private:
	double m_Pitch;
	// pitch

	CTrajectoryNormal *m_objTrajNormal;
	// the trajectory planning helper object

	CInterpolator *m_pInterpolator;
	// pointer to associated trajectory interpolator interface

	CRTMutex m_cs;
	// mutex for object state consistent

	enum EHOMESTATE {
		STATE_Idle,
		STATE_Start,
		STATE_FirstTravel,
		STATE_SecondTravel,
		STATE_FinalTravel,
		STATE_WaitIdle
	} m_State;

	double m_Vmax;
	// get motor V max, default using servo axis setting, in BLU/us

	double m_Amax;
	// maximum axis acceleration, in BLU/(us^2)

	double m_Jmax;
	// get motor J max, default using servo axis setting, in BLU/(us^3)

	double m_FirstMovement;
	// first movement, unit: BLU

	double m_SecondMovement;
	// second movement, unit: BLU

	double m_FirstFeedrate;
	// first feedrate, unit: BLU/us

	double m_SecondFeedrate;
	// second feedrate, unit: BLU/us

	double m_StartServoPosition;
	// start servo position, unit: BLU

	double m_Stopdown;
	// stop down distance, in BLU

	long m_WaitStopTimer;
	// wait stop timer, unit: us

	BOOL m_fHomeFound;
	// falg of home found

	BOOL m_bIsLinear;
	// is axis type linear or rotary

	double m_CommandDisplacement;
	// total command displacement, in BLU

	double m_CommandAbsDisp;
	// total command abs displacement, always > 0 in BLU

	double m_RemainDistance;
	// total remain distance, in BLU

private:
	BOOL planMovement( DOUBLE displacement, DOUBLE V0, DOUBLE Vref, DOUBLE Vc );
	// issue motion command.
	// displacement		movement displacement, in BLU
	// feedrate			movement feedrate, in BLU/us

	void WriteToInterpolator( double displacement, TPVTSheet &sheet );
	// write to interpolator, unit: BLU

	BOOL DoHoming( void );
	// home search finite-state machine
	// Use threads: interpolation

	double CalculateOverrun( void );
	// calculate overrun, unit: BLU

	BOOL ProcessStopDown( DOUBLE overrun, DOUBLE velocity );
	// process stop down, unit: BLU, BLU/us
};
