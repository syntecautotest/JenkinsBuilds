#if !defined(KINEMATICDATADUMP_H__INCLUDED_)
#define KINEMATICDATADUMP_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CKinematicDataDump
{
public:
	static CKinematicDataDump *getKDataLogger( VOID );
	// get Kinematic Data Dump helper object

	static VOID Deinit( VOID );
	// deinitial, delete Kinematic Data Dump helper object

	VOID Dump( LONG nType, VOID *pData );
	// dump event kinematic data

private:
	CKinematicDataDump( VOID );
	// constructor

	~CKinematicDataDump( VOID );
	// destructor

	static CKinematicDataDump *m_pKDataLogger;
	// Kinematic Data Dump instance.

	static CRTMutex m_cs;
	// mutex for object state consistent
};

#endif// !defined(KINEMATICDATADUMP_H__INCLUDED_)