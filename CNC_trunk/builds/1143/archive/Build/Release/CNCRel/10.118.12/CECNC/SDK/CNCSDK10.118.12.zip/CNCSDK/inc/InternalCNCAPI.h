//
//	InternalCNCAPI.H
//
//	Open CNC Application Internal Public Interface
//

#if !defined(_InternalCNCAPI_INCLUDED_)
#define _InternalCNCAPI_INCLUDED_

#include "nstdlib.h"
#include "CommonStruct.h"

//------------------------------------------------------------
// processor provider interface

#ifndef TTPREPDXB_TYPEDEF_
#define TTPREPDXB_TYPEDEF_

class IParseContext {
public:
	virtual ~IParseContext( void ) {}
	// destructor

	virtual void CNCAPI PutGlobalVariable( int no, TOcVariant *value ) = 0;
	// assign global variable value of parser associated channel

	virtual BOOL CNCAPI GetGlobalVariable( int no, TOcVariant *value ) = 0;
	// get global variable value of parser associated channel
	// return TRUE when variable exist, else return FALSE
};

struct TPrepDXB {
	long InLineCount;		// [in] total line count of input data
	long InFirstLineNo;		// [in] the first line number of input data
	long InDataSize;		// [in] input data size, in bytes.
	char *pInData;			// [in] pointer to input data buffer
	long OutDataSize;		// [out] output data size, in bytes
	char *pOutData;			// [out] pointer to output data buffer
	long ErrorLineNo;		// [out] error line number
	long ErrorReason;		// [out] error reason code, 0(no error)
	BOOL bHandled;			// [out] TRUE(handled),FALSE(bypass)
	IParseContext *pContext;// [in] parser context interface pointer.
	long nMaxInDataSize;	// [in] maxmum input data size in bytes.
	BOOL bIsMacro;			// [out] TRUE(Macro), FALSE(IsoProgram)
	char reserved[4];		// reserved for future extension
};
// preprocessor data exchange block

typedef void (PFNCNCAPI *PFNPREPROCESSOR)( TPrepDXB *pDXB );
// type definition for preprocessor callback

#endif // TTPREPDXB_TYPEDEF_

extern "C" {
void CNCAPI RegPreprocessor( PFNPREPROCESSOR pfnCallBack, DWORD *pdwCookie );
// pfnProprocessor	pointer to preprocessor callback function
// pdwCookie		pointer to buffer for store result cookie

void CNCAPI UnregPreprocessor( DWORD dwCookie );
// unregistry preprocessor associated with specified cookie.
};

class CXMLDatabase;
extern CXMLDatabase *theXmlDb;
// System XML interface object

extern PFNPREPROCESSOR theExternalPreprocessor;

#define ENABLE_MacroExecuterThread	1
#define PROMOTE_MacroExecuter		1
#define PROMOTE_NcLoader			1

#endif // InternalCNCAPI
