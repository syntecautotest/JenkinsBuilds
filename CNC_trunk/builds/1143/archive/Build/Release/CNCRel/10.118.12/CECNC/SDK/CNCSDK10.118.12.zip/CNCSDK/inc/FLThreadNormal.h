#if !defined(_FLTHREADNORMAL_H____INCLUDED_)
#define _FLTHREADNORMAL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// to calculate middle among three elements
#define MaxAmong(a,b,c)				( ((a)>(b)) ? (((a)>(c)) ?(a) : (c)) : (((b)>(c)) ? (b) : (c)) )
#define MaxIndex(a,b,c,a1,b1,c1)	( ((a)>(b)) ? (((a)>(c)) ?(a1) : (c1)) : (((b)>(c)) ? (b1) : (c1)) )

class CFLThreadNormal : public CFeedLimit
{
public:

	enum EThreadType {
		HighOrExtThread = 2
	};
	// high or extreme speed threading type

	CFLThreadNormal( CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	~CFLThreadNormal( void );
	// destructor

	BOOL IsEmpty( void );
	// query whether the pipe is empty

	void PutLANodeToCurvPart( TLANode *pNode );
	// put look ahead node to curvature part of feed limit module

	void putMaxRapidFeedrate( const double Fmax[] );
	// put G00 maximum axis feedrate in IU / us

	void putMaxRapidAcc( const double Amax[] );
	// put G00 maximum axis acceleration in IU / us ^ 2

	void CalcBlockLength( TLANode *pNode, CArcFeature &af );
	// calculate block length.

protected:
	void FlushAllQueue( void );
	// flush queued nodes of feed limit module

	TLANode *ReversePeek( void );
	// peek the last node in feed limit module

	void CalcBlockMotionFeature( TLANode *pNode, CArcFeature &af );
	// calculate block motion feature.

	void CalcCornerFeature( TLANode *pNode, double &eLastVc );
	// to calculate inter-block feature

private:
	void ProcessThreadCorner( TLANode *pNode, TLANode *pLNode );
	// process threading corner

	void ClampBlockAcc( TLANode *pNode );
	// clamp block acceleration by maximum axis acceleration

	void ClampBlockFeedrateByProgramFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum programming feedrate

	void ClampBlockFeedrateByCompoundFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum compound feedrate

	void ClampBlockFeedrateByAxisFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum axis cutting feedrate

	double m_RapidFmax[NUMOF_AXIS];
	// G00 maximum axis feedrate in IU / us

	double m_RapidAmax[NUMOF_AXIS];
	// G00 maximum axis acceleration in IU / us ^ 2
};

#endif // !defined(_FLTHREADNORMAL_H____INCLUDED_)
