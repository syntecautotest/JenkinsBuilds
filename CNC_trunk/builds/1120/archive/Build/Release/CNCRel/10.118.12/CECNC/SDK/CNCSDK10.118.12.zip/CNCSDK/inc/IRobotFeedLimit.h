#if !defined(_IROBOTFEEDLIMIT_H____INCLUDED_)
#define _IROBOTFEEDLIMIT_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IRobotFeedLimit
{
public:
	virtual ~IRobotFeedLimit( void ) {}
	// destructor

public:
	virtual void putMotionNode( TLANode *pNode ) = 0;
	// put motion node to feedlimit module

	virtual void onMotionParamChanged( const TMotParamTable &MotParamTable ) = 0;
	// on motion parameters changed

	virtual void calcLength( TLANode *pNode ) = 0;
	// calculate block length.

	virtual BOOL processMaxOverride( TLANode *pNode, LONG nArg[ 2 ] ) = 0;
	// process maximmum overridee
};
#endif // !defined(_IROBOTFEEDLIMIT_H____INCLUDED_)
