// ISriComPort.h: interface for the ISriComPort class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ISRICOMPORT_H____INCLUDED_)
#define _ISRICOMPORT_H____INCLUDED_

class ISriComPort
{
public:
	virtual BOOL writeData( int nIdx, WORD *pData, WORD Size ) = 0;
	// write data for hardware scan

	virtual BOOL readData( int nIdx, WORD *pData, WORD Size ) = 0;
	// read data for hardware scan

	virtual BOOL writeData( BYTE *pData, WORD Size ) = 0;
	// write data for software communication

	virtual BOOL readData( BYTE *pData, WORD &Size ) = 0;
	// read data for software communication

public:
	virtual void setCommProperty( INT nControlMode, BYTE ProtocolType, DWORD Baudrate, DWORD ScanTime, DWORD Timeout ) = 0;
	// set communication property for each communication

	virtual void setRegionProperty( INT nRegionIdx, WORD Addr, WORD Size, WORD Station, INT nRW, INT nMaxError, INT nRetry ) = 0;
	// set region property for each region, it is used for hard scan

	virtual BOOL SwitchSoftModeRequest( BOOL bEnable, INT nTimeout = 0 ) = 0;
	// switch to soft communication mode request

	virtual BOOL IsInSoftMode( void ) = 0;
	// query whether it is in soft mode

public:
	virtual DWORD getRealScanTime( void ) = 0;
	// get real scan time for each communication

	virtual DWORD readTimeout( void ) = 0;
	// query whether it is timeout by bit (region1~32) for each communication

	virtual DWORD readCRCError( void ) = 0;
	// query whether it is CRC error by bit (region1~32) for each communication

	virtual DWORD readByteError( void ) = 0;
	// query whether it is byte error by bit (region1~32) for each communication

	virtual WORD readErrorCode( INT nRegionIdx ) = 0;
	// read error code for each region

	virtual DWORD readErrorCount( INT nRegionIdx ) = 0;
	// read error count for each region

	virtual DWORD readTimeoutCount( INT nRegionIdx ) = 0;
	// read timeout count for each region

	virtual DWORD readCRCErrorCount( INT nRegionIdx ) = 0;
	// read CRC error count for each region

	virtual DWORD readByteErrorCount( INT nRegionIdx ) = 0;
	// read byte count error count for each region
};
#endif //(_ISRICOMPORT_H____INCLUDED_)