// BitFilter.h: interface for the CBitFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BITFILTER_H__300FF148_002E_11D3_B6BF_000000000000__INCLUDED_)
#define AFX_BITFILTER_H__300FF148_002E_11D3_B6BF_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBitFilter  
{
public:
	enum EFilterMethod {
		FM_AnyTwo = 0,
		FM_1Repeat = 1,
		FM_3Repeat = 2,
		FM_5Repeat = 3
	};
	// constant for filter method selection

public:
	CBitFilter( INT nNumOfChannel );
	// constructs bit digital filter

	~CBitFilter( void );
	// destructs this object

	void setFilterMethod( INT method );
	// set filter method

	void filter( INT channel, ULONG &data );
	// do filter

	void filter( INT channel, WORD &data );
	// do filter

	void filter( INT channel, BYTE &data );
	// do filter

private:
	void RepeatFilter( INT nRepeat, ULONG *pPipe, ULONG &nData );
	// filter that require repeated times to pass

private:
	enum EMaxBound {
		FILTERLEVEL_1Repeat	= 1,
		FILTERLEVEL_3Repeat	= 3,
		FILTERLEVEL_5Repeat	= 5,
		MAX_FilterLength,
	};
	// constant for maximum bound

	enum EChannelState {
		STATE_NotYetUsed,
		STATE_Used
	};
	// constants for channel state

	INT m_nMethod;
	// current selected filter method

	INT m_nNumOfChannel;
	// the number of channel

	INT *m_ChannelState;
	// the channel state

	typedef ULONG TFilterChannelPipe[ MAX_FilterLength ];
	// type definition for filter channel data

	TFilterChannelPipe *m_DataPipe;
	// data pipe to store past bit state used for digital filter,
	// the zero index of channel buffer is result output value

	void resetAllChannelState( void );
	// reset all channel state
};

#endif // !defined(AFX_BITFILTER_H__300FF148_002E_11D3_B6BF_000000000000__INCLUDED_)
