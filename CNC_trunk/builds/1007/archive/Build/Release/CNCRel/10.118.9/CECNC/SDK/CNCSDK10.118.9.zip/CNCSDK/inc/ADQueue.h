#if !defined(AFX_ADQUEUE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_)
#define AFX_ADQUEUE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_

struct TADNode
{
	double Displacement[NUMOF_AXIS];
	double AxWeight[NUMOF_AXIS];
	double Length;
	double TwoLengthAcc;
	double TangentAcc;
	double VelLimit;
	double VelLimitSquare;
	double DecTargetVelSquare;
	BOOL IsAcc;						// flag for acceleration or deceleration in backward elimination
};

class CADQueue
{
public:
	CADQueue( int size );
	// constructor

	~CADQueue( void );
	// destructor

	BOOL IsEmpty( void );
	// query whether queue is empty

	BOOL IsFull( void );
	// query whether queue is full

	int GetCount( void );
	// return the number of node inside queue

	TADNode *Add( void );
	// add node into queue tail

	TADNode *Remove( void );
	// remove and return head node

	TADNode *Peek( int index );
	// to peek a node with specified index relative to queue head, index is 0 for head node.

	TADNode *rPeek( int index );
	// to peek a node with speciifed index relative to queue tail, index is 0 for tail node.

	int GetTarget( void );
	// return the number of node which already decide deceleration target velocity

	void PlusTarget( void );
	// target ++

	void Reset( void );
	// reset
private:

	CRTMutex m_cs;
	// mutex for object state

	int m_size;
	// size of queue

	int m_head;
	// head of queue

	int m_count;
	// number of node in queue

	TADNode **m_ppBuffer;

};
#endif
