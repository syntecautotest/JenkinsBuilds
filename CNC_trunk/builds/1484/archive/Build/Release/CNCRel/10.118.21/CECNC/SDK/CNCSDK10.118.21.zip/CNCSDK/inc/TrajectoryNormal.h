// TrajectoryNormal.h: interface for the CTrajectoryNormal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_TRAJECTORYNORMAL_H____INCLUDED_)
#define _TRAJECTORYNORMAL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define CoefEpsilon					1.0e-8	// experiment data
#define IterEpsilon					5.0e-5	// epsilon for iteration
#define CalcErrTolerance			1.0e-4	// calculation error tolerance
#define SmallErrorTolerance			1.0e-12	// avoid outputMaxVelocity error
#define TIMETOL_HighPrec			DBL_EPSILON //unit:us
#define TIMETOL_LowPrec				20 //unit:us

class CTrajectoryNormal : public CTrajectory
{
public:
	CTrajectoryNormal( BOOL bDumpData = TRUE );
	~CTrajectoryNormal( void );

	BOOL planBlockWithDec( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Vref1, DOUBLE Vref2, DOUBLE Accmax, DOUBLE Decmax, DOUBLE Jmax, TPVTSheet *pPVT, BOOL bNormalPVT = TRUE, BOOL bAllowBreakAJ = TRUE );
	// to plan block trajectory with specific deceleration

	BOOL planBlockWithoutDiffDec( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Vref1, DOUBLE Vref2, DOUBLE Amax, DOUBLE Jmax, TPVTSheet *pPVT, BOOL bNormalPVT = TRUE, BOOL bAllowBreakAJ = TRUE );
	// to plan block trajectory without different deceleration, using deceleration the same as acceleration
	// type A:
	//			V0, Vc, Vf1, Vf2
	//			A0, Ac, Amax, Jmax, P
	//
	// Acceleration profile                Velocity profile
	//      |			                      |
	// A0   |   ---                           |      .---.
	//      |  /   \                          |    .'     \
	//      | /     \____                     |   /        \
	//    --+------------\---------- t        |  /          \
	//      |             \      /         V0 |-'            \
	//      |              \    /             |               `-- Vc
	//      |               ---     -Ac      -+------------------------ t
	//      |                                 |
	// this algorithm is refered to "Motion Planning"-"Trajectory Planning" and "Constant Jerk Trajectory" / ���m��

	void genCornerAcceleration( TPVTSheet *pPVT, double Vbegin, double Vend, double P, double Ts, double Ta );
	// to generate corner acceleration trajectory for G62.1 and G33/G34.
	// pPVT		[out] pointer to PVT segment buffer.
	// Vbegin	[in] block velocity at begin, in BLU / micro-second
	// Vend		[in] block velocity at end, in BLU / micro-second
	// P		[in] startup distance
	// Ts		[in] bell-shaped acceleration time, in micro-second.
	// Ta		[in] acceleration time of fix time trajectory, in micro-second. Only use bell-shaped trajectory when Ta equal Ts.

	BOOL PlanConstVelEnd( double V0, double A0, double Vc, double Ac, double L, double Vmax, double &Amax, double &Jmax , double &Lout, double &Vout, double *Tout = NULL );
	// find the distance and velocity at the end of constant velocity
	// Tout is "estimated" moving time, not real interpolation time

	BOOL CalMaxVel( double &Vc, double &Ac, double V0, double A0, double P, double Amax, double Jmax, bool bHighPrecision = FALSE );
	// calculate max Vc and Ac from V0, A0 in length of P

	double ForwardTimeDiff_Dist( TPVTSheet *pPVT, int nAccIndex, double Dist, double Length, double AccTime );
	// forward time difference by the distance under the constraint V0 = Vc = 0 && A0 = Ac = 0

	double BackwardTimeDiff_Dist( TPVTSheet *pPVT, int nDecIndex, double Dist, double Length, double DecTime );
	// backward time difference by the distance under the constraint V0 = Vc = 0 && A0 = Ac = 0

	DOUBLE PlanTwoOrThreeSection( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Amax, DOUBLE Jmax, TPVTSheet *sheet );
	// plan ( V0, A0 ) -> ( Vc, 0 ) by acceleration and jerk limited, return total distance

	DOUBLE PlanOneSection( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE T, TPVTSheet *sheet );
	// plan ( V0, A0 ) -> ( Vc, Ac ) using time T, return total distance

private:
	void PreModifyJerk( DOUBLE V0, DOUBLE A0, DOUBLE Vmax, DOUBLE &Vleast, DOUBLE &J );
	// pre-modify jerk for unreasonable input

	BOOL Process7SectionsCase( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE V1, DOUBLE V2, DOUBLE Accmax, DOUBLE Decmax );
	// process seven sections case

	void OutputStartUp( DOUBLE V0, DOUBLE Vc, TTrajInfo &StartUp );
	// output startup profile

	void OutputStopDown( DOUBLE V0, DOUBLE Vc, TTrajInfo &StopDown );
	// output stopdown profile

	BOOL Process6SectionsCase( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE V, DOUBLE Accmax, DOUBLE Decmax );
	// process six sections case

	BOOL Process3SectionsCase( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Accmax, DOUBLE Decmax, DOUBLE Jmax );
	// process two or three sections case by limited acceleration and jerk.
	// P must be calculated in advance to be matched with two or three sections.

	BOOL ProceseBreakJerkCase( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Accmax, DOUBLE Decmax );
	// process break jerk case

	BOOL outputMaxVelocity( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Vmax, DOUBLE Amax, DOUBLE Jmax, DOUBLE &V );
	// output maximum velocity through algebraic method

	BOOL SolveVpeak_2ConstAccRegions( DOUBLE V0, DOUBLE Vc, DOUBLE P, DOUBLE Amax, DOUBLE Jmax, DOUBLE &Vpeak );
	// solve Vpeak for two sides with constant acceleration regions

	BOOL SolveVpeak_1ConstAccRegion( DOUBLE V0, DOUBLE Vc, DOUBLE P, DOUBLE Amax, DOUBLE Jmax, DOUBLE &V );
	// solve Vpeak for single side with constant acceleration region
	// when degenerate region 2, ( V0, Vc ) = ( V0_least, Vc_least )
	// when degenerate region 6, ( V0, Vc ) = ( Vc_least, V0_least )

	BOOL SolveVpeak_0ConstAccRegion( DOUBLE V0, DOUBLE Vc, DOUBLE P, DOUBLE Jmax, DOUBLE &V );
	// solve Vpeak for two sides without constant acceleration region

	DOUBLE searchMaxVelocity( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE V_low, DOUBLE V_up, DOUBLE Accmax, DOUBLE Decmax );
	// search maximum velocity through numerical method

	void MergeAndOutputPVT( DOUBLE V0, DOUBLE Vc, DOUBLE V_Goal );
	// merge epsilon distance difference and output PVT

	void MergeEpsilonDist( TTrajInfo &Traj );
	// merge epsilon distance difference to Traj

	void MergeEpsilonDist( TTrajInfo &Traj1, TTrajInfo &Traj2, DOUBLE dT, DOUBLE V1, DOUBLE V2 );
	// merge epsilon distance difference to Traj1 and Traj2 in Process7SectionCases

	BOOL ModifyJerk( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Accmax, DOUBLE Decmax );
	// modify jerk

	BOOL ModifySmallJerk( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Accmax, DOUBLE Decmax );
	// modify smaller jerk

	BOOL FindMiddleJerk( DOUBLE V0, DOUBLE A0, DOUBLE P, DOUBLE A, DOUBLE &J );
	// find middle jerk

	BOOL ModifyBothJerks( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Accmax, DOUBLE Decmax );
	// modify both jerks

	BOOL FindGoalJerk( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE Accmax, DOUBLE Decmax );
	// find goal jerk

	BOOL FindGoalJerk_Acc( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE A );
	// find goal jerk in acceleration case

	BOOL FindGoalJerk_Dec( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE A );
	// find goal jerk in deceleration case

	BOOL SolveJerk_1S2S( DOUBLE V0, DOUBLE A0, DOUBLE P, DOUBLE &J );
	// single side two sections

	BOOL SolveJerk_1S3S( DOUBLE V0, DOUBLE A0, DOUBLE P, DOUBLE A, DOUBLE &J );
	// single side three sections

	BOOL SolveJerk_2S3S( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P );
	// two sides three sections

	BOOL SolveJerk_2S4S( DOUBLE V0, DOUBLE A0, DOUBLE Vc, DOUBLE Ac, DOUBLE P, DOUBLE A );
	// two sides four sections

private:
	TPVTSheet *m_pPVT;
	// PVT sheet

	double m_J1, m_J2;
	// jerks for startup and stopdown

	double m_V1_least, m_V2_least;
	// least V1 and V2

	double m_dP;
	// distance difference

	TTrajInfo m_StartUp, m_StopDown;

	double m_V_low;
	// lower velocity

	BOOL m_bStarUpIsOneSection;
	// flag for whether the start up tracjectory is one section only
	// e.g. is it's ture, means the situation as in the following figure
	//      |        \    |                |
	//      |     A0  \   |                |
	//      |          \  |  stop down     |
	//      |           \ |  3 sections    |
	//      |            \|                |
	//      |-------------|---------- t    |
	//      |             |\      /        |
	//      | start up    | \    /         |
	//      | 1 section   |  ----    -Ac   |
	//      |             |                |

	double m_Pbound;
	// distance boundary

	CPolynomialRootSolver m_PRS;
	// polynomial root solver

	double m_Coeff[5];
	// polynomial coefficients with m_Coeff[i] for i-th degree coefficient

	double m_P_up, m_P_low;
	// upper and lower distance difference in recursion
};

#endif // !defined(_TRAJECTORYNORMAL_H____INCLUDED_)
