#if !defined(AFX_ISERIALPLCCHANNEL_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
#define AFX_ISERIALPLCCHANNEL_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISerialPLCChannel
{
public:
	virtual ~ISerialPLCChannel( void ) {}
	// destructor

	virtual int CNCAPI TypeOfChannel( void ) = 0;
	// get type of channel

	virtual void CNCAPI SetServoOn( BOOL bServoOn ) = 0;
	// set servo state

	virtual void CNCAPI RefreshAlarmFlags( void ) = 0;
	// refresh alarm flags

	virtual BOOL CNCAPI IsServoOn( void ) = 0;
	// is servo on

	virtual BOOL CNCAPI GetServoIOSignal( int IOSignal ) = 0;
	// get servo IO Signal

	virtual LONG CNCAPI ReadAlarmFlags( void ) = 0;
	// read alarm flags

	virtual LONG CNCAPI GetAlarmID( void ) = 0;
	// read alarm flags

	virtual LONG CNCAPI GetWarningID( void ) = 0;
	// get servo warning id

	virtual LONG CNCAPI ReadRealPosition( void ) = 0;
	// read real position

	virtual EDriverEncoderType CNCAPI getEncoderType( void ) = 0;
	// get encoder type

	virtual BOOL CNCAPI setPosingData( LONG Position, DOUBLE Velocity, DOUBLE VelocityRefAcc, DOUBLE AccTime ) = 0;
	// set posing data
	// position in pulse
	// velocity in pulse / s
	// velocity ref acc in pulse / s
	// acceleration time in ms

	virtual BOOL CNCAPI setVelCtrlData( DOUBLE Velocity, DOUBLE AccTime ) = 0;
	// set velocity control data
	// velocity in pulse / s
	// acceleration time in ms

	virtual void CNCAPI StartPosing( void ) = 0;
	// start posing

	virtual void CNCAPI FinishPosing( void ) = 0;
	// finish posing

	virtual void CNCAPI EmergyStop( void ) = 0;
	// emergency stop

	virtual void CNCAPI Stop( void ) = 0;
	// stop

	virtual BOOL CNCAPI IsPosingFinish( void ) = 0;
	// is posing finsih

	virtual BOOL CNCAPI IsVelocityReached( void ) = 0;
	// is velocity reached

	virtual BOOL CNCAPI IsHoldFinish( void ) = 0;
	// is hold finish

	virtual BOOL CNCAPI IsSupportROT( void ) = 0;
	// whether support ROT

	virtual BOOL CNCAPI IsSupportSPLCA( void ) = 0;
	// whether support serial plc axis

	virtual BOOL CNCAPI IsSupportMPG( void ) = 0;
	// whether support MPG

	virtual BOOL CNCAPI IsInitFinish( void ) = 0;
	// whether initial process finish

	virtual LONG CNCAPI getActualVelocity( void ) = 0;
	// get actual velocity in pulse / s

	virtual BOOL CNCAPI setPositionCheckWindow( LONG nWindow ) = 0;
	// set position check window in pulse

	virtual BOOL CNCAPI setVelocityCheckWindow( LONG nWindow ) = 0;
	// set velocity check window in mm / min

	virtual void CNCAPI PutTorqueLimit( long RatedTRQLimit ) = 0;
	// put torque limit in 0.01% rated torque

	virtual BOOL CNCAPI CNCDeviceIoControl( unsigned long dwIoControlCode, void *lpArgBuf, unsigned int nArgBufSize ) = 0;
	// Device IO control, OCDevice interface

	virtual BOOL CNCAPI IsSignalCaptured( INT nSelect, ELatchSource nLatchSource ) = 0;
	// is signal captured

	virtual LONG CNCAPI ReadSignalPosition( INT nSelect, ELatchSource nLatchSource ) = 0;
	// read signal position

	virtual BOOL CNCAPI StartSignalCapture( INT nSelect, ELatchSource nLatchSource, EEventMode nEventMode = EEM_Trigger ) = 0;
	// start signal position capture

	virtual void CNCAPI SetOpMode( int nMode ) = 0;
	// set operation mode

	virtual void CNCAPI PutPositionCommand( long pulse ) = 0;
	// put position command
	// unit: counts, same as encoder resolution with DMR

	virtual long CNCAPI ReadTorqueLoad( void ) = 0;
	// read torque load in 0.01% rated torque
};

#endif // !defined(AFX_ISERIALPLCCHANNEL_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
