// SCurveTrajectory.h: interface for the CSCurveTrajectory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCURVETRAJECTORY_H__E9F08563_1681_11D3_B6E7_000000000000__INCLUDED_)
#define AFX_SCURVETRAJECTORY_H__E9F08563_1681_11D3_B6E7_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSCurveTrajectory
// Cause: the interface arguments which related to time
// you should floor or ceil to clamp it near integer, if
// not the class may generate different trajectory segments
// from different object even its time arguments is the same,
// because math truncation error.
{
public:
	CSCurveTrajectory();
	virtual ~CSCurveTrajectory();

	void setITrajInterpolator( ITrajInterpolator *pTrajInt );
	// associate interpolator object for output planning command
	// Use threads: constructor

	void set( DOUBLE velocity, DOUBLE distance );
	// set initial state
	
	DOUBLE MoveTo( DOUBLE P, DOUBLE TM, DOUBLE TA, DOUBLE TS );
	// relative move to with blended
	// P	displacement, in BLU.
	// TM	movement time, in microsecond.
	// TA	acceleration time. in microsecond.
	// TS	S-curve acceleration time, in microsecond.
	// Use threads: motion plan

	DOUBLE MoveTo( DOUBLE P, DOUBLE TM, DOUBLE TA, DOUBLE TS, DOUBLE Ws, DOUBLE We );
	// relative move to with blended
	// P	displacement, in BLU.
	// TM	movement time, in microsecond.
	// TA	acceleration time. in microsecond.
	// TS	S-curve acceleration time, in microsecond.
	// Ws	start point feedrate weighting
	// We	end point feedrate weighting

	double RapidTo( double P, double TM, double TA, double TS );
	// ralative move to without blended
	// P	displacement, in BLU.
	// TM	movement time, in microsecond.
	// TA	acceleration time. in microsecond.
	// TS	S-curve acceleration time, in microsecond.
	// Use threads: motion plan

	double RapidTo( double P, double TM, double TA, double TS, double Ws, double We );
	// relative move to with blended
	// P	displacement, in BLU.
	// TM	movement time, in microsecond.
	// TA	acceleration time. in microsecond.
	// TS	S-curve acceleration time, in microsecond.
	// Ws	start point feedrate weighting
	// We	end point feedrate weighting

	void JogTo( double velocity, double TA, double TS );
	// jog to is velocity type movement command, current version
	// only support 17.5 minute movement by specified velocity. So
	// if your usage exceed 17.5 minute, you need re-issue this command
	// again to keep movement, otherwise it will go to stop
	// suddenly. Or you choose to re-design this method.
	// velocity	desired velocity, in BLU per microsecond
	// TA		acceleration time. in microsecond.
	// TS		S-curve acceleration time, in microsecond.
	// Use threads: motion plan

	void GetRemainDisplacement( double &displacement );
	// get remain displacement which is queue in buffer

	DOUBLE DelayWithTA( DOUBLE time );
	// delay time with previous TA
	// time		in microsecond
	// Use threads: motion plan

	DOUBLE Delay( DOUBLE time );
	// delay time without previous TA
	// time		in microsecond
	// Use threads: motion plan

	DOUBLE Flush( void );
	// flush internal buffered commands
	// Use threads: motion plan

	int IsReady( void );
	// Use threads: motion plan

	void Reset( void );
	// Use threads: <= motion plan

private:
	static const double EPSILON_displacement;
	// epsilon amount for displacement

private:
	ITrajInterpolator	*m_pTrajInt;
	// associated trajectory interpolator interface

	double m_P0;	// clearance amount for deceleration
	double m_V0;	// the end velocity of last planning

	// althought the P, V is enough to record current trajectory
	// state, but the block move time is the basic factor to
	// synchronize multiple trajectory planner, so TM also the
	// important object state.
	double m_TM0;	// the movement time of clearance amount

	double m_TA0;	// the acceleration time of last planning
	double m_TS0;	// the S-curve acceleration time of last planning

	CRTMutex m_cs;
	// mutex for object state consistent
};

#endif // !defined(AFX_SCURVETRAJECTORY_H__E9F08563_1681_11D3_B6E7_000000000000__INCLUDED_)
