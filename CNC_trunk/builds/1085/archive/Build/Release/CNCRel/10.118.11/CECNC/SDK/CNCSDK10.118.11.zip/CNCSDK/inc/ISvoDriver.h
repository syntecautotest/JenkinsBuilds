// ISvoDriver.h: interface for the ISvoDriver class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISVODRIVER_H__170AAE34_8CA6_43ca_9A8B_F2B36771DACA__INCLUDED_)
#define AFX_ISVODRIVER_H__170AAE34_8CA6_43ca_9A8B_F2B36771DACA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISvoChannel;
class IServoLink;

// communication type
enum ECommType {
	ECMT_Null,
	ECMT_General,
	ECMT_M2,
	ECMT_M3,
	ECMT_EtherCAT,
	ECMT_RTEX,
	ECMT_SRI,
	ECMT_RF,
};

// channel type
enum EChType {
	ECT_Svo = 0,
	ECT_PLC = 1,
	ECT_MPG = 2,
	ECT_Galvo = 3,
	ECT_Laser = 4,
	ECT_Tuning = 5,
	ECT_SerialParam = 6,
	ECT_M3_DAQ = 7,
	ECT_CNC2_DAQ = 8,
	ECT_CNC2_Param = 9,
	ECT_M3IO = 10,
	ECT_M3_IOProfile = 11,
	ECT_RF = 12,
};

class ISvoDriver
{
public:
	enum ECommRet
	{
		ERet_Success = 0,
		ERet_SerialCommFailure,
	};

	// driver initialize result
	enum EInitResult {
		EIR_SUCCESS = 0,
		EIR_LOADAUXMCIFAIL,
		EIR_NETWORKFAIL,
	};

public:
	virtual ~ISvoDriver( void ) {}
	// destructor

	virtual ECommType CNCAPI GetCommType( void ) = 0;
	// get communication type

	virtual long CNCAPI GetDDADuration( void ) = 0;
	// query actual DDA duration, in micro-second

	virtual int CNCAPI Start( void ) = 0;
	// To activate ISR.
	// This function should be called after motion interfaces have
	// been well configured.

	virtual INT CNCAPI GetCommResNum( INT nType, INT nPortID ) = 0;
	// To get the number of communication resource ( DI/DO/AI/AO/MPG... )

	virtual void* CNCAPI GetChannel( EChType nChType, INT nPortID ) = 0;
	// To get the control of indicated channel.
	// The first channel is numbered as 1.

	virtual void CNCAPI SetEStop( BOOL bOn ) = 0;
	// emergency stop servo driver

	virtual int CNCAPI QueryDebugDataSize( void ) = 0;
	// get driver debug data size

	virtual long CNCAPI QueryDebugData( int index ) = 0;
	// get driver debug data
	// index	index of debug data, start from 0

	virtual BOOL CNCAPI isReady( void ) = 0;
	// query whether driver is ready to received next command?

	virtual BOOL CNCAPI isSupportFineDDA( void ) = 0;
	// query whether support fine DDA interrupt

	virtual long CNCAPI GetFineDDADuration( void ) = 0;
	// to get fine DDA interrupt duration

	virtual void CNCAPI WatchDogEnable( void ) = 0;
	// enable watch dog function.

	virtual void CNCAPI WatchDogDisable( void ) = 0;
	// disable watch dog function.

	virtual void CNCAPI GetExtServoLink( IServoLink **pInterface ) = 0;
	// get extension interface

	virtual BOOL CNCAPI InterruptDone( void ) = 0;
	// interrupt done

	virtual long CNCAPI GetFirmwareVersion( void ) = 0;
	// query motion card firmware version number

	virtual BOOL CNCAPI CNCDeviceIoControl( ULONG dwIoControlCode, void *lpArgBuf, UINT nArgBufSize ) = 0;
	// Device IO control, OCDevice interface

	virtual BOOL CNCAPI SetupExtIODev( INT nDeviceID, INT nPortID, LONG nWriteStartRbit, LONG nWriteLength, LONG nReadStartRbit, LONG nReadLength ) = 0;
	// setup externel IO device
};

#endif // !defined(AFX_ISVODRIVER_H__170AAE34_8CA6_43ca_9A8B_F2B36771DACA__INCLUDED_)
