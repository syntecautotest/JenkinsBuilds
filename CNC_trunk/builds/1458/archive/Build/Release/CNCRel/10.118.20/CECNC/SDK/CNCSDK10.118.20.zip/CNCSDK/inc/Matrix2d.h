// Matrix2d.h: interface for the CMatrix2d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATRIX2D_H__D5DE5FA9_F511_4111_879E_C7795601D321__INCLUDED_)
#define AFX_MATRIX2D_H__D5DE5FA9_F511_4111_879E_C7795601D321__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CVector2d;

class CMatrix2d  
{
public:
	CMatrix2d();
	virtual ~CMatrix2d();

	friend class CMatrix2dTest;

	void set( CVector2d &u1, CVector2d &u2 );
	// construct matrix2d using specified unit vector

	void set( double angle );
	// construct maxtrix2d using specified rotation angle

	void transform( CVector2d &vec );
	// do 2d vector transform

	void transform( CVector2d &vec, CVector2d &vecOut );
	// do 2d vector transform

	void setZero( void );
	// Sets this matrix to all zeros.

	void setIdentity( void );
	// Sets this Matrix4d to identity.

	void setElement( int row, int column, double value );
	// set element value

private:
	double m_matrix[2][2];
};

#endif // !defined(AFX_MATRIX2D_H__D5DE5FA9_F511_4111_879E_C7795601D321__INCLUDED_)
