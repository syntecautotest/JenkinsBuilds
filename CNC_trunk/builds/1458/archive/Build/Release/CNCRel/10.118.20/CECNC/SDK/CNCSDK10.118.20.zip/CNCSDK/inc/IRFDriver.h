// IRFDriver.h: interface for the IRFDriver class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_IRFDRIVER_H____INCLUDED_)
#define _IRFDRIVER_H____INCLUDED_

// radio frequdency read error code
#define RF_RD_NO_ERROR				( 0 )
#define RF_RD_ERR_LOST_KEY_UP		( 0x00000001 )
#define RF_RD_ERR_CRC				( 0x00000002 )

// radio frequdency write error code
#define RF_WR_NO_ERROR				( 0 )
#define RF_WR_ERR_HHB_REMOVE		( 0x00000001 )
#define RF_WR_ERR_HHB_COMM_ERR		( 0x00000002 )

enum ERFReadErrIndex {
	ERFRE_LOST_KEY_UP = 0,
	ERFRE_CRC_ERROR = 1,
	ERFRE_NUM,
};

class IRFDriver
{
public:
	virtual ~IRFDriver( void ) {}
	// destructor

	virtual LONG CNCAPI GetDebugData( LONG nIndex ) = 0;
	// get debug data

	virtual void* CNCAPI GetChannel( void ) = 0;
	// get radio freq. channel

	virtual void SetCommErrPermitTime( LONG nCommErrPermitTime ) = 0;
	// set communication error time

	virtual void RefreshAlarmFlags( void ) = 0;
	// refresh alarm
};
#endif //(_IRFDRIVER_H____INCLUDED_)