// IEnIPCenter Common Interface Declaration
#pragma once


// EnIP Connection Mode
enum EEnIPConnectMode {
	EENIPCM_ExpMsg = 0,	// Explicit Message
	EENIPCM_ImpMsg = 1,	// Implicit Message
};


#pragma pack( push, 1 ) // 1-byte Alignment

// EnIP Ticket
struct TEnIPTicket {
	DWORD nStation;			// EnIP Station
	ENIP_HANDLE hHandle;	// EnIP Handle
};

#pragma pack( pop )


class IEnIPCenter
{
public:
	enum EInfoModelType {
		EIMT_ConfigFile = 0,	// Source from config file
		EIMT_Broadcast = 1,		// Source from broadcast
	};

	// Get EnIP Info Model data size (unit: BYTE) for byte array capacity needed
	virtual UINT GetInfoModelSize( /*In*/ EInfoModelType eModelType ) = 0;

	// Load EnIP Info Model data from specific model type to prepared data buffer
	virtual BOOL LoadInfoModelData( /*In*/ EInfoModelType eModelType, /*Out*/ void *pDataBuf, /*In*/ UINT nMaxBufSize ) = 0;

	// Save EnIP Info Model data from specific data buffer to config xml file
	virtual BOOL SaveInfoModelData( /*In*/ const void *pDataBuf, /*In*/ UINT nBufSize ) = 0;

	// Send the UDP broadcast message to get potential EnIP device from specific LAN port number
	// Note: Specify the LAN number to broadcast, or 0 is all LAN broadcast
	virtual BOOL Broadcast( /*In*/ UINT nLAN ) = 0;

	// Send EnIP explicit message request command to specific device
	// If success output Ticket and return TRUE, otherwise return FALSE
	// Note: Specify the LAN number for station ID to search, or 0 is all LAN number search
	virtual BOOL SendExpMsgReq( /*Out*/ TEnIPTicket &EnIPTicket, /*In*/ UINT nLAN, /*In*/ ULONG nStationID, /*In*/ const TEnIPExpMsgReq &ReqInfo ) = 0;

	// Recv EnIP explicit message response data from specific ticket
	// Copy the response data into buffer and record information in RspInfo
	virtual EEnIPRecvState RecvExpMsgRsp( /*In*/ const TEnIPTicket &EnIPTicket, /*Out*/ void *pRspBuf, /*In*/ INT nMaxBufSize, /*Out*/ TEnIPExpMsgRsp &RspInfo ) = 0;

	// Abort EnIP explicit message request command from specific ticket
	// Note: If request was sent, then successful abort must wait until data receive finished or other errors occured,
	// otherwise can not send next request or get current response during this time
	virtual void AbortExpMsgReq( /*In*/ const TEnIPTicket &EnIPTicket ) = 0;
};
