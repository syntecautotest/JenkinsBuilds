// RTMutex.h: interface for the CRTMutex class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RTMUTEX_H__FCB29EB5_E988_457B_B621_799096D6201A__INCLUDED_)
#define AFX_RTMUTEX_H__FCB29EB5_E988_457B_B621_799096D6201A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class IMutex {
public:
	virtual ~IMutex( void ) {}
	// destructor

	virtual void lock( void ) = 0;
	// enter critical section

	virtual void unlock( void ) = 0;
	// leave critical section
};

class CRTMutex : public IMutex
{
public:
	CRTMutex();
	virtual ~CRTMutex();

	void lock( void );
	// enter critical section

	void unlock( void );
	// leave critical section

private:
	CRITICAL_SECTION m_cs;
};

class CSoftMutex : public IMutex
{
public:
	CSoftMutex();
	virtual ~CSoftMutex();

	void lock( void );
	// enter critical section

	void unlock( void );
	// leave critical section

private:
	HANDLE m_hMutex;
};

#endif // !defined(AFX_RTMUTEX_H__FCB29EB5_E988_457B_B621_799096D6201A__INCLUDED_)
