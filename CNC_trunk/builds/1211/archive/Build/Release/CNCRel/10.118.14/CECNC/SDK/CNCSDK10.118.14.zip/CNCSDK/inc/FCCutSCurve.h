#if !defined(_FCCUTSCURVE_H____INCLUDED_)
#define _FCCUTSCURVE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPlanGroupTest;

class CFCCutSCurve : public CFeedControl
{
public:
	friend class CPlanGroupTest;

	CFCCutSCurve( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	~CFCCutSCurve( void );
	// destructor

	BOOL BlockStop( double &TargetVel, double &TargetDist, double Vcur, double Acur, BOOL &bTarVelModified );
	// do block stop

	void Feedhold( double &TargetVel, double &TargetDist, double Vcur, double Acur, BOOL &bTarVelModified, BOOL &bForward );
	// do feedhold

	void ForwardElimination_FH( double V0 );
	// forward elimination for feedhold

	BOOL PlanGroup( TLANode *&pNode );
	// calculate Lgrp, Vgrp, Lcvs, and Vcvs for first group

public:
	void putLANode( TLANode *pNode, double eParam1 = 0 );
	// put look ahead node to feed control module

	void setExactStop( void );
	// set exact stop

	void setEOBMark( const TPacketInfo &PacketInfo );
	// set EOB Mark

	void Remove( void );
	// remove raw queue node

protected:
	virtual void onBeginDispatchBlock( BOOL bForceFlush = TRUE ) {}
	// trajectory planning tick call back

private:
	int FindFirstGroupEnd( int nStartIndex, int nEndIndex, TLANode *&pGroupNode );
	// find first group end node from nStartIndex, return group end index

	void NotifyDecToZero( void );
	// notify decelerate to zero

	void StepOneEOB( int nEndIndex, int nGroupIndex, TLANode *pGroupNode );
	// step several cutting blocks with one EOB, return end index

	void TagTargetZero( int nEndIndex, int nCutIndex, int nGroupIndex, TLANode *pCutNode, TLANode *pGroupNode, double CutLength );
	// tag cut group end zero velocity

	void PartitionGroup( TLANode *pCutNode, TLANode *pGroupNode, double CutLength );
	// partition group

	BOOL DecInAccSection( double &TargetVel, double &TargetDist, double Vcur, double Acur, BOOL &bTarVelModified, int nEndIndex, int nGroupIndex, TLANode *pGroupNode );
	// decelerate in acceleration sections, return end index of the cutting node with EOB mark

	int DecInCurrentGroup( int nEndIndex, int nGroupIndex, TLANode *pGroupNode, double LeastLength );
	// decelerate in current group, return end index of the cutting node with EOB mark

	BOOL RePlanCurrentGroup( double &TargetVel, double &TargetDist, double Vcur, double Acur, BOOL &bTarVelModified, TLANode *pNode, double RemainLength, double ConsumeLength );
	// re-plan current group

	void DecToZero_BStop( int nStartIndex, int nEndIndex, double V0 );
	// decelerate to zero velocity, return end index of the cutting node with EOB mark

	int DecToZero_FH( int nStartIndex, int nEndIndex, double V0, BOOL &bForward );
	// decelerate to zero velocity, return end index of the cutting node

private:
	void Grouping( TLANode *pNode );
	// group nodes and calculate Lgrp, Vgrp, Lcvs, and Vcvs for each group

	void ClassifyNode( TLANode *pNode );
	// classify nodes into group

	void FindInhibitArea( int nStartIndex, int nEndIndex, double V0, int &nInhibitEnd );
	// calculate the upper bound and lower bound of the inhibit velocity area

	void FollowInhibitArea( int nInhibitStart, int nInhibitEnd, double V0 );
	// follow inhibit area

	int ForwardElimination( int nStartIndex, int nEndIndex, double &V0 );
	// forward elimination, return first intersection index

	int DecToZero( int nStartIndex, int nEndIndex, double &V0 );
	// decelerate to zero velocity, return end index of the cutting node

	BOOL BackwardElimination( int nStartIndex, int nEndIndex, int nQueueCount, double Vc );
	// backward elimination

	BOOL ProcessInhibitInterval( int nStartIndex, int nInhibitEnd, int nQueueCount, TLANode *pNode, double Vc, BOOL bReachEnd );
	// process inhibit interval, return TRUE if Vc lies in inhibit interval

	void BackwardMarkMature( int nEndIndex );
	// backward mark all groups mature

	void ForwardCancelMature( int nStartIndex, int nEndIndex );
	// forward cancel all mature mark

	void putGeomAxis( const int XAxis, const int YAxis, const int ZAxis );
	// to put geometry axis index

private:
	double m_V_low;
	double m_V_high;
	// the upper bound and lower bound of the inhibit interval

	CTrajectoryNormal *m_pTrajNormal;
	// trajectory normal
};

#endif // !defined(_FCCUTSCURVE_H____INCLUDED_)
