#if !defined(_FLCUTSCURVE_H____INCLUDED_)
#define _FLCUTSCURVE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCurvatureCalculator;
class CArcFeature;
class CTrajectory;

class CFLCutSCurve : public CFeedLimit
{
public:
	CFLCutSCurve( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	~CFLCutSCurve( void );
	// destructor

	void putLookAheadCondition( const double ChordErrorTol, const double CornerFeedrate, const double ArcRefRadius, const double ArcRefFeedrate );
	// set maximum allowable feedrate for motion block movement
	// chord error tolerance, in IU
	// corner feedrate at 120 degree, in IU / us
	// arc reference radius and reference feedrate, in IU, and IU / us

private:
	void deriveGeometryCondition( double normal[], int Direction, CArcFeature af );
	// to derive geometry space condition, work plane maximum feedrate, Z-axis maximum feedrate

public:
	BOOL IsEmpty( void );
	// query whether the pipe is empty

	void Abort( void );
	// abort

	void Reset( void );
	// reset

public:
	virtual void PutLANodeToCurvPart( TLANode *pNode );
	// put look ahead node to curvature part of feed limit module

public:
	void CalcBlockLength( TLANode *pNode, CArcFeature &af );
	// calculate block length.

	int getCountOfCCQue( void );
	// get count in C.C. Queue

protected:
	void FlushAllQueue( void );
	// flush queued nodes of feed limit module

	TLANode *ReversePeek( void );
	// peek the last node in feed limit module

	void CalcBlockMotionFeature( TLANode *pNode, CArcFeature &af );
	// calculate block motion feature

private:
	void ClampBlockAccByAxisAcc( TLANode *pNode );
	// clamp block acceleration by maximum axis acceleration

	void ClampArcBlockFeedrateBy408( TLANode *pNode, CArcFeature &af );
	// clamp arc block feedrate by parameter 408

	void ClampArcBlockFeedrateAndAccByWP( TLANode *pNode, CArcFeature &af );
	// clamp arc block feedrate and acceleration by work plane feedrate and acceleration

	void ClampArcBlockFeedrateAndAccByZ( TLANode *pNode, CArcFeature &af );
	// clamp arc block feedrate and acceleration by Z-axis feedrate and acceleration

protected:
	void CalcCornerFeature( TLANode *pNode, double &eLastVc );
	// to calculate inter-block feature

private:
	void ClampLinearBlockFeedrateBy408( TLANode *pNode );
	// clamp linear block feedrate by parameter 408

	BOOL CalculateCornerDeviation( TLANode *pNode, TLANode *pLNode, double &eDeviationLen, double eDeviation[] );
	// calculate corner deviation and its length

	void ClampCornerFeedrateBy406( TLANode *pNode, double eDeviationLen );
	// clamp corner feedrate by parameter 406

	void ClampCornerFeedrateByAxis406( TLANode *pNode, double eDeviation[] );
	// clamp corner feedrate by maximum feedrate difference of each axis

	void ClampCornerFeedrateByBlockFeedrate( TLANode *pNode, TLANode *pLNode );
	// clamp corner feedrate by block feedrate

private:
	CCurvatureCalculator *m_pCurvatureCalculator;
	// curvature calculator object pointer

	CTrajectory *m_pTrajectory;
	// trajectory object pointer
};

#endif // !defined(_FLCUTSCURVE_H____INCLUDED_)
