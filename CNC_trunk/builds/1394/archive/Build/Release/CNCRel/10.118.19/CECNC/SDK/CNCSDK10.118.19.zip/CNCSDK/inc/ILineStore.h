// ILineStore.h: interface for the ILineStore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ILINESTORE_H__B746284A_41A3_46A3_8E69_E9D20F5DA57E__INCLUDED_)
#define AFX_ILINESTORE_H__B746284A_41A3_46A3_8E69_E9D20F5DA57E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class ILineStore
{
public:
	virtual ~ILineStore( void ) {};

	virtual int CNCAPI readLine( long lineno, void *buffer, int count ) = 0;
	// return the data size copied, when count is 0,
	// then return the actual size of specified line

	virtual long CNCAPI getLineCount( void ) = 0;
	// return the total line count

	virtual void CNCAPI clearAll(void) = 0;
	// clear all content

	virtual BOOL CNCAPI insert( long lineno, void *data, int size ) = 0;
	// insert data before specified line number.
	// return TRUE, when successful, others, return FALSE.

	virtual BOOL CNCAPI append( void *data, int size ) = 0;
	// append specified data at the tail of whole data.

	virtual BOOL CNCAPI deleteLine( long lineno ) = 0;
	// delete specified line, this function will all behind line move
	// forward one line.

	virtual BOOL CNCAPI put( long lineno, void *data, int size ) = 0;
	// put specified data into specified line

	virtual BOOL CNCAPI erase( long lineno ) = 0;
	// erase specified line data, this function just rease specified
	// line data, and no move behind line forward.
};

#endif // !defined(AFX_ILINESTORE_H__B746284A_41A3_46A3_8E69_E9D20F5DA57E__INCLUDED_)
