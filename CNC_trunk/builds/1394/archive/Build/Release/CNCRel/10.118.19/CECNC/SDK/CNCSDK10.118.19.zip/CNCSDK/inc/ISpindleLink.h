#if !defined(_ISPINDLELINK_H____INCLUDED_)
#define _ISPINDLELINK_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define DegreePerRev						360

class ISpindleLink
{
public:
	virtual ~ISpindleLink( void ) {}
	// destructor

	virtual BOOL IsReadyforCutting( void ) = 0;
	// query whether spindle is ready for cutting

	virtual BOOL IsReadyforThreading( void ) = 0;
	// is ready for threading

	virtual BOOL getEncoderExist( void ) = 0;
	// query whether position sensor exist?

	virtual void StartIndexCapture( void ) = 0;
	// start latch index absolute position process
	// Use threads: <= interpolation

	virtual int IsIndexCaptured( void ) = 0;
	// query whether the index has been latched ?
	// Use threads: <= interpolation

	virtual long GetIndexPosition( void ) = 0;
	// get index position in pulse counts

	virtual long GetAbsoluteCounter( void ) = 0;
	// get spindle position in pulse counts.

	virtual void GetReferenceSpeed( double *speed ) = 0;
	// get maximum cutting speed
	// speed		in RPM
	// Use threads: <= motion plan

	virtual double GetSpdSpeed_Pulse( void ) = 0;
	// get spindle speed in absolute counter.

	virtual double GetSpindleSpeed( void ) = 0;
	// get spindle actual speed, this function work when
	// there are encoder feedback.
	// speed		in RPM
	// Use threads: <= motion plan

	virtual double GetSpindleSmoothedSpeed( void ) = 0;
	// get spindle actual speed, this function work when
	// there are encoder feedback.
	// speed		in RPM
	// Use threads: <= motion plan
};

#endif // !defined(_ISPINDLELINK_H____INCLUDED_)
