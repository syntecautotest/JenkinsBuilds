// OneBlockInterpolator.h: interface for the COneBlockInterpolator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(ONEBLOCKINTERPOLATOR__INCLUDED_)
#define ONEBLOCKINTERPOLATOR__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COneBlockInterpolator : public CInterpolator
{
public:
	COneBlockInterpolator( int QueueSize, int StackSize );
	// 4 * 16 block + 4 tail * feedrate override ( 200% )
	// constructor

	void ConstantJerkPVTToEx(int fBreakble, double displacement, double from_velocity, double to_velocity, double time );
	// fBreakable       whether current command is breakable by any block in queue.
	//					that is, this command will automatically abort when there
	//					are new commands put into queue.	
	// displacement		position displacement
	// from_velocity	velocity at time 0
	// to_velocity		velocity at time T
	// time				block move time, that is, T.
	// Use threads: motion plan

	void GetSegment( DOUBLE TimeElapse,
					DOUBLE *x_segment,
					DOUBLE *y_segment,
					DOUBLE *z_segment );
	// TimeElapse			current time base
	// x_segment			pointer to store x buffer
	// y_segmennt			pointer to store y buffer
	// z_segmennt			pointer to store z buffer
	// Use threads: interpolation

protected:
	int m_nElementsInQueue;
	// record number of elements in queue

	int m_nCurQueueIndex;
	// index of current command queue

	BOOL m_bNewCmdQueue;
	// if command queue is clear, this flag is TRUE

protected:
	void init( void );
	// init interpolator
};

#endif // !defined(ONEBLOCKINTERPOLATOR__INCLUDED_)
