#if !defined(_QUATERNION_H____INCLUDED_)
#define _QUATERNION_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMatrixN;
class CVector3d;

class CQuaternion
{
public:
	CQuaternion( void );
	// constructor

	CQuaternion( CMatrixN &mat );
	// constructor, given rotation matrix

	CQuaternion( const double angle, const double axis[3] );
	// constructor, given angle and axis

	CQuaternion( const double alpha, const double beta, const double gamma );
	// constructor, given Euler angle with ZXZ rotation

	~CQuaternion( void );
	// destructor

	void SetByAngleAndAxis( const double angle, const double axis[3] = NULL );
	// set quaternion by angle and axis

	void SetByEulerAngleZXZ( const double alpha, const double beta, const double gamma );
	// set quaternion by Euler angle with ZXZ rotation: [gamma] * [beta] * [alpha]

	void SetByRotMat( CMatrixN &Mat );
	// set quaternion by rotation matrix

	void SetByRotMat( const double Rot[9] );
	// set quaternion by rotation matrix
	// the array size must be 3x3

	void SetByArray( const double q[4] );
	// set quaternion by an array

	void Copy( const CQuaternion &q );
	// copy quaternion

	void UpdateAngleAndAxis( void );
	// update angle and axis

	void Normalize( void );
	// normalize

	void GetQuaternion( double q[4] ) const;
	// output quaternion

	double GetAngle( void ) const;
	// return angle

	void GetAxis( double axis[3] ) const;
	// output axis

	void ToRotMat( CMatrixN &Mat ) const;
	// quaternion to rotation matrix

	void ToRotMat( double R[] );
	// quaternion to rotation array R[], row first

	void ToEulerAngleZXZ( double angle[3] ) const;
	// quaternion to ZXZ Euler angle

	void Multiply( const CQuaternion &quat1, const CQuaternion &quat2 );
	// q1 multiplied by q2

	CVector3d Multiply( CVector3d &vec );
	// Multiplying a quaternion q with a vector v applies the q-rotation to v

	void Conjugate( CQuaternion &result );
	// output quaternion conjugate of this quaternion

	void Conjugate();
	// convert this quaternion to conjugate

private:
	double m_q0;
	// quaternion, w

	double m_q1;
	// quaternion, i

	double m_q2;
	// quaternion, j

	double m_q3;
	// quaternion, k

	double m_angle;
	// rotation angle

	double m_iAxis;
	double m_jAxis;
	double m_kAxis;
	// rotation axis
};

#endif // !defined(_QUATERNION_H____INCLUDED_)