#if !defined(_OperationDef_INCLUDE_)
#define _OperationDef_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SIZEOF_SWPOneShotAction		( 19 )
#define NUMOF_SWP_AXIS				( 16 )
#define NUMOF_SWP_Direction			( 2 )
#define DeviceType_Number			( EDT_SVO_NUM + EDT_IO_ENDNUM - EDT_IO_STARTNUM )
#define MAXNUM_OF_OneDeviceType		( SIZE_AxisStore > SIZE_SpindleStore ? SIZE_AxisStore : SIZE_SpindleStore )

enum EDeviceType {
	EDT_AXIS = 0,
	EDT_SPD = 1,
	EDT_SPLCA = 2,
	EDT_ROT = 3,
	EDT_GALVOAXIS = 4,
	EDT_DUAL = 5,
	EDT_SVO_NUM,
	EDT_IO_STARTNUM = 100,
	EDT_IO = 100,
	EDT_EXTIO = 101,
	EDT_IO_ENDNUM,
};

enum EMaxBounds {
	SIZE_CBitCache = 512,
	SIZE_RRegisterCache = 19999,
	NUMOF_MPG = 3,
	NUMOF_ExtMPG = 7,
};

enum EIRQLevel {
		// real-time above drivers.( 0 ~ 96 )
		IRQL_DDA				= 5,
		IRQL_ServoNetDDA		= 16,	// definied in ISvoChannel.h
		IRQL_FineDDA			= 17,	// definied in ISvoChannel.h
		IRQL_FineInterpolation	= 18,	// definied in ISvoChannel.h
		IRQL_MatrixIoScan		= 19,
		IRQL_Interpolation		= 20,
		IRQL_TrajPlan			= 21,
		IRQL_IoScan				= 22,
		IRQL_PLCScan			= 24,
		IRQL_MotionPlan			= 25,
		IRQL_SubInterpolation	= 26,

		// Used by the default Windows CE-based device drivers.( 97 ~ 152 )
		// nothing

		// real-time below drivers.( 153 ~ 247 )
		IRQL_MacroExecuter		= 200,
		IRQL_OpScan				= 201,
		IRQL_PLCNet				= 202,
		IRQL_HouseKeeping		= 240,
		IRQL_Foreground			= 247,

		// non-real-time priorities.( 248 ~ 255 )
		IRQL_HMIWatchDog		= 248,
		IRQL_SriComm			= 249,
		IRQL_DiskALimit			= 250
};

// Software Panel action
enum ESWPAction {
	SWPAction_CStart = 0, // cycle start
	SWPAction_FHold, // feedhold
	SWPAction_1stAxisJOGPos, // 1st Axis jog +
	SWPAction_1stAxisJOGNeg, // 1st Axis jog -
	SWPAction_2ndAxisJOGPos, // 2nd Axis jog +
	SWPAction_2ndAxisJOGNeg, // 2nd Axis jog -
	SWPAction_3rdAxisJOGPos, // 3rd Axis jog +
	SWPAction_3rdAxisJOGNeg, // 3rd Axis jog -
	SWPAction_4thAxisJOGPos, // 4th Axis jog +
	SWPAction_4thAxisJOGNeg, // 4th Axis jog -
	SWPAction_5thAxisJOGPos, // 5th Axis jog +
	SWPAction_5thAxisJOGNeg, // 5th Axis jog -
	SWPAction_6thAxisJOGPos, // 6th Axis jog +
	SWPAction_6thAxisJOGNeg, // 6th Axis jog -
	SWPAction_7thAxisJOGPos, // 7th Axis jog +
	SWPAction_7thAxisJOGNeg, // 7th Axis jog -
	SWPAction_8thAxisJOGPos, // 8th Axis jog +
	SWPAction_8thAxisJOGNeg, // 8th Axis jog -
	SWPAction_9thAxisJOGPos, // 9th Axis jog +
	SWPAction_9thAxisJOGNeg, // 9th Axis jog -
	SWPAction_10thAxisJOGPos, // 10th Axis jog +
	SWPAction_10thAxisJOGNeg, // 10th Axis jog -
	SWPAction_11thAxisJOGPos, // 11th Axis jog +
	SWPAction_11thAxisJOGNeg, // 11th Axis jog -
	SWPAction_12thAxisJOGPos, // 12th Axis jog +
	SWPAction_12thAxisJOGNeg, // 12th Axis jog -
	SWPAction_13thAxisJOGPos, // 13th Axis jog +
	SWPAction_13thAxisJOGNeg, // 13th Axis jog -
	SWPAction_14thAxisJOGPos, // 14th Axis jog +
	SWPAction_14thAxisJOGNeg, // 14th Axis jog -
	SWPAction_15thAxisJOGPos, // 15th Axis jog +
	SWPAction_15thAxisJOGNeg, // 15th Axis jog -
	SWPAction_16thAxisJOGPos, // 16th Axis jog +
	SWPAction_16thAxisJOGNeg, // 16th Axis jog -
	SWPAction_MPGSimu, // MPG simulation
	SWPAction_1stAxisSetMachinePos, // Set 1st Axis machine position
	SWPAction_2ndAxisSetMachinePos, // Set 2nd Axis machine position
	SWPAction_3rdAxisSetMachinePos, // Set 3rd Axis machine position
	SWPAction_4thAxisSetMachinePos, // Set 4th Axis machine position
	SWPAction_5thAxisSetMachinePos, // Set 5th Axis machine position
	SWPAction_6thAxisSetMachinePos, // Set 6th Axis machine position
	SWPAction_7thAxisSetMachinePos, // Set 7th Axis machine position
	SWPAction_8thAxisSetMachinePos, // Set 8th Axis machine position
	SWPAction_9thAxisSetMachinePos, // Set 9th Axis machine position
	SWPAction_10thAxisSetMachinePos, // Set 10th Axis machine position
	SWPAction_11thAxisSetMachinePos, // Set 11th Axis machine position
	SWPAction_12thAxisSetMachinePos, // Set 12th Axis machine position
	SWPAction_13thAxisSetMachinePos, // Set 13th Axis machine position
	SWPAction_14thAxisSetMachinePos, // Set 14th Axis machine position
	SWPAction_15thAxisSetMachinePos, // Set 15th Axis machine position
	SWPAction_16thAxisSetMachinePos, // Set 16th Axis machine position
	SWPAction_1stAxisManualControl, // 1st Axis manual control
	SWPAction_2ndAxisManualControl, // 2nd Axis manual control
	SWPAction_3rdAxisManualControl, // 3rd Axis manual control
	SWPAction_4thAxisManualControl, // 4th Axis manual control
	SWPAction_5thAxisManualControl, // 5th Axis manual control
	SWPAction_6thAxisManualControl, // 6th Axis manual control
	SWPAction_7thAxisManualControl, // 7th Axis manual control
	SWPAction_8thAxisManualControl, // 8th Axis manual control
	SWPAction_9thAxisManualControl, // 9th Axis manual control
	SWPAction_10thAxisManualControl, // 10th Axis manual control
	SWPAction_11thAxisManualControl, // 11th Axis manual control
	SWPAction_12thAxisManualControl, // 12th Axis manual control
	SWPAction_13thAxisManualControl, // 13th Axis manual control
	SWPAction_14thAxisManualControl, // 14th Axis manual control
	SWPAction_15thAxisManualControl, // 15th Axis manual control
	SWPAction_16thAxisManualControl, // 16th Axis manual control
	SWPAction_Reset, // reset
	SWPAction_SingleBlock, // single block
	SWPAction_ModeSelection, // mode selection
	SWPAction_IncFeed, // increment feed
	SWPAction_SpdOverride, // spindle override
	SWPAction_CuttingOverride, // cutting override
	SWPAction_JOGOverride, // JOG override
	SWPAction_RTOverride, // rapid travel override
	Max_NumOfSWP
};

// JOG Action Table
static const ESWPAction g_JOGAction[ NUMOF_SWP_AXIS ][ NUMOF_SWP_Direction ] = {
	{ SWPAction_1stAxisJOGNeg, SWPAction_1stAxisJOGPos },
	{ SWPAction_2ndAxisJOGNeg, SWPAction_2ndAxisJOGPos },
	{ SWPAction_3rdAxisJOGNeg, SWPAction_3rdAxisJOGPos },
	{ SWPAction_4thAxisJOGNeg, SWPAction_4thAxisJOGPos },
	{ SWPAction_5thAxisJOGNeg, SWPAction_5thAxisJOGPos },
	{ SWPAction_6thAxisJOGNeg, SWPAction_6thAxisJOGPos },
	{ SWPAction_7thAxisJOGNeg, SWPAction_7thAxisJOGPos },
	{ SWPAction_8thAxisJOGNeg, SWPAction_8thAxisJOGPos },
	{ SWPAction_9thAxisJOGNeg, SWPAction_9thAxisJOGPos },
	{ SWPAction_10thAxisJOGNeg, SWPAction_10thAxisJOGPos },
	{ SWPAction_11thAxisJOGNeg, SWPAction_11thAxisJOGPos },
	{ SWPAction_12thAxisJOGNeg, SWPAction_12thAxisJOGPos },
	{ SWPAction_13thAxisJOGNeg, SWPAction_13thAxisJOGPos },
	{ SWPAction_14thAxisJOGNeg, SWPAction_14thAxisJOGPos },
	{ SWPAction_15thAxisJOGNeg, SWPAction_15thAxisJOGPos },
	{ SWPAction_16thAxisJOGNeg, SWPAction_16thAxisJOGPos }
};

// Set Machine Position Action Table
static const ESWPAction g_SetMachinePosAction[ NUMOF_SWP_AXIS ] = {
	SWPAction_1stAxisSetMachinePos,
	SWPAction_2ndAxisSetMachinePos,
	SWPAction_3rdAxisSetMachinePos,
	SWPAction_4thAxisSetMachinePos,
	SWPAction_5thAxisSetMachinePos,
	SWPAction_6thAxisSetMachinePos,
	SWPAction_7thAxisSetMachinePos,
	SWPAction_8thAxisSetMachinePos,
	SWPAction_9thAxisSetMachinePos,
	SWPAction_10thAxisSetMachinePos,
	SWPAction_11thAxisSetMachinePos,
	SWPAction_12thAxisSetMachinePos,
	SWPAction_13thAxisSetMachinePos,
	SWPAction_14thAxisSetMachinePos,
	SWPAction_15thAxisSetMachinePos,
	SWPAction_16thAxisSetMachinePos
};

// Manual Control Action Table
static const ESWPAction g_ManualCtrlAction[ NUMOF_SWP_AXIS ] = {
	SWPAction_1stAxisManualControl,
	SWPAction_2ndAxisManualControl,
	SWPAction_3rdAxisManualControl,
	SWPAction_4thAxisManualControl,
	SWPAction_5thAxisManualControl,
	SWPAction_6thAxisManualControl,
	SWPAction_7thAxisManualControl,
	SWPAction_8thAxisManualControl,
	SWPAction_9thAxisManualControl,
	SWPAction_10thAxisManualControl,
	SWPAction_11thAxisManualControl,
	SWPAction_12thAxisManualControl,
	SWPAction_13thAxisManualControl,
	SWPAction_14thAxisManualControl,
	SWPAction_15thAxisManualControl,
	SWPAction_16thAxisManualControl
};

// One-Shot Action Table
static const ESWPAction g_OneShotAction[ SIZEOF_SWPOneShotAction ] = {
	SWPAction_CStart,
	SWPAction_FHold,
	SWPAction_1stAxisSetMachinePos,
	SWPAction_2ndAxisSetMachinePos,
	SWPAction_3rdAxisSetMachinePos,
	SWPAction_4thAxisSetMachinePos,
	SWPAction_5thAxisSetMachinePos,
	SWPAction_6thAxisSetMachinePos,
	SWPAction_7thAxisSetMachinePos,
	SWPAction_8thAxisSetMachinePos,
	SWPAction_9thAxisSetMachinePos,
	SWPAction_10thAxisSetMachinePos,
	SWPAction_11thAxisSetMachinePos,
	SWPAction_12thAxisSetMachinePos,
	SWPAction_13thAxisSetMachinePos,
	SWPAction_14thAxisSetMachinePos,
	SWPAction_15thAxisSetMachinePos,
	SWPAction_16thAxisSetMachinePos,
	SWPAction_Reset
};

enum EActionSource {
	EAS_Default, // default, normal case
	EAS_MMI, // from MMI
	EAS_SWP // from software panel
};

// select sample type of data acquisition
enum EDAQ_SELECT_TYPE {
	NOT_DEFINED = 0,
	POS_CMD = 1,
	POS_FEEDBACK = 2,
	POS_ERROR = 3,
	VEL_CMD = 4,
	VEL_FEEDBACK = 5,
	VEL_ERROR = 6,
	CUR_CMD = 7,
	CUR_FEEDBACK = 8,
	CUR_ERROR = 9,

	MAX_SEL_TYPE,
};

// data type of data acquisition
enum EDAQ_Data_Type {
	DDT_WORD = 0,
	DDT_LONG = 1,
};

// auxiliary signal type
enum EAUX_SIGNAL_TYPE {
	VEL_CHIRP_SIGNAL = 1,
};

enum EParamSaveResult {
	EPSR_Busy = 0,
	EPSR_Finish = 1,
	EPSR_Fail = 2
};

enum ESupportStatus {
	ESS_UNSUPPORT = 0,
	ESS_SUPPORT = 1,
	ESS_YET_UNKNOWN = 2,
};

// Register Servo Channel ID result
enum ERegSvoChIDResult {
	ERSR_Suceess = 0,
	ERSR_Exist = 1,
	ERSR_ArgErr = 2,
};

#endif // _OperationDef_INCLUDE_
