#if !defined(_MODBUSCOMMDEF_INCLUDED_)
#define _MODBUSCOMMDEF_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SIZEOF_MBAPHeader				( 7 )
#define SIZE_MODBUS_BUFFER				( 254 + ( SIZEOF_MBAPHeader - 1 ) )
#define MODBUS_PORT						( 502 )
#define MODBUS_CLIENT_PORT_BASE			( 26100 )
#define MAX_PORTIDX						( 9 )			// 0 ~ 9

#define PORT_MODBUS_TCP					( 9 )
#define PORT_MODBUS_COMM_1				( 1 )		// serial port comm 1
#define PORT_MODBUS_COMM_2				( 2 )		// serial port comm 2
#define PORT_MODBUS_COMM_3				( 3 )		// serial port comm 3


#pragma pack( 1 )

// modbus MBAP header
struct TMBAPHeader {
	WORD TransactionID;		// transaction id
	WORD ProtocolID;		// protocol id
	WORD Length;			// TCP data length
	BYTE UnitID;			// unit id
};

#pragma pack()

enum EModbusResult{
	EMR_OK,
	EMR_Wait,
	EMR_PortNotOpen,
	EMR_SendMsgFail,
	EMR_RecvMsgFail,
	EMR_WriteFailed,
	EMR_ReadFailed,
	EMR_ReadEmpty,
	EMR_CrcGenFail,
	EMR_CrcNotMatch,
	EMR_DeviceIdNotMatch,
	EMR_FunctionCodeNotMatch,
	EMR_HasErrorCode,
	EMR_BufferOverflow,
	EMR_NotImplemented,
	EMR_Undefined,
};

#endif
