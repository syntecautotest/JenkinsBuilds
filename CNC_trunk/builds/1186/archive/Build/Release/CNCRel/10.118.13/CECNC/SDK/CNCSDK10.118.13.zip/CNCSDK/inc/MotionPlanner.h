#if !defined(_MOTIONPLANNER_H____INCLUDED_)
#define _MOTIONPLANNER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAsynQueue;
class CLANodePool;

class CMotionPlanner : public IMotionPlanner, public IListener
{
public:
	CMotionPlanner( IFuncCallHandler *pFuncCallHandler, unsigned QueueSize, unsigned StackSize, int nEventCoordID, CLANodePool *pLAPool );
	// constructor

	virtual ~CMotionPlanner( void );
	// destructor

public:
	virtual BOOL isReady( void );
	// is ready

	virtual BOOL isIdle( void );
	// is idle

	virtual BOOL isAtStartPoint( void );
	// is at start point

	virtual BOOL isAtEndPoint( void );
	// is at end point

	BOOL isStop( void );
	// is stop

	BOOL isBlockStop( void );
	// is block stop

	BOOL isExecutingMotCode( void );
	// is executing motion code

	virtual BOOL isReadyForRecord( void );
	// is ready for record, this function is used for record mode

public:
	virtual void Start( void );
	// cycle start

	virtual void notifyBStopRequest( void );
	// b stop request

	virtual BOOL notifyChangeMotionMode( BOOL bForward );
	// protect one timebase is positive and the other is negative
	// check the double link list is safe when change motion mode

	virtual BOOL NotifyWaitRequest( void );
	// notify wait request

public:
	virtual void putExactStop( void );
	// put exact stop

	virtual void putEOBMark( const TPacketInfo &PacketInfo );
	// put EOB mark

	virtual void putFuncCallInfo( TPacketInfo &PacketInfo, const EFUNCID nFuncCallID, EStopType nStopType, BOOL bFlag );
	// put function call information

	virtual void TrajPlanTick( void ) {}
	// trajectory plan tick

	virtual void MotionPlanTick( void ) {}
	// motion plan tick

	virtual void getRemainDisplacement( double displacement[] );
	// get remain displacement

	virtual long getGCodeMode( void );
	// get G code mode

	virtual int getMotionMode( void ) const;
	// get motion mode

	virtual double getRemainTime( void );
	// get interpolation remain time

	virtual void get_SnapshotQueTime( long *lpdwRaw, long *lpdwMature ) {}
	// to get remain queue time inside queue.

protected:
	virtual void Reset( void );
	// reset

	virtual void Abort( void );
	// abort

	virtual BOOL ExecuteFuncCall( double Timebase, BOOL bMovement );
	// execute func call
	// return TRUE: skip while-loop of this motion planner
	// return FALSE: do while-loop continuously

	virtual BOOL ExecuteNextMicroCode( void );
	// execute next micro code
	// return FALSE: next micro code is NULL

	virtual BOOL ExecuteLastMicroCode( void );
	// execute last micro code
	// return FALSE: last micro code is NULL

	virtual void PutFuncCall( const EFUNCID FuncID, long lpvarArgs[] = NULL, int cArgs = 0, EStopType nStopType = EST_Stopless, const TPacketInfo *pPacketInfo = NULL ) = 0;
	// put function call to LANode

	virtual void HandleFuncCall( TMotReqPkt *pMRP );
	// handle func call from MRP to LANode

	virtual void HandleMOTOP( TMotReqPkt *pMRP ) {};
	// handle motion opcode from MRP to LANode

	virtual void IssueFuncCall( TLANode *pNode );
	// issue func call from LANode to MicroCode

	virtual void IssueMOTOP( TLANode *pNode ) {};
	// issue motion opcode from LANode to MicroCode

	void writeMicroCode( int ClassID, int Opcode, long lParam[], int nCount );
	// write micro code into main tape

	void writeMicroCode( int ClassID, int Opcode, long lParam = 0, long lParam2 = 0, long lParam3 = 0, long lParam4 = 0 );
	// write micro code into main tape

	void writeMicroCode( int ClassID, int Opcode, double duration, double AX[], const TQuaternionInfo *pQInfo = NULL, const TFiveAxisData *pFData = NULL );
	// write micro code into main tape

	void writeMicroCode( int ClassID, int Opcode, const TPacketInfo &PacketInfo );
	// write micro code into main tape

	void writeMicroCode( int ClassID, int Opcode, double duration, double AX[], double EntryAX[] );
	// write micro code into main tape

	double calcElapse( double &Timebase );
	// calculate elapse ,and update the value of Timebase and m_NowTimeCursor

	virtual void UpdateRemainDisp( double displacement[], BOOL bPlus );
	// update remain displacement

	BOOL IsOverlapAvailable( double RemainDis );
	// Is overlapping available?

	void putWPInfo( long *Para );
	// put work plane information

protected:
	CRTMutex m_cs;

	IFuncCallHandler *m_pFuncCallHandler;
	// func call handler

	CAsynQueue *m_pCommandQueue;
	// command queue

	TMicroCode *m_pNowTapeHead;
	// tape head

	CLANodePool *m_pLAPool;
	// free look ahead node pool

	double m_NowTimeCursor;
	// now time cursor

	double m_TimeInQueue;
	// time in queue

	BOOL m_fAtEnd;
	// at end

	BOOL m_fAtStart;
	// at start

	double m_RemainDisp[NUMOF_AXIS];
	// remain displacement

	long m_GCodeMode;
	// G code mode

	int m_MotionMode;
	// motion mode

	int m_nEventCoordID;
	// is in event trigger

	double m_OverlapLength;
	// overlap length

	BOOL m_bOverlapEnabled;
	// overlap enabled

	BOOL m_bOnProcessReset;
	// flag for whether on process reset

	enum EBlockStopState {
		EBSS_Normal,
		EBSS_Deceleration,
		EBSS_WaitBStop,
		EBSS_BStop
	} m_nBlockStopState;
	// block stop state

	enum EStopState {
		ESS_Normal,
		ESS_Stop
	} m_nStopState;
	// stop state

public:
	void *PeekTrajEnd( void );
	// peek next TrajEnd

protected:
	BOOL m_bBStopRequest;
	// b stop request

	BOOL m_bFeedholdRequest;
	// feedhold request

	long m_nInterpolationTimeBase;
	// interpolation timebase

	long m_nMotionPlanTimeBase;
	// MotionPlan timebase
};
#endif // !defined(_MOTIONPLANNER_H____INCLUDED_)
