// ParamStore.h: interface for the CParamStore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PARAMSTORE_H__17F46A24_37B8_4118_AD39_B401225B27C8__INCLUDED_)
#define AFX_PARAMSTORE_H__17F46A24_37B8_4118_AD39_B401225B27C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "IParamListener.h"

class CArchiveManager;
class CLineMap;
class CGuardRegistry;

class CParamStore
{
public:
	CParamStore( void );
	virtual ~CParamStore( void );

public:

	enum EMaxBounds {
		SIZEOF_DBParameter = 10240,
		MAX_TITLELEN = 256,
		SIZE_ListenerTable = 50,		// Required: API*1 + Op*1 + Sys*1 + Axis*16 + Coord*4 + Spd*6 + ...
	};

	struct TParamSchema {
		LONG			Min;
		LONG			Max;
		LONG			Default;
		CHAR			Title[ MAX_TITLELEN ];
	};

	BOOL putSchema( LONG no, TParamSchema *pSchema, INT size );
	// put parameter schema
	// return TRUE when success, otherwise return FALSE

public:
	BOOL AssociatePersistent( CHAR *root, CHAR *path, CHAR *function, CHAR *name, INT size = SIZEOF_DBParameter );
	// associate persistent storage

	void setListener( IParamListener *pListener );
	// set event handler

	void removeListener( IParamListener *pListener );
	// remove event handler

	void EndOfDefinition( void );
	// end of load definition

	INT IsExist( LONG no );
	// query whether there is the paramter no ?
	// return	TRUE		when the parameter exist
	//			FALSE		when the parameter not exist

	INT NumOfParameter( void );
	// get the number of parameter

	LONG GetNo( INT index );
	// get parameter no from sorted index

	CHAR *LookupTitle( LONG no, CHAR *buffer, INT count );
	// get parameter title

	LONG LookupMax( LONG no );
	// lookup maximum value

	LONG LookupMin( LONG no );
	// lookup minimum value

	LONG LookupDefault( LONG no );
	// lookup default value

	LONG GetValue( LONG no );
	// get parameter value

	void PutValue( LONG no, LONG value );
	// put parameter value

	INT GetVersion( void );
	// get registry format version

	void GetModifiedTime( SYSTEMTIME *t );
	// get modification time

	INT ImportFrom( CHAR *lpLocation );
	// import data into registry from specified location
	// return TRUE when successful, return FALSE when failure.

	INT ExportTo( CHAR *lpLocation );
	// export data from registry to specified location
	// return TRUE when successful, return FALSE when failure.

private:

	static INT __cdecl compare_IndexToNo( const void *arg1, const void *arg2 );
	// compare function for index-to-no Table sorting and searching

	CLineMap *m_pParamSpec;
	// parameter specification data base

	INT m_NumOfParameter;
	// the number of parameter been defined

	INT m_NumOfDBParameter;
	// the number of data base parameter been defined

	LONG *m_IndexToNoTable;
	// the table of index-to-no mapping

	IParamListener *m_pListenerTable[ SIZE_ListenerTable ];
	// associated event handler

	INT m_ListenerTableCount;
	// the number of data in event listener table

	CGuardRegistry *m_pRegistry;
	// value storage
};

#endif // !defined(AFX_PARAMSTORE_H__17F46A24_37B8_4118_AD39_B401225B27C8__INCLUDED_)
