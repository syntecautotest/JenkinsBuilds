// Trajectory.h: interface for the CTrajectoryThread9 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTrajectoryThread9_H__85B84D2F_E947_459E_AD27_FF6F9ACDA9B3__INCLUDED_)
#define AFX_CTrajectoryThread9_H__85B84D2F_E947_459E_AD27_FF6F9ACDA9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTrajectoryThread :public CTrajectory
{
public:
	CTrajectoryThread();
	// constructor

	~CTrajectoryThread();
	// destructor

	void BellShapedAcceleration( TPVTSheet *pPVT, double P, double V0, double Vc, double Vref1, double Vref2, double Ts, double Amax, double Ta );
	// do bell-shape acceleration trajectory planning, when Amax is greater than zero, then use fix slope planning, if Amax is zero, then use Ta
	// as acceleration time for fix time planning, when Amax is not zero, Ta will not be use, please set it to zero.
	// pPVT		[out] pointer to PVT segment buffer.
	// P		[in] the total compound displacement, in BLU.
	// V0		[in] block start velocity, in BLU / micro-second.
	// Vc		[in] end corner velocity, in BLU / micro-second.
	// Vref1	[in] block reference velocity in the begin.
	// Vref2	[in] block reference velocity in the end.
	// Ts		[in] bell-shaped acceleration time, in micro-second.
	// Amax		[in] maximum compound feedrate, in BLU / (micro-second ^ 2). use fix slope trajectory when Amax is not zero.
	// Ta		[in] acceleration time of fix time trajectory, in micro-second. use fix time trajectory when Amax is zero.

	void genAcceleration( TPVTSheet *pPVT, double Vbegin, double Vend, double P, double Ts, double Ta );
	// to generate acceleration trajectory
	// pPVT		[out] pointer to PVT segment buffer.
	// Vbegin	[in] block velocity at begin, in BLU / micro-second
	// Vend		[in] block velocity at end, in BLU / micro-second
	// P		[in] startup distance
	// Ts		[in] bell-shaped acceleration time, in micro-second.
	// Ta		[in] acceleration time of fix time trajectory, in micro-second. use fix time trajectory when Amax is zero.

private:
	BOOL genBellShaped( TPVTSheet *pPVT, double P, double V0, double Vc, double Vref1, double Vref2, double Ts, double Amax, double Ta );
	// generate bell-shape acceleration trajectory
	// pPVT		[out] pointer to PVT segment buffer.
	// P		[in] the total compound displacement, in BLU.
	// V0		[in] block start velocity, in BLU / micro-second.
	// Vc		[in] end corner velocity, in BLU / micro-second.
	// Vref1	[in] block reference velocity in the begin.
	// Vref2	[in] block reference velocity in the end.
	// Ts		[in] bell-shaped acceleration time, in micro-second.
	// Amax		[in] maximum compound feedrate, in BLU / (micro-second ^ 2). use fix slope trajectory when Amax is not zero.
	// Ta		[in] acceleration time of fix time trajectory, in micro-second. use fix time trajectory when Amax is zero. 
	// return TRUE, when successful, return FALSE, when failure

	void calcAccelerationFeature( double &P, double Vbegin, double Vend, double &Ts, double Amax, double &Ta );
	// to calculate acceleration feature: distance, acceleration time, and bell-shaped acceleration time.
	// P		[out] startup/stop-down displacement, in BLU.
	// Vbegin	[in] velocity at begin, in BLU / micro-second.
	// Vend		[in] velocity at end, in BLU / micro-second.
	// Ts		[in,out] bell-shaped acceleration time, in micro-second.
	// Amax		[in] maximum compound feedrate, in BLU / (micro-second ^ 2). use fix slope trajectory when Amax is not zero.
	// Ta		[in,out] acceleration time of fix time trajectory, in micro-second. use fix time trajectory when Amax is zero. 
};

#endif // !defined(AFX_TRAJECTORY_H__85B84D2F_E947_459E_AD27_FF6F9ACDA9B3__INCLUDED_)
