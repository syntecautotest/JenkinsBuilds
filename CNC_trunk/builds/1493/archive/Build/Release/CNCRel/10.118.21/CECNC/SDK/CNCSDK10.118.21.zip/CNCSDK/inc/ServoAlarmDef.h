#if !defined(AFX_SERVOALARMDEF_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_)
#define AFX_SERVOALARMDEF_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// alaram flag bit-mask
#define	ALARM_NoError						0L
#define	ALARM_SvoEncoderSignalError			0x00000001
#define	ALARM_SvoErrorCounterOverflow		0x00000002
#define	ALARM_SvoEncoderModuloError			0x00000004
#define	ALARM_SvoNoIndexInterrupt			0x00000008
#define ALARM_SvoDDACommandOverflow			0x00000010
#define ALARM_SvoPowerStatusError			0x00000020
#define ALARM_SvoPowerOff					0x00000040
#define ALARM_SvoLossPulse					0x00000080
#define ALARM_SvoServoAlarm					0x00000100
#define ALARM_QueueSafityAlarm				0x00000200
#define ALARM_CANopenCommunicationError		0x00000400
#define ALARM_CANopenHomeSearchError		0x00000800
#define ALARM_AutoTuningFailed				0x00001000
#define ALARM_SvoChannelAmountExceed		0x00002000
#define ALARM_SerialParamWriteFail			0x00004000
#define ALARM_AbsEncoderReset				0x00008000
#define ALARM_SaveParamUnderServoON			0x00010000
#define ALARM_IncEncoderUsageError			0x00020000
#define ALARM_AbsEncoderFailure				0x00040000
#define ALARM_TorqueOptionMismatch			0x00080000
#define ALARM_AbsEncoderMultiTurnClear		0x00100000
#define ALARM_SoftVerNotSupported			0x00200000
#define ALARM_EncUpdateFinished				0x00400000
#define ALARM_EncInfoReadTimeout			0x00800000

#endif// (AFX_SERVOALARMDEF_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_)