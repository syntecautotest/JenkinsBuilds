#if !defined(AFX_MIXTILTINGTYPE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_)
#define AFX_MIXTILTINGTYPE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_

class CMixTiltingType : public CFiveAxisMechanism
{
public:
	CMixTiltingType( INT nID );
	// constructor

	virtual ~CMixTiltingType( void );
	// destructor

	void SetOffset( double FirstOffset[], double SecondOffset[] );
	// FirstOffset = ToolHolderToMaster
	// SecondOffset = MachineToSlave

	void UpdateConstOffset( void );
	// set const offset

	BOOL IsValidSetting( void );
	// is valid setting for five axis

	void Kinematic( CVector3d &ToolTipPosition, double MasterRotAngle, double SlaveRotAngle, const CVector3d &ControlPoint );
	// Kinematic transformation for Mix Tilting Type Machine
	// Compute Tool Tip Position
	// unit : BLU
	// right hand side

	int InverseKinematic( const CVector3d &ToolTipPosition, double MasterRotAngle, double SlaveRotAngle, CVector3d &ControlPoint );
	// Inverse Kinmatic transformation for Mix Tilting Type Machine
	// Compute  WorkPieceToMaster
	// unit : BLU
	// right hand side
	
	int InverseKinematic( CVector3d ToolTipPosition, CVector3d FeedDirection, double LastMasterRotAngle, double LastSlaveRotAngle, CVector3d &ControlPoint, double &MasterRotAngle, double &SlaveRotAngle, double ToolLength );
	// Inverse Kinmatic transformation for Mix Tilting Type Machine
	// Given Tool Tip Position and Feed Direction and last rotate angle
	// Compute  ControlPoint and RotateAngle
	// unit : BLU
	// right hand side

	INT ComputeRotateAngle( CVector3d FeedDirection, DOUBLE LastMasterRotAngle, DOUBLE LastSlaveRotAngle, DOUBLE &MasterRotAngle, DOUBLE &SlaveRotAngle, EFiveAxSolType type = EST_ShortestDist );
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle
	// unit : BLU
	// right hand side

	void GetToolCoordUnderMachineCoord( double MasterAngle, double SlaveAngle, CMatrix3d &ToolCoord, EToolCoordType Type );
	// get tool coord
	// right hand side

	void MStoIJK( double MasterAngle, double SlaveAngle, CVector3d *RotAxis );
	// convert (M,S) to (I,J,K)
	// right hand side

private:
	void SetConstVecMasterToToolTip( void );
	// set const vector m_ConstVecMasterToToolTip

	void SetConstVecHolderToMaster( void );
	// set const vector m_ConstVecHolderToMaster

private:
	CVector3d m_ToolHolderToMaster;
	// the vector from tool holder to master axis

	CVector3d m_MachineToSlave;
	// the vector from slave axis to workpiece

	CVector3d m_ConstVecMasterToToolTip;
	// const vector from master to tool tip

	CVector3d m_ConstVecHolderToMaster;
	// const vector from holder to master

public:
	void CalcInvJacobian( CQuickMatrixN &InvJa, DOUBLE ToolTipPosition[], DOUBLE MasterRotAngle, DOUBLE SlaveRotAngle );
	// calculate inverse jacobian
	// input : BCS, IU, rad, RHS
	// output: MCS, IU, rad, RHS
};

#endif
