// IAlarmStore.h: interface for the IAlarmStore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IALARMSTORE_H__C51BA6FC_BAFB_4439_A296_5F99C515DBD1__INCLUDED_)
#define AFX_IALARMSTORE_H__C51BA6FC_BAFB_4439_A296_5F99C515DBD1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef TOCALARMINFO_STRUCT_
#define TOCALARMINFO_STRUCT_

typedef struct {
	WORD		ClassID;
	WORD		ObjectID;
	WORD		AlarmID;
	SYSTEMTIME	Time;
	TCHAR		HintText[80];
} TOcAlarmInfo;
// alarm information data
#endif // TOCALARMINFO_STRUCT_

#ifndef _IALARMSTORE_INTERFACE_
#define _IALARMSTORE_INTERFACE_

class IAlarmStore  
{
public:
	virtual ~IAlarmStore( void ) {}
	// destructor

	virtual void GetAlarmList( /*[out]*/ TOcAlarmInfo *pAlarmList, /*[in]*/ long nSizeToRead, /*[out]*/ long *lpSizeRead ) = 0;
	// to get all alarm list

	virtual long FindFirst( TOcAlarmInfo *pAlarmInfo ) = 0;
	// If successful, FindFirst return a unique search handle identifying,
	// which can be used in a subsequent call to FindNext. Otherwise
	// FindFirst return �V1.

	virtual int FindNext( long handle, TOcAlarmInfo *pAlarmInfo ) = 0;
	// If successful, return 0. Otherwise, they return �V1.

	virtual long getCount( void ) = 0;
	// get alarm count

	virtual void ForceReNotifyAlarm( void ) = 0;
	// force re-notify alarm

	virtual BOOL isAlarmDirty( void ) = 0;
	// is alarm dirty
};

#endif // _IALARMSTORE_INTERFACE_

#endif // !defined(AFX_IALARMSTORE_H__C51BA6FC_BAFB_4439_A296_5F99C515DBD1__INCLUDED_)
