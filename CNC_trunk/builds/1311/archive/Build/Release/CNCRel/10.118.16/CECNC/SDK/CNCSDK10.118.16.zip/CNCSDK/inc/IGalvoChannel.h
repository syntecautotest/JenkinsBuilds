#if !defined(_IGALVOCHANNEL_H_INCLUDED_)
#define _IGALVOCHANNEL_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IGalvoChannel
{
public:
	virtual ~IGalvoChannel( void ) {}
	// destructor

	virtual void CNCAPI PutPositionCommand( long *pPulse ) = 0;
	// put position command, unit: count

	virtual void CNCAPI setDelayCount( int nCount ) = 0;
	// set laser delay count

	virtual void CNCAPI enableDelayQueue( BOOL bEnable ) = 0;
	// enable delay queue

	virtual long CNCAPI ReadRealPosition( void ) = 0;
	// read absolute counter

	virtual void CNCAPI SetServoOn( BOOL bOn ) = 0;
	// set servo ON/OFF

	virtual void CNCAPI PutFineDDACount( long nFineDDACount ) = 0;
	// put fine DDA count

	virtual void CNCAPI SetGalvoServoOn( BOOL bOn ) = 0;
	// set galvo module servo ON/OFF

	virtual BOOL CNCAPI GetGalvoServoState( void ) = 0;
	// get galvo module servo ON/OFF state

	virtual BOOL CNCAPI GalvoHomeSetting( void ) = 0;
	// clear galvo module absolute count, not clear yet when return FALSE
};

#endif // _IGALVOCHANNEL_H_INCLUDED_
