#if !defined(_ROBOTWAITSIGNALMANAGER_H____INCLUDED_)
#define _ROBOTWAITSIGNALMANAGER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRobotWaitSignalManager
{
//--------------------------------------------------functions--------------------------------------------------
public:
	CRobotWaitSignalManager( void );
	// constructor

	~CRobotWaitSignalManager( void );
	// destructor

	void writeWaitSignalInfo( TRobotMRP *pCurRobotMRP, TRobotMRP *pNextRobotMRP );
	// write ROBOT wait signal information into RobotMRP

	void setWaitSignalInfoByRMRP( TWaitSigInfo *OvlWaitSigInfo, double *OverlapStartTime );
	// set ROBOT wait signal information by OvlWaitSigInfo in RobotMRP

	void setWaitSignalInfoByFuncCall( long lParam[ IFuncCallHandler::MAX_NumOfArg ] );
	// set ROBOT wait signal information by function call

	void processWaitSignal( void );
	// process ROBOT wait signal function

	void judgeWaitSignalState( double elapse, double NowTimeCursor );
	// determining ROBOT wait signal state

	void StartCountWaitTime( void );
	// start to count wait time

	BOOL isWaitingSignal( void );
	// signal is waiting or not

	void Reset( void );
	// reset

	void Abort( void );
	// abort

private:
	BOOL setWaitSignalInfo( long lParam[ IFuncCallHandler::MAX_NumOfArg ] );
	// set ROBOT wait signal information

	BOOL isSignalConditionMatch( void );
	// is siganl condition match according to the user setting

//--------------------------------------------------variables--------------------------------------------------
private:
	TWaitSigInfo m_WaitSigInfo;
	// packed info. of the signal

	double m_WaitSigStartTime;
	// wait signal start time

	BOOL m_bWaitSignalStandby;
	// flag for wait signal standby for the WaitSigStartTime arrive

	BOOL m_bWaitSignal;
	// wait siganl state

	BOOL m_bCountWaitTime;
	// flag to start counting wait time

	int m_nSigLastTime;
	// counter of the signal lasting time (usec)

	int m_nSigWaitTime;
	// counter of the signal waiting time (usec)

	long m_nTimeBase;
	// interpolation time base (usec)
};

#endif // !defined(_ROBOTWAITSIGNALMANAGER_H____INCLUDED_)
