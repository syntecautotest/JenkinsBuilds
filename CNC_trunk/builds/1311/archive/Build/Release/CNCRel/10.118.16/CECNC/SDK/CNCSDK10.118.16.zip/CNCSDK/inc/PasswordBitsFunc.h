// CPasswordBitsFunc.h: interface for the Bits function class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PASSWORDBITSFUNC_H__E9D92FBB_75C0_49A9_B15B_5962A0D48C52__INCLUDED_)
#define AFX_PASSWORDBITSFUNC_H__E9D92FBB_75C0_49A9_B15B_5962A0D48C52__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPasswordBitsFunc
{
public:
	CPasswordBitsFunc();
	// constructs a CPasswordBitsFunc class

	virtual ~CPasswordBitsFunc();
	// destructs this object

	unsigned short CRC16(unsigned char *puchMsg, unsigned short usDataLen);
	// help function for do CRC check

	void DES_CRC16(unsigned char *source, unsigned char *result, unsigned short usDataLen);
	// help function for do CRC check

	void BitsArrayToText( unsigned char *source , unsigned char *result , int sourceCharsLen, int resultCharsLen);
	// prase bits array (from DES encode message) to Text chars ( using 32 chars table)

	void TextToBitsArray( unsigned char *source , unsigned char *result , int sourceCharsLen, int resultCharsLen);
	// merge Text chars ( using 32 chars table) to bits array (using DES to decode this message)

	void BitsArrayToText( char *TextTable, unsigned char *source , unsigned char *result , int sourceCharsLen, int resultCharsLen);
	// prase bits array (from DES encode message) to Text chars ( using 32 chars table)

	void TextToBitsArray( char *TextTable, unsigned char *source , unsigned char *result , int sourceCharsLen, int resultCharsLen);
	// merge Text chars ( using 32 chars table) to bits array (using DES to decode this message)

	long getBitsValue( unsigned char *bitData , int nStartPos, int nBitsLength);
	// get partial bit data 

	void putBitsValue( unsigned char *bitData , long bitValue, int startPos, int bitsLength);
	// put partial bit data 

private:	
	char *TextTable;

};

#endif // !defined(AFX_PASSWORDBITSFUNC_H__E9D92FBB_75C0_49A9_B15B_5962A0D48C52__INCLUDED_)

