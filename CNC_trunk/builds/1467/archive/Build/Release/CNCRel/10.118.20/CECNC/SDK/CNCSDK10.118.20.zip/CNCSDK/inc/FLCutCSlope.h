#if !defined(_FLCUTCSLOPE_H____INCLUDED_)
#define _FLCUTCSLOPE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCurvatureCalculator;
class CArcFeature;

class CFLCutCSlope : public CFeedLimit
{
public:
	CFLCutCSlope( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool, CBPTLimiter *pBPTLimiter );
	// constructor

	~CFLCutCSlope( void );
	// destructor

	void putGeomAxis( const int XAxis, const int YAxis, const int ZAxis );
	// to put geometry axis index

	void putLookAheadCondition( const double ChordErrorTol, const double CornerFeedrate, const double ArcRefRadius, const double ArcRefFeedrate );
	// set maximum allowable feedrate for motion block movement
	// chord error tolerance, in IU
	// corner feedrate at 120 degree, in IU / us
	// arc reference radius and reference feedrate, in IU, and IU / us

public:
	BOOL IsEmpty( void );
	// query whether the pipe is empty

	void Abort( void );
	// abort

	void Reset( void );
	// reset

	void PutLANodeToCurvPart( TLANode *pNode );
	// put look ahead node to curvature part of feed limit module

	void CalcBlockLength( TLANode *pNode, CArcFeature &af );
	// calculate block length.

	void GetLengthAccumulator( DOUBLE &lengthAccumulator );
	// Get Length Accumulator and reset LengthAccumulator

	int getCountOfCCQue( void );
	// get count in C.C. Queue

	int getNumBPTLimtedBlock( void );
	// get number of blocks that their feedrates are limited BPT Limiter

	void FlushAllQueue( void );
	// flush queued nodes of feed limit module

	void NotifyNoCorner( BOOL bflag );
	// notify if corner existed

protected:
	TLANode *ReversePeek( void );
	// peek the last node in feed limit module

	virtual void CalcBlockMotionFeature( TLANode *pNode, CArcFeature &af );
	// calculate block motion feature

	void ClampBlockAccByAxisAcc( TLANode *pNode );
	// clamp block acceleration by maximum axis acceleration

	void ClampBlockAccByCompoundAcc( TLANode *pNode );
	// clamp block acceleration by compound acceleration

	void ClampArcBlockFeedrateBy408( TLANode *pNode, CArcFeature &af );
	// clamp arc block feedrate by parameter 408

	virtual void CalcCornerFeature( TLANode *pNode, double &eLastVc );
	// to calculate inter-block feature

	void ClampByBPTLimiter( TLANode *pNode );
	// clamp feedrate by BPT Limiter

	void ClampLinearBlockFeedrateBy408( TLANode *pNode );
	// clamp linear block feedrate by parameter 408

	BOOL CalculateCornerDeviation( TLANode *pNode, TLANode *pLNode, double &eDeviationLen, double eDeviation[] );
	// calculate corner deviation and its length

	void ClampCornerFeedrateBy406( TLANode *pNode, double eDeviationLen );
	// clamp corner feedrate by parameter 406

	void ClampCornerFeedrateByAxis406( TLANode *pNode, double eDeviation[] );
	// clamp corner feedrate by maximum feedrate difference of each axis

	virtual void ClampCornerFeedrateByBlockFeedrate( TLANode *pNode, TLANode *pLNode );
	// clamp corner feedrate by block feedrate

	int GetNumLimitedBlock( void );
	// debug data 375, shows the num of blocks that are limited by BPTLimiter

protected:
	CCurvatureCalculator *m_pCurvatureCalculator;
	// curvature calculator object pointer

	CBPTLimiter *m_pBPTLimiter;
	// BPT Limiter pointer

	int m_nNumLimitedBlock;
	// records the number of blocks that are limited by BPT Limiter

private:
	DOUBLE m_LengthAccumulator;
	// Length Accumulator
};

#endif // !defined(_FLCUTCSLOPE_H____INCLUDED_)
