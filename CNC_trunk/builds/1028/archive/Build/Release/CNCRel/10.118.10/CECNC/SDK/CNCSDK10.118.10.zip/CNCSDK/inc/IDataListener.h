#if !defined(_IDATALISTENER_INCLUDE_)
#define _IDATALISTENER_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IDataListener : public IListener
{
public:
	virtual ~IDataListener() {}

	virtual void Init( INT nQueueLen = LEN_DEFAULT_QUEUE, INT nPackLen = LEN_DEFAULT_BUFF_PACK ) = 0;
	// init the variable and set buffer size

	virtual void Deinit() = 0;
	// free all buffer

	virtual BOOL RegisterEvt( TEvtInfo tEvtInfo, TCatchInfo tCatchInfo, BOOL bCritical = FALSE ) = 0;
	// register infomation to record info list

	virtual BOOL UnregisterEvt( TEvtInfo tEvtInfo, TCatchInfo tCatchInfo ) = 0;
	virtual void UnregisterAllEvt() = 0;
	// unregister infomation from record info list

	virtual void DumpBufferData( BYTE* byte, const int nInSize, int* nReadSize ) = 0;
	// dump and clear data from buffer

	virtual void ResetWatchDogTick() = 0;
	// reset watch dog tick

	virtual BOOL IsUsed() = 0;
	// whether being used in somewhere

	virtual BOOL IsCriticalOccurred() = 0;
	// wether critical evt data being recoreded

	virtual void ClearRecordQueue() = 0;
	// clear data queue
};

#endif // !defined(_IDATALISTENER_INCLUDE_)

