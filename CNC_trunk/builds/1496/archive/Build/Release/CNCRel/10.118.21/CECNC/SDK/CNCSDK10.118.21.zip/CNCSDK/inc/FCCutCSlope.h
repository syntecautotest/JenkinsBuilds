#if !defined(_FCCUTCSLOPE_H____INCLUDED_)
#define _FCCUTCSLOPE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFCCutCSlope : public CFeedControl
{
public:
	CFCCutCSlope( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool, BOOL bDumpData = TRUE );
	// constructor

	virtual ~CFCCutCSlope( void );
	// destructor

	int getCntQueueNotMature( void );
	// get count of call of FlushImmatureNodes() called, this means the CPU power is not engogh for normally flush mature queue
	// debug data 376, shows immature queue flush counts

protected:
	virtual void onBeginDispatchBlock( BOOL bForceFlush = TRUE );
	// trajectory planning tick call back

	void NotifyDecToZero( void );
	// notify decelerate to zero

	void FlushMatureNodes( int count );
	// flush specified number of nodes inside raw queue into mature queue

	virtual void ForwardElimination( int nStartIndex, int nEndIndex, double tmpVc );
	// do forward singular block elimination

	virtual BOOL NormalFlushRawQueueNodes( int &nCount );
	// normally flush raw queue nodes

	virtual int rSearchMatureBlock( double &tmpVc );
	// to search the first mature block in reverse order

	virtual void BackwardElimination( int nPos, double tmpVc );
	// backward singular block elimination

	virtual BOOL PseudoBackwardElimination( int nStartIndex, int nEndIndex, double &tmpVc, BOOL bStopInMature, int &nMatureIndex );
	// pseudo backward singular block elimination, return TRUE if the block of nStartIndex is clamped down

	virtual void FlushImmatureNodes( int nFlushCount );
	// flush immature node of specified number of count from raw queue.
	// count	the number of node count to be release

protected:
	int m_nCntQueueNotMature;
	// shows the count that FlushImmatureNodes() is called, dump debug data No. 376
};

#endif // !defined(_FCCUTCSLOPE_H____INCLUDED_)
