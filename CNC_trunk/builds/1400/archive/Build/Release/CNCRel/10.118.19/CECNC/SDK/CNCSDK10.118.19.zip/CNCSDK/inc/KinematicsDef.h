#if !defined(_KinematicsDef_H____INCLUDED_)
#define _KinematicsDef_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Tolreance for five axis kinematics transform choose solution
#define FIVEAXIS_SOL_TOL			( CZMath::EPSILON_double * 1.0e14 )

// define robot solution domain related
#define NUMOF_SOLUTION_DOMAIN		( 3 ) // please reference to enumeration ESolutionType
#define SOLUTION_DOMAIN_EPSILON		( 1.0e-1 ) // for length: 1.0e-1 mm, for angle: 1.0e-1 radian
#define REACHABLE_EPSILON			( 1.0e-9 ) // 1.0e-9 * (total robot arm length)
#define JOINT_EPSILON				( 1.0e-9 ) // for length: 1.0e-9 mm, for angle: 1.0e-9 radian

// define number of coupling ratio
#define NUMOF_COUPLING_TABLE		( 10 )
#define NUMOF_CONST_COUPLING_TABLE	( 5 )

#define NUMOF_ROBOT_JOINT			( 12 )
// in serial robots, the max. joint number is 8 ( H4L1_A ), but 12 is set because of the parallel robots ( Delta robots ),
// generally, F.K. variable "CrdAll" should be ( ( joint number + 1 ) * 3 ) in serial robots,
// however, in Delta robot, "CrdAll" should be 39 ( joint number = 4 for Delta ),
// for the sake of modularization, we set this parameter to 12 because 39 = ( 12 + 1 ) * 3

// for different robot types but sharing the same Robot{Name}.cpp
// some robots have two or more different axis types, such as Delta robots
enum ERobotAxisType {
	DEFAULT_AXIS_TYPE = 0, // default type
	THREE_AXIS_TYPE = 3,
	FOUR_AXIS_TYPE = 4,
};

// defines joint types
enum EJointType {
	DUMMY_JOINT,
	REVOLUTE_JOINT,
	PRISMATIC_JOINT,
	BALL_SCREW_SPLINE_JOINT,
	UNDERACTUATED_R_JOINT,	// under-actuated revolute joint
	UNDERACTUATED_P_JOINT,	// under-actuated prismatic joint
	UNDERACTUATED_B_JOINT,	// under-actuated ball screw spline joint
};

// defines machine unit types
enum EMachineUnitType {
	EMUT_LINEAR,
	EMUT_ROTARY,
};

// define robot current command mode: MOVJ or MOVL for IK solver
enum ECmdType {
	NONE,			// for RobotExecutive
	CMD_MOVJ,
	CMD_MOVJII,
	CMD_MOVL,
};

// defines robot orientation type
enum EOrientationType {
	EORI_TYPE_NOTDEFINED = 0,
	EORI_TYPE_NONE,
	EORI_TYPE_A,
	EORI_TYPE_B,
	EORI_TYPE_C,
	EORI_TYPE_AB,
	EORI_TYPE_BC,
	EORI_TYPE_AC,
	EORI_TYPE_ABC,
};

enum EFiveAxisSetting{
	FA_BASE = 0,
									// Pr--01
	FA_DOfTool = 2,					// Pr--02
	FA_RA,							// Pr--03
	FA_RB,							// Pr--04
	FA_DOfFirst,					// Pr--05
	FA_DOfSecond,					// Pr--06
	FA_RDOfFirst,					// Pr--07
	FA_RDOfSecond,					// Pr--08
	FA_FStartAngle,					// Pr--09
	FA_FEndAngle,					// Pr--10
	FA_SStartAngle,					// Pr--11
	FA_SEndAngle,					// Pr--12
	FA_ToolHolderOffset,			// Pr--13
									// Pr3014

	FA_FirstRotationOffsetA = 15,	// Pr--15
	FA_FirstRotationOffsetB,		// Pr--16
	FA_FirstRotationOffsetC,		// Pr--17
	FA_SecondRotationOffsetA,		// Pr--18
	FA_SecondRotationOffsetB,		// Pr--19
	FA_SecondRotationOffsetC,		// Pr--20

	FA_ToolHolderToSlaveX = 21,		// Pr--21
	FA_ToolHolderToSlaveY,			// Pr--22
	FA_ToolHolderToSlaveZ,			// Pr--23
	FA_SlaveToMasterX,				// Pr--24
	FA_SlaveToMasterY,				// Pr--25
	FA_SlaveToMasterZ,				// Pr--26

	FA_MasterToSlaveX = 31,			// Pr--31
	FA_MasterToSlaveY,				// Pr--32
	FA_MasterToSlaveZ,				// Pr--33
	FA_MachineToMasterX,			// Pr--34
	FA_MachineToMasterY,			// Pr--35
	FA_MachineToMasterZ,			// Pr--36

	FA_ToolHolderToMasterX = 41,	// Pr--41
	FA_ToolHolderToMasterY,			// Pr--42
	FA_ToolHolderToMasterZ,			// Pr--43
	FA_MachineToSlaveX,				// Pr--44
	FA_MachineToSlaveY,				// Pr--45
	FA_MachineToSlaveZ,				// Pr--46
									// Pr3051 ~ Pr3053
	FA_TCPIntMode = 54,				// Pr--54
	FA_TCPTableCrdSys,				// Pr--55
	FA_FINAL,
};

static const LONG RTCPParamBase[ SIZE_RTCPMechStore ] = { 3001, 3101, 5501, 5601 };

// define robot solution domain type
enum ESolutionType {
	EST_TYPE_LR = 0, // domain: Left, Right
	EST_TYPE_UD = 1, // domain: Up, Down
	EST_TYPE_FB = 2, // domain: Forward, Backward
};

// define robot solution domain for IK solver
enum ESolutionDomain {
	// default
	ESD_NONE		= 0,
	// EST_TYPE_LR
	ESD_LEFT		= 1,
	ESD_RIGHT		= 2,
	// EST_TYPE_UD
	ESD_UP			= 3,
	ESD_DOWN		= 4,
	// EST_TYPE_FB
	ESD_FORWARD		= 5,
	ESD_BACKWARD	= 6,
};

enum EToolCalibrationMethod {
	ETCM_NOTDEFINED = 0,
	ETCM_4Pt = 1,
	ETCM_6Pt = 2,

	ETCM_NUMOF_TOOLCALIMETHOD,
};

#endif //  !defined(_KinematicsDef_H____INCLUDED_)
