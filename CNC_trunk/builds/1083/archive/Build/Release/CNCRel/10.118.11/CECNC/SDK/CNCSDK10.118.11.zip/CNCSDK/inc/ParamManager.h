// ParamManager.h: interface for the CParamManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PARAMMANAGER_H____INCLUDED_)
#define AFX_PARAMMANAGER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CommonStruct.h"

class CParamStore;
class IParamListener;

class CParamManager
{
public:
	CParamManager( TNumOfEachParamType tNumOfEachParamType[], INT nParamTypeNum );
	// constructor

	~CParamManager( void );
	// destructor

public:
	void RegistryParam( EParamType eParamType, INT nID, DWORD dwContext );
	// registry param

	void UnregistryParam( EParamType eParamType, INT nID );
	// unregistry param

	INT GetGroupNumOfType( EParamType eParamType );
	// get group number of type

	BOOL IsExist( EParamType eParamType, INT nID, LONG nNo );
	// query whether the parameter no is defined

	INT NumOfParameter( EParamType eParamType, INT nID );
	// query the number of parameter

	void ParamDump( EParamType eParamType, INT nID, TParamSpec *pSpec, LONG nLength );
	// param dump

	LONG LookupMax( EParamType eParamType, INT nID, LONG nNo );
	// lookup maximum of parameter value

	LONG LookupMin( EParamType eParamType, INT nID, LONG nNo );
	// lookup minimum of parameter value

	CHAR *LookupTitle( EParamType eParamType, INT nID, LONG nNo, CHAR *buffer, INT nCount );
	// lookup parameter title

	LONG GetValue( EParamType eParamType, INT nID, LONG nNo );
	// get parameter value

	void PutValue( EParamType eParamType, INT nID, LONG nNo, LONG nValue );
	// put parameter value

	INT GetVersion( EParamType eParamType, INT nID );
	// get parameter version number

	void GetModifiedTime( EParamType eParamType, INT nID, SYSTEMTIME *t );
	// get modified time

	INT Import( EParamType eParamType, INT nID, CHAR *lpLocation );
	// import parameter from external device

	INT Export( EParamType eParamType, INT nID, CHAR *lpLocation );
	// export parameter to external device

	void SetListener( EParamType eParamType, INT nID, IParamListener *pListener );
	// hook parameter event handler

	void RemoveListener( EParamType eParamType, INT nID, IParamListener *pListener );
	// remove parameter event handler

private:
	struct TParamTypeTable {
		CParamStore **pParam;
		INT nNum;
	};

	TParamTypeTable m_tTable[ NUMOF_PARAM_TYPE ];
	// param typ table

private:
	LONG GetNo( EParamType eParamType, INT nID, INT nIndex );
	// get paramater no by index, which is start from 0.

	BOOL CheckParamTypeValid( EParamType eParamType, INT nID, BOOL bCheckObject = TRUE );
	// check whether param type is valid

	EParamType TransferCNCToCoordForCoordParam( EParamType eParamType, INT nID, LONG nNo );
	// transfer parameter from CNC to Coordinate if Pr4001~Pr5000 or Pr3201
};

#endif // !defined(AFX_PARAMMANAGER_H____INCLUDED_)
