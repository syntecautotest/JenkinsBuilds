// FourAxis.h: interface for the FourAxis class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOURAXIS_H__INCLUDED_)
#define AFX_FOURAXIS_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFourAxis : public IRTCPKinematic
{
public:
	CFourAxis( void );

	virtual ~CFourAxis( void );
	// destructor

public: // to implement IRTCPKinematic interface
	void setMechanism( IRTCPMechanism *pMechanism );
	// set mechanism type of four axis

	BOOL IsBelongToMech( INT nIndex );
	// is axis belong to RTCP mechanism

	BOOL isSetMechanism( void );
	// is mechanism type of four axis already setting?

	void attach( INT nXAxisIndex, INT nYAxisIndex, INT nZAxisIndex, INT nMasterAxisIndex, INT nSlaveAxisIndex );
	// set four axis axis index

	void setType( INT nConfigOfTx );
	// set Type: Normal or FixAngle

	void setToolDirCtrl( BOOL bToolDirCtrl, DOUBLE RValue );
	// enable/disable tool center point retention type tool axis direction control (typeII), G53.6
	// set distance from tool tip to rotation center, R_ in BLU

	void setRotationAngleForFixAngleType( DOUBLE MasterAngle, DOUBLE SlaveAngle );
	// set rotate angle for fix angle type
	// in BLU

	void setRotationStartAngle( DOUBLE Position[] );
	// set rotate start angle in BLU

	void SetIU_BLU_Ratio( const DOUBLE IUtoBLU_Linear, const DOUBLE IUtoBLU_Rotary );
	// set IUtoBLU

	void getRTCPAxisIndex( INT pRTCPAxisIndex[] );
	// get RTCP axis id in a NUMOF_RTCP_AXIS-elements array
	// return -1 to elements after 4th

	INT getMasterAxisIndex( void );
	// get master axis index

	INT getSlaveAxisIndex( void );
	// get slave axis index

	// ask IFiveAxisMech function
	INT getMechID( void );
	// get the ID of four axis mechanism

	INT getMechType( void );
	// get four axis mechanism type

	INT GetToolAxisDirection( void );
	// get tool axis direction

	INT GetDirectionOfFirstRotationAxis( void );
	// get the axis direction of the first rotation axis.

	INT GetDirectionOfSecondRotationAxis( void );
	// get the axis direction of the second rotation axis.

	BOOL IsQuatIntMode( void );
	// is Quaternion Interpolation Mode?

	BOOL IsTableCrdSysFromZeroPos( void );
	// is basic position of table coordinate system for RTCP from zero position?

	INT IsAlarm( ERTCPState nCommandType = RTCP_Off );
	// is alarm?

	void SetToolLength( DOUBLE ToolLength );
	// set tool length
	// unit : BLU

	INT ToolCoordDis( DOUBLE displacement[], DOUBLE position[] );
	// get movement along tool coord

	INT ComputeRotateAngleForToolDirCtrl( CVector3d FeedDirection, DOUBLE MCS[], DOUBLE &MasterAngle, DOUBLE &SlaveAngle, LONG type = 0 );
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle for tool axis direction control, G53.1/G53.6

	INT ComputeRotateAngleForRTCP( CVector3d FeedDirection, DOUBLE BCS[], DOUBLE &MasterAngle, DOUBLE &SlaveAngle );
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle for move command on G43.5

	void GetToolDirectionUnderWorkPieceCoord( DOUBLE position[], DOUBLE ToolDirect[] );
	// tool direction under workpiece coord

	void GetToolCoordSystem( DOUBLE position[], IRTCPMechanism::EToolCoordType type, DOUBLE RotAngle, CMatrix3d &ToolCoord );
	// get tool coordinate system based on type

	void ConvertToQuaternion( DOUBLE fromPos[], DOUBLE toPos[], TQuaternionInfo *pQInfo, TFiveAxisData *pFData );
	// input M1 and M2 in 0.001deg(BLU), then convert to rotation matrix (Quaternion)

	INT ConvertToMS( DOUBLE disp[], DOUBLE &CurQAngle, DOUBLE &MasterAngle, DOUBLE &SlaveAngle, TQuaternionInfo &QInfo, TFiveAxisData &FData );
	// input all disp( include dTheta ) in radian(IU) and current (I,J,K),
	// then convert Quaternion to (dM) in deg(IU) and write back to displacement.
	// return AlarmID

public:
	void ComputeFeedDirection( DOUBLE MasterAngle, CVector3d *FeedDirection );
	// compute feed direction

	INT MCStoBCS( DOUBLE InMCS[], DOUBLE OutBCS[], INT nType = CACHE );
	// machine coordinate system to basic coordinate system

	INT BCStoMCS( DOUBLE InBCS[], DOUBLE InMCS[], DOUBLE OutMCS[] );
	// basic coordinate system to machine coordinate system with last machine coordinate system position

private:
	void updateToolLength( void );
	// update active tool length

	void updateTCPCtrl( void );
	// update whether it is tool center point control or not, while moving rotation axis

protected:
	CFourAxisMechanism *m_pFourAxisMech;
	// mechanism type of four axis

	INT m_nXAxisIndex;
	INT m_nYAxisIndex;
	INT m_nZAxisIndex;

	INT m_nMasterAxisIndex;
	DOUBLE m_MasterAngle;
	// use only when m_nConfigOfTx == 2
	// in BLU

	DOUBLE m_MasterStartAngle;
	// master start angle
	// in BLU

	INT m_nConfigOfTx;
	// 1 : transform depend on angles
	// 2 : transform independ on angles

	BOOL m_bToolDirCtrl;
	// is tool center point retention type tool axis direction control (typeII), G53.6

	BOOL m_bTCPCtrl;
	// is tool center point control?

	DOUBLE m_ActiveToolLength;
	// active tool length, BLU

	DOUBLE m_RValue;
	// disp from tool tip to rotation center, BLU

	DOUBLE m_ToolLength;
	// tool length, BLU
};

#endif
