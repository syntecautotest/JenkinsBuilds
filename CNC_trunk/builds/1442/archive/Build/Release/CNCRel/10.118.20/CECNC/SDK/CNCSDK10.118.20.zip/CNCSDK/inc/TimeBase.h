// TimeBase.h: interface for the CTimeBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMEBASE_H__3CAB5701_8E9B_423D_B9A8_3BDB4CDF4069__INCLUDED_)
#define AFX_TIMEBASE_H__3CAB5701_8E9B_423D_B9A8_3BDB4CDF4069__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define Analysis_SpdPos_In_Thread_Debug_Mode	0
#define START_DUMP_RVALUE_IN_THREAD				8300

class ISpindleLink;
class CVelocityControl;

class CTimeBase
{
public:
	CTimeBase( void );
	// constructor

	~CTimeBase();
	// destructor

	friend void DumpDebugData( CTimeBase *pTimebase, LONG *data );
	// open friend relationship to dump object state for debug purpose

	static void AdvanceInterpolationCount( void );
	// to advance interpolation count

	static LONG get_InterpolationCount( void );
	// to advance interpolation count

	static void PutTrajPlanInterval( LONG nInterval );
	// set trajectory plan tick time interval, in micro-second

	static void PutMotionPlanInterval( LONG nInterval );
	// set motion plan tick time interval, in micro-second

	static void PutNormalPLCScanInterval( LONG nInterval );
	// set motion plan tick time interval, in micro-second
	
	static void PutInterpolationInterval( LONG nInterval );
	// set interpolation tick time interval, in micro-second

	static void PutOperationScanInterval( LONG nInterval );
	// set operation scan tick time interval, in micro-second

	static void PutHousekeepingInterval( LONG nInterval );
	// set housekeeping tick time interval, in micro-second

	static void InterpolationTick( void );
	// Use threads: interpolation

	LONG GetTimeBase( void );
	// get next timebase
	// Use threads: interpolation

	BOOL IsStop( void );
	// query whether it is stop.
	// Use threads: <= motion plan

	void Start( void );
	// start time axis movement
	// Use threads: <= motion plan

	void Stop( void );
	// stop time axis movement
	// Use threads: <= motion plan

	void Reset( void );
	// reset timebase
	// Use threads: <= motion plan

	void TimeMode( void );
	// use world time as time source
	// Use threads: <= motion plan

	void RevolutionMode( void );
	// use spindle revolution as time source
	// Use threa ds: <= motion plan

	INT IsInRevolutionMode( void );
	// query whether it is in revolution mode
	// Use threads: <= motion plan

	void EnterThreadMode( void );
	// enter use ecnoder revolution as time source
	// Use threads: <= motion plan

	void ExitThreadMode( void );
	// exit use ecnoder revolution as time source
	// Use threads: <= motion plan

	void setDryRun( BOOL bDryRun );
	// set dry run mode

	void setTightCoupling( BOOL bTightCoupling );
	// set tight coupling mode

	BOOL IsTightCoupling( void );
	// is tight coupling?

	void putOverrideInhibit( BOOL bOverrideInhibit );
	// enable feedrate override inhitbit, that is, inhibit override input
	// disable feedrate override inhibit, that is, accept override input

	void putSpeedCheckInhibit( BOOL flag );
	// set inhibit spindle speed check flag

	void setMaxOverride( DOUBLE Override );
	// set maximum override, unit: 1%

	BOOL SyncTimeBase( void );
	// sync time base

	void PutSCurveTA( LONG time );
	// set the time constant for S-Curve timebase transition.

	void PutSkewTA( LONG time );
	// set the time constant for timebase transition.
	// time			in micro-second.
	// Use threads: <= motion plan

	void setThreadingStartAngle( DOUBLE angle );
	// set thread cutting start angle

	void PutOverride( DOUBLE Override );
	// set feedrate override, unit: 1%
	// Override			0%~MAXOVERRIDE%

	DOUBLE GetOverride( void );
	// get feedrate override
	// Override			0%~MAXOVERRIDE%

	void AssociateSpdLink( ISpindleLink *pSpdLink );
	// associate encoder for revolution time resource.
	// Use threads: constructor

	void setMPGSimulation( BOOL bMPGSimu );
	// set MPG simulation function enable/disable

	LONG getIndexErrCount( void );
	// get error count of index large than position in AdvanceTimeBase()

	static LONG GetTrajPlanInterval( void );
	// get trajectory plan tick time interval, in micro-second

	static LONG GetMotionPlanInterval( void );
	// get motion plan tick time interval, in micro-second

	static LONG GetNormalPLCScanInterval( void );
	// get motion plan tick time interval, in micro-second

	static LONG GetInterpolationInterval( void );
	// get interpolation tick time interval, in micro-second

	static LONG GetOperationScanInterval( void );
	// get operation scan tick time interval, in micro-second

	static LONG GetHousekeepingInterval( void );
	// get housekeeping tick time interval, in micro-second

public:
	static const DOUBLE MAX_FeedrateOverride;
	// maximum feedrate override

protected:
	BOOL m_bRunning;
	// running flag

	BOOL m_bMPGSimu;
	// MPG simulation flag

	// state identifier
	enum EFeedMode
	{
		MODE_TIME,			// world time as source
		MODE_REVOLUTION		// encoder position as source
	};

	enum
	{
		THREADING_IDLE,					// idle
		THREADING_STARTINDEXCAPTURE,	// start spindle index capture
		THREADING_RECAPTUREINDEX,		// re-capture spindle index
		THREADING_WAITINDEX,			// wait until index has found
		THREADING_WAITNEXTPOS			// wait next spindle position
	};

	EFeedMode m_nSourceMode;
	// time source mode

	BOOL m_bRevModeRequest;
	// revolution mode request

	BOOL m_fThreadMode;
	// thread cutting mode

	BOOL m_bDryRun;
	// flag for dry run mode

	BOOL m_bTightCoupling;
	// do tight coupling under feed per revolution mode

	DOUBLE m_ThreadingStartAngle;
	// the thread cutting start angle

	DOUBLE m_MaxOverride;
	// maximum allowable override

	INT m_nSyncIndexState;
	// state variable for sync. with index.

	DOUBLE m_RevTimeRemainder;
	// remainder of revolution time, in microsecond.

	LONG m_nIndexErrCount;
	// the error count of index large than position in AdvanceTimeBase()

	LONG m_nLastEncoderPosition;
	// last encoder position.

	LONG m_nLLastEncoderPosition;
	// last last encoder position.

	LONG m_nSkewRate;
	// maximum allowable timebase change,
	// in micro-second.

	DOUBLE m_ReferenceSpeed;
	// spindle reference speed, in RPM

	LONG m_nCurrentTimeBase;
	// current time base in micro-second,

	DOUBLE m_Override;
	// feedrate override from 0% to MAXOVERRIDE%

	DOUBLE m_Amax;
	// maximun acceleration/deceleration when override change

	DOUBLE m_Jmax;
	// maximun jerk

	BOOL m_fOverrideInhibit;
	// flag for inhibit feedrate override

	BOOL m_bSpeedCheckInhibit;
	// flag for inhibit spindle spped check

	ISpindleLink *m_pSpdLink;
	// associated spindle link for revolution time resource.

	CRTMutex m_cs;
	// mutex for object state consistent

	CVelocityControl *m_objSCurveController;
	// the s_curve controller 

	static LONG m_nInterpolationInterval;
	// interpolation time interval in micro-second

	static LONG m_nTrajPlanInterval;
	// trajectory planning time interval in micro-second

	static LONG m_nMotionPlanInterval;
	// motion planning time interval in micro-second

	static LONG m_nNormalPLCScanInterval;
	// motion planning time interval in micro-second

	static LONG m_nOperationScanInterval;
	// operation scan time interval in micro-second

	static LONG m_nHousekeepingInterval;
	// housekeeping time interval in micro-second

	static LONG m_nInterpolationCount;
	// the number of interpolation counter

	static CTimeBase *m_TimeBaseList;
	// list of all CTimeBase objects

	CTimeBase *m_Next;
	// pointer to next CTimeBase object in the m_TimeBaseList list

	void AdvanceTimeBase( void );
	// calculate next timebase
	// Use threads: interpolation

private:
	LONG getTargetTimeBase( void );
	// calculate and get target timebase

	BOOL WaitForThreading( void );
	// wait for threading

	BOOL m_bFirstEnterThread;
	// is first timebase tick in threading.

	DOUBLE calcTB_SpindleSpeed( void );
	// calculate time base by spinlde speed

	void PlanTB_ConstantSlope( LONG nTargetTimeBase );
	// plan time base by constant slope

	void PlanTB_ConstantJerk( LONG nTargetTimeBase );
	// plan time base by constant jerk

#if Analysis_SpdPos_In_Thread_Debug_Mode
	void dumpSpdPos( DOUBLE position );
	// dump spindle position

	void dumpSpdIndex( void );
	// dump spindle index

	void dumpErrSpdPosCase( DOUBLE delta1, DOUBLE delta2 );
	// dump error spindle position case
#endif
};

#endif // !defined(AFX_TIMEBASE_H__3CAB5701_8E9B_423D_B9A8_3BDB4CDF4069__INCLUDED_)
