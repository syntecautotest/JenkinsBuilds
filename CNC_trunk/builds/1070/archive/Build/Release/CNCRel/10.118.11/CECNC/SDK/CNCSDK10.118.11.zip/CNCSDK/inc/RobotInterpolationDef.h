#if !defined(_ROBOTINTERPOLATIONDEF_H____INCLUDED_)
#define _ROBOTINTERPOLATIONDEF_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_INTERPOLATION_BUCKET		( 6 )	// one bucket for total displacement
												// one bucket for joint compensation
												// four buckets for interpolation across two blocks
												// 1 + 1 + 4 = 6

struct TRobotSegmentNode {
	double						MoveTime;
	CCJerkHelicalInt::TCtlBlk	CtlBlk;
};

struct TIntBuffer {
	double				SegmentRemainTime;
	double				SegmentMoveTime;
	double				NowTimeCursor; // for debug

	struct {
		double			LocalLen;				// records local current accumulated length
		double			LocalStart[ 2 ];
		double			LocalCenter[ 2 ];
		double			LocalEnd[ 2 ];			// records local points to describe the arc
		double			Length;
		double			ArcAngle;				// records the MOVC arc length and angle
		double			LastLocalMovcAX[ 2 ];	// records the last Local MovcAX
		CMatrixN		CoordFrame;				// stores each MOVC coord frame
		CMatrixN		LocalVec;				// stores each MOVC local movement vector
		CMatrixN		WorldVec;				// stores each MOVC world movement vector
	}Movc;

	CCJerkHelicalInt	awt;
};

struct TInterpolationBlock {
	int					nNextIndex;							// records the index of SegmentNode while interpolation
	int					nCount;								// records how many segemnts in one block
	double				NodeTime;							// records move time of the block
	double				RotAngleAccumlator;					// records accumulated rotation angle of the block while interpolation; unit:deg
	double				NowTimeCursor;						// records time cursor in the block
	TRobotSegmentNode	SegmentNode[ MAX_NumOfPVTSegment ];	// records SegmentNodes of the block
	TIntBuffer			*pIntBuffer;
};

struct TRobotMicroCode {
	int								ClassID;
	int								Opcode;
	union {
		// MOTOP
		struct {
			void					*pMotionHandler;
			double					duration;

			// Normal
			struct {
				long				Flags;								// working flag
				short int			MOVJ_LimitingJoint;					// for robot MOVJs
				BOOL				bJointCompensationInhibit;			// joint compensation inhibit, MOVC mid point is true, others are false

				double				StartJointPos[ NUMOF_ROBOT_AXIS ];	// joint position at the beginning of the block
				double				AX[ NUMOF_AXIS ];					// increament data
				double				RemainDisp[ NUMOF_AXIS ];			// remain displacement
				double				MOVC_GeomLen;						// MOVC arc length (XYZ)
				double				OverlapStartTime[ 2 ];				// overlapping start time

				TQuaternionInfo		QInfo;								// rotation quaternion
				TQuaternionInfo		StartQInfo;							// start quaternion
				TWaitSigInfo		OvlWaitSigInfo;						// SWAITSIG: robot wait signal info. for overlapping next block or not
				TIOFcnLink			IOFcnLink;			// IO related function pointers
			};

			TInterpolationBlock		IntBlock;
		};

		// FUNCCALL
		struct {
			int					nExecute;
			union {
				// [case(FUNCID_PacketInfo)]
				TPacketInfo		PacketInfo;

				// [default]
				long			lParam[ IFuncCallHandler::MAX_NumOfArg ];
			};
		};
	};
};

enum ETrajSpace {
	ETS_NOTDEFINED = -1,
	ETS_JOINT,
	ETS_CARTESIAN,

	ETS_NUMOF_TRAJSPACE,	// number of trajectory space
};

// defines robot interpolation type for orientation
enum EInterpolationType {
	EINT_TYPE_LINEAR = 0,
	EINT_TYPE_QUATERNION = 1,
};

struct TMotDisp {
	INT TrajSpace;				// defined by ETrajSpce
	DOUBLE Disp[ NUMOF_AXIS ];	// for ETS_JOINT, Disp is joint displacement in IU
								// for ETS_CARTESIAN, Disp is ( dx, dy, dz, dtheta, dQAngle, i, j, k )
};

#endif // !defined(_ROBOTINTERPOLATIONDEF_H____INCLUDED_)
