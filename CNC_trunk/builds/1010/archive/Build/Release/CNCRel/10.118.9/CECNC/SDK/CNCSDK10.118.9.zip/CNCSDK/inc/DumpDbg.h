#if !defined(DUMPDBG_H_)
#define DUMPDBG_H_

#define DEBUG_AXIS_PER_PAGE			( 16 )
#define DEBUG_SPD_PER_PAGE			( 5 )
#define DEBUG_SPD_DATA_SIZE			NUMOF_DEBUGDATA_SYNTEC_SPINDLE

// axis 1~16
#define DEBUG_PAGE_2_COL_1_BASE		( 80 )
#define DEBUG_PAGE_2_COL_2_BASE		( 96 )
#define DEBUG_PAGE_2_COL_3_BASE		( 112 )
#define DEBUG_PAGE_2_COL_4_BASE		( 128 )
#define DEBUG_PAGE_2_COL_5_BASE		( 144 )
#define DEBUG_PAGE_3_COL_1_BASE		( 160 )
#define DEBUG_PAGE_3_COL_2_BASE		( 176 )
#define DEBUG_PAGE_3_COL_3_BASE		( 192 )
#define DEBUG_PAGE_3_COL_4_BASE		( 208 )
#define DEBUG_PAGE_3_COL_5_BASE		( 224 )
#define DEBUG_PAGE_4_COL_1_BASE		( 240 )
#define DEBUG_PAGE_4_COL_2_BASE		( 256 )
#define DEBUG_PAGE_4_COL_3_BASE		( 272 )
#define DEBUG_PAGE_4_COL_4_BASE		( 288 )
#define DEBUG_PAGE_4_COL_5_BASE		( 304 )
#define DEBUG_PAGE_5_COL_3_BASE		( 352 )

// spindle 1~5
#define DEBUG_PAGE_6_COL_1_BASE		( 400 )

// spindle 6~8, reserved for 10 spindles
#define DEBUG_PAGE_7_COL_1_BASE		( 480 )

// axis 17~18, reserved for 32 axes
#define DEBUG_PAGE_8_COL_1_BASE		( 560 )
#define DEBUG_PAGE_8_COL_2_BASE		( 576 )
#define DEBUG_PAGE_8_COL_3_BASE		( 592 )
#define DEBUG_PAGE_8_COL_4_BASE		( 608 )
#define DEBUG_PAGE_8_COL_5_BASE		( 624 )
#define DEBUG_PAGE_9_COL_1_BASE		( 640 )
#define DEBUG_PAGE_9_COL_2_BASE		( 656 )
#define DEBUG_PAGE_9_COL_3_BASE		( 672 )
#define DEBUG_PAGE_9_COL_4_BASE		( 688 )
#define DEBUG_PAGE_9_COL_5_BASE		( 704 )
#define DEBUG_PAGE_10_COL_1_BASE	( 720 )
#define DEBUG_PAGE_10_COL_2_BASE	( 736 )
#define DEBUG_PAGE_10_COL_3_BASE	( 752 )
#define DEBUG_PAGE_10_COL_4_BASE	( 768 )
#define DEBUG_PAGE_10_COL_5_BASE	( 784 )

// debug page 11
#define DEBUG_PAGE_11_COL_1_BASE	( 800 )

// class declaration
class CControlSystem;
class CTimeBase;
class CAsynQueue;
class CInterpolator;
class CMotionPlanner;
class CCoordinate;
class CNCExecutive;
class CCNCCenter;

// dump debug information interface
extern void DumpDebugData( CTimeBase *pTimebase, long *data );
extern void DumpDebugData( CAsynQueue *pQueue, long *data );
extern void DumpDebugData( CInterpolator *pInterpolator, long *data );
extern void DumpDebugData( CMotionPlanner *pMotionPlanner, long *data );
extern void DumpDebugData( CNCExecutive *pExecutive, long *data );
extern void DumpDebugData( CControlSystem *pControl, long *buffer );
extern void GetDebugData( CControlSystem *pControl, long *buffer );
extern void GetOtherDebugData( CControlSystem *pCtrl, long no, long *buffer );
extern void GetRefDebugData( CControlSystem *pCtrl, LONG no, LONG *buffer );

// dump running state interface
extern void DumpRunningState( CControlSystem *pControl, long *buffer );

// inside aid function
void GetFollowingErrorLimit( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get following error limit

void GetFeedbackPosition( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get feedback position

void GetTheoryFollowingError( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get theory folling error

void GetServoCommand( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get servo command

void ReadIndexPosition( CCNCCenter *pCNC, LONG nNo, LONG *buffer, BOOL bDual );
// read index position

void GetHomeGrid( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get home grid

void GetForwardFollowingError( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get forward folling error

void GetMPGAbsoluteCounter( CControlSystem *pCtrl, LONG nNo, LONG *buffer );
// dump MPG absolute counter

void GetSpindleSynchError( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get spindle synch error

void GetMachinePosition( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get machine position

void GetDualPositionError( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get dual position error

void GetDualFeedbackPosition( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get dual feedback position

void GetFollowingError( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get following error

void ReadDACommand( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// read DA command

void GetEstimateLoopGain( CCNCCenter *pCNC, LONG nNo, LONG *buffer );
// get estimate loop gain

#endif  // DUMPDBG_H_
