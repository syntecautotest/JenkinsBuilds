#if !defined(_IMOTIONPLANNER_H____INCLUDED_)
#define _IMOTIONPLANNER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define REMAIN_TIME_BOUNDARY		2.0e6

class IMotionPlanner
{
public:
	virtual ~IMotionPlanner( void ) {}
	// destructor

public:
	virtual BOOL isReady( void ) = 0;
	// check whether the help object is ready for accept next command ?

	virtual BOOL isIdle( void ) = 0;
	// check whether the help object is idle

	virtual void Reset( void ) = 0;
	// reset

	virtual void Abort( void ) = 0;
	// abort

	virtual BOOL isAtStartPoint( void ) = 0;
	// is at start point

	virtual BOOL isAtEndPoint( void ) = 0;
	// is at end point

	virtual BOOL isStop( void ) = 0;
	// is stop

	virtual BOOL isBlockStop( void ) = 0;
	// is block stop

	virtual BOOL isExecutingMotCode( void ) = 0;
	// is executing motion code

	virtual BOOL isReadyForRecord( void ) = 0;
	// is ready for record, this function is used for record mode

public:
	virtual void notifyBStopRequest( void ) = 0;
	// b stop request

	virtual BOOL notifyChangeMotionMode( BOOL bForward ) = 0;
	// check the double link list is safe
	// use time: rewind through MPG simulation

	virtual BOOL NotifyWaitRequest( void ) = 0;
	// notify wait request

	virtual void Start( void ) = 0;
	// start

	virtual void Stop( void ) = 0;
	// stop

public:
	virtual void putMRP( TMotReqPkt *pMRP ) = 0;
	// put MRP

	virtual void putWPInfo( long *Para ) = 0;
	// put work plane information

	virtual void putExactStop( void ) = 0;
	// put exact stop

	virtual void putEOBMark( const TPacketInfo &PacketInfo ) = 0;
	// put EOB mark

	virtual void putFuncCallInfo( TPacketInfo &PacketInfo, const EFUNCID nFuncCallID, EStopType nStopType, BOOL bFlag ) = 0;
	// put function call information

	virtual BOOL GetDisplacement( double Disp[] ) = 0;
	// get displacement

	virtual double getTimeTick() = 0;
	// get time tick

	virtual void TrajPlanTick( void ) = 0;
	// trajectory plan tick

	virtual void MotionPlanTick( void ) = 0;
	// motion plan tick

	virtual void getRemainDisplacement( double displacement[] ) = 0;
	// get remain displacement

	virtual long getGCodeMode( void ) = 0;
	// get G code mode

	virtual int getMotionMode( void ) const = 0;
	// get motion mode

	virtual INT getTrajSpace( void ) { return -1; }
	// get trajectory space, robot only

	virtual int getRobotLimitingJoint( void ) { return -1; }
	// get Robot Limiting Joint in MOVJ mode
	// robot MOVJ only, for other classes it always return -1

	virtual double getRemainTime( void ) = 0;
	// get interpolation remain time

	virtual void get_SnapshotQueTime( long *lpdwRaw, long *lpdwMature ) = 0;
	// to get remain queue time inside LA queue.
};
#endif //(_IMOTIONPLANNER_H____INCLUDED_)
