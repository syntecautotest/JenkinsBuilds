#ifndef nstdlib_h
#define nstdlib_h 1

#include <windows.h>
#include <iphlpapi.h>

//#define USE_RTDEBUGER		1
//#define USE_RTDEBUGER2		1

#ifndef ASSERT
#include <assert.h>
#endif

#if defined(UNDER_CE)
#include "pbdef.h"
#include "winbase.h"
#endif

#include <limits.h>
#include <memory.h>
#include <string.h>
#include <tchar.h>

#include <math.h>
#include <float.h>

#if !defined(UNDER_CE)
#define Vsqrt			sqrt
#define Vsin			sin
#define Vcos			cos
#define Vtan			tan
#define Vasin			asin
#define Vacos			acos
#define Vatan2			atan2
#define Vatan			atan
#define Vfloor			floor
#define Vceil			ceil
#define Vfabs			fabs
#define Vpow			pow
#define Vlog10			log10
#define Vlog			log
#define Vexp			exp
#endif

#ifndef ASSERT
#define ASSERT			assert
#endif

#ifndef NULL
#ifdef __cplusplus
#define NULL			0
#else
#define NULL			((void *)0)
#endif
#endif

#define REENTRYAPI				_stdcall
#define CRTCALLBACK				_cdecl
#define CNCAPI					WINAPI
#define PFNCNCAPI				WINAPI
#define CNCDATAAPI

#ifdef CNCKE_EXPORTS
#define CNCKEAPI				__declspec(dllexport)
#define CNCKEDATAAPI			__declspec(dllexport)
#else
#define CNCKEAPI				__declspec(dllimport)
#define CNCKEDATAAPI			__declspec(dllimport)
#endif

#define UTILAPI

#ifdef SWING_EXPORTS
#define SWINGAPI
#else
#define SWINGAPI
#endif

typedef DWORD (PFNCNCAPI *PFNSERVICE)( LPVOID dwContext );
// type definition for service routine callback

typedef void (PFNCNCAPI *PFNPROGRESS)( LONGLONG nFileSize, LONGLONG nBytesTransferred );
// type definition for progress routine callback

#define DNCREAD_Busy		-1
#define DNCREAD_EOF			-2

#ifdef __cplusplus
extern "C" {
#endif

extern void CNCAPI dbg_putchar(unsigned ch);
// put debug character at specified position

void CNCAPI errlog( char *fmt, ... );
// log error string

#ifdef __cplusplus
}
#endif

#define EOF				(-1)
#define TRUE			1
#define	FALSE			0
#define VLONG_MAX		(LONG_MAX)
#define VUINT_MAX		(UINT_MAX)
#define min(a, b)		(((a) < (b)) ? (a) : (b))  
#define max(a, b)		(((a) > (b)) ? (a) : (b))  

#define JRECT			RECT
#define PJRECT			PRECT
#define LPJRECT			LPRECT
#define LPCJRECT		LPCRECT
#define HJFONT			HFONT
#define JCopyFile		CopyFile

#ifdef USE_RTDEBUGER
#define RtDbgTrace(s)	errlog(s)
#else
#define RtDbgTrace(s)
#endif

#ifdef USE_RTDEBUGER2
#define RtDbgTrace2(s)	errlog(s)
#else
#define RtDbgTrace2(s)
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern PVOID CNCAPI MemMapIoSpace( DWORD PhysicalAddress, DWORD NumberOfBytes );
extern void CNCAPI MemUnMapIoSpace( PVOID VirtualAddress );
// physical address to virtual address

#if defined(UNDER_CE)

#define _MAX_DRIVE  3   /* max. length of drive component */
#define _MAX_DIR    256 /* max. length of path component */
#define _MAX_FNAME  256 /* max. length of file name component */
#define _MAX_EXT    256 /* max. length of extension component */

void __cdecl _tsplitpath (
	const TCHAR *path,
	TCHAR *drive,
	TCHAR *dir,
	TCHAR *fname,
	TCHAR *ext
	);

void __cdecl _tmakepath (
	TCHAR *path,
	const TCHAR *drive,
	const TCHAR *dir,
	const TCHAR *fname,
	const TCHAR *ext
	);

void * __cdecl bsearch (
	const void *key,
	const void *base,
	size_t num,
	size_t width,
	int (__cdecl *compare)(const void *, const void *)
	);

void * __cdecl _lfind (
	const void *key,
	const void *base,
	unsigned int *num,
	unsigned int width,
	int (__cdecl *compare)(const void *, const void *)
	);

void __cdecl _splitpath (
	const char *path,
	char *drive,
	char *dir,
	char *fname,
	char *ext
	);

void __cdecl _makepath (
	char *path,
	const char *drive,
	const char *dir,
	const char *fname,
	const char *ext
	);

#else // defined(UNDER_CE)

#include <search.h>

#endif // defined(UNDER_CE)

extern int PalGetSystemDirectory( LPTSTR buffer, int count );
// get system directory pathname

#ifdef __cplusplus
}
#endif 

#endif // nstdlib_h

