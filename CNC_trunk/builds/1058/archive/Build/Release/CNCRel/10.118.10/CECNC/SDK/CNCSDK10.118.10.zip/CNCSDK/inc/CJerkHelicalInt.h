// CJerkHelicalInt.h: interface for the CCJerkHelicalInt class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CJERKHELICALINT_H__C63F8EB3_1963_11D3_841D_0000E86B4150__INCLUDED_)
#define AFX_CJERKHELICALINT_H__C63F8EB3_1963_11D3_841D_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCJerkHelicalInt : public ITrajectoryInt
{
public:
	CCJerkHelicalInt();
	virtual ~CCJerkHelicalInt();

public:
	enum EBlockType {
		BT_Helical,
		BT_Linear
	};

	struct TCtlBlk
	{
		CCJerkLineInt::TCtlBlk	CtlBlk;		// for interpolation
		int						type;		// interpolation type
		union {
			struct { // for CInterpolator
				double					transform[9];
				double					Px_0;			// x-position at time 0
				double					Py_0;			// y-position at time 0
				double					Rad_0;			// radius at time 0
				double					Angle_0;		// angle at time 0
				double					Px_T;			// x-position at time T
				double					Py_T;			// y-position at time T
				double					Rad_T;			// radius at time T
				double					Angle_T;		// angle at T;
				double					ZSpan;			// Z axis span
			};

			struct { // for CRobotIntepolator <-- used for 3D circular interpolation
				double					CoordFrame[9];	// coordinate frame of the 3D circle
				double					LocalStart[2];	// local start point
				double					LocalCenter[2];	// local center point
				double					LocalEnd[2];	// local end point
				double					ArcAngle;		// total arc angle
				double					GeomLength;		// total length ( includes GeomLen and RotLen )
				double					NodeTime;		// total time of each MOVC PVT sheet
			};
		};

	};

	struct TParam
	{
		double	Rad0;				// radius position at start point
		double	RadT;				// radius position at end point
		double	Angle0;				// angle position at start point
		double	AngleT;				// angle position at end point
		double	Omega0;				// anglular velocity at start point
		double	OmegaT;				// anglular velocity at end point
		double	NAxis0;				// normal axis position at start point
		double	NAxisT;				// normal axis position at end point
		double	transform[9];		// transformation matrix
	};

	static const double THRESHOLD_SmallRadius;
	// radius threshold for interpolation algrithm selection

public:
	static void getControlBlock( TCtlBlk *block, TParam &param, double TM );
	// get control block

	static void getControlBlock( TCtlBlk *block, CCJerkLineInt::TParam &param, double TM );
	// get 1d movement control block

	void startBlock( ITrajectoryInt::TCtlBlk *block, int fBackward );
	// issue control block to start excute
	// block		pointer to control block
	// fBackward	flag fto indicate backward interpolation

	void getSegment( double time, double segment[] );
	// calculate next move segment
	// time			current time base
	// segment		to buffer for store movement

private:
	int					m_type;			// block type
	CCJerkLineInt		m_ConstJerkInterpolator;	// helper for angle interpolation
	double				m_transform[9];	// transformation matrix
	double				m_Px;			// absolute x position
	double				m_Py;			// absolute y position
	double				m_Pz;			// absolute z position
	double				m_Radius;		// current radius position
	double				m_Angle;		// current angle
	double				m_Radius0;		// init radius
	double				m_Angle0;		// init angle
	double				m_RadiusSpan;	// radius span
	double				m_AngleSpan;	// angle span
	double				m_ZSpan;		// Z span
};

#endif // !defined(AFX_CJERKHELICALINT_H__C63F8EB3_1963_11D3_841D_0000E86B4150__INCLUDED_)
