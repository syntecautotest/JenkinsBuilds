// AxFrame.h: interface for the CAxFrame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AXFRAME_H__8295AC3F_F440_43E3_9F26_0FC7CBE67EC7__INCLUDED_)
#define AFX_AXFRAME_H__8295AC3F_F440_43E3_9F26_0FC7CBE67EC7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OpenCncDef.h"
#include "Frame3d.h"
#include "Vector3d.h"

// SUGGESTION:
// this class can be extend to include two-plane(wcut) application,
// by a share transformation frame, and play it into x/y plane, and
// u/v plane simultanenously.
class CAxFrame
{
public:
	CAxFrame();
	virtual ~CAxFrame();

	void set( CAxFrame &f );
	// Sets the value of this frame to a copy of the passed frame f

	void setIdentity( void );
	// Sets this Matrix4d to identity.

	void set( double trans[], int nCount );
	void set( CVector3d &vNormal, double angle, int nCount );
	void set( double trans[], CVector3d &vNormal, double angle, int nCount );
	void set( double trans[], BOOL bMirror[], BOOL bXYExchange, int nCount );
	void set( double trans[], BOOL bMirror[], BOOL bXYExchange, double scale[], int nCount );
	void set( double trans[], double alpha, double beta, double gamma, int nCount );
	void set( double trans[], CMatrix3d &RotMatrix, int nCount );
	// set transition, mirror, axis exchange, rotation, scale

	// transform n-dimension point
	void transformPoint( double pt[], int nCount );
	void transformPoint( double pt[], double ptOut[], int nCount );
	// transform point

	void transformVector3d( double normal[]  );
	void transformVector3d( double normal[], double normalOut[] );
	// transform 3d vector

	void transform( CVector3d &normal );
	void transform( CVector3d &normal, CVector3d &normalOut );
	// transform CVector3d

	// transform n-dimension vector
	void transformVector( double normal[], int nCount );
	void transformVector( double normal[], double normalOut[], int nCount );
	// transform axis array vector

	void getFrameTransAndRot( double Trans[], double R[] );
	// get frame translation part and rotation matrix with array.

	void invert( CAxFrame &f );
	// Inverts frame m and places the new values into this matrix

	void mul( CAxFrame &f );
	// Sets the value of this matrix to the result of multiplying
	// itself with matrix m.
	// this = this * f

	void mul( CAxFrame &f1, CAxFrame &f2 );
	// Sets the value of this matrix to the result of multiplying
	// the two argument matrices together.
	// this = f1 * f2

private:
	CFrame3d m_frame;
	double m_trans[NUMOF_AXIS];
	double m_scale[NUMOF_AXIS];
};

#endif // !defined(AFX_AXFRAME_H__8295AC3F_F440_43E3_9F26_0FC7CBE67EC7__INCLUDED_)
