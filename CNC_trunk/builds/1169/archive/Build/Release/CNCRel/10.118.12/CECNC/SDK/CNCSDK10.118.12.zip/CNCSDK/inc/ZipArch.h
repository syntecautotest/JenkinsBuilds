// ZipArch.h: interface for the CZipArchive class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(ZIPARCH_H_)
#define ZIPARCH_H_

#include "zcrc32.h"

class CZipArchive
{
public:

	enum EMaxBounds {
		MAX_HuffCodeBitLen = 16,			// maximum bits in code
		MAX_HuffTreeTableSize = 288			// maximum number of codes in set
	};

// enable 2-byte alignment
#pragma pack(2)

	// local file header
	struct TLocalFileRecord {
		unsigned short	fExtract;			// vers needed to extract
		unsigned short	Attribute;			// general purpose flag
		unsigned short	CompressMethod;		// compression method
		unsigned short	FileTime;			// file time
		unsigned short	FileDate;			// file date
		unsigned long	CRCSum;				// CRC-32 for file
		unsigned long	CompressedSize;		// compressed size
		unsigned long	UnCompressedSize;	// uncompressed size
		unsigned short	FileNameLength;		// file name length
		unsigned short	ExtraLength;		// extra field length
	};
	// this is the file header leading its compressed data, for single
	// disk it carry all information about file. but for multi-disk span,
	// the compressed size and CRC checksum fields are absent, they will appear
	// in following TLocalFileEnd tailing block.

	// local file end, data description block
	struct TLocalFileEnd {
		unsigned long	CRCSum;				// CRC-32 for file
		unsigned long	CompressedSize;		// compressed size
		unsigned long	UnCompressedSize;	// uncompressed size
	};
	// this block only appear when LF_FLAG_DDREC bit, in Attribute field,
	// turn on. this field design for multi-disk span case, because the
	// local file header disk has be removed out from drive, when compressed
	// size and CRC checksum carry out and know, so local file header will
	// not contain up-to-date information, the up-to-date information will
	// fill in this record, and appedn this record behind its compressed
	// data, the unzip utility can use this block to stop decode process,
	// and use CRC checksum to verify data integrity.
	//
	// In recent, the zip has be used to archive purpose, it will generate
	// central directory at the tail of archive, which contains of full
	// up-to-date information about files in archive, in this case the
	// archive unility can directly read central directory, so this block
	// is useless for archive utility.
	//
	// Because the central directory is in the tailing of zip archive, so
	// in multi-disk span case, user need to insert the last disk first to
	// read out central directory. for some consideration, if you use zip
	// only for compress data purpose, not for archive purpose, and you hope
	// the disk insertion sequence is in order, start from one not from last,
	// then you can try to use this block information to stop decoding.
	// Because the compressed size is unknown before or during decoding, so
	// the decoding process must detect this block and automatically stop
	// itself.

	struct TFileRecord {
		unsigned short	fh_made;			// version made by
		unsigned short	fh_extract;			// version needed to extract
		unsigned short	fh_flag;			// general purpose flag
		unsigned short	fh_cm;				// compression method
		unsigned short	fh_time;			// file time
		unsigned short	fh_date;			// file date
		unsigned long	fh_crc;				// CRC-32 for file
		unsigned long	fh_csize;			// compressed size
		unsigned long	fh_size;			// uncompressed size
		unsigned short	fh_fn_len;			// file name length
		unsigned short	fh_ef_len;			// extra field length
		unsigned short	fh_fc_len;			// file comment length
		unsigned short	fh_disk;			// the disk number with this file
		unsigned short	fh_attr;			// internal file attrib
		unsigned long	fh_eattr;			// external file attrib
		unsigned long	fh_offset;			// offset of local header
	};
	// this is the file description record of central directory, it carry all
	// up-to-date information about files in this archive. All information
	// in local file header and local file end blocks can be found in this
	// record, from fh_extract to fh_ef_len field.
	//
	// the central directory records will be append behind all compressed data,
	// in the tail of archive.

	struct TEndOfCentralDirRecord {
		unsigned short	ed_disk;			// this disk number
		unsigned short	ed_cdisk;			// the disk number with central dir
		unsigned short	ed_current;			// current disk's dir entries
		unsigned short	ed_total;			// total dir entries
		unsigned long	ed_size;			// size of central dir
		unsigned long	ed_offset;			// offset of central dir
		unsigned short	ed_zc_len;			// zip file comment length
	};
	// this is the last and alway the last record of archive, it mark the end
	// of central directory. it describe the central directory location and size.

	struct THuffmanTree {
		unsigned char		ExtraBits;		// extra bits
		unsigned char		BitLength;		// bit length
		struct {
			unsigned short	code;			// could be literal, length, or distance
			THuffmanTree	*pNext;			// chain to next table pointer
		} v;
	};

// restore original alignment
#pragma pack()

public:
	CZipArchive( unsigned InBufSize = 16384, unsigned OutBufSize = 32768 );
	// constructor

	virtual ~CZipArchive();
	// destructor

	void ScanDirectory( void );
	// scan zip file directory

	int ReadAlarmCode( void ) { return m_AlarmCode; }
	// read alarm code

protected:

	virtual void WriteOut( unsigned char *data, unsigned size ) = 0;
	// write de-compressed data out to destination stream

	virtual unsigned ReadIn( unsigned char *data, unsigned size ) = 0;
	// read compressed data from source stream
	// return is the number of data been read

	virtual void SkipSourceTo( unsigned long count ) = 0;
	// skip data in source stream
	// count	the number to be skip from current position, in bytes.

	virtual void RewindSourceStream() = 0;
	// rewind data in source stream

	virtual int IsSourceStreamEOF() = 0;
	// query whether end-of-file

	virtual void LFRHandler( TLocalFileRecord *pLFR,
							 char *pathname,
							 int &fAccept,
							 int &fStopScan
	) = 0;
	// local file record handler
	// return 0 for continue scan, 1 for stop scan

	int ExtractFile( TLocalFileRecord *pFH );
	// extract a file block

private:

	enum {
		EOFTYPE_APPENDZERO,
		EOFTYPE_EOFCODE
	};
	
	// attribute constant for general purpose
	enum {
		LH_FLAG_ENCRYPT = 0x01	// file is encrypted
	};

	// flags for deflated decompression
	enum {
		FLAG_Normal			= 0x00,		// normal compression
		FLAG_Maximum		= 0x02,		// maximum compression
		FLAG_Fast			= 0x04,		// fast compression
		FLAG_SuperFast		= 0x06,		// super fast compression
		FLAG_LocalFileEnd	= 0x08		// use local file end record
	};

	// compression method 
	enum {
		CM_Stored = 0,		// 0 stored
		CM_Shrunk,			// 1 shrunk
		CM_Reduced1,		// 2 reduced with factor 1
		CM_Reduced2,		// 3 reduced with factor 2
		CM_Reduced3,		// 4 reduced with factor 3
		CM_Reduced4,		// 5 reduced with factor 4
		CM_Imploded,		// 6 imploded
		CM_Tokenized,		// 7 tokenized (not used)
		CM_Deflated			// 8 deflated
	};

	// signature constant
	enum {
		SIG_PK				= 0x4b50,	// PK record signature
		SIG_LocalFile		= 0x0403,	// file descrition record leading its data
		SIG_LocalFileEnd	= 0x0807,	// scan disk signature and local file end record
		SIG_CentralFile		= 0x0201,	// file description record in central directory
		SIG_EndOfCentralDir	= 0x0605	// end of central directory record
	};

	static unsigned short m_SortedCLIforCLT[19];
	// the sorted code length table index for build code
	// length tree to decode the code length table for futher
	// decoding

	static unsigned short m_NonSmpleLenCodeTable[31];
	// code table for length code in literal Huffman tree

	static unsigned short m_NonSmpleLenExtraBitTable[31];
	// extra bit table for length code in literal Huffman tree

	static unsigned short m_NonSmpleDistCodeTable[30];
	// code table for distance Huffman tree

	static unsigned short m_NonSmpleDistExtraBitTable[30];
	// extra bit table for distance Huffman tree

	int m_AlarmCode;
	// current alarm code from last decoding process

	CZCRC32			m_CRC32;
	// CRC32 helper object

	unsigned char	*m_OutBuffer;
	// pointer to output buffer to store de-compressed character

	unsigned char	*m_OutBufCursor;
	// pointer to next empty slot for store character

	unsigned char	*m_OutBufLimit;
	// upper bound pointer of output buffer

	unsigned		m_OutBufSize;
	// size of output buffer

	unsigned char	*m_InBuffer;
	// pointer to input buffer to cache input stream data

	unsigned char	*m_InBufCursor;
	// pointer to next un-read character wait for read

	unsigned char	*m_InBufTail;
	// pointer to slot after last available character

	unsigned		m_InBufSize;
	// size of input buffer

	unsigned long	m_SourceRemainSize;
	// remain size of source data

	unsigned long	m_BitHolder;
	// source bit holder

	int m_BitHolderLen;
	// number of bit inside the bit holder

	int m_EOFType;
	// type of end of stream code

	void ExtractBegin( unsigned long SourceSize, int EOFType );
	// begin of extract process

	int ExtractEnd( unsigned long crc );
	// end of extract process

	void StoreChar(unsigned char data);
	// store uncompressed character into output buffer, also
	// calculate and update CRC accumulator

	int ReadChar(void);
	// read one character from input buffer

	void ExtractCopy( unsigned long size );
	// copy source data to output but with

	unsigned short PeekCode( int NumOfBit );
	// peek code from input stream

	unsigned short GetCode( int NumOfBit );
	// get code from input stream

	int BuildHuffmanTree( unsigned short *CodeLenTable, int CodeLenTableSize, int NumOfSimpleCode,
						  unsigned short *NonSimpleCodeTable, unsigned short *NonSimpleExtraBitTable,
						  THuffmanTree **pHuffmanTree, int *MaxLookupLen
	);
	// build a Huffman lookup tree
	// CodeLenTable				the table of code length
	// CodeLenTableSize			the size of code length table
	// NumOfSimpleCode			number of simple code
	// NonSimpleCodeTable		non-simple code code table
	// NonSimpleExtraBitTable	extra bit table for non-simple code
	// HuffmanTable				the result huffman table
	// MaxLookupLen				the maximum lookup bit length of huffman table
	// return					TRUE for successful, FALSE for failure

	void FreeHuffmanTree( THuffmanTree *pHuffmanTree );
	// free a huffman tree

	int HuffmanDecoder(	THuffmanTree *LiteralTree,
						THuffmanTree *DistanceTree,
						int LiteralLookupLen,
						int DistanceLookupLen
	);
	// decoder for huffman code block
	// LiteralTree				literal huffman tree
	// DistanceTree				distance huffman tree
	// LiteralLookupLen			literal maximum lookup length
	// DistanceLookupLen		distance maximum lookup length
	// return TRUE for successful, return FALSE for failure

	int DecodeFixedHuffmanBlock(void);
	// decode a fixed Huffman code block, which use a fixed Huffamn
	// tree for decoding
	// return TRUE for successful, return FALSE for failure

	int DecodeDynamicHuffmanBlock(void);
	// decode a dynamic Huffman code block, which use a dynamic
	// construted Huffman tree for decoding
	// return TRUE for successful, return FALSE for failure

	int ExtractStoredFile( unsigned long size, unsigned long crc );
	// extract stored type data from zip compressed data
	// return TRUE for successful, FALSE for failure

	int ExtractInflateFile(	unsigned long size,	unsigned long crc );
	// extract a deflated compressed file
	// return TRUE for successful, FALSE for failure

};

#endif // !defined(ZIPARCH_H_)
