// IRtcDevice.h: interface for the IRtcDevice class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IRTCDEVICE_H__93384C24_8E73_11D3_850F_0000E86B4150__INCLUDED_)
#define AFX_IRTCDEVICE_H__93384C24_8E73_11D3_850F_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class IRtcDevice  
{
public:
	virtual ~IRtcDevice() {}
	// destructor

	virtual void start(void) = 0;
	// start RTC service

	virtual void stop(void) = 0;
	// stop RTC service

	virtual ULONG connect( PFNSERVICE pfnService, LPVOID lpParameter, ULONG duration ) = 0;
	// connect to realtime timer callback service
	// pfnService	pointer to timer arrival service routine.
	// lpParameter	pointer service parameter.
	// duration		calling duration, in micro second
	// return the handle of this connection

	virtual void disconnect( ULONG handle ) = 0;
	// disconnect from specified timer channel
	// handle		the handle of connection, return from connect()

	virtual ULONG getCounter( void ) = 0;
	// get RTC(real time clock) timer counter value

	virtual ULONG getFrequency( void ) = 0;
	// get real time cloack frequency

	virtual ULONG getActualDuration( ULONG handle ) = 0;
	// get actual duration of specified channel, in micro-second
};

#endif // !defined(AFX_IRTCDEVICE_H__93384C24_8E73_11D3_850F_0000E86B4150__INCLUDED_)
