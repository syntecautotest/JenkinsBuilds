#if !defined(_QUATERNION_H____INCLUDED_)
#define _QUATERNION_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMatrixN;
class CVector3d;

class CQuaternion
{
public:
	CQuaternion( void );
	// constructor

	CQuaternion( CMatrixN &mat );
	// constructor, given rotation matrix

	CQuaternion( const double angle, const double axis[3] );
	// constructor, given angle and axis

	CQuaternion( const double alpha, const double beta, const double gamma );
	// constructor, given Fixed angle with XYZ rotation

	~CQuaternion( void );
	// destructor

	void SetByAngleAndAxis( const double angle, const double axis[3] = NULL );
	// set quaternion by angle and axis

	void setByFixedAngleZXZ( const DOUBLE alpha, const DOUBLE beta, const DOUBLE gamma );
	// set quaternion by Fixed angle with ZXZ rotation: [gamma] * [beta] * [alpha]

	void setByFixedAngleXYZ( const DOUBLE roll, const DOUBLE pitch, const DOUBLE yaw );
	// set quaternion by Fixed angle with RPY rotation: [ yaw ] * [ pitch ] * [ roll ]
	// Fixed angle Rz(yaw) * Ry(pitch) * Rx(roll) (first)
	// Euler angle (first) Rz(alpha) * Ry(beta) * Rx(gamma)
	// Fixed RPY			<->	Euler ZYX
	// C : yaw		(z)		<->	alpha	(z)
	// B : pitch	(y)		<->	beta	(y')
	// A : roll		(x)		<->	gamma	(x")

	void SetByRotMat( CMatrixN &Mat );
	// set quaternion by rotation matrix

	void SetByRotMat( const double Rot[9] );
	// set quaternion by rotation matrix
	// the array size must be 3x3

	void SetByArray( const double q[4] );
	// set quaternion by an array

	void Copy( const CQuaternion &q );
	// copy quaternion

	void UpdateAngleAndAxis( void );
	// update angle and axis

	void Normalize( void );
	// normalize

	void GetQuaternion( double q[4] ) const;
	// output quaternion

	double GetAngle( void ) const;
	// return angle

	void GetAxis( double axis[3] ) const;
	// output axis

	void ToRotMat( CMatrixN &Mat ) const;
	// quaternion to rotation matrix

	void ToRotMat( double R[] );
	// quaternion to rotation array R[], row first

	void ToFixedAngleZXZ( DOUBLE angle[ 3 ] ) const;
	// quaternion to ZXZ Fixed angle

	void ToFixedAngleXYZ( DOUBLE angle[ 3 ] ) const;
	// X angle[ 0 ] = roll
	// Y angle[ 1 ] = pitch
	// Z angle[ 2 ] = yaw

	void Multiply( const CQuaternion &quat1, const CQuaternion &quat2 );
	// q1 multiplied by q2

	CVector3d Multiply( CVector3d &vec );
	// Multiplying a quaternion q with a vector v applies the q-rotation to v

	void Conjugate( CQuaternion &result );
	// output quaternion conjugate of this quaternion

	void Conjugate();
	// convert this quaternion to conjugate

private:
	double m_q0;
	// quaternion, w

	double m_q1;
	// quaternion, i

	double m_q2;
	// quaternion, j

	double m_q3;
	// quaternion, k

	double m_angle;
	// rotation angle

	double m_iAxis;
	double m_jAxis;
	double m_kAxis;
	// rotation axis
};

#endif // !defined(_QUATERNION_H____INCLUDED_)