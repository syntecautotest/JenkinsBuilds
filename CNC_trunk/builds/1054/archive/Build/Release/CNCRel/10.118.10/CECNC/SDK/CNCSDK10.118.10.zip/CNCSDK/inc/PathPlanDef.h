#if !defined(PATHPLANDEF_H__INCLUDED_)
#define PATHPLANDEF_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#endif // !defined(PATHPLANDEF_H__INCLUDED_)
