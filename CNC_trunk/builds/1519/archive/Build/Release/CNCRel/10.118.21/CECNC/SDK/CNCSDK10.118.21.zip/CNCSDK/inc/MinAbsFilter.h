// SvoMinAbsFilter.h: interface for the CSvoMinAbsFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SVOMINABSFILTER_H__E9398740_A264_4778_B568_879BAE963F64__INCLUDED_)
#define AFX_SVOMINABSFILTER_H__E9398740_A264_4778_B568_879BAE963F64__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// To filter the minimum absolute value from n newest raw data,
// and return its raw value.
class CMinAbsFilter
{
public:
	CMinAbsFilter( UINT nArrLength = 3 );
	// Constructor (default array length is 3)

	~CMinAbsFilter();
	// Destructor

public:
	void Put( LONG nValue );
	// Put value to array

	LONG Get( void );
	// Get filtered value from array

	void Clear( void );
	// Clear all array data

private:
	const UINT m_nArrLength;
	// Array length

	LONG *m_pRawValueArr;
	// Record input raw data

	LONG *m_pAbsValueArr;
	// Record absolute value array which mapping raw data array

	UINT m_nNextIndex;
	// Record current write data index

	CRTMutex m_cs;
	// To protect data conflict
};

#endif // !defined(AFX_SVOMINABSFILTER_H__E9398740_A264_4778_B568_879BAE963F64__INCLUDED_)
