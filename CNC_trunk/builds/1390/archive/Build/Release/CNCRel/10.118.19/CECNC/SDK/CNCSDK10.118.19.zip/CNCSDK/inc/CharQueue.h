// CharQueue.h: interface for the CCharQueue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHARQUEUE_H__618F6283_5B5A_11D3_8491_0000E86B4150__INCLUDED_)
#define AFX_CHARQUEUE_H__618F6283_5B5A_11D3_8491_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCharQueue
{
public:
	enum EExtendChar {
		CH_EOF = -1
	};
	// extended character code

public:
	CCharQueue( INT nCapacity = 2048 );
	// constructor

	~CCharQueue();
	// destructor

	INT getCapacity( void );
	// get maximum number of charachers in queue.

	INT getChar( void );
	// get one character from queue

	BOOL putChar( INT nCh );
	// put one character into queue

	INT getNumOfChar( void );
	// get number of character in queue

	INT isFull( void );
	// query whether the queue is full

	INT isEmpty( void );
	// query whether the queue is empty

	void empty( void );
	// empty all queue data

	INT seekChar( INT nChKey );
	// to seek specified character
	// return position from queue head, position start from 0 , -1 for not found

private:
	INT *m_pData;
	// pointer to data buffer

	INT m_nTail;
	// queue tail index

	INT m_nHead;
	// queue head index

	INT m_nCapacity;
	// queue capacity, maximum number of characters in queue

	CRTMutex m_cs;
	// mutex for object state consistent
};

#endif // !defined(AFX_CHARQUEUE_H__618F6283_5B5A_11D3_8491_0000E86B4150__INCLUDED_)
