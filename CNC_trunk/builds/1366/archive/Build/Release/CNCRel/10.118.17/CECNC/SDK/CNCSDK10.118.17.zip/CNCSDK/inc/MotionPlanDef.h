#if !defined(_MOTIONPLANDEF_H____INCLUDED_)
#define _MOTIONPLANDEF_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define	Max_NumOfECam			( 8 )			// maximum number of ecams
#define	Max_NumOfPair			( 32 )			// maximum number of curves
#define	Max_NumOfBlock			( 200 )			// maximum number of blocks
#define MovementEpsilon			( 1.0e-10 )		// epsilon for movement
#define Max_NumOfRegisterNo		( 100 )			// maximum number of Register No

#define MaxVRef		( 166.66666666666666666666666666667 )
#define MinFclamp	( 1.6666666666666666666666666666667e-11 )

typedef struct {
	DOUBLE MMtoIU;
	DOUBLE DefAmax;						// for NurbsAPI
	DOUBLE DefJmax;						// for NurbsAPI
	DOUBLE Fmax;
	DOUBLE Amax;
	DOUBLE Jmax;
	DOUBLE FRmax;						// for robot
	DOUBLE ARmax;						// for robot
	DOUBLE JRmax;						// for robot
	DOUBLE DFRmax;						// for robot
	DOUBLE ChordErrorTol;
	DOUBLE ArcRefRadius;
	DOUBLE ArcRefFeedrate;
	DOUBLE DefArcRefFeedrate;			// for NurbsAPI
	DOUBLE CornerFeedrate;
	DOUBLE ThreadAmax;					// for ThreadNormal
	DOUBLE AxFmax[ NUMOF_AXIS ];
	DOUBLE AxAmax[ NUMOF_AXIS ];
	DOUBLE AxJmax[ NUMOF_AXIS ];
	DOUBLE AxFDmax[ NUMOF_AXIS ];
	DOUBLE AxRapidFmax[ NUMOF_AXIS ];
	DOUBLE AxRapidF0[ NUMOF_AXIS ];
	DOUBLE AxRapidAccmax[ NUMOF_AXIS ];
	DOUBLE AxRapidDecmax[ NUMOF_AXIS ];
	DOUBLE AxRapidJmax[ NUMOF_AXIS ];
	DOUBLE LoopGain[ NUMOF_AXIS ];
	DOUBLE AxTA[ NUMOF_AXIS ];
	DOUBLE AxTs[ NUMOF_AXIS ];
	DOUBLE ServoGain;					// for EDM
	BOOL bRapidByLinear;				// for Rapid Travel
	LONG nUseG00FmaxAmax;				// #1517
	DOUBLE Ts;							// for ThreadNormal
	INT nZIndex;						// for ThreadNormal
} TMotParamTable;

struct TFileData {
	double V;		// velocity of the point
	double A;		// acceleration of the point
	double Pm;		// horizontal coordinate of th point
	double Ps;		// vetical coordinate of the point
};

struct TBlockData {
	double V0;		// start velocity of the block
	double Vc;		// end velocity of the block
	double A0;		// start acceleration of the block
	double Ac;		// end acceleration of the block
	double Pm;		// block move time( displacement of the master axis )
	double Ps;		// block movement
};

struct TRegMapData {
	int nGroup;		// index of ECam
	int nCurve;		// index of ECam pair
	int nPoint;		// index of FileData
	int nAttribute;	// which attribute of FileData
	int nRegister;	// corresponds to Register No
};

struct TFileDataPacket {
	int NumOfPoints;
	TFileData Fdata[Max_NumOfBlock];

	TFileDataPacket() {
		NumOfPoints = 0;
	}
};

enum EECamErrCode {
	ERROR_NOERROR = 0,
	ERROR_TOOMUCHPOINT,
	ERROR_NOAXISNAME,
	ERROR_PLANFAILURE,
	ERROR_NOTSUPPORT
};

enum E3DArcVector {
	ARC_CenterVectorX = 0,	// index of Center vector x
	ARC_CenterVectorY = 1,	// index of Center vector y
	ARC_CenterVectorZ = 2,	// index of Center vector z
	ARC_NormalVectorX = 3,	// index of Normal vector x
	ARC_NormalVectorY = 4,	// index of Normal vector y
	ARC_NormalVectorZ = 5,	// index of Normal vector z
};

// define for skip source
#define SKIP_SOURCE_Default				( 62 )
#define SKIP_SOURCE_ExtendStart			( 101 )
#define SKIP_SOURCE_ExtendEnd			( 132 )
#define SKIP_SOURCE_Driver				( 200 )
#define SKIP_SOURCE_DriverEnd			( 200 + NUMOF_AXIS )


// 1G = 9.8 m / s^2 = 9.8e-9 mm / us^2
#define CONSTANT_ACC1G_MM_US		(9.8e-9)

// predefined code class
#define MRPCLASS_EOF					9998	// end of stream
#define MRPCLASS_EOB					9997	// end of block
#define MRPCLASS_WAIT					9996	// wait()
#define MRPCLASS_MACROCALL				8000	// macro function package

// opcode for MRPCLASS_EOF
#define EOF_NORMAL						0		// Normal Situation, when main NC file meets EOF
#define EOF_FORCE_RESET					100		// After NC File meets EOF, force coordinate to reset

// opcode for MRPCLASS_MACROCALL
#define MF_SETDRAW					1
#define MF_DRAWMARK					2
#define MF_DRAWHOLE					3
#define MF_STOPDRAW					4
#define MF_FUNCCALL_START			101
#define MF_SETFEEDCONTROL			101
#define MF_SETSINGLEBLOCKINHIBIT	102
#define MF_SETSPACONTROL			103
#define MF_SETOVERRIDELOCK			104
#define MF_SETUSEG00FMAXAMAX		105
#define MF_RESETTHREADDEBUGDATA		106
#define MF_INTERRUPTCALL			107
#define MF_SETG00MOTIONCONTROL		108
#define MF_RECORDMODE_START			109
#define MF_RECORDMODE_END			110
#define MF_PLAYMODE_START			111
#define MF_PACKETINFO				112
#define MF_NOTIFY_LASER_SYNC		113
#define MF_SETTAPRETRACEBLOCK		114
#define MF_SETPOWEROFFRETURNINHIBIT	115
#define MF_FUNCCALL_END				115

// size of global buffer
#define SIZE_ToolRadiusPreviewQueue				40
#define SIZE_ToolRadiusLookAhead				24
#define SIZE_PathSmoothMaxOutput				6
#define SIZE_ToolRadiusPacketBuffer				SIZE_ToolRadiusLookAhead * 8
#define MAX_FEATUREVECTOR						4
#define SIZE_CompensatePipe						8

// axis type for fAX
#define AXVATYPE_VACANT		0
#define AXVATYPE_MODAL		1
#define AXVATYPE_INC		2
#define AXVATYPE_CUSTOM		3

// axis direction for fAX
#define AXDIRECTION_CCW		0
#define AXDIRECTION_CW		1

#define MOTPKTFLAG_FullCircleHandled		0x01
#define MOTPKTFLAG_FullCircleYes			0x02
#define MOTPKTFLAG_GCodeInput				0x04
// reserved 0x08
#define MOTPKTFLAG_AddWeaveCondition		0x10
#define MOTPKTFLAG_UnderConveyorTracking	0x20

// motion param
#define MOTION_DefaultVelocity				1 / 6.0e3			// IU / us     ( 10 m / min )
#define MOTION_DefaultAcc					1 / 6.0e8			// IU / us ^ 2 ( accelerate to 10 m / min in 100 ms )
#define MOTION_DefaultJerk					1 / 2.0e12			// IU / us ^ 3 ( accelerate to 10 m / s ^2 in 20 ms )

// bit mask for feedhold and override inhibit
#define MASK_FeedholdInhibit				0x0004
#define MASK_RapidTravelOverrideInhibit		0x0008
#define MASK_CuttingOverrideInhibit			0x0010
#define MASK_SpindleOverrideInhibit			0x0020

// bit mask for override lock
#define MASK_RapidTravelOverrideLock		0x0008
#define MASK_CuttingOverrideLock			0x0010
#define MASK_SpindleOverrideLock			0x0020

// Event trigger CoordinateID
#define Event_CoordIdGap					( 100 )
#define Event_LaserCoordId					( 1000 )

#ifdef __cplusplus
extern "C" {
#endif

// enable 2-byte alignment
//#pragma pack(2)

#ifndef TMotReqPkt_TYPEDEF_
#define TMotReqPkt_TYPEDEF_

struct TQuaternionInfo {
	double QAngle;				// quaternion dTheta in radian(IU)
	double RotAxis[3];			// rotation axis of orientation of robot arm, or quaternion rotate axis
	short int bQuatMarked;		// if quaternion is changed, mark it.
};

struct TRobotAccSet {
	double AccOverride;			// acceleration override address value
	double JerkOverride;		// jerk override address value

	BYTE fAccOverride;			// acceleration override
	BYTE fJerkOverride;			// jerk override
};

struct TRobotMotIns {
	TRobotAccSet AccSet;		// robot acceleration instruction
	long OvlType;				// robot overlap type
	double OvlParam;			// robot overlap param

	// reserve for robot motion setting in the future
};

struct TFiveAxisData {
	double vStart[3];			// start tool orientation
	double StartMasterAngle;	// start MasterAngle and SlaveAngle in radian(BLU)
	double StartSlaveAngle;
	// Arrays below are arranged as the sequence of [ X, Y, Z, M ,S ]'s information
	DOUBLE fromPos[ NUMOF_RTCP_AXIS ];	// axis position at the start of node( BCS, IU) 
	DOUBLE toPos[ NUMOF_RTCP_AXIS ];	// axis position at the start of node( BCS, IU)
	DOUBLE eAxEnter[ NUMOF_RTCP_AXIS ];	// axis enter vector( MCS, IU )
	DOUBLE eAxLeave[ NUMOF_RTCP_AXIS ];	// axis leave vector( MCS, IU )

};

// data structure for storing block information, which
// have been executing
struct TPacketInfo {
	LONG	ProgramNameID;					// program name identifier
	LONG	SequenceNumber;					// sequence number
	LONG	DispatchSeqNumber;				// dispatch sequence number
	LONG	LineNumber;						// line number
	LONG	BlockAccTime;					// block acceleration time
	DOUBLE	BlockCmdFeedrate;				// block command feedrate, max of F1, F2( IU/us )
	union {
		// CNC only
		DOUBLE RTOverride;					// rapid traverse override, unit: 1%
		DOUBLE RTF0Override;				// rapid traverse F0 override, unit: 1%
		// ROBOT only
		struct {
			INT nMOVJ_LimitingRobotJoint;	// in MOVJ mode, the robot joint which has the max %
			INT nMOVJ_LimitingExtAxJoint;	// in MOVJ mode, the external joint which has the max %
		};
	};
	// TO DO: for MPG simulation backward trace, not implement for saving memory
	// long	LastBlockAccTime;				// last block acceleration time

	struct TBlockModalState {
		long InterpolationMode;				// interpolation mode: G00, G01, G02, G03, G06, G06.2, G33, G34
		long CuttingFeedrateControlMode;	// cutting feedrate control mode: G61, G62, G63, G63.2, G64
		long ToolLengthCompensationMode;	// tool length compensation mode: G43, G43.4, G43.5, G44, G49
		long CoordinateRotationMode;		// coordinate rotation mode: G68, G68.2, G68.3, G69
		WORD WorkingPlaneMode:2;			// work plane selection mode: G17, G18, G19
		WORD FeedMode:2;					// feed mode: G93, G94, G95
		WORD InputCommandMode:1;			// input command mode: G90, G91
		WORD InputDimensionMode:1;			// input dimension mode: G70, G71
		WORD StrokeCheckMode:1;				// stored stroke check mode: G22, G23
		WORD CutterCompensationMode:2;		// cutter compensation mode: G40, G41, G42
		WORD ScalingMode:1;					// scaling mode: G50, G51
		WORD SpindleSpeedMode:1;			// spindle speed mode: G96, G97
		WORD SpindleSpeedDetectionMode:1;	// spindle speed fluctuation detection mode: G25, G26
		WORD PolarTransformMode:1;			// polar coordinate transform mode: G12, G13
		WORD PolarCommandMode:1;			// polar coordinate command mode: G15, G16
		WORD Reserved:2;					// reserved for future use
	} BlockModalState;
};

typedef TPacketInfo::TBlockModalState TBlockModalState;

struct TAxisFlag
{
	int	mode : 4;
	int	direction : 1;
};

struct TMotReqPkt {

	// common field
	TMotReqPkt	*pNext;			// link to next packet
	LONG		ClassID;		// class identifier
	LONG		Opcode;			// opcode
	BYTE		fQuietMode;		// quiet mode indicator
	TPacketInfo	PacketInfo;		// packet information
	BYTE		Flags;

	// [switch_type(int),switch_is(Class)]
	union {

		// [case(MRPCLASS_MACROCALL)] or [case G10 L1021]
		struct {
			int			cArgs;						// argument count
			TOcVariant	vArgs[MAX_MotReqPktArgs];	// argument value
		};

		// [default]
		struct {
			double		AX[NUMOF_AXIS];				// axis address value
			TAxisFlag	fAX[NUMOF_AXIS];			// axis address attribute

			double		FA[ 3 ];					// feedrate parameter address value
			BYTE		fFA[ 3 ];					// feedrate parameter

			double		Arg[5];						// macro argument
			BYTE		fArg[5];					// macro argument attribute

			long		P;							// P address, dwell time in mini-second
			long		L;							// L address
			double		Q;							// Q address
			double		R;							// R address
			double		Angle;						// angle address
			union {
				double	Round;						// corner round address
				double	Chamfer;					// corner chamfer address
			};

			struct TAddressFlag {					// flags for address appearance
				BYTE fAbsolute:1;					// absolute movement command
				BYTE fP:1;							// P address
				BYTE fL:1;							// L address
				BYTE fQ:1;							// Q address
				BYTE fR:1;							// R address
				BYTE fAngle:1;						// angle address
				BYTE fRound:1;						// corner angle address
				BYTE fChamfer:1;					// corner chamfer address
			} fAddr;

			TQuaternionInfo	QInfo;					// quaternion info for five axis machine & robot

			union {
				// CNC only
				struct {
					double				IP[6];					// interpolation parameter address value
					BYTE				fIP[6];					// arc interpolation parameter

					double				TO[3];					// tool orientation parameter address value for RTCP type2
					BYTE				fTO[3];					// tool orientation parameter

					long				S[NUMOF_SPINDLE+1];		// S address, maximum spindle speed for G92
																// 0 for cutting spindle;
																// 1 for S1, 2 for S2, etc...
					BYTE				fS[NUMOF_SPINDLE+1];	// S address

					long				RadiusOverride;			// tool radius override
					TFiveAxisData		FData;					// data for five axis machine
				};

				// Robot only
				struct {
					DOUBLE				StartJointPos[ NUMOF_ROBOT_AXIS ];	// joint position at the beginning of the block

					DOUBLE				AX2[ NUMOF_AXIS ];					// axis address value (for MOVC)
					TAxisFlag			fAX2[ NUMOF_AXIS ];					// axis address attribute (for MOVC)
					
					DOUBLE				EECmd[ NUMOF_ROBOT_AXIS ];			// end-effector pos and ori address value
					TAxisFlag			fEECmd[ NUMOF_ROBOT_AXIS ];			// end-effector pos and ori address attribute

					DOUBLE				EECmd2[ NUMOF_ROBOT_AXIS ];			// end-effector pos and ori address value (for MOVC)
					TAxisFlag			fEECmd2[ NUMOF_ROBOT_AXIS ];		// end-effector pos and ori address attribute (for MOVC)

					TRobotMotIns		MotIns;								// Robot motion instruction

					DOUBLE				RotAngle[ 2 ];						// end-effector orientation rotation angle
					TQuaternionInfo		QInfo2;								// extended quaternion info (for MOVC)
				};
			};
		};
	};
};

enum EHaltedPtStatus {
		HPS_Error,
		HPS_NonZeroOffset,
		HPS_ZeroOffset
};
// Offset Status of Halted Pt for AuxCoord

#endif // TMotReqPkt_TYPEDEF_

#ifndef TLANODE_TYPEDEF_
#define TLANODE_TYPEDEF_

#define LAOPCODE_FuncCall			99999999L
#define SIZE_LAFuncCallArgs			( 10 )

// common flag
#define LAMASK_ExactStop			0x00000001
//#define LAMASK_xxx				0x00000002
//#define LAMASK_xxx				0x00000004
//#define LAMASK_xxx				0x00000008
#define LAMASK_BackElimination		0x00000010
#define LAMASK_ThreadExceedFeed		0x00000020
#define LAMASK_InvalidThreadingLead	0x00000040
#define LAMASK_EOBMark				0x00000080
#define LAMASK_ThreadGeomAxisSetErr 0x00000100

// flag for CutSmoothSCurve
#define LAMASK_ForwardStart			0x00000100
#define LAMASK_BackwardStart		0x00000200
#define LAMASK_ModifyTop			0x00000400
//#define LAMASK_xxx				0x00000800

// flag for CutSCurve
#define LAMASK_CalcStartVel			0x00001000
#define LAMASK_Monotone				0x00002000 // monotonously decreasing for general purpose (PlanGroup, function of FCCutSCurve)
#define LAMASK_Mature				0x00004000
#define LAMASK_GroupEnd				0x00008000
#define LAMASK_InhibitInterval		0x00010000
#define LAMASK_VcFixed				0x00020000
//#define LAMASK_xxx				0x00040000

// flag for CutString
#define LAMASK_HasTimeAxis			0x10000000
#define LAMASK_HasOtherAxes			0x20000000
#define LAMASK_IncrementCommand		0x40000000
#define LAMASK_OnlyMaster			0x80000000

#define UnreachableFeedrate			(1.0e8)
#define UnreachableAcceleration		(1.0e60)

enum EStopType {
	EST_Stopless = 0,	// needn't stop
	EST_V0VcZero,		// V0 = Vc = 0.0
	EST_VcZero			// Vc = 0.0
};

enum ECoordType {
	ECT_Normal = 0,					// normal CNC coordinate
	ECT_SingleAxis,					// single axis coordinate
	ECT_Aux,						// auxiliary coordinate
	ECT_Simulate,					// simulate coordinate
	ECT_Robot,						// Robot coordinate
	ECT_BackgndExecuter,			// background executer
	ECT_Loader						// loader coordinate
};

// type of move command
enum EMoveType {
	MOVE_NONE = 0,	// not define cmd type
	MOVE_AUTO,		// cmd from InterpolationTick
	MOVE_MANUAL,	// cmd from putManualMovement
};

#ifndef TPVTSEGMENT_TYPEDEF_
#define TPVTSEGMENT_TYPEDEF_

typedef struct tagPVTSegment {
	double	P;
	double	V;
	double	T;
} TPVTSegment;

enum EMaxBound {
	MAX_NumOfPVTSegment	= 10
	// count	usage
	//-----------------------------------------
	// 7		bell-shaped trajectory segments
	// 1		initial velocity boost segment
	// 1		reserved for G00 sync segment
};
// bound constant

struct TPVTSheet {
	double		MoveTime;
	int			count;
	TPVTSegment segment[MAX_NumOfPVTSegment];

	TPVTSheet() { // init
		MoveTime = 0.0;
		count = 0;
	}
};
// data structure for PVT segment list
// MoveTime	block movement time, in micro-second
// count	the number of PVT segment
// segment	PVT movement segment
// P		displacement of segment, displacement per BLU
// V		velocity of segment, in velocity per BLU
// T		movement time of segment, in micro-second

#endif // TPVTSEGMENT_TYPEDEF_

struct TLANode {

	// common field
	TPacketInfo		PacketInfo;			// packet for block information tracking
	long			Opcode;				// opcode 1, 2, 3, 31, 33, 34
	long			flags;				// working flags
	EStopType		nStopType;			// stop type
	TLANode			*pNext;				// pointer to next node

	// [switch_type(long),switch_is(Opcode)]
	union {

		// case : LAOPCODE_FuncCall
		struct {
			long		FuncID;							// function identifier
			int			cArgs;							// argument count
			long		varArgs[SIZE_LAFuncCallArgs];	// argument value
			int			nExecute;						// has been executed
		};

		// case : MOTOP for MotionPlanner
		struct {
			double	AxisValue[NUMOF_AXIS];	// displacement, in IU

			double	FA[2];		// feedrate parameter address value
			BYTE	fFA[2];		// feedrate parameter

			long P;			// P address
			long L;			// L address
			double Q;		// Q address
			double R;		// R address

			struct TAddressFlag { // flags for address appearance
				BYTE fP:1;				// P address
				BYTE fL:1;				// L address
				BYTE fQ:1;				// Q address
				BYTE fR:1;				// R address
				BYTE reserved: 4;		// reserved memory
			} fAddr;
		};

		// case	 : MOTOP for LAMotionPlanner
		struct {
			double Length;					// length, in IU
			double V0;						// start corner velocity, in IU/us
			double Vc;						// destination corner velocity, in IU/us
			double A0;						// start corner acceleration , in IU/us^2
			double Ac;						// destination corner acceleration, in IU/us^2

			union {
				// [case(Nurbs)]
				struct {
					void *pVoid;			// nurbs curve pointer
					double MaxVelocity;		// maximum velocity, in IU/us
					double MoveTime;		// movetime, in us
				};

				// [default]
				struct {
					double	Elapse;					// estimated block elapse time, in micro-second
					double	Vref1;					// beginning velocity, in IU/us
					double	Vref2;					// ending velocity, in IU/us
					double	Fclamp;					// maximim clamp compound feedrate
					double	Aclamp;					// maximum clamp compound acceleration
					double	Jclamp;					// maximum clamp compound jerk
					double	TwoLAmax;				// 2.0 * Length * Aclamp, internal use
					double	PathLen;				// path length for feedrate calculation
					double	GeomLen;				// geometry space length, in IU, internal use
					double	EnterLen;				// enter leading length, in IU
					double	LeaveLen;				// leave tail length, in IU
					double	AX[NUMOF_AXIS];			// displacement, in IU
					double	EntryAX[NUMOF_AXIS];	// displacement at entry
					double	GeomAX[3];				// geometry axis displacement, in IU
					double	radius;					// fitting radius
					double	InvWeight[NUMOF_AXIS];	// Inverse weight of each axis displacement
					double	InvPathLenRatio;		// length / path length

					TQuaternionInfo QInfo;			// used by five-axis and robots machine

					// [case(G62)]
					double	Vstart;				// V0 for this Group
					double	Lcvs;				// distance at end of constant velocity section, in IU
					double	Vcvs;				// velocity at end of constant velocity section, in IU/us
					double	Lgrp;				// distance at end of this group, in IU
					double	Vgrp;				// velocity at end of this group, in IU/us
					double	Lrmn;				// distance remaining

					// for CNC
					double	IP[3];				// arc center vector, in IU
					double	Param[3];			// associate parameter
					long	nNumOfRev;			// number of revolution for spiral
					BOOL	fStraightLineNurbs;	// flag that this LANode is a part of zero curvature nurbs curve
												// i.e., it is a straight line nurbs curve, and it has only two control points.
					double	eCCEnter[3];		// curvature calculator enter unit vector, in IU
					double	eCCLeave[3];		// curvature calculator leave unit vector, in IU
					double	CornerFactor;		// corner factor, between 0.0 and 1.0
					double	eEnter[NUMOF_AXIS];	// enter unit vector, in IU
					double	eLeave[NUMOF_AXIS];	// leave unit vector, in IU

					TFiveAxisData FData;		// used by five-axis machines
				};
			};
		};
	};
};
// Look Ahead Node

#endif // TLANODE_TYPEDEF_

#ifndef TROBOTMRP_TYPEDEF_
#define TROBOTMRP_TYPEDEF_

// indicate displacement trajectory space
enum ETrajSpace {
	ETS_NOTDEFINED = -1,
	ETS_JOINT,
	ETS_CARTESIAN,

	ETS_NUMOF_TRAJSPACE,	// number of trajectory space
};

// store displacement from interpolator with specified trajectory space
struct TTrajDisp {
	ETrajSpace	TrajSpace;				// defined by ETrajSpace
	DOUBLE		Disp[ NUMOF_AXIS ];		// for ETS_JOINT, displacement stored in joint space in IU
										// for ETS_CARTESIAN, displacement stored in cartesian space in IU
};

struct TWaitSigInfo {
	int Num;				// signal number
	int LastTime;			// signal last time
	int WaitTime;			// signal wait time
	BYTE Source;			// 0: None, 1: I bit; 2: C bit; 3: R bit
	BYTE BitNum;			// bit number if R bit used
	BYTE Condition;			// 0: off; 1: on
	BYTE Reserved;			// Padding byte
};

struct TIOFcnLink {
	void *pSyncOut;			// SYNCOUT: robot synchronous out info. list
};

struct TRobotMRP {

	// common field
	TPacketInfo		PacketInfo;		// packet for block information tracking
	LONG			Opcode;			// opcode 1, 2, 3, 31, 33, 34
	LONG			flags;			// working flags
	EStopType		nStopType;		// stop type
	TRobotMRP		*pNext;			// pointer to next node
	BOOL bUnderConveyorTracking;			// flag for under conveyor tracking

	// [switch_type(long),switch_is(Opcode)]
	union {

		// case : LAOPCODE_FuncCall
		struct {
			LONG	FuncID;								// function identifier
			INT		cArgs;								// argument count
			LONG	varArgs[ SIZE_LAFuncCallArgs ];		// argument value
			INT		nExecute;							// has been executed
		};

		// case : MOTOP for RobotMotionPlanner
		struct {
			// motion handler pointer
			void *pMotionHandler;

			// motion associated function
			TWaitSigInfo	OvlWaitSigInfo;		// SWAITSIG: robot wait signal info. for overlapping next block or not
			TIOFcnLink		IOFcnLink;			// IO related function pointers

			// robot block info
			BOOL	bSecondBlk;					// MOVC consists of two blocks, this flag indicate the second block
			DOUBLE	SegLoBound;					// legnth acummulation of previous segments in %
			DOUBLE	SegUpBound;					// length accumulation of segments ( inc. current ) in %
			DOUBLE	FJ;							// FJ assigned command feedrate
			DOUBLE	FEJ;						// FEJ assigned command feedrate
			DOUBLE	FL;							// FL assigned command feedrate
			DOUBLE	FR;							// FR assigned command feedrate
			DOUBLE	AccRatio;					// ACC acceleration command override
			DOUBLE	JerkRatio;					// JERK jerk command override

			// robot Ovl info
			INT		nOvlType;					// overlap type
			INT		nAccIndex;					// index of the pvt sheet that is acceleration
			INT		nDecIndex;					// index of the pvt sheet that is deceleration
			DOUBLE	AccTime;					// acceleration time of s-curve velocity profile
			DOUBLE	DecTime;					// deceleration time of s-curve velocity profile
			DOUBLE	OvlParam;					// overlap parameter
			DOUBLE	OverlapStartTime[ 2 ];		// overlap start time

			// default robot motion specification
			TPVTSheet	Sheet;
			DOUBLE		Elapse;							// estimated block elapse time, in micro-second
			DOUBLE		Fclamp;							// maximim clamp compound feedrate
			DOUBLE		Aclamp;							// maximum clamp compound acceleration
			DOUBLE		Jclamp;							// maximum clamp compound jerk
			TTrajDisp	IntDisp;						// internal displacement
			TTrajDisp	ExtDisp;						// external displacement
			DOUBLE		StartJointPos[ NUMOF_ROBOT_AXIS ];	// joint position at the beginning of the block
			TQuaternionInfo	QInfo;						// used by five-axis and robots machine
			DOUBLE	V0;									// start corner velocity, in IU/us
			DOUBLE	Vc;									// destination corner velocity, in IU/us
			DOUBLE	A0;									// start corner acceleration , in IU/us^2
			DOUBLE	Ac;									// destination corner acceleration, in IU/us^2
			DOUBLE	Length;								// block length: synthesis length, in IU
			DOUBLE	AxLen;								// block length: joint space displacement, in IU
			DOUBLE	GeomLen;							// block length: end-effector geometry space displacement, in IU
			DOUBLE	RotLen;								// block length: end-effector rotational displacement, in IU
			DOUBLE	RotAngle;							// rotational angle

			// for MOVC motion specification
			DOUBLE	FRclamp;			// maximum clamp FR feedrate
			DOUBLE	Radius;				// fitting radius
			DOUBLE	ArcAngle;			// angle of the arc in MOVC
			DOUBLE	LocalStartPt[ 2 ];	// Local MOVC start point
			DOUBLE	LocalCenterPt[ 2 ];	// Local MOVC center point
			DOUBLE	LocalEndPt[ 2 ];	// Local MOVC end point
			DOUBLE	CoordFrame[ 9 ];	// coord frame description in world coord of local MOVC coord
			DOUBLE	EnterVec[ 3 ];		// MOVC enter vector
			DOUBLE	LeaveVec[ 3 ];		// MOVC leave vector
		};
	};
};

enum EWaitSignalType {
	SIG_TYPE_NONE = 0,
	SIG_TYPE_IBit = 1,
	SIG_TYPE_RBit = 2,
	SIG_TYPE_ABit = 3,
};

#endif // TROBOTMRP_TYPEDEF_

#ifndef EMircoCode_DEF_
#define EMircoCode_DEF_

enum EClassID {
	ECID_MOTOP = 0,
	ECID_FUNCCALL
};

// Notice: if you add a motion opcode that belongs to Robot, plz add it to RobotMOTOP for OCTest
enum EMOTOP {
	MOTOP_Null = -1,
	MOTOP_Rapid = 0,
	MOTOP_Linear = 1,
	MOTOP_ArcCW = 2,
	MOTOP_ArcCCW = 3,
	MOTOP_3DArc = 2004,
	MOTOP_Nurbs = 6002,
	MOTOP_SkipFunc = 31,
	MOTOP_ConstantThread = 33,
	MOTOP_VariableThread = 34,
	MOTOP_SkipTravel = 28001,
	MOTOP_FastDrill,
	MOTOP_StopCandidate,
	MOTOP_MOVL = 1001,
	MOTOP_MOVJ = 1002,
	MOTOP_MOVJII = 1003,
	MOTOP_MOVC = 1004,
	MOTOP_INCMOVL = 1005,
	MOTOP_INCMOVJ = 1006,
	MOTOP_INCMOVJII = 1007,
};

#define NUMOF_RBT_MOTOP		( 7 )

// robot motion opcode
// !! notice: the group of opcode is for OCTest separating robot from others
static const INT RobotMOTOP[ NUMOF_RBT_MOTOP ] = {
	MOTOP_MOVL,			MOTOP_MOVJ,			MOTOP_MOVJII,		MOTOP_MOVC,
	MOTOP_INCMOVL,		MOTOP_INCMOVJ,		MOTOP_INCMOVJII
};

// Notice: if you add a func call, plz make sure the reserved slots for LAPool is correct!
enum EFUNCID {
	FUNCID_Dwell = 4,						// Dwell
	FUNCID_Minimum = 8000,
	FUNCID_FeedPerMin,
	FUNCID_FeedPerRev,
	FUNCID_ExactStop,						// bExactStop
	FUNCID_StartLearningControl,			// for enable learning control data collection
	FUNCID_StopLearningControl,				// for disable learning control data collection
	FUNCID_MaxOverrideHint,					// New maximum override, .Old maximum override
	FUNCID_RigidTappingTo,					// ZAxisID, Displacement, Feedrate
	FUNCID_WritePLCRegister,				// bAbsolute, Register Number, Value
	FUNCID_WritePLCRegisterBit,				// write plc register bit
	FUNCID_SOSOffsetSetting,				// bAbsolute, Spindle No., Offset
	FUNCID_BacklashChange,					// to change backlash flag for rapid travel
	FUNCID_IBitLatchSetting,				// I-bit latch setting
	FUNCID_DrvSglLatchSetting,				// driver signal latch setting
	FUNCID_EnIPMacroInstruction,			// Ethernet/IP Explicit Message Macro Instruction

	FUNCID_RobotSyncOut,					// write synchronous output( robot only )
	FUNCID_WriteOBit,						// write O bit
	FUNCID_WriteABit,						// write A bit

	// the following is feedhold and override inhibit group, the order must NOT be changed
	FUNCID_SetFeedholdInhibit,				// to set feedhold inhibit word
	FUNCID_SetRapidTravelOverrideInhibit,	// to set rapid travel override inhibit word
	FUNCID_SetCuttingOverrideInhibit,		// to set cutting override inhibit word
	FUNCID_SetSpindleOverrideInhibit,		// to set spindle override inhibit word

	FUNCID_SetRapidTravelOverrideLock,		// to set rapid travel override lock word
	FUNCID_SetCuttingOverrideLock,			// to set cutting override lock word
	FUNCID_SetSpindleOverrideLock,			// to set spindle override lock word

	FUNCID_SetSPAInhibit,					// to set SPA function inhibit word
	FUNCID_ServoFastTapping,				// run fast tapping
	FUNCID_SingleStepInhibit,				// to set single step inhibit word
	FUNCID_PacketInfo,						// to save packet information indicator
	FUNCID_DummyEOB,						// for dummy EOB mark node
	FUNCID_DummyExactStop,					// for dummy Exact Stop
	FUNCID_TrajEnd,							// trajectort end
	FUNCID_TrajStart,						// trajectory start
	FUNCID_PostAccSPAChanged,				// post acc and SPA changed
	FUNCID_ThreadChanged,					// thread changed
	FUNCID_ThreadDumpDataReset,				// thread dump data reset
	FUNCID_OverlapInfo,						// overlap changed
	FUNCID_DummyLAWait,						// look ahead node of wait
	FUNCID_PostCheckStrokeLimitChanged,		// axis command queue changed
	FUNCID_StringStart,						// cycle start
	FUNCID_StringEnd,						// cycle end
	FUNCID_ProcessCommand,					// flush shift command
	FUNCID_CutStringClearSign,				// cycle clear
	FUNCID_SetSpindleSpeedCheckInhibit,		// to set spindle speed check inhibit word
	FUNCID_SetWPInfo,						// set workplane information.
	FUNCID_SetBackwardLocked,				// set MPG simulation backward locked
	FUNCID_RobotWaitSyncTracking,			// robot wait synchronized tracking
	FUNCID_RobotEndSyncTracking,			// robot end synchronized tracking
	FUNCID_SetSgnlLatchSource,				// set signal latch source
	FUNCID_EndExSgnlLatch,					// end external input signal latch
	FUNCID_WriteParam,						// write parameter value
	FUNCID_RecordMode_Start,				// record mode start
	FUNCID_RecordMode_End,					// record mode end
	FUNCID_PlayMode_Start,					// play mode start
	FUNCID_StartFromZero,					// start from zero speed
	FUNCID_BodeStartSampling,				// start sampling data for Bode plot
	FUNCID_RobotSmartWaitSignal,			// robot smart wait signal
	FUNCID_RobotZeroOverlap,				// robot zero overlap
	FUNCID_SetRobotUCSInfo,					// set robot user coordinate information
	FUNCID_SetRobotCoordUserOFST,			// set robot coordinate offset
	FUNCID_ClearRobotCoordUserOFST,			// clear robot coordinate offset
	FUNCID_SetRobotCoordSysOFST,			// set robot coordinate system offset
	FUNCID_ClearRobotCoordSysOFST,			// clear robot coordinate system offset
	FUNCID_StartVelChirpSignal,				// start velocity chirp signal
	FUNCID_StopVelChirpSignal,				// stop velocity chirp signal
	FUNCID_NOTIFY_LASER_SYNC,				// notify laser sync signal
	FUNCID_SetTapRetBlock,					// set tapping retrace block flag
	FUNCID_SetPowerOffReturnInhibit,		// set power off pull up inhibit
	FUNCID_SyncOutRegister,					// SYNCOUT Register
	FUNCID_SyncOutUnRegister,				// SYNCOUT UnRegister
	FUNCID_ZeroDispBlock,					// set zero displacement block flag
	FUNCID_SetWeaving,						// set start weaving or end weaving ( for robot )
	FUNCID_SetMotionWeavingCondition,		// set motion weaving condition ( for robot )
	FUNCID_SetStitch,						// set start stitching or end stitching( for robot )
	FUNCID_SetPostKineAccInhibit,			// set post kinematic acc inhibit
	FUNCID_SetSignalCondition,				// set signal condition
	FUNCID_SetWaitSignalCond,				// set wait signal condition
};

// Notice: if you add a func call, plz make sure the reserved slots for LAPool is correct!
#define MAX_DELIVER_NODES						8								// 8: TrajStart/TrajEnd, WPInfo Start/End, on/off spa, on/off PostKineAccInhibit, OverlapInfo, StartFromZero, MRP, MaxOverride
#define MIN_LAPOOL_BUFFER						( 4 + MAX_DELIVER_NODES )	// 12: see the following array
// this array is to list all possible LANodes while the motion planners change
// by updating this array, it also reminds us update the #define value to avoid memory crash
static const int LAPOOL_BUFFER[ MIN_LAPOOL_BUFFER ] = {
	// reserved for current motion planner
	FUNCID_SetPostKineAccInhibit,			// post kinematic acc inhibit info
	FUNCID_PostAccSPAChanged,				// post acc and SPA changed
	FUNCID_SetWPInfo,						// set workplane information.
	FUNCID_TrajEnd,							// trajectort end

	// reserved for next motion planner
	FUNCID_TrajStart,						// trajectory start
	FUNCID_SetWPInfo,						// set workplane information.
	FUNCID_PostAccSPAChanged,				// post acc and SPA changed
	FUNCID_SetPostKineAccInhibit,			// post kinematic acc inhibit info
	FUNCID_OverlapInfo,						// overlap changed
	FUNCID_StartFromZero,					// start from zero speed
	MOTOP_Linear,							// MRP
	FUNCID_MaxOverrideHint,					// New maximum override, .Old maximum override
};

enum EMotionMode {
	EMM_NULL = -1,
	EMM_RapidTravel,
	EMM_CutCSlope,
	EMM_Dwell,
	EMM_ThreadNormal,
	EMM_FastDrill,
	EMM_Tapping,
	EMM_SkipTravel,
	EMM_SkipFunction,
	EMM_CutSCurve,
	EMM_Nurbs,
	EMM_MachineCoordPositioning,
	EMM_CutString,
	EMM_MOVL,
	EMM_MOVJ,
};

enum EExecRetCode {
	RETOP_Shift = 0,
	RETOP_Wait,
	RETOP_ShiftAndEat,
	RETOP_ChangeMOT,
};

// peek wait signal condition function call result
enum EPeekWSCResult {
	EPWSCR_Exist = 0,
	EPWSCR_Empty,
	EPWSCR_NotDecided,
};

enum EHPCCSwitch {
	HPCC_Off = 0,			// HPCC off
	HPCC_CutCSlope,			// use CutCSlope module
	HPCC_Nurbs,				// use NurbsInterpolation module
	HPCC_CutCSlopeNoCorner,	// use CutCSlope and corenr combine module
	HPCC_CutFiveCSlope,		// use CutCSlope module for RTCP
	HPCC_CutFiveQuat		// use CutFiveAxis module for RTCP
};

enum ERobotMasterType {
	TYPE_Linear = 0,
	TYPE_Rotation,
};

// RTCP state identifier
enum ERTCPState {
	RTCP_Off = 0,		// RTCP off
	RTCP_RotAng = 1,	// G43.4, type1
	RTCP_ToolVec = 2,	// G43.5, type2
};

// TCP control on feature coordinate state identifier
enum ETCPFCState {
	TCP_FC_OFF,		// TCP control off
	TCP_FC_ON,		// TCP control on feature coordinate
};

struct TMicroCode {
	int								ClassID;
	int								Opcode;
	union {
		// MOTOP
		struct {
			double					duration;

			union {
				// Normal
				struct {
					double				AX[NUMOF_AXIS];
					double				EntryAX[NUMOF_AXIS];
					TQuaternionInfo		QInfo;				// five axis and robot

					// five axis
					TFiveAxisData	FData;				// used by five-axis machines
				};

				// Nurbs
				struct {
					void			*pNurbsCurve;	// nurbs curve
					TPacketInfo		PacketInfo;
					double			Lcvs;			// distance at end of constant velocity section
					double			Vcvs;			// velocity at end of constant velocity section
					double			Lgrp;			// total distance subtract distance at end of constant velocity section
					double			Vgrp;			// velocity at end of this group
				};
			};
		};

		// FUNCCALL
		struct {
			int					nExecute;
			union {
				// [case(FUNCID_PacketInfo)]
				TPacketInfo		PacketInfo;

				// [default]
				long			lParam[ SIZE_LAFuncCallArgs ];
			};
		};
	};
};

// exec control intruction return code
#endif // EMircoCode_DEF_

#ifndef TCTRLBLK_TYPEDEF_
#define TCTRLBLK_TYPEDEF_

enum EBlockType {
	BT_Helical,
	BT_Linear
};

typedef struct tagTCtrlBlkLine {
	double	V_0;		// velocity at time 0
	double	A_0;		// acceleration at time 0
	double	V_T;		// velocity at time T
	double	A_T;		// acceleration at time T
	double	C;			// jerk
	double	TM;			// block move time
} TCtrlBlkLine;

typedef struct tagTCtrlBlk {
	int				type;
	TCtrlBlkLine	CtlBlk;		// for angular interpolation
	double			transform[9];
	double			Px_0;			// x-position at time 0
	double			Py_0;			// y-position at time 0
	double			Rad_0;			// radius at time 0
	double			Angle_0;		// angle at time 0
	double			Px_T;			// x-position at time T
	double			Py_T;			// y-position at time T
	double			Rad_T;			// radius at time T
	double			Angle_T;		// angle at T;
	double			ZSpan;			// Z axis span
} TCtrlBlk;

#endif // TCTRLBLK_TYPEDEF_

#ifndef TCVSBLK_TYPEDEF_
#define TCVSBLK_TYPEDEF_

typedef struct tagTCvsBlk {
	double			Lcvs;			// x-position at time 0
	double			Vcvs;			// y-position at time 0
	double			Lgrp;			// radius at time 0
	double			Vgrp;			// angle at time 0
	double			Vcur;			// x-position at time T
	double			Acur;			// y-position at time T
	double			Amax;			// radius at time T
	double			Jmax;			// angle at T;
} TCvsBlk;

#endif // TCVSBLK_TYPEDEF_

// restore original alignment
//#pragma pack()
#ifdef __cplusplus
}
#endif /* extern "C" */

#endif // !defined(_MOTIONPLANDEF_H____INCLUDED_)
