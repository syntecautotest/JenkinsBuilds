// IBatteryRecordChannel.h : interface of IBatteryRecordChannel class.
//
//////////////////////////////////////////////////////////////////////
#if !defined ( AFX_IBATTERYRECORDCHANNEL_H__B21ED766_3360_46c9_90D1_1AD7DDBE9B47__INCLUDED_ )
#define AFX_IBATTERYRECORDCHANNEL_H__B21ED766_3360_46c9_90D1_1AD7DDBE9B47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IBatteryRecordChannel
{
public:
	virtual ~IBatteryRecordChannel(){};
	// destructor

	virtual void PrepareBatteryVoltage( void ) = 0;
	// start to get absolute encoder battery voltage information

	virtual EReadBatteryStatus GetBatteryVoltage( INT &nVoltage ) = 0;
	// check if battery info is ready, if yes, return the voltage
};

#endif // !defined ( AFX_IBATTERYRECORDCHANNEL_H__B21ED766_3360_46c9_90D1_1AD7DDBE9B47__INCLUDED_ )