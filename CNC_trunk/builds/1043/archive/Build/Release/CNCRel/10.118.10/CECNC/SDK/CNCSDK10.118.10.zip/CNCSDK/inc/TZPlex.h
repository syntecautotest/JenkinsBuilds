// TZPlex.h: interface for the TZPlex class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TZPLEX_H__FC7C9287_CF02_11D3_8588_0000E86B4150__INCLUDED_)
#define AFX_TZPLEX_H__FC7C9287_CF02_11D3_8588_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

struct TZPlex
// this is a variable length structure
{
	TZPlex* pNext;
	// pointer to next node

	void* data() { return this+1; }
	// return application data area

	static TZPlex* Create(TZPlex*& head, UINT nMax, UINT cbElement);
	// create a MPlex node

	void FreeDataChain();
	// free this one and links
};

#endif // !defined(AFX_TZPLEX_H__FC7C9287_CF02_11D3_8588_0000E86B4150__INCLUDED_)
