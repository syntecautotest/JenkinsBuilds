//
//	TPDAPIDef.H
//
//	Definitions for TPDAPI
//

#if !defined(_TPDAPIDEF_INCLUDED_)
#define _TPDAPIDEF_INCLUDED_

// available connection ID
#define MCCH_HouseKeeping		1	// non-real-time, non-sleepable kernel job.
#define MCCH_PLC				2	// real time
#define MCCH_Interpolation		4	// real time

#define PFNORXAPI				WINAPI

#define NUMOF_ROBOT_AXIS		6

// type definition for service routine callback
typedef DWORD (PFNORXAPI *PFNSERVICE)( LPVOID dwContext );

// axis control mode
enum ETPDAxisCtrlMode {
	ETPDACM_Unknown = -1,
	ETPDACM_Position = 0,
	ETPDACM_Torque = 1,
};


#endif // (_TPDAPIDEF_INCLUDED_)
