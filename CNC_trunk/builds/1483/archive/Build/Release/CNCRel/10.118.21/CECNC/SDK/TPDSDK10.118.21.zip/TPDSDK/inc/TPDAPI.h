//
//	TPDAPI.H
//
//	Third Party Developers Application Internal Public Interface
//

#if !defined(_TPDAPI_INCLUDED_)
#define _TPDAPI_INCLUDED_

HRESULT TPD_McConnect( INT nChannel, PFNSERVICE pfnService, LPVOID lpParameter, ULONG *pdwCookies );
// request multi-cast callback
// pfnService	pointer to service routine.
// lpParameter	pointer service parameter.
// pdwCookies	pointer to cookies, return non-zero when success, 0 for failure

HRESULT TPD_McDisconnect( INT nChannel, ULONG dwCookies );
// cancel multi-cast callback

HRESULT TPD_LgcGetRegister( INT nNo, LONG &nValue );
// get a PLC register 32-bit-relay state

HRESULT TPD_LgcPutRegister( INT nNo, LONG nValue );
// set a PLC register 32-bit-relay state

HRESULT TPD_PutCrdAxisPositionCmd( INT nCoordID, double Position[ NUMOF_ROBOT_AXIS ] );
// put axis position command for coordinate

HRESULT TPD_GetCrdAxisPositionFbk( INT nCoordID, double Position[ NUMOF_ROBOT_AXIS ] );
// get axis position feedback for coordinate

HRESULT TPD_PutCrdTCPPositionCmd( INT nCoordID, double XYZABC[ NUMOF_ROBOT_AXIS ] );
// put tool center point position with XYZ fixed angle command for coordinate

HRESULT TPD_GetCrdTCPPositionFbk( INT nCoordID, double XYZABC[ NUMOF_ROBOT_AXIS ] );
// get tool center point position with XYZ fixed angle feedback for coordinate

HRESULT TPD_SetControlMode( INT nAxisID, ETPDAxisCtrlMode nMode );
// set axis control mode, supported mode: position, torque

HRESULT TPD_GetControlMode( INT nAxisID, ETPDAxisCtrlMode &nMode );
// get axis control mode, supported mode: position, torque

HRESULT TPD_PutTorqueCommand( INT nAxisID, LONG nTRQCmd );
// torque command in 0.01% rated torque, supported mode: torque

HRESULT TPD_GetTorqueCommand( INT nAxisID, LONG &nTRQCmd );
// get torque command in 0.01% rated torque, supported mode: torque

#endif // (_TPDAPI_INCLUDED_)
