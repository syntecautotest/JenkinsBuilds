#if !defined(_FLCUTRTCP_H____INCLUDED_)
#define _FLCUTRTCP_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCurvatureCalculator;
class CArcFeature;
class CRTCPManager;

class CFLCutRTCP : public CFeedLimit
{
public:
	CFLCutRTCP( LONG nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool, CBPTLimiter *pBPTLimiter, CRTCPManager *pRTCPManager, DOUBLE InterpolationInterval );
	// constructor

	~CFLCutRTCP( void );
	// destructor

	void putGeomAxis( const INT XAxis, const INT YAxis, const INT ZAxis );
	// to put geometry axis index

	void putLookAheadCondition( const DOUBLE ChordErrorTol, const DOUBLE CornerFeedrate, const DOUBLE ArcRefRadius, const DOUBLE ArcRefFeedrate );
	// set maximum allowable feedrate for motion block movement
	// chord error tolerance, in IU
	// corner feedrate at 120 degree, in IU / us
	// arc reference radius and reference feedrate, in IU, and IU / us

public:
	BOOL IsEmpty( void );
	// query whether the pipe is empty

	void Abort( void );
	// abort

	void Reset( void );
	// reset

	void PutLANodeToCurvPart( TLANode *pNode );
	// put look ahead node to curvature part of feed limit module

	void CalcBlockLength( TLANode *pNode, CArcFeature &af );
	// calculate block length.

	void GetLengthAccumulator( DOUBLE &lengthAccumulator );
	// Get Length Accumulator and reset LengthAccumulator

	INT getCountOfCCQue( void );
	// get count in C.C. Queue

	INT getNumBPTLimtedBlock( void );
	// get number of blocks that their feedrates are limited BPT Limiter

	void FlushAllQueue( void );
	// flush queued nodes of feed limit module

	void NotifyNoCorner( BOOL bflag );
	// notify if corner existed

	void putMaxAxisRapidFmax( const DOUBLE AxRapidFmax[] );
	// put maximum axis rapid feedrate in IU / us

	void putMaxAxisRapidAmax( const DOUBLE AxRapidAmax[] );
	// put maximum axis rapid feedrate in IU / us

protected:
	TLANode *ReversePeek( void );
	// peek the last node in feed limit module

	virtual void CalcBlockMotionFeature( TLANode *pNode, CArcFeature &af );
	// calculate block motion feature

	void ClampBlockAccByAxisAcc( TLANode *pNode );
	// clamp block acceleration by maximum axis acceleration

	void ClampBlockAccByCompoundAcc( TLANode *pNode );
	// clamp block acceleration by compound acceleration

	void ClampArcBlockFeedrateBy408( TLANode *pNode, CArcFeature &af );
	// clamp arc block feedrate by parameter 408

	virtual void CalcCornerFeature( TLANode *pNode, DOUBLE &eLastVc );
	// to calculate inter-block feature

	void ClampByBPTLimiter( TLANode *pNode );
	// clamp feedrate by BPT Limiter

	void ClampLinearBlockFeedrateBy408( TLANode *pNode );
	// clamp linear block feedrate by parameter 408

	BOOL CalculateCornerDeviation( TLANode *pNode, TLANode *pLNode, DOUBLE &eDeviationLen, DOUBLE eDeviation[] );
	// calculate corner deviation and its length

	void ClampCornerFeedrateBy406( TLANode *pNode, DOUBLE eDeviationLen );
	// clamp corner feedrate by parameter 406

	void ClampCornerFeedrateByAxisAcc( TLANode *pNode, TLANode *pLNode );
	// clamp corner feedrate by maximum acc of each axis

	virtual void ClampCornerFeedrateByBlockFeedrate( TLANode *pNode, TLANode *pLNode );
	// clamp corner feedrate by block feedrate

	INT GetNumLimitedBlock( void );
	// debug data 375, shows the num of blocks that are limited by BPTLimiter

	void ClampBlockFeedrateByCompoundFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum compound feedrate

	void ClampBlockFeedrateByProgramFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum programming feedrate

	void ProcessMaxOverride( TLANode *pNode );
	// process maximum override

	void calcEnterLeaveVector( TLANode *pNode, CArcFeature &af );
	// calculate enter unit vector, leave unit vector

	void EstimateElapseTime( TLANode *pNode );
	// estimate elapse time of pNode

	long EstimateElapseTime_V0Vc( TLANode *pNode );
	// estimate elapse time of pNode with acceleration

protected:
	CCurvatureCalculator *m_pCurvatureCalculator;
	// curvature calculator object pointer

	CBPTLimiter *m_pBPTLimiter;
	// BPT Limiter pointer

	INT m_nNumLimitedBlock;
	// records the number of blocks that are limited by BPT Limiter

private:
	DOUBLE m_LengthAccumulator;
	// Length Accumulator

	CRTCPManager *m_pRTCPManager;
	// RTCP kinematic transform object manager

	CTrajectory m_TJ;
	// trajectory object

	DOUBLE m_InterpolationInterval;
	// interpolation interval

	DOUBLE m_AxRapidFmax[ NUMOF_AXIS ];
	// max axis rapid travel feed

	DOUBLE m_AxRapidAmax[ NUMOF_AXIS ];
	// max axis rapid travel acceleration

private:
	void ClampBlockFeedrateByAxisFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum axis feedrate

	void CalcNonLinearKineEnterLeaveVector( TLANode *pNode );
	// calc enter leave vector for non-linear kinematic transform RTCP

	void ClampCornerFeedrateByJerk( TLANode *pNode );
	// clamp Vc by constant jerk planning ( A0, Ac = 0 )

	void ClampBlockJerk( TLANode *pNode );
	// clamp block jerk by maximum jerk

};

#endif // !defined(_FLCUTRTCP_H____INCLUDED_)
