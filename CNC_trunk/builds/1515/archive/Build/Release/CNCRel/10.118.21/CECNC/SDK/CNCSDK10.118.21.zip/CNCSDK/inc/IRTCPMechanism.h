// IRTCPMechanism.h: interface for the IRTCPMechanism class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IRTCPMECHANISM_H_)
#define AFX_IRTCPMECHANISM_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IRTCPMechanism
{
public:
	enum EToolCoordType {
		ETCT_Cross,
		ETCT_Rotation,
	};

	enum ETableCoordSys {
		RTCS_StartPos,
		RTCS_ZeroPos,
	};

	enum EIntMode {
		EIM_NormalInt,
		EIM_QuatInt,
	};

	enum EFiveAxSolType {
		EST_ShortestDist = 0,	// choose shostest distance
		EST_MasterPos = 1,		// master rotary axis move toward positive direction
		EST_MasterNeg = 2,		// master rotary axis move toward negative direction
	};
	// define Five Axis kinematics choose solution type

public:
	virtual ~IRTCPMechanism( void ) {};
	// destructor

	virtual INT getMechType( void ) = 0;
	// get the type of RTCP mechanism
};

#endif	// IRTCPMECHANISM_H_
