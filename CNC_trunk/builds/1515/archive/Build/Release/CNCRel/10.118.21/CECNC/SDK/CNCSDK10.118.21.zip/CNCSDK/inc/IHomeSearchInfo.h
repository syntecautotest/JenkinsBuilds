// IHomeSearchInfo.h: interface for the IHomeSearchInfo
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IHOMESEARCHINFO_H__INCLUDED_)
#define AFX_IHOMESEARCHINFO_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct THomingInfo {
	INT		nSensorType;
	LONG	TA;				// unit: us
	LONG	TS;				// unit: us
	DOUBLE	IndexSpace;
	DOUBLE	MMToBLU;
	DOUBLE	Pitch;
	DOUBLE	InvAmax;		// max acceleration, unit: us * min / BLU
};

class IHomeSearchInfo
{
public:
	virtual ~IHomeSearchInfo( void ) {}
	// destructor

	virtual double readAbsolutePosition( void ) = 0;
	// read absolute position, in BLU

	virtual BOOL isIndexCaptured( void ) = 0;
	// is index capture

	virtual double readIndexPosition( void ) = 0;
	// read index position, in BLU

	virtual void startIndexCapture( void ) = 0;
	// start index capture

	virtual BOOL isZeroSpeed( void ) = 0;
	// is zero speed

	virtual BOOL IsOnHomeSensor( void ) = 0;
	// is on home sensor

// interface for CANOpenHoming
public:
	virtual void ResetIndexCapture( void ) = 0;
	// reset index capture

	virtual void setFollowingErrorCheck( BOOL bEnable ) = 0;
	// set following error check
};

#endif // !defined(AFX_IHOMESEARCHINFO_H__INCLUDED_)
