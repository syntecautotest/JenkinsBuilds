#if !defined(_SVOUTILITYDEF_H_INCLUDED_)
#define _SVOUTILITYDEF_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OperationDef.h"

////////////////////////////////
////// Latch Function /////////
///////////////////////////////
#define LS_BASEID		1		// latch select base ID

enum ELatchSource {
	ELS_Disabled = -1,
	ELS_Index = 0,
	ELS_Ext1 = 1,
	ELS_Ext2 = 2,
	ELS_Ext3 = 3,
	ELS_NUM,
};

enum EEventMode {
	EEM_Trigger = 0,
	EEM_Continuous,
};

enum EEdegStyle {
	EES_Positive = 0,
	EES_Negative,
};

enum ESyntecVersionInfo {
	ESVI_NotExist_Syntec = 0,
	ESVI_SupportNonSyntecPackageRestore,
	ESVI_NotSupportNonSyntecPackageRestore,
};

////////////////////////////////////
/////// Motor Information //////////
///////////////////////////////////
#define MOTORINFO_BIT_NOT_DEFINE				( 0x0000 )
#define MOTORINFO_BIT_RATED_TORQUE				( 0x0001 )
#define MOTORINFO_BIT_TYPE						( 0x0002 )
#define MOTORINFO_BIT_INERTIA					( 0x0004 )

#define MAX_VENDOR_NUM			( 3 )
#define MAX_MOTOR_NUM			( 200 )
#define MAX_MOTOR_NAME_LEN		( 32 )

enum EMotorVendor {
	NOT_DEFINE = 0,
	YASKAWA_SIGMA5,
	YASKAWA_SIGMA7,
	PANASONIC_A6,
};

enum EMotorType {
	UNSUPPORT_MOTOR = -1,
	ROTARY_MOTOR = 0,
	LINEAR_MOTOR,
};

enum EMotorInfoIndex {
	EMI_RATED_TORQUE = 0,
	EMI_MOTORTYPE = 1,
	EMI_INERTIA = 2,
	EMI_NUM,
};

enum EAlmWrnReadStatus {
	AWRD_FAIL = -1,
	AWRD_SUCCESS,
	AWRD_BUSY,
};

// param init status
enum EParamInitStatus {
	INIT_FAIL = 0,
	INIT_SUCCESS,
	INIT_PROCESSING,
};

struct TMOTORINFO
{
	DWORD nMask;
	LONG nType;
	double eInertia;
	double eRatedTorque;
};

struct TMotorInfoDef {
	TMOTORINFO tInfo;
	CHAR szName[ MAX_MOTOR_NAME_LEN ];
};

struct TMotorInfoTank {
	LONG nVendorID;
	LONG nCount;
	TMotorInfoDef tMotorInfo[ MAX_MOTOR_NUM ];
};

// data structure for fractional delay compensation
struct TFracDelayDef {
	DOUBLE CmdExeTiming;
	DOUBLE MonitorDataTiming;
	ESupportStatus nSupportStatus;
	LONG nReserved;
};

//////////////////////////////////
/////// Control Parameter ////////
/////////////////////////////////
#define CTRLPARAM_SEL_Active					( 0 )
#define CTRLPARAM_SEL_1st						( 1 )
#define CTRLPARAM_SEL_2nd						( 2 )

#define CTRLPARAM_BIT_NOT_DEFINE				( 0x0000 )
#define CTRLPARAM_BIT_SPEED_GAIN				( 0x0001 )
#define CTRLPARAM_BIT_SPEED_INT_TIMECONST		( 0x0002 )
#define CTRLPARAM_BIT_POS_GAIN					( 0x0004 )
#define CTRLPARAM_BIT_TRQ_FILTER_TIMECONST		( 0x0008 )
#define CTRLPARAM_BIT_MDL_CTRL_GAIN				( 0x0010 )
#define CTRLPARAM_BIT_MDL_CTRL_GAIN_COMP		( 0x0020 )
#define CTRLPARAM_BIT_FRICTION_COMP_GAIN		( 0x0040 )
#define CTRLPARAM_BIT_SPEED_FILTER_TIMECONST	( 0x0080 )
#define CTRLPARAM_BIT_MOMENT_INERTIA_RATIO		( 0x0100 )

// control parameter index
enum ECtrlParamIndex {
	ECPI_SpeedLoopGain = 0,
	ECPI_SpeedIntTimeConst = 1,
	ECPI_PosLoopGain = 2,
	ECPI_TrqFilterTimeConst = 3,
	ECPI_ModelControlGain = 4,
	ECPI_ModelControlGainComp = 5,
	ECPI_FrictionCompGain = 6,
	ECPI_SpeedFilterTimeConst = 7,
	ECPI_MomentInertiaRatio = 8,
	ECPI_Num,
};

// control parameter
struct TCtrlParam
{
	DWORD	nMask;					// bit 0~8 used to describe if the following control parameter enabled to read/write, max 32 parameters
	union {
		struct {
			LONG	nSpeedLoopGain;			// active speed loop gain, unit: 0.1Hz
			LONG	nSpeedIntTimeConst;		// active speed loop integral time constant, unit: 0.01ms
			LONG	nPosLoopGain;			// active position loop gain, unit: 1/s
			LONG	nTrqFilterTimeConst;	// active torque reference filter time constant, unit: 0.01ms
			LONG	nModelControlGain;		// active model following control gain, unit: 0.1/s
			LONG	nModelControlGainComp;	// active model following control gain compensation, unit: 0.1%
			LONG	nFrictionCompGain;		// active friction compensation gain, unit: 1%
			LONG	nSpeedFilterTimeConst;	// active speed reference filter time constant, unit: 0.01ms
			LONG	nMomentInertiaRatio;	// active moment of inertia ratio, unit: 1%
		};
		LONG	nParam[ ECPI_Num ];
	};
};

// get supported control parameter number
struct TSVOCHANNEL_GetCtrlParamNum
{
	LONG nNumber;			// out
};

// get control parameter mask
struct TSVOCHANNEL_GetCtrlParamMask
{
	LONG nSelect;			// in
	BOOL bSuccess;			// out
	DWORD nMask;			// out
};

// put control parameter from cnc
struct TSVOCHANNEL_PutCtrlParam
{
	LONG nSelect;			// in
	BOOL bSave;				// in
	TCtrlParam *pData;		// in
	BOOL bSuccess;			// out
};

// switch control parameter
struct TSVOCHANNEL_SwitchCtrlParam
{
	BOOL bSuccess;			// out
	LONG nSelect;			// in
	LONG nLastSelect;		// out
};

// Syntec function
#define ENABLE_BASE_UNIT_SETTING	( 0x00000001 )	// enable syntec base unit setting
#define ENABLE_POWEROFF_PULLUP		( 0x00000002 )	// enable syntec power off pull-up
#define ENABLE_ORIENTATION_SWITCH	( 0x00000004 )	// enable syntec orientation switch
#define ENABLE_WINDINGMODE_CHANGE	( 0x00000008 )	// enable syntec winding mode change

////////////////////////////////
////// Encoder Tuning /////////
///////////////////////////////
// encoder eccentric compensation mode
enum EEncCompSituation {
	EECS_NotSupport,
	EECS_1stCtrl_1stDetect,
	EECS_1stCtrl_2ndDetect,
	EECS_2ndCtrl_2ndDetect,
};

struct TEncInfo {
	BOOL bEccCompEnable;
	BOOL bEncPolarity;
	LONG nEncResolution;
	LONG nEncJogDirection;
};

#endif // !defined(_SVOUTILITYDEF_H_INCLUDED_)
