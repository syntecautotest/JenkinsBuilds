// OCMapFile.h: interface for the CMapFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OCMAPFILE_H__4C88620E_425C_4502_A4A3_27E311EA5562__INCLUDED_)
#define AFX_OCMAPFILE_H__4C88620E_425C_4502_A4A3_27E311EA5562__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMapFile  
{
public:
	CMapFile( LPCTSTR lpszName, DWORD dwSize, BOOL bInitZero, INT chInitValue )
	{
		// init data buffer pointer
		m_pDataBuffer = NULL;
		m_bFirst = FALSE;

		// Create a named file mapping object.
		m_hMapObj = CreateFileMapping(
								(HANDLE) 0xFFFFFFFF,	// Use paging file
								NULL,					// No security attributes
								PAGE_READWRITE,			// Read/Write access
								0,						// Mem Size: high 32 bits
								dwSize,					// Mem Size: low 32 bits
								lpszName);				// Name of map object

		if (NULL != m_hMapObj) {
			// Determine if this is the first create of the file mapping.
			m_bFirst = (ERROR_ALREADY_EXISTS != GetLastError());

			// Now get a pointer to the file-mapped shared memory.
			m_pDataBuffer = MapViewOfFile(
							m_hMapObj,				// File Map obj to view
							FILE_MAP_WRITE,			// Read/Write access
							0,						// high: map from beginning
							0,						// low:
							0);						// default: map entire file

			if (NULL != m_pDataBuffer) {
				if (m_bFirst && bInitZero) {
					// If this is the first attaching process, init the
					// shared memory.
					memset(m_pDataBuffer, chInitValue, dwSize);
				}
			}
		}
	}

	virtual ~CMapFile()
	{
		if( m_pDataBuffer ) {
			UnmapViewOfFile(m_pDataBuffer);
		}

		// Close the process's handle to the file-mapping object.
		if( m_hMapObj ) {
			CloseHandle(m_hMapObj);
		}
	}

	BOOL isFirst( void )
	{
		return m_bFirst;
	}

	void *m_pDataBuffer;

private:
	HANDLE m_hMapObj;
	BOOL m_bFirst;
};

#endif // !defined(AFX_OCMAPFILE_H__4C88620E_425C_4502_A4A3_27E311EA5562__INCLUDED_)
