#if !defined(_EVENTTRIGGERGP_INCLUDE_)
#define _EVENTTRIGGERGP_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEventTrigger;

class CEventTriggerGroup
{
public:
	CEventTriggerGroup( int nEvtID, int nStartID, int nEndID );
	// constructor

	~CEventTriggerGroup();

	void Trigger( TEvtInfo *pEvtArg, va_list var );
	// Trigger Event

	BOOL Register( int nEvtArg, int nStartArg, int nEndArg, IListener *pListener );
	// register listener for single-event

	BOOL Unregister( int nEvtArg, int nStartArg, int nEndArg, IListener *pListener );
	// unregister listener for single-event

private:
	CObList *m_pEvtList;
	// record all listener,  object is CListenerInfo

	INT m_nEvtID;
	INT m_nStartID;
	INT m_nEndID;
	// event ID

private:
	CEventTrigger *FindEvt( int nEvtArg, int nStartArg, int nEndArg );
	// find out the EventTrigger with the same argument
};
#endif // !defined(_EVENTTRIGGERGP_INCLUDE_)

