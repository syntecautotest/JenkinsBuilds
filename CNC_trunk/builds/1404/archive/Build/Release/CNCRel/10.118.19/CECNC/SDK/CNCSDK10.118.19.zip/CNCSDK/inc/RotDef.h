#if !defined(AFX_ROTDEF_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
#define AFX_ROTDEF_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define NUM_OF_Rot				( 3 )
#define FullCircleDeg			( 360000.0 )
#define HalfCircleDeg			( FullCircleDeg / 2 )
#define UNREACHABLE_Pos			( LONG_MAX / 2L )
#define DefaultAccRPM			( 1000L )
#define MinToolNumber			( -2 )
#define PositionNotAtAnyTool	( -1 )

#define BASE_ROT_HomeLatched( nAxID )					( 0 + nAxID )
#define BASE_ROT_Direction( nAxID )						( 3 + nAxID )
#define BASE_ROT_AbsOffset( nAxID )						( 50 + nAxID )
#define BASE_ROT_OverflowLapCounter( nAxID )			( 60 + nAxID )

#define ALMID_ROT_NoSettingHome							( 1 )
#define ALMID_ROT_ParamChangedMustReopenAndSetHome		( 2 )
#define ALMID_ROT_NotAbsEncoder							( 3 )
#define ALMID_ROT_TargetToolNumberErr					( 4 )
#define ALMID_ROT_PortNotExist							( 5 )
#define ALMID_ROT_ChannelSettingRepeated				( 6 )
#define ALMID_ROT_RRegSettingErr						( 7 )
#define ALMID_ROT_ToolPositionErr						( 8 )
#define ALMID_ROT_CommunicationAlarm					( 9 )
#define ALMID_ROT_PosingAccDecVelSettingErr				( 10 )
#define ALMID_ROT_SvoPowerStatusError					( 11 )
#define ALMID_ROT_ChannelNotSupport						( 12 )
#define ALMID_ROT_DoPosingOverflow						( 13 )
#define ALMID_ROT_EncUpdateFinished						( 14 )
#define ALMID_ROT_EncInfoReadTimeout					( 15 )

#endif // !defined(AFX_ROTDEF_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
