// MovingAverageFilter.h: interface for the CMovingAverageFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MOVINGAVERAGEFILTER_H__805AEEA8_12FC_4bc2_AF9E_B291392EFD18__INCLUDED_)
#define AFX_MOVINGAVERAGEFILTER_H__805AEEA8_12FC_4bc2_AF9E_B291392EFD18__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMovingAverageFilter : public CDelayFilter
{
public:

	CMovingAverageFilter( long nTimeBase, long nMaxTimeInterval );
	// constructor

	CMovingAverageFilter( int nCapacity );
	// constructor with parameter capacity

	virtual ~CMovingAverageFilter();
	// destructor

	void empty( void );
	// empty object

	void shiftCommand( double &command );
	// to shift new command

	void shiftCommand( double InCommand, double &OutCommand );
	// to shift new command

	DOUBLE getRampInputDelayTime( void );
	// get delay time when the input is a ramp signal (*HSHP-2505)
	// time unit: micro-second

private:

	double m_Accumulator;
	// moving average buffer data sum.
};

#endif // !defined(AFX_MOVINGAVERAGEFILTER_H__805AEEA8_12FC_4bc2_AF9E_B291392EFD18__INCLUDED_)
