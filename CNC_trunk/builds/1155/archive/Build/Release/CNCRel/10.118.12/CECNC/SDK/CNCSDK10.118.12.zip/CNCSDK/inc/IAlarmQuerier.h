// IAlarmQuerier.h: interface for the IAlarmQuerier class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IALARMQUERIER_H__INCLUDED_)
#define AFX_IALARMQUERIER_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IAlarmQuerier
{
public:
	virtual ~IAlarmQuerier( void ) {};
	// destructor

	virtual BOOL isInAlarm( void ) = 0;
	// query is in alarm

	virtual BOOL isInWarning( void ) = 0;
	// query is in warming
};

#endif // !defined(AFX_IALARMQUERIER_H__INCLUDED_)