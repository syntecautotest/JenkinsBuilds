#if !defined(_FEEDLIMIT_H____INCLUDED_)
#define _FEEDLIMIT_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CArcFeature;
class CFreeNodePool;
class CRTMutex;
class CLANodePool;

// to calculate middle among three elements
#define minAcceleration(a,b)		(((a) > 0.0 && (b) > 0.0 ) ? (min(a,b)) : (((a) > 0.0) ? (a) : (b)))

class CFeedLimit : public CLAFilter
{
public:
	CFeedLimit( CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	~CFeedLimit( void );
	// destructor

	void set_ChannelCount( const int nCount );
	// to set channel count

	virtual void putGeomAxis( const int XAxis, const int YAxis, const int ZAxis );
	// to put geometry axis index

	void putPathAxisSelection( const ULONG bPathAxisSelection );
	// to put path axis selection

	void putAxisRatioSquare( const double ratioSquare, const int channel );
	// put ratio square of virtual circle radius data

	void resetAxisRatioSquare( void );
	// reset ratio square of virtual circle radius

	void putMaxCompFeedrate( double Fmax );
	// to put maximum geometry-space-related compound feedrate, in IU / us.

	virtual void putMaxAxisFeedrate( const double AxFmax[] );
	// to put maximum axis-related feedrate, in IU / us., the array size should be NUMOF_AXIS.

	void putMaxCompCorFeedrate( const double feedrate );
	// to put corner feedrate at 120 degree. in IU / us

	void putMaxAxisCorFeedrate( const double AxDFmax[] );
	// to put maximum axis-related feedrate difference, in IU / us, the array size should be NUMOF_AXIS.

	virtual void putMaxCompAcceleration( const double Amax );
	// to put maximum geometry-space-related compound acceleration, in IU / us ^ 2.

	virtual void putMaxAxisAcceleration( const double AxAmax[] );
	// to put maximum axis-related acceleration, in IU / us, the array size should be NUMOF_AXIS.

	void putMaxCompJerk( const double Jmax );
	// the maximum jerk in IU / us ^ 3

	void putMaxAxisJerk( const double AxJmax[] );
	// the maximum axis jerk in IU / us ^ 3

	virtual void putArcCondition( const double radius, const double feedrate );
	// to put arc reference radius and reference feedrate, in IU, and IU / us

public:
	virtual void putLANode( TLANode *pNode, double eParam1 = 0 );
	// put look ahead node to feed limit module

	virtual void setExactStop( void );
	// set exact stop

	virtual void setEOBMark( const TPacketInfo &PacketInfo );
	// set EOB Mark

public:
	virtual BOOL IsEmpty( void ) = 0;
	// query whether the pipe is empty

	virtual void Abort( void );
	// abort

	virtual void Reset( void );
	// reset

	virtual void putLookAheadCondition( const double ChordErrorTol, const double CornerFeedrate, const double ArcRefRadius, const double ArcRefFeedrate ) {}
	// set maximum allowable feedrate for motion block movement
	// chord error tolerance, in IU
	// corner feedrate at 120 degree, in IU / us
	// arc reference radius and reference feedrate, in IU, and IU / us

	virtual int getCountOfCCQue( void ) { return 0; }
	// get count in C.C. Queue

	virtual void onRotAxisRadiusChanged( const double Radius, const int channel ) {}
	// on virtual circle radius for rotary axis changed

	virtual void putRotAxisRadius( const double Radius, const int channel ) {}
	// put virtual circle radius data

	virtual void resetVirtualCircle( void ) {}
	// reset virtual circle radius

public:
	virtual void PutLANodeToCurvPart( TLANode *pNode ) {}
	// put look ahead node to curvature part of feed limit module

	void PutLANodeToCornPart( TLANode *pNode );
	// put look ahead node to corner part of feed limit module

public:
	virtual void CalcBlockLength( TLANode *pNode, CArcFeature &af ) {}
	// calculate block length.

	virtual void GetLengthAccumulator( DOUBLE &lengthAccumulator ) {}
	// Get Length Accumulator

	virtual void FlushAllQueue( void ) = 0;
	// flush queued nodes of feed limit module

protected:
	virtual TLANode *ReversePeek( void ) = 0;
	// peek the last node in feed limit module

	BOOL ProcessZeroLengthBlock( TLANode *pNode );
	// Process zero-length block.

	void postReferenceFeedrate( TLANode *pNode );
	// post reference feedrate processing

	virtual void calcEnterLeaveVector( TLANode *pNode, CArcFeature &af );
	// calculate enter unit vector, leave unit vector

	virtual void CalcBlockMotionFeature( TLANode *pNode, CArcFeature &af ) {}
	// calculate block motion feature

	virtual void ClampBlockFeedrateByProgramFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum programming feedrate

	virtual void ClampBlockFeedrateByCompoundFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum compound feedrate

	virtual void ClampBlockFeedrateByAxisFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum axis cutting feedrate

	virtual void ClampBlockJerk( TLANode *pNode );
	// clamp block jerk by maximum jerk and maximum axis jerk

	void ProcessNonPathBlock( TLANode *pNode );
	// Process non-path axis movement block

	virtual void EstimateElapseTime( TLANode *pNode );
	// estimate elapse time of pNode

	virtual long EstimateElapseTime_V0Vc( TLANode *pNode );
	// estimate elapse time of pNode with acceleration

private:
	void CheckThreadFeedrateOverflow( TLANode *pNode, double eCandidate );
	// check threading feedrate overflow

protected:
	virtual void CalcCornerFeature( TLANode *pNode, double &eLastVc ) {}
	// to calculate inter-block feature

	virtual void ProcessMaxOverride( TLANode *pNode );
	// process maximum override

	void ProcessMaxOverride( TLANode *pNode, double Vref );
	// process maximum override

public:
	int m_XAxis;
	int m_YAxis;
	int m_ZAxis;
	// geometry axes index

protected:
	CRTMutex m_cs;
	// mutex for protected queue in feedlimit

	int m_nChannelCount;
	// number of axis

	ULONG m_bPathAxisSelection;
	// path axis selection

	double m_AxisUnitRatioSquare[NUMOF_AXIS];
	// = Radius * IU degree / 180 * PI

	double m_Fmax;
	// maximum compound feedrate, in IU / us

	double m_AxFmax[NUMOF_AXIS];
	// maximum axis feedrate, in IU / us

	double m_AxHalfDFmax[NUMOF_AXIS];
	// half of maximum axis feedrate, in IU / us

	double m_DFmax;
	// maximum corner feedrate, in IU / us

	double m_AxDFmax[NUMOF_AXIS];
	// maximum axis feedrate difference, in IU / us

	double m_Amax;
	// maximum acceleration in IU / us ^ 2

	double m_AxAmax[NUMOF_AXIS];
	// maximum axis acceleration, in IU / (us ^ 2)

	double m_GeomAxAmax[3];
	// maximum geometry axis acceleration, in IU / (us ^ 2)

	double m_Jmax;
	// maximum jerk in IU / us ^ 3

	double m_AxJmax[NUMOF_AXIS];
	// maximum axis jerk in IU / us ^ 3

	double m_ArcRadiusRef;
	// arc radius reference, in IU

	double m_ArcFeedrateRef;
	// arc feedrate reference, in IU / us

	double m_MaxCentripetalForce;
	// maximum centripetal force

	double m_WPFmax;
	// maximum feedrate projection on working plane 

	double m_ZFmax;
	// maximum feedrate projection on virtual Z axis of geometry space

	double m_WPAmax;
	// maximum acceleration projection on working plane

	double m_ZAmax;
	// maximum acceleration projection on virtual Z axis of geometry space

	TLANode m_LNode;
	// last cutting node

	BOOL m_bExistLNode;
	// last cutting node exists

	double m_MaxOverride;
	// max override

};
#endif // !defined(_FEEDLIMIT_H____INCLUDED_)
