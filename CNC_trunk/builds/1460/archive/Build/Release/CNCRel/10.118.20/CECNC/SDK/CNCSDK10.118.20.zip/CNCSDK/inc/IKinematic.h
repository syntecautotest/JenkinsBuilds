// IKinematic.h: interface for the IKinematic class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IKINEMATIC_H__E8901742_6F8A_4AC1_932F_8F07C1267D35__INCLUDED_)
#define AFX_IKINEMATIC_H__E8901742_6F8A_4AC1_932F_8F07C1267D35__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IKinematic
{

#define MAX_NUM_KINEMATICS_MOTOR	( 6 )					// the maximum number of motors for KinematicTx
#define MIN_EPSILON_THRESHOLD		( DBL_EPSILON * 1.0e6 )	// threshold for calculate in double type

public:
	// forward kinematics type , cache: get buffer, Normal: do F.K.
	enum EFKType {
		CACHE = 0,
		NORMAL,
	};

public:
	virtual ~IKinematic( void ) {}
	// destructor

	virtual int MCStoBCS( double InMCS[], double OutBCS[], int nType = CACHE ) = 0;
	// machine coordinate system to basic coordinate system

	virtual int BCStoMCS( double InBCS[], double InMCS[], double OutMCS[] ) = 0;
	// basic coordinate system to machine coordinate system with last machine coordinate system position
};

#endif // !defined(AFX_KINEMATIC_H__E8901742_6F8A_4AC1_932F_8F07C1267D35__INCLUDED_)
