#if !defined(_FILEDIRINFO_INCLUDED_)
#define _FILEDIRINFO_INCLUDED_

#include "CommonStruct.h"

#ifdef __cplusplus
extern "C" {
#endif

HRESULT NcGetOSInfo( /*out*/ DWORD *lpdwMajorVersion, /*out*/ DWORD *lpdwMinorVersion, /*out*/ TCHAR *lpName, /*in,out*/ LONG nNameLength );

HRESULT NcGetDirs( LPCTSTR lpszName, TCHAR *lpBuffer, LONG nLength, char KeyName[] );

HRESULT NcGetDirFiles( LPCTSTR lpDir, TCHAR *lpBuffer, LONG nLength );

HRESULT NcGetDirFilesInfo( /*in*/ LPCTSTR lpDir, /*in*/ LONG nLengthToRead, /*out*/ TOcMyFileInfo *lpBuffer, /*out*/ LONG *lpnLengthRead );

#ifdef __cplusplus
}
#endif 

#endif //_FILEDIRINFO_INCLUDED_

