// Variant.h: interface for the COcVariant class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VARIANT_H__756A5B6A_BF2A_4892_ADE4_B91430B68593__INCLUDED_)
#define AFX_VARIANT_H__756A5B6A_BF2A_4892_ADE4_B91430B68593__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

extern "C" {
#ifndef EOCVARIANTTYPE_ENUM_
#define EOCVARIANTTYPE_ENUM_

enum EOcVariantType {
	OCVT_VACANT,
	OCVT_LONG,
	OCVT_DOUBLE,
	OCVT_STRING
};

#endif // EOCVARIANTTYPE_ENUM_

#ifndef TOCVARIANT_STRUCT_
#define TOCVARIANT_STRUCT_

typedef struct tagTOcVariant {
	short		m_type;
	union {
		long	m_long;
		double	m_double;
	};
} TOcVariant;

#endif // TOCVARIANT_STRUCT_
};

class COcVariant
{
public:
	static const double EPSILON_ZeroBand;
	// zero band eplison for variant logic operation

public:

	COcVariant( void );
	COcVariant( long value );
	COcVariant( double value );
	COcVariant( TOcVariant *pVal );
	COcVariant( TOcVariant &Val );
	virtual ~COcVariant();
	operator TOcVariant();
	COcVariant &operator+=( COcVariant &operand );
	COcVariant &operator-=( COcVariant &operand );
	COcVariant &operator*=( COcVariant &operand );
	COcVariant &operator/=( COcVariant &operand );
	COcVariant &operator|=( COcVariant &operand );
	COcVariant &operator|=( LONG nValue );
	COcVariant &operator^=( COcVariant &operand );
	COcVariant &operator&=( COcVariant &operand );
	COcVariant &operator&=( LONG nValue );
	COcVariant &operator%=( COcVariant &operand );
	COcVariant &operator>( COcVariant &operand );
	COcVariant &operator<( COcVariant &operand );
	COcVariant &operator>=( COcVariant &operand );
	COcVariant &operator<=( COcVariant &operand );
	COcVariant &operator==( COcVariant &operand );
	COcVariant &operator!=( COcVariant &operand );
	COcVariant &operator=( COcVariant &operand );
	COcVariant &operator=( LONG value );
	COcVariant &operator=( DOUBLE value );
	COcVariant &operator=( TOcVariant &var );
	COcVariant &operator!( void );
	COcVariant &operator-( void );
	COcVariant &OpSin( void );
	COcVariant &OpCos( void );
	COcVariant &OpTan( void );
	COcVariant &OpAsin( void );
	COcVariant &OpAcos( void );
	COcVariant &OpAtan( void );
	COcVariant &OpSqrt( void );
	COcVariant &OpExp( void );
	COcVariant &OpLog( void );
	COcVariant &OpAbs( void );
	COcVariant &OpSign( void );
	COcVariant &OpFloor( void );
	COcVariant &OpCeil( void );
	COcVariant &OpRound( void );
	COcVariant &OpRadToDeg( void );
	COcVariant &OpDegToRad( void );
	COcVariant &OpStandard( COcVariant &operand );
	COcVariant &OpMax( COcVariant &operand );
	COcVariant &OpMin( COcVariant &operand );
	COcVariant &OpPow( COcVariant &operand );
	int IsNull(void);
	int IsExist(void);
	int IsTrue(void);
	int IsLong( void );
	int IsDouble( void );
	BOOL IsEqual(  COcVariant &operand );
	long getLong( void );
	double getDouble( void );
	BOOL IsValidDivider( void );
	int IsValidLogicOperand( void );
	void PutNull( void );
	void PutString( long nSymbolID );
	void PutLong( long nValue );
	long GetString( void );
	BOOL IsString( void );
	int type( void ) { return m_type; }

	static void setPocketDecimalPoint( BOOL bPocket );
	// set decimal point type

private:
	void PutBoolean( int BoolValue );

	static BOOL m_bPocketDecimalPoint;
	// use pocket decimal point type

private:

	int m_type;
	// data type

	union {
		long	m_long;
		double	m_double;
	};
	// storage for store data value
};

#endif // !defined(AFX_VARIANT_H__756A5B6A_BF2A_4892_ADE4_B91430B68593__INCLUDED_)
