// ParamStore.h: interface for the CParamStore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PARAMSTORE_H__17F46A24_37B8_4118_AD39_B401225B27C8__INCLUDED_)
#define AFX_PARAMSTORE_H__17F46A24_37B8_4118_AD39_B401225B27C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "IParamListener.h"

class CArchiveManager;
class CLineMap;
class CGuardRegistry;

class CParamStore
{
public:
	CParamStore();
	virtual ~CParamStore();

public:

	enum EMaxBounds {
		SIZEOF_DBParameter = 10240,
		MAX_TITLELEN = 256,
		SIZE_ListenerTable = 50,		// Required: API*1 + Op*1 + Sys*1 + Axis*16 + Coord*4 + Spd*6 + ...
	};

	struct TParamSchema {
		long			Min;
		long			Max;
		long			Default;
		char			Title[ MAX_TITLELEN ];
	};

	BOOL putSchema( long no, TParamSchema *pSchema, int size );
	// put parameter schema
	// return TRUE when success, otherwise return FALSE

public:
	BOOL AssociatePersistent( CHAR *root, CHAR *path, CHAR *function, CHAR *name, INT size = SIZEOF_DBParameter );
	// associate persistent storage

	void setListener( IParamListener *pListener );
	// set event handler

	void removeListener( IParamListener *pListener );
	// remove event handler

	void EndOfDefinition( void );
	// end of load definition

	int IsExist( long no );
	// query whether there is the paramter no ?
	// return	TRUE		when the parameter exist
	//			FALSE		when the parameter not exist

	int NumOfParameter( void );
	// get the number of parameter

	long GetNo( int index );
	// get parameter no from sorted index

	char *LookupTitle( long no, char *buffer, int count );
	// get parameter title

	long LookupMax( long no );
	// lookup maximum value

	long LookupMin( long no );
	// lookup minimum value

	long GetValue( long no );
	// get parameter value

	void PutValue( long no, long value );
	// put parameter value

	int GetVersion(void);
	// get registry format version

	void GetModifiedTime( SYSTEMTIME *t );
	// get modification time

	int ImportFrom( char *lpLocation );
	// import data into registry from specified location
	// return TRUE when successful, return FALSE when failure.

	int ExportTo( char *lpLocation );
	// export data from registry to specified location
	// return TRUE when successful, return FALSE when failure.

private:

	static int __cdecl compare_IndexToNo( const void *arg1, const void *arg2 );
	// compare function for index-to-no Table sorting and searching

	CLineMap *m_pParamSpec;
	// parameter specification data base

	int m_NumOfParameter;
	// the number of parameter been defined

	int m_NumOfDBParameter;
	// the number of data base parameter been defined

	long *m_IndexToNoTable;
	// the table of index-to-no mapping

	IParamListener *m_pListenerTable[SIZE_ListenerTable];
	// associated event handler

	int m_ListenerTableCount;
	// the number of data in event listener table

	CGuardRegistry *m_pRegistry;
	// value storage
};

#endif // !defined(AFX_PARAMSTORE_H__17F46A24_37B8_4118_AD39_B401225B27C8__INCLUDED_)
