#if !defined(_ROBOTDYNAMICSDEF_H____INCLUDED_)
#define _ROBOTDYNAMICSDEF_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// 0:direct teaching function has not yet ready for the user
#define DIRECT_TEACHING_TEST_MODE	( 0 )

// common definition
#define MAX_AXIS_OUTPUT_TORQUE		( 10000 ) // unit: 0.01%

// for robot learning
#define NUMOF_RECORD_DATA			( 23 ) // depends on the phase number

// for robot dynamics
#define NUMOF_DYNAMIC_MODEL_TYPE	( 2 ) // dynamic model types

// refer to Pr4551
enum ERobotDirectTeachingControlType {
	CtrlType_Close = 0,
	CtrlType_Torque = 1,
	CtrlType_Position = 2,
};

enum ERobotAxisDoFType {
	DoF_Rotary = 0,
	DoF_Linear = 1,
};

enum ERobotAxisServoType {
	NotDefineServo = 0,
	RotaryServo = 1,
	RotaryServoWithScrew = 2, // axis with linear motion
	LinearServo = 3,
};

enum ERobotAxisGeometricType {
	SingleLink = 0,
	TwoLinks1st = 1,
	TwoLinks2nd = 2, // second link must be first link + 1
};

enum ERobotAxisGravityType {
	GravityNone = 0,
	GravityConstant = 1,
	GravitySinusoidal = 2,
};

enum ERobotTeachDynamicModelType {
	Axis_Independent = 0,
	Axis_DynamicDetail = 1,
};

struct TDynamicVariables {

	double StatFricMax[ NUMOF_ROBOT_AXIS ];
	// max static friction (fs,max)

	double SlidFric[ NUMOF_ROBOT_AXIS ];
	// sliding friction (fk)

	double ViscCoef[ NUMOF_ROBOT_AXIS ];
	// viscous coefficient (c)

	double GravityData[ NUMOF_ROBOT_AXIS ];
	// gravity term where the definition depends on the type of the robot

	double CoriolisData[ NUMOF_ROBOT_AXIS ];
	// Coriolis and centrifugal terms where the definition depends on the type of the robot

	double MassData1[ NUMOF_ROBOT_AXIS ];
	double MassData2[ NUMOF_ROBOT_AXIS ];
	// mass matrix related data where the definition depends on the type of the robot
};

struct TRobotAxisInfo {
	CManualAxis *pAxis;			// axis pointer
	int			nPolarity;		// axis polarity
	int			nAxisID;		// mapping robot axis ( i.e., C1 C2 C3...) to axis ID ( 1st axis 2nd axis 3rd axis...)
};

#endif // !defined(_ROBOTDYNAMICSDEF_H____INCLUDED_)
