// XMLDBCycle.h: interface for the CJCycleSchema class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CYCLESCHEMA_H__F79CF3D4_720F_4394_BF0C_5A0734CE98CF__INCLUDED_)
#define AFX_CYCLESCHEMA_H__F79CF3D4_720F_4394_BF0C_5A0734CE98CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CJXmlTextReader;

#if !defined(UNDER_CE)
class CMapStringToPtr;
#endif

class CJCycleSchema  
{
public:
	CJCycleSchema();
	virtual ~CJCycleSchema();

	enum EInputFormat {
		TYPE_LONG,
		TYPE_DOUBLE,
		TYPE_VARIANT,
		TYPE_STRING,
		TYPE_XML
	};
	// input format constant

	enum EDeviceType {
		DEVTYPE_NULL,
		DEVTYPE_PLC_R_REGISTER,
		DEVTYPE_GLOBALVARIABLE,
		DEVTYPE_PERSISTREGISTRY,
		DEVTYPE_XMLVARIABLE
	};

	struct TFieldSchema {
		TCHAR	Name[50];
		long	DeviceType;
		long	DeviceNo;
		long	InputFormat;
		TCHAR	InputFormatText[10];
		TCHAR	*lpszDefault;
		long	Length;
		long	StorageStep;
		long	RepeatCount;
		TCHAR	szDefaultValueBuf[16];
		BOOL	bUseExtendDefaultBuffer;

		void init( long RepeatCount, long StorageStep );
		void cleanup( void );
		void syncstate( void );
		void standardize( LPTSTR lpszValue );

		HRESULT deserialize( CJXmlTextReader *lpReader );
	};
	// field schema structure

	enum EMaxBound {
		MAX_FieldCount = 8192
	};

	HRESULT deserialize( CJXmlTextReader *lpReader );
	// init object by specified cycle node

	long get_Length( void );
	// to get the number of field in this field

	TFieldSchema *getItem( long index );
	// get specified field

	long getIndexFromName( TCHAR *FieldName );
	// to get the index of specified named field

	TCHAR m_szCycleName[128];
	// my cycle name
private:

	long m_nFieldCount;
	// number of field count

	long m_nDefaultStorageStep;
	// the default storage step interval

	long m_nDefaultRepeatCount;
	// the default repeat count of data

	long m_pFieldBufferSize;

	TFieldSchema *m_pFieldBuffer;
	// field schema data

	CMapStringToPtr *m_pMap;
};

#endif // !defined(AFX_CYCLESCHEMA_H__F79CF3D4_720F_4394_BF0C_5A0734CE98CF__INCLUDED_)
