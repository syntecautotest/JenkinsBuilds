#if !defined(_IROBOTMOTIONHANDLER_H____INCLUDED_)
#define _IROBOTMOTIONHANDLER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IRobotMotionHandler
{
public:
	virtual ~IRobotMotionHandler( void ) {};
	// destructor

public:
	virtual void Reset( void ) = 0;
	// reset

	virtual void packMicroCodeInfo( TRobotMRP *pRobotMRP, TRobotMicroCode *pCode ) = 0;
	// pack micro code information
	// Use threads: trajectory plan

	virtual BOOL getSegment( TRobotMicroCode *pCode, DOUBLE elapse, TMotionDisp &Segment ) = 0;
	// get displacement per interpolation tick.
	// unit:IU
	// Use threads: interpolation

	virtual void writeOverlapStartTime( TRobotMRP *pCurRobotMRP, TRobotMRP *pNextRobotMRP ) = 0;
	// write overlap start time
	// Use threads: trajectory plan

	virtual void updateRemainDisp( TRobotMicroCode *pCode, DOUBLE IntDisp[], DOUBLE ExtDisp[], BOOL bPlus ) = 0;
	// update remain displacement

	virtual INT getTrajSpace( void ) = 0;
	// get trajectory space
};
#endif // !defined(_IROBOTMOTIONHANDLER_H____INCLUDED_)
