// CByteOrder Declaration
#pragma once


class CByteOrder
{
public:
	enum EOrder {
		EO_LittleEnd, // Little Endian byte order
		EO_BigEnd, // Big Endian byte order
	};

	// The system byte order
	static const EOrder m_SysOrder;

	// Reverse the byte order from SrcMem to DstMem (Big Endian <--> Little Endian)
	static void Reverse( void *pDstMem, const void *pSrcMem, size_t nMemSize );

	// Transform SrcMem (any byte order) to DstMem (system byte order)
	static void ToSysOrder( void *pDstMem, EOrder eSrcOrder, const void *pSrcMem, size_t nMemSize );

	// Transform SrcMem (system byte order) to DstMem (any byte order)
	static void ToDstOrder( EOrder eDstOrder, void *pDstMem, const void *pSrcMem, size_t nMemSize );

private:
	// Check system byte order
	static EOrder CheckSystemByteOrder( void );

	// Transform SrcMem (any byte order) to DstMem (any byte order)
	static void ByteOrderTransform( EOrder eDstOrder, void *pDstMem, EOrder eSrcOrder, const void *pSrcMem, size_t nMemSize );
};
