// ZRtl.h: interface for the CZRtl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZRTL_H__1EB31A43_2851_11D3_8436_0000E86B4150__INCLUDED_)
#define AFX_ZRTL_H__1EB31A43_2851_11D3_8436_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class CZRtl
{
public:
	enum ESignalState {
		_BitHigh_ = 0xFF,
		_BitLow_  = 0
	};
	// constants for byte signal

	static const unsigned char HexToCharTable[16];
	// hex to character map table

	static const char InvalidCharDecTable[41];
	// invalid filename character in decimal map table
	// 1-30 : ASCII control code chart
	// 34  42  47  58  60  62  63  92  124 mapping to :
	// "   *   /   :   <   >   ?   \   |

	static void ChangeFileExt( char *dest, char *src, char *ext );
	// change file extension

	static void tChangeFileExt( TCHAR *dest, TCHAR *src, TCHAR *ext );
	// change file extension

	static BOOL checkFileExtType( char *pathname, char *ext );
	// check if specified file has specified file extension
	// return TRUE when answer is yes, return FALSE when answer is no.

	static int ParseArguments( char *szSrc, char *arg[], int count, char *seps );
	// parse arguments

	static int ParseArgumentsT( TCHAR *szSrc, TCHAR *arg[], int count, TCHAR *seps );
	// parse arguments

	static char *MkEnvFile( char *root, char *path, char *filename, char *buffer, int count );
	// search a filename from environment path reltive root directory
	// return NULL to indicate file not found

	static char *MkEnvFileExt( char *root, char *path, char *filename, char *buffer, int count );
	// search a filename from environment path reltive root directory (also search ".mas" file)
	// return NULL to indicate file not found

	static void GetRelativeFilename( LPCTSTR lpszBaseFilename, LPCTSTR lpszFilename, TCHAR *lpBuffer, DWORD count );
	// to get a relative filename, which relative to specified reference filename

	static long GetFileSize(char *filename);
	// get file size
	// if failure return -1

	static long tGetFileSize( TCHAR *filename);
	// get file size
	// if failure return -1

	static BOOL isDirectoryExist( char *pathname );
	// check whether specified directory is exist ?

	static BOOL makeDirectory( char *pathname );
	// make specified directory, return TRUE when successful, else return FALSE

	static void expandBitToByte( ULONG BitData, unsigned char *ByteData, int BitCount );
	// expand bit representation into byte representation

	static ULONG mergeByteToBit( unsigned char *ByteData, int BitCount );
	// merge byte represenation into bit representation

	static void expandWordToShort( WORD *pWordData, SHORT *pShortData, INT nLength );
	// expand word representation into short representation

	static void expandShortToLong( SHORT *pShortData, LONG *pLongData, INT nLength );
	// expand short representation into long representation

	static void mergeLongToWord( LONG *pLongData, WORD *pWordData, INT nLength );
	// merge long represenation into word representation

	static void HexToStr( unsigned char data[], unsigned char buf[], int len );
	// convert data in hex value into string
	// data		hex value data
	// buf		buffer to store character string
	// len		hex data length

	static void StrToHex( unsigned char data[], unsigned char buf[], int len );
	// convert data in string into hex value
	// data		character string data
	// buf		buffer to store hex value
	// len		hex data length

	static int StrToHex( unsigned char data[] );
	// convert 2 byte data in string into hex value, teen return
	// data		character string data, 2-element array
	// return	the 2-element cooresponding hex value

	static long Bytes2Long( const BYTE* bytes, int size = 4 );

	static void Long2Bytes( long value, BYTE* bytes, int size = 4 );

	static void Str2Long( const char* data, long& value );

	static char * Int2Str( int value, char* buf );

	static char * Long2Str( long value, char* buf );

	static char * Double2Str( double value, char* buf, int precision = 6 );

	static char * GetFileNameWithoutExtenstion( const char* file_name, char* buf );

	static int _tcsFind( LPCTSTR lpszString, TCHAR ch );
	// to find specified character, in string
	// return index of that character, return -1 when specified character not found

	static TCHAR *_tcsLeft( LPCTSTR lpszString, TCHAR *lpBuffer, int nCount );
	// Extracts the first (that is, leftmost) nCount characters from lpszString and
	// returns a copy of the extracted substring

	static TCHAR *_tcsRight( LPCTSTR lpszString, TCHAR *lpBuffer, int nCount );
	// Extracts the last (that is, rightmost) nCount characters from lpszString and
	// returns a copy of the extracted substring.

	static void trim( LPCTSTR lpszString, TCHAR *lpBuffer, UINT count );
	// trim leading and tailing white space.

	static BOOL isNumberString( LPCTSTR lpszString );
	// whether specified string is a number

	static void SpiltPath( LPCTSTR lpszPathName, TCHAR *lpszFolder, TCHAR *lpszFilename );
	// to split pathname into folder name and filename.

	static void MergePath( TCHAR *lpszPathName, LPCTSTR lpszFolder, LPCTSTR lpszFilename );
	// to merge folder name and filename into pathname

	static void ChangeFileExtEx( TCHAR *lpszDest, LPCTSTR lpszSrc, LPCTSTR lpszExt );
	// to change filename extension

	static BOOL IsMacroHeader( char *lpBuffer, int nCount );
	// recognize macro program header

	static BOOL IsMultiNcProgHead( char *lpBuffer, int nCount );
	// recognize multi nc program header

	static FILE *OpenFile( char *filename, char *mode);
	// open file function, to process fopen (Dos) and _tfopen (32/CE)

	static FILE *tOpenFile( TCHAR *filename, TCHAR *mode);
	// open file function, to process fopen (Dos) and _tfopen (32/CE)

	static BOOL CheckFileNameChars( char *filename );
	// check whether file name is valid.

	static BOOL isFileExists( const wchar_t *filename );
	// check file existance

	static void RemoveDirectory( const wchar_t *path );
	// remove directory recursively

	static void CopyDirectory( wchar_t *src, wchar_t *dest );
	// copy directory recursively

	static __int64 GetDirectorySize( LPCTSTR lpDir );
	// get directory size
};

#endif // !defined(AFX_ZRTL_H__1EB31A43_2851_11D3_8436_0000E86B4150__INCLUDED_)
