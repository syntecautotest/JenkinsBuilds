// VelAccMeter.h: interface for the CVelAccMeter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VELACCMETER_H__B646AD87_C4D4_457B_97A7_A8A603541DA8__INCLUDED_)
#define AFX_VELACCMETER_H__B646AD87_C4D4_457B_97A7_A8A603541DA8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IFeedbackPosition;
class CMovingAverageFilter;

#define TIME_VelAccMeterPeekInterval		100000

class CVelAccMeter
{
public:
	CVelAccMeter( long PeekInterval = TIME_VelAccMeterPeekInterval );
	virtual ~CVelAccMeter();

	void setFbkPosInterface( IFeedbackPosition *pFbkPos );
	// set associated feedback position object

	double GetSpeed( void );
	// get real speed

	double GetSmoothedSpeed( void );
	// get speed which is smoothed by a 100ms moving average filter

	double GetAcc( void );
	// get real acceleration

	double GetSmoothedAcc( void );
	// get acceleration which is smoothed by a 100ms moving average filter

	void SyncFbkAbsoultePos( void );
	// sync feedback absoulte position

	void InterpolationTick( void );
	// Use threads: interpolation

private:
	IFeedbackPosition *m_pFbkPos;
	// associated feedback position object

	CMovingAverageFilter *m_pSpeedSmoother;
	// the speed smoother

	CMovingAverageFilter *m_pAccSmoother;
	// the acceleration smoother

	double m_Speed;
	// speed in BLU

	double m_SmoothedSpeed;
	// smoothed speed in BLU

	double m_Acc;
	// acceleration in BLU/us^2

	double m_SmoothedAcc;
	// smoothed acceleration in BLU/us^2

	long m_nLastAbsolutePosition;
	// last absolute position in BLU

	double m_LastSpeed;
	// last speed in BLU/us

	long m_nTimeBase;
	// speed timebase in micro-second

	double m_InvTimeBase;
	// reciprocal of timebase in micro-second
};

#endif // !defined(AFX_VELACCMETER_H__B646AD87_C4D4_457B_97A7_A8A603541DA8__INCLUDED_)
