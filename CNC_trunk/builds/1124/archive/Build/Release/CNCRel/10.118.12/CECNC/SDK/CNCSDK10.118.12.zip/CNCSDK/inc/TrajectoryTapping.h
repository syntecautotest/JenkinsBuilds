// TrajectoryTapping.h: interface for the CTrajectoryTapping class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_TRAJECTORYTAPPING_H____INCLUDED_)
#define _TRAJECTORYTAPPING_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTrajectoryTapping : public CTrajectory
{
public:
	CTrajectoryTapping( void );
	~CTrajectoryTapping( void );

	BOOL planBlock_tapping( DOUBLE V0, DOUBLE A0, DOUBLE *Ac, DOUBLE P, DOUBLE Vmax, DOUBLE Amax, DOUBLE Jmax, TPVTSheet *pPVT );
	// to plan block trajectory
	// type B:
	//			V0 = Vc, Vmax
	//			A0, Amax, Jmax, P
	// Note: Ac will be calculated from this planning
	//       V0 is zero in tapping application, because Vc is zero.
	//
	// Acceleration profile                Velocity profile
	//      |  ---              |		     |
	//      | /   \             |            |    
	//   A0 |/     \            |            |    .------.    
	//      |       \           |            |   /        \
	//    --+-------------------+---> t      |  /          \
	//      |             \     |		  V0 |-'            \
	//      |              \    |			 |               
	//      |               \___|            +------------------> t
	//      |                   |			 |
	// the algorithm is refered to "Smooth 3"-"Situation A"

private:
	BOOL planBlock_tapping_MaxA0( DOUBLE V0, DOUBLE *Ac, DOUBLE P, DOUBLE Vmax, DOUBLE Amax, DOUBLE Jmax, TPVTSheet *pPVT );
	BOOL planBlock_tapping_NullA0( DOUBLE V0, DOUBLE *Ac, DOUBLE P, DOUBLE Vmax, DOUBLE Amax, DOUBLE Jmax, TPVTSheet *pPVT );
	BOOL planBlock_tapping_MidA0( DOUBLE V0, DOUBLE A0, DOUBLE *Ac, DOUBLE P, DOUBLE Vmax, DOUBLE Amax, DOUBLE Jmax, TPVTSheet *pPVT );
};

#endif // !defined(_TRAJECTORYTAPPING_H____INCLUDED_)
