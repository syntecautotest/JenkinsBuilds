#if !defined(_FILEWRITER_INCLUDE_)
#define _FILEWRITER_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFileWriter
{
public:

	CFileWriter( LPCTSTR lpszFilename, DWORD nBufferSize )
	{
		m_hFile = INVALID_HANDLE_VALUE;
		m_lpFileBuffer = NULL;
		m_nFileBufferIndex = 0;
		m_nFileBufferSize = nBufferSize;

		// open specified file
		m_hFile = CreateFile( lpszFilename, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
		if( m_hFile == INVALID_HANDLE_VALUE ) {
			return;
		}

		m_lpFileBuffer = (CHAR *)::LocalAlloc(LMEM_FIXED,nBufferSize);
		ASSERT( m_lpFileBuffer != NULL );
		if( m_lpFileBuffer == NULL ) {
			CloseHandle( m_hFile );
			m_hFile = INVALID_HANDLE_VALUE;
		}
	}

	virtual ~CFileWriter(void)
	{
		if( m_hFile != INVALID_HANDLE_VALUE ) {
			if( m_nFileBufferIndex ) {
				DWORD nMumberOfBytesWritten;
				WriteFile( m_hFile, m_lpFileBuffer, m_nFileBufferIndex, &nMumberOfBytesWritten, NULL );
			}

			CloseHandle( m_hFile );
		}
		if( m_lpFileBuffer ) {
			::LocalFree( (HLOCAL)m_lpFileBuffer );
		}
	}

	BOOL WriteBinaryData( LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite, LPDWORD lpnNumberOfBytesWritten )
	{
		if( m_hFile == INVALID_HANDLE_VALUE ) {
			return FALSE;
		}

		DWORD nWrittenIndex = 0;
		while( nWrittenIndex < nNumberOfBytesToWrite ) {

			DWORD nFileBufferRemainBytes = m_nFileBufferSize - m_nFileBufferIndex;
			DWORD nCopyBytes = nNumberOfBytesToWrite - nWrittenIndex;
			if( nCopyBytes > nFileBufferRemainBytes ) {
				nCopyBytes = nFileBufferRemainBytes;
			}

			// copy data into file buffer
			MoveMemory( &m_lpFileBuffer[m_nFileBufferIndex], &((CHAR *)lpBuffer)[nWrittenIndex], nCopyBytes );

			// flush file buffer
			if( (m_nFileBufferIndex + nCopyBytes) == m_nFileBufferSize ) {
				DWORD nMumberOfBytesWritten;
				BOOL bSuccess = WriteFile( m_hFile, m_lpFileBuffer, m_nFileBufferSize, &nMumberOfBytesWritten, NULL );
				if( !bSuccess ) {
					m_nFileBufferIndex += nMumberOfBytesWritten;
					nWrittenIndex += nMumberOfBytesWritten;
					*lpnNumberOfBytesWritten = nWrittenIndex;
					return FALSE;
				}
				m_nFileBufferIndex = 0;
				nWrittenIndex += nCopyBytes;

			// file buffer is not full
			} else {
				m_nFileBufferIndex += nCopyBytes;
				nWrittenIndex += nCopyBytes;
			}
		}

		// successful
		ASSERT( nWrittenIndex == nNumberOfBytesToWrite );
		*lpnNumberOfBytesWritten = nWrittenIndex;
		return TRUE;
	}

private:
	CHAR *m_lpFileBuffer;
	DWORD m_nFileBufferSize;
	DWORD m_nFileBufferIndex;
	HANDLE m_hFile;
};


#endif // !defined(_FILEWRITER_INCLUDE_)
