// LineMap.h: interface for the CLineMap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINEMAP_H__51794BEF_CA13_4FBC_9F60_13E1C41070DB__INCLUDED_)
#define AFX_LINEMAP_H__51794BEF_CA13_4FBC_9F60_13E1C41070DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ILineStore.h"

class CLinePage;

class CLineMap : public ILineStore
{
public:
	CLineMap();
	virtual ~CLineMap();

private:
	enum EPageTable {
		SIZE_PageTable			= 8192,		// size of page table
		SHIFT_PageTablePage		= 13,		// bit shift for page caculation
		MASK_PageTableIndex		= 0x1FFF	// mask for page index caculation
	};
	// maximum bound constants

public:		// public function
	long getDataCount( void );
	// get number of line, which has data inside.

// implement ILineStore interface
	int CNCAPI readLine( long lineno, void *buffer, int count );
	// return the character counts in specified line

	long CNCAPI getLineCount( void );
	// return the total line count

	void CNCAPI clearAll(void);
	// clear all content

	BOOL CNCAPI insert( long lineno, void *data, int size );
	// insert data before specified line number.
	// return TRUE, when successful, others, return FALSE.
	// this function will not support in current release

	BOOL CNCAPI append( void *data, int size );
	// append specified data at the tail of whole data.
	// this function will not support in current release

	BOOL CNCAPI deleteLine( long lineno );
	// delete specified line
	// this function will not support in current release

	BOOL CNCAPI put( long lineno, void *data, int size );
	// put specified data into specified line

	BOOL CNCAPI erase( long lineno );
	// erase specified line data, this function just rease specified
	// line data, and no move behind line forward.

private:	// private helper function

	void expandDirTable( long pageno );
	// expand directory table to have capacity to store specified line

private:	// private implement function

	enum EMaxBounds {
		MAX_DirTableSize		= 8192,
		SIZE_InitDirTable		= 32,
		MIN_DirTableInc			= 128,
		SIZE_FreePagePool		= 8
	};
	// maximum bound constants

	struct TNode {
		CLinePage *PageTable;		// pointer to page table
	};

	TNode *m_DirTable;
	// directory table

	long m_TableSize;
	// directory table size

	long m_pagecount;
	// current page count in this directory

	CLinePage *m_pFreePagePool[SIZE_FreePagePool];
	// free line page pool

	int m_FreePageCount;
	// free page count
};

#endif // !defined(AFX_LINEMAP_H__51794BEF_CA13_4FBC_9F60_13E1C41070DB__INCLUDED_)
