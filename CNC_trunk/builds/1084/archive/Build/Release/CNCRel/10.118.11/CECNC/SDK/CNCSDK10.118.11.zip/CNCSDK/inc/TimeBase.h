// TimeBase.h: interface for the CTimeBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMEBASE_H__3CAB5701_8E9B_423D_B9A8_3BDB4CDF4069__INCLUDED_)
#define AFX_TIMEBASE_H__3CAB5701_8E9B_423D_B9A8_3BDB4CDF4069__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define Analysis_SpdPos_In_Thread_Debug_Mode	0
#define START_DUMP_RVALUE_IN_THREAD				8300

class ISpindleLink;
class CVelocityControl;

class CTimeBase
{
public:
	CTimeBase( void );
	// constructor

	virtual ~CTimeBase();
	// destructor

	friend void DumpDebugData( CTimeBase *pTimebase, long *data );
	// open friend relationship to dump object state for debug purpose

	static void AdvanceInterpolationCount( void );
	// to advance interpolation count

	static long get_InterpolationCount( void );
	// to advance interpolation count

	static void PutTrajPlanInterval( long interval );
	// set trajectory plan tick time interval, in micro-second

	static void PutMotionPlanInterval( long interval );
	// set motion plan tick time interval, in micro-second

	static void PutNormalPLCScanInterval( long interval );
	// set motion plan tick time interval, in micro-second
	
	static void PutInterpolationInterval( long interval );
	// set interpolation tick time interval, in micro-second

	static void PutOperationScanInterval( long interval );
	// set operation scan tick time interval, in micro-second

	static void InterpolationTick( void );
	// Use threads: interpolation

	long GetTimeBase( void );
	// get next timebase
	// Use threads: interpolation

	BOOL IsStop( void );
	// query whether it is stop.
	// Use threads: <= motion plan

	void Start( void );
	// start time axis movement
	// Use threads: <= motion plan

	void Stop( void );
	// stop time axis movement
	// Use threads: <= motion plan

	void Reset( void );
	// reset timebase
	// Use threads: <= motion plan

	void TimeMode( void );
	// use world time as time source
	// Use threads: <= motion plan

	void RevolutionMode( void );
	// use spindle revolution as time source
	// Use threa ds: <= motion plan

	int IsInRevolutionMode( void );
	// query whether it is in revolution mode
	// Use threads: <= motion plan

	void EnterThreadMode( void );
	// enter use ecnoder revolution as time source
	// Use threads: <= motion plan

	void ExitThreadMode( void );
	// exit use ecnoder revolution as time source
	// Use threads: <= motion plan

	void setDryRun( BOOL bDryRun );
	// set dry run mode

	void setTightCoupling( BOOL bTightCoupling );
	// set tight coupling mode

	BOOL IsTightCoupling( void );
	// is tight coupling?

	void putOverrideInhibit( BOOL bOverrideInhibit );
	// enable feedrate override inhitbit, that is, inhibit override input
	// disable feedrate override inhibit, that is, accept override input

	void putSpeedCheckInhibit( BOOL flag );
	// set inhibit spindle speed check flag

	void setMaxOverride( double Override );
	// set maximum override

	BOOL SyncTimeBase( void );
	// sync time base

	void PutSCurveTA( long time );
	// set the time constant for S-Curve timebase transition.

	void PutSkewTA( long time );
	// set the time constant for timebase transition.
	// time			in micro-second.
	// Use threads: <= motion plan

	void setThreadingStartAngle( double angle );
	// set thread cutting start angle

	void PutOverride( double Override );
	// set feedrate override
	// Override			0%~MAXOVERRIDE%
	// Use threads: <= interpolation

	void AssociateSpdLink( ISpindleLink *pSpdLink );
	// associate encoder for revolution time resource.
	// Use threads: constructor

	void setMPGSimulation( BOOL bMPGSimu );
	// set MPG simulation function enable/disable

	long getIndexErrCount( void );
	// get error count of index large than position in AdvanceTimeBase()

	static long GetTrajPlanInterval( void );
	// get trajectory plan tick time interval, in micro-second

	static long GetMotionPlanInterval( void );
	// get motion plan tick time interval, in micro-second

	static long GetNormalPLCScanInterval( void );
	// get motion plan tick time interval, in micro-second

	static long GetInterpolationInterval( void );
	// get interpolation tick time interval, in micro-second

	static long GetOperationScanInterval( void );
	// set operation scan tick time interval, in micro-second

public:
	static const double MAX_FeedrateOverride;
	// maximum feedrate override

protected:
	BOOL m_bRunning;
	// running flag

	BOOL m_bMPGSimu;
	// MPG simulation flag

	// state identifier
	enum
	{
		MODE_TIME,			// world time as source
		MODE_REVOLUTION		// encoder position as source
	};

	enum
	{
		THREADING_IDLE,					// idle
		THREADING_STARTINDEXCAPTURE,	// start spindle index capture
		THREADING_RECAPTUREINDEX,		// re-capture spindle index
		THREADING_WAITINDEX,			// wait until index has found
		THREADING_WAITNEXTPOS			// wait next spindle position
	};

	int m_SourceMode;
	// time source mode

	int m_fThreadMode;
	// thread cutting mode

	BOOL m_bDryRun;
	// flag for dry run mode

	BOOL m_bTightCoupling;
	// do tight coupling under feed per revolution mode

	double m_ThreadingStartAngle;
	// the thread cutting start angle

	double m_MaxOverride;
	// maximum allowable override

	int m_SyncIndexState;
	// state variable for sync. with index.

	double m_RevTimeRemainder;
	// remainder of revolution time, in microsecond.

	long m_nIndexErrCount;
	// the error count of index large than position in AdvanceTimeBase()

	long m_LastEncoderPosition;
	// last encoder position.

	long m_LLastEncoderPosition;
	// last last encoder position.

	long m_SkewRate;
	// maximum allowable timebase change,
	// in micro-second.

	double m_ReferenceSpeed;
	// spindle reference speed, in RPM

	long m_CurrentTimeBase;
	// current time base in micro-second,

	double m_Override;
	// feedrate override from 0% to MAXOVERRIDE%

	double m_Amax;
	// maximun acceleration/deceleration when override change

	double m_Jmax;
	// maximun jerk

	int m_fOverrideInhibit;
	// flag for inhibit feedrate override

	BOOL m_bSpeedCheckInhibit;
	// flag for inhibit spindle spped check

	ISpindleLink *m_pSpdLink;
	// associated spindle link for revolution time resource.

	CRTMutex m_cs;
	// mutex for object state consistent

	CVelocityControl *m_objSCurveController;
	// the s_curve controller 

	static long m_InterpolationInterval;
	// interpolation time interval in micro-second

	static long m_TrajPlanInterval;
	// trajectory planning time interval in micro-second

	static long m_MotionPlanInterval;
	// motion planning time interval in micro-second

	static long m_NormalPLCScanInterval;
	// motion planning time interval in micro-second

	static long m_OperationScanInterval;
	// operation scan time interval in micro-second

	static long m_nInterpolationCount;
	// the number of interpolation counter

	static CTimeBase *m_TimeBaseList;
	// list of all CTimeBase objects

	CTimeBase *m_Next;
	// pointer to next CTimeBase object in the m_TimeBaseList list

	void AdvanceTimeBase( void );
	// calculate next timebase
	// Use threads: interpolation

private:
	LONG getTargetTimeBase( void );
	// calculate and get target timebase

	BOOL WaitForThreading( void );
	// wait for threading

	BOOL m_bFirstEnterThread;
	// is first timebase tick in threading.

	double calcTB_SpindleSpeed( void );
	// calculate time base by spinlde speed

	void PlanTB_ConstantSlope( long TargetTimeBase );
	// plan time base by constant slope

	void PlanTB_ConstantJerk( long TargetTimeBase );
	// plan time base by constant jerk

#if Analysis_SpdPos_In_Thread_Debug_Mode
	void dumpSpdPos( double position );
	// dump spindle position

	void dumpSpdIndex( void );
	// dump spindle index

	void dumpErrSpdPosCase( double delta1, double delta2 );
	// dump error spindle position case
#endif
};

#endif // !defined(AFX_TIMEBASE_H__3CAB5701_8E9B_423D_B9A8_3BDB4CDF4069__INCLUDED_)
