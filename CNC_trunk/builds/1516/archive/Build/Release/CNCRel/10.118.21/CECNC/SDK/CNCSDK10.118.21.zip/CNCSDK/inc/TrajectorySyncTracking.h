// TrajectorySyncTracking.h: interface for the CTrajectoryEcam class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_TRAJECTORYSYNCTRACKING_H____INCLUDED_)
#define _TRAJECTORYSYNCTRACKING_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTrajectorySyncTracking : public CTrajectory
{
public:
	CTrajectorySyncTracking( BOOL bNeedNormSheet = FALSE, BOOL bNegVelAllowable = TRUE, BOOL bDumpData = TRUE );
	~CTrajectorySyncTracking( void );

	int planBlock_Dist( double V0, double Vc, double Vmax, double Amax, double Jmax, double Master, double Slave, TPVTSheet *pPVM );
	// plan block base on distance

	enum EResult {
		FailToSolve = 0,
		Success,
		NegativeVelocity,
		AccTooLarge,
		JerkTooLarge,
	};

public:
	INT planBlock_MaxConstVelProfile( DOUBLE Amax, DOUBLE Jmax, DOUBLE Master, DOUBLE Slave, TPVTSheet *pPVM );
	// plan block base on maximum constant-velocity slope

	BOOL SolveMaxConstVel_5S( DOUBLE Amax, DOUBLE Jmax, DOUBLE Master, DOUBLE Slave, DOUBLE &Vel, TBlkFeature &BlkFeature );
	// solve root for 5 sections case to find out max const Vel

	BOOL SolveMaxConstVel_7S( DOUBLE Amax, DOUBLE Jmax, DOUBLE Master, DOUBLE Slave, DOUBLE &Vel, TBlkFeature &BlkFeature );
	// solve root for 7 sections case to find out max const Vel

protected:
	BOOL StrictMonotone( double V0, double Vc, double Master, double Slave, double Amax, double Jmax, TBlkFeature &BlkFeature );
	// strict monotone case: accelerate or decelerate
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	BOOL Monotone( double V0, double Vc, double Master, double Slave, double Vmax, double Amax, double Jmax, TBlkFeature &BlkFeature );
	// monotone case: accelerate or decelerate
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	BOOL FindGoalVel_4S( double V0, double Vc, double Master, double Slave, TBlkFeature &BlkFeature );
	// find goal velocity, four sections
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	BOOL FindGoalVel_5S( double V0, double Vc, double Master, double Slave, TBlkFeature &BlkFeature, int sign, double Amax );
	// find goal velocity, five sections
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	BOOL FindGoalVel_6S( double V0, double Vc, double Master, double Slave, TBlkFeature &BlkFeature, int sign, double Amax );
	// find goal velocity, six sections
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	BOOL FindVmaxLen_5S( double V0, double Vc, double Master, double Slave, TBlkFeature &BlkFeature, double Vmax );
	// find length of maximum velocity, five sections
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	BOOL FindVmaxLen_6S( double V0, double Vc, double Master, double Slave, TBlkFeature &BlkFeature, int sign, double Amax, double Vmax );
	// find length of maximum velocity, six sections
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	BOOL FindVmaxLen_7S( double V0, double Vc, double Master, double Slave, TBlkFeature &BlkFeature, int sign, double Amax, double Vmax );
	// find length of maximum velocity, seven sections
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	BOOL IsAccTooSmall( double V0, double Vc, double P, double A );
	// is A * P larger than |Vc - V0|

	BOOL VpeakProfile( double V0, double Vc, double Master, double Slave, double Vmax, double Amax, double Jmax, int &nType, TBlkFeature &BlkFeature );
	// in this case, the profile has Vpeak

	BOOL VmaxProfile( double V0, double Vc, double Master, double Slave, double Vmax, double Amax, double Jmax, TBlkFeature &BlkFeature );
	// in this case, the profile touch Vmax

private:
	BOOL ProcessGeneralCase( double V0, double Vc, double Master, double Slave, double &Vmax, double &Amax, double &Jmax, int &nType, TBlkFeature &BlkFeature );
	// process general case
	// return TRUE : there is a path under the conditions
	// return FALSE : there is no satisfied path under the conditions

	double SolveRootFor4Section( double V0, double Vc, double Master, double Slave );
	// solve root for 4 sections case

	double SolveRootFor5Section( double V0, double Vc, double Master, double Slave, int sign, double Amax );
	// solve root for 5 sections case

	double SolveRootFor6Section( double V0, double Vc, double Master, double Slave, double Amax, double Vmax );
	// solve root for 6 sections case

	void NormalizeSheet( double Master, double Slave, TPVTSheet *pPVM );
	// normalize sheet

private:
	CPolynomialRootSolver m_PRS;
	// polynomial root solver

	double m_Coeff[5];
	// polynomial coefficients with m_Coeff[i] for i-th degree coefficient

	TPVTSheet *m_pPVM;
	// PVT sheet
	// named PVM since here regard the displacement of the master axis as time

	BOOL m_bNegVelAllowable;
	// is negative velocity allowable

	BOOL m_bNeedNormSheet;
	// is PVT sheet need normalization

	enum ESolutionType {
		ST_NoSolution = -1,
		ST_NoRealSolution = -2,
	};
};

#endif // !defined(_TRAJECTORYSYNCTRACKING_H____INCLUDED_)
