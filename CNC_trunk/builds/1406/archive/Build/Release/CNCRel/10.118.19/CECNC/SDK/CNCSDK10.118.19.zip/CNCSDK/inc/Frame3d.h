// Frame3d.h: interface for the CFrame3d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRAME3D_H__F47440FB_404B_4574_A948_71C551E2C952__INCLUDED_)
#define AFX_FRAME3D_H__F47440FB_404B_4574_A948_71C551E2C952__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Matrix4d.h"

class CVector3d;
class CMatrix3d;

class CFrame3d : public CMatrix4d  
{
public:
	CFrame3d();
	virtual ~CFrame3d();

	void set( CFrame3d &f );
	// Sets the value of this frame to a copy of the passed frame f

	void set( double trans[] );
	// set transition

	void set( CVector3d &vNormal, double angle );
	// set rotation

	void set( double trans[], CVector3d &vNormal, double angle );
	// set transition, rotation

	void set( double trans[], BOOL bMirror[], BOOL bXYExchange );
	// set transition, mirror, axis exchange, rotation, scale

	void set( double trans[], BOOL bMirror[], BOOL bXYExchange, double scale[] );
	// set transition, mirror, axis exchange, rotation, scale

	void set( double trans[], double alpha, double beta, double gamma );
	// set transition, and euler angle

	void setByFixedAngleXYZ( DOUBLE trans[], DOUBLE alpha, DOUBLE beta, DOUBLE gamma );
	// set by transition vector and fixed angle XYZ ( Extrinsic euler angle XYZ )
	// Fixed X:alpha -> Fixed Y:beta -> Fixed Z:gamma
	// Rz(gamma) * Ry(beta) * Rx(alpha)

	void set( double trans[], CMatrix3d &RotMatrix );
	// set transition and rotation matrix

	void transformPoint( double pt[] );
	void transformPoint( double pt[], double ptOut[] );
	// transform point

	void transformVector( double normal[] );
	void transformVector( double normal[], double normalOut[] );
	// transform vector
};

#endif // !defined(AFX_FRAME3D_H__F47440FB_404B_4574_A948_71C551E2C952__INCLUDED_)
