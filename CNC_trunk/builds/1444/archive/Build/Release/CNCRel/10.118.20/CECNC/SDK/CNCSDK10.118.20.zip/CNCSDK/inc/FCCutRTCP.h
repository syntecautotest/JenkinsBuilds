#if !defined(_FCCUTRTCP_H____INCLUDED_)
#define _FCCUTRTCP_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFCCutRTCP : public CFeedControl
{
public:
	CFCCutRTCP( LONG nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	virtual ~CFCCutRTCP( void );
	// destructor

	INT getCntQueueNotMature( void );
	// get count of call of FlushImmatureNodes() called, this means the CPU power is not engogh for normally flush mature queue
	// debug data 376, shows immature queue flush counts

protected:
	virtual void onBeginDispatchBlock( BOOL bForceFlush = TRUE );
	// trajectory planning tick call back

	void NotifyDecToZero( void );
	// notify decelerate to zero

	void FlushMatureNodes( INT nCount );
	// flush specified number of nodes inside raw queue into mature queue

	virtual void ForwardElimination( INT nStartIndex, INT nEndIndex, DOUBLE tmpVc );
	// do forward singular block elimination

	virtual BOOL NormalFlushRawQueueNodes( INT &nCount );
	// normally flush raw queue nodes

	virtual INT rSearchMatureBlock( DOUBLE &tmpVc );
	// to search the first mature block in reverse order

	virtual void BackwardElimination( INT nPos, DOUBLE tmpVc );
	// backward singular block elimination

	virtual BOOL PseudoBackwardElimination( INT nStartIndex, INT nEndIndex, DOUBLE &tmpVc, BOOL bStopInMature, INT &nMatureIndex );
	// pseudo backward singular block elimination, return TRUE if the block of nStartIndex is clamped down
	// calculate by constant jerk planning

	virtual void FlushImmatureNodes( INT nFlushCount );
	// flush immature node of specified number of count from raw queue.
	// count the number of node count to be release

private:
	INT m_nCntQueueNotMature;
	// shows the count that FlushImmatureNodes() is called, dump debug data No. 376

	CTrajectory m_TJ;
	// trajectory functions

	BOOL CalcReasonableVelocity( DOUBLE &Vel_High, const DOUBLE Vel_Low, TLANode *pNode );
	// return TRUE if Vel_High is clamped down, else return FALSE

};

#endif // !defined(_FCCUTRTCP_H____INCLUDED_)
