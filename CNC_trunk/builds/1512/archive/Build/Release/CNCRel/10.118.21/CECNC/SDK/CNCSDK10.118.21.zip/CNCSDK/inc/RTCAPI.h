// RTCAPI.h: interface for the real time clock API.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_RTCAPI_INCLUDED_)
#define _RTCAPI_INCLUDED_

#include "nstdlib.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void RtcInit( DWORD dwIRtcDevice );
// set associated IRtcDevice interface object

extern void RtcStart(void);
// start RTC service

extern void RtcStop(void);
// stop RTC service

extern ULONG CNCAPI RtcConnect( PFNSERVICE pfnService, LPVOID lpParameter, ULONG duration );
// connect to realtime timer callback service
// pfnService	pointer to timer arrival service routine.
// lpParameter	pointer service parameter.
// duration		calling duration, in macro second
// return the handle of this connection
// Note:
//		the timer service function cannot use floating point calculation

extern void CNCAPI RtcDisconnect( ULONG handle );
// disconnect from specified timer channel
// handle		the handle of connection, return from RtcConnect

extern ULONG CNCAPI RtcGetCounter( void );
// get current realtime timer counter

extern ULONG CNCAPI RtcGetFrequency( void );
// get timer interrupt frequency, Herz

extern ULONG CNCAPI RtcGetActualDuration( ULONG duration );
// get actual duration of specified duration

#ifdef __cplusplus
}
#endif 

#endif // !defined(_RTCAPI_INCLUDED_)
