// InterruptSignalManager.h: implementation of the CInterruptSignalManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_INTERRUPTSIGNALMANAGER_H____INCLUDED_)
#define _INTERRUPTSIGNALMANAGER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CInterruptSignalManager
{
//--------------------------------------------------functions--------------------------------------------------
public:
	CInterruptSignalManager( void );
	// constructor

	~CInterruptSignalManager( void );
	// destructor

	BOOL isInterruptCallEnabled( void );
	// is interrupt manager enable

	BOOL isTriggered( void );
	// query is interrupt signal triggered

	void scanInterruptState( void );
	// scan all source signal, use thread: InterpolationTick

	void reset( void );
	// reset

	void setUntriggered( void );
	// setinterrupt state back to waiting for edge, forcing rescan

public:
	void setInterruptManagerEnable( BOOL bEnable );
	// set manager enable to trace interrupt signal

	BOOL setInterruptInfo( INT nType, INT nNum, INT nCond, INT nLastTime );
	// set interrupt signal information

private:
	BOOL isInterruptInfoValid( INT nType, INT nNum, INT nCond, INT nLastTime );
	// check interrupt signal information is valid

	void updateInterruptState( void );
	// update interrupt signal trigger state

	BOOL detectBitCondition( void );
	// detect source signal state change

private:
//-------------------------------------------------struct & enum----------------------------------------------
	struct TIntSigInfo {
		// [ signal property ]
		INT		Num;		// signal number
		INT		LastTime;	// signal last time( us )
		BYTE	BitNum;		// bit number if R bit used
		BYTE	Source;		// 0: C bit, 1: I bit, 2: R bit, 3: A bit
		BYTE	Condition;	// 0: off; 1: on
		BYTE	Reserved;	// padding
		// [ signal state ]
		BOOL	Enable;		// signal enable
		BOOL	PrevCond;	// previous signal condition
		INT		State;		// trigger state
		INT		Elapse;		// elapse time( us )
	};

	// interrupt signal soutce
	enum ESigSource {
		SIG_TYPE_CBIT = 0,
		SIG_TYPE_IBIT,
		SIG_TYPE_RBIT,
		SIG_TYPE_ABIT,
		// for count enum
		SIG_TYPE_LAST,
	};

	// interrupt signal state
	enum EInterruptSignalState {
		SIG_WAIT_EDGE = 0,
		SIG_CHECK_ELAPSE,
		SIG_TRIGGERED,
	};

//--------------------------------------------------variables--------------------------------------------------
private:
	CRTMutex m_cs;
	// object state consistent mutex

	TIntSigInfo m_IntSigInfo;
	// packed info. of the interrupt signal

	BOOL m_bInterruptEnable;
	// interrupt manager enable / disable

	LONG m_nTimebase;
	// interpolation time base (usec)
};

#endif // !defined(_INTERRUPTSIGNALMANAGER_H____INCLUDED_)
