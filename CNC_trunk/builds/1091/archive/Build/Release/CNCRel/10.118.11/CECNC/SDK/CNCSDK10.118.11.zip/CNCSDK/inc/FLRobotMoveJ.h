#if !defined(_CFLROBOTMOVEJ_H____INCLUDED_)
#define _CFLROBOTMOVEJ_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFLRobotMoveJ : public IRobotFeedLimit
{
public:
	CFLRobotMoveJ( void );
	// constructor

	~CFLRobotMoveJ( void );
	// destructor

public:
	void putMotionNode( TLANode *pNode );
	// put motion node to feedlimit module

	void onMotionParamChanged( const TMotParamTable &MotParamTable );
	// on motion parameters changed

	void calcLength( TLANode *pNode );
	// calculate block length.

	BOOL processMaxOverride( TLANode *pNode, LONG nArg[ 2 ] );
	// process maximum override

public:
	void setChannelCount( int nChannelCount );
	// set number of axis channel

protected:
	void calcMotionFeature( TLANode *pNode );
	// calculate block motion feature.

	void estimateElapseTime( TLANode *pNode );
	// estimate elapse time of pNode

private:
	void putMaxAxisFeedrate( const double AxFmax[] );
	// put maximum axis feedrate in IU / us

	void putMaxAxisAcceleration( const double AxAmax[] );
	// put maximum axis acceleration in IU / us ^ 2

	void putMaxAxisJerk( const double AxJmax[] );
	// put maximum axis jerk

private:
	void clampFeedrateByAxisLimit( TLANode *pNode );
	// clamp feedrate by the max speed of each axis

	void clampBlockAccByAxisAcc( TLANode *pNode );
	// clamp block acceleration by maximum axis acceleration

	void clampBlockJerk( TLANode *pNode );
	// clamp block jerk by maximum jerk and maximum axis jerk

protected:
	double m_MaxOverride;
	// max override

	TLANode *m_pNode;
	// motion node

	int m_nChannelCount;
	// channel count

	int m_nLimitingJoint;
	// the number of joint who clamps the Fclamp

	double m_AxFmax[ NUMOF_ROBOT_AXIS ];
	double m_AxAmax[ NUMOF_ROBOT_AXIS ];
	double m_AxJmax[ NUMOF_ROBOT_AXIS ];
	// Feedrate, Acceleration, Jerk for each axis
};
#endif // !defined(_CFLROBOTMOVEJ_H____INCLUDED_)
