// _cncapi.h
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX__CNCAPI_H__INCLUDED_)
#define AFX__CNCAPI_H__INCLUDED_

#include "nstdlib.h"
#include "Variant.h"
#include "CommonStruct.h"
#include "OperationDef.h"
#include "InternalCNCAPI.h"
#include "cncapi.h"

#endif // AFX__CNCAPI_H__INCLUDED_
