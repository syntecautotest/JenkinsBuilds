// AuxInterpolator.h: interface for the CAuxInterpolator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_AUXINTERPOLATOR_H____INCLUDED_)
#define _AUXINTERPOLATOR_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMovingAverageFilter;
class CIntegerQueue;

class CAuxInterpolator
{
public:
	CAuxInterpolator( long nTimeBase );
	~CAuxInterpolator( void );
	// Construction Destruction

	BOOL SubsCompensation( LONG nCompensation );
	// substituted intertpolate compensation

	BOOL SubsShiftCommand( long &nOutCommand );
	// shift command in the case for input command is missing

	void ShiftCommand( long nInCommand, long &nOutCommand );
	// shift command in general case

	void Reset( void );
	// reset

private:
	LONG CalcSubsCommand( void );
	// calculate substituted interpolate command

	void GenerateSubsCommand( void );
	// generate substitute command

	void GenerateMergedCommand( long nInCommand );
	// generate merged command

	BOOL MergePosition( long nInCommand, long &nOutCommand );
	// merge to match position

	void InitSubsState( void );
	// init substitute state

	void InitMergeState( void );
	// init merge state

private:
	enum ECSSTATE {
		ECS_Idle = 0,
		ECS_DoSubs,
		ECS_DoMerge,
	};

	CIntegerQueue m_CommandQueue;
	// command queue

	CMovingAverageFilter *m_pMAFilter;
	// moving average filter

	int m_nMaxCount;
	// max count of substitute command

	long m_nTimeBase;
	// timebase

	struct TSubsInfo {
		int nCount;			// substitute count
		long nCommand;		// substitute command
		long nCommandAcc;	// substitute command acceleration (count per tick)
		long nTotalCommand;	// total substitute command
	};

	TSubsInfo m_SubsInfo;
	// substitute command information

	struct TMergeInfo {
		int nCount;					// merge count
		int nReserved;				// reserved
		double Command;				// merge command
		double CommandRemainder;	// merge command remainder
		double MaxCommand;			// max merge command
		double CommandAcc_1;		// command acceleration (count per tick)
		double CommandAcc_2;		// command acceleration (count per tick)
	};

	TMergeInfo m_MergeInfo;
	// merge command information

	int m_nState;
	// state
};

#endif // !defined(_AUXINTERPOLATOR_H____INCLUDED_)
