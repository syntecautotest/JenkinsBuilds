#if !defined(_ISVODEVCOMSTATE_H_INCLUDED_)
#define _ISVODEVCOMSTATE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISvoDevComState
{
public:
	virtual ~ISvoDevComState( void ) {}
	// destructor

	virtual LONG GetSvoDevName( void ) = 0;
	// get servo device name

	virtual LONG GetTypeOfChannel( void ) = 0;
	// get type of channel
};

#endif // _ISVODEVCOMSTATE_H_INCLUDED_
