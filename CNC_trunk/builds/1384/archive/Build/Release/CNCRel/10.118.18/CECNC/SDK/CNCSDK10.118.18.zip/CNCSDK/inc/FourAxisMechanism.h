// FourAxisMechanism.h: interface for the FourAxisMechanism class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOURAXISMECHANISM_H_)
#define AFX_FOURAXISMECHANISM_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFourAxisMechanism : public IRTCPMechanism
{
public:
	CFourAxisMechanism( INT nID );

	virtual ~CFourAxisMechanism( void );
	// destructor

public:
	void SetToolAxisDirection( INT n, DOUBLE RA, DOUBLE RB );
	// 1:Positive X-Axis direction
	// 2:Positive Y-Axis direction
	// 3:Positive Z-Axis direction
	// unit : BLU
	// see Fanuc p540
	// parameter 19698 and 19699

	void SetDirectionOfFirstRotationAxis( INT type, DOUBLE RotationOffset[] );
	// set the axis direction of the first rotation axis.
	// type 1: On X-axis
	// type 2: On Y-axis
	// type 3: On Z-axis

	void SetRotationDirectionOfFirstRotationAxis( INT n );
	// 0:rule of right hand side
	// 1:rule of left hand side

	void SetRestrictOfFirstRotationAxis( DOUBLE Start, DOUBLE End );
	// set restriction of first rotation axis
	// unit : BLU
	// 0 ~ 2PI

	void SetToolHolderOffset( DOUBLE ToolHolderOffset );
	// set tool holder offset
	// unit : BLU

	void SetDefaultTCPIntMode( EIntMode bQuatInt );
	// set flag of default TCP Interpolation Mode

	void SetTCPTableCrdSys( ETableCoordSys nBasicPos );
	// set basic position of table coordinate system for RTCP

	INT GetToolAxisDirection( void );
	// get tool axis direction

	INT GetDirectionOfFirstRotationAxis( void );
	// get the axis direction of the first rotation axis.

	BOOL IsQuatIntMode( void );
	// is Quaternion Interpolation Mode?

	BOOL IsTableCrdSysFromZeroPos( void );
	// is basic position of table coordinate system for RTCP from zero position?

	BOOL IsSetToolAxisDirection( void );
	// does set tool axis direction

	BOOL IsSetDirectionOfFirstRotationAxis( void );
	// does set direction of first rotation axis

	BOOL IsSetRotationDirectionOfFirstRotationAxis( void );
	// does set rotation direction of first rotation axis

	BOOL IsAtPermissibleRangeForMasterAxis( DOUBLE &Angle );
	// is the angle at permissible range for Master Axis
	// Unit : BLU
	// -PI ~ PI
	// right hand side

public:
	void SetIU_BLU_Ratio( const DOUBLE IUtoBLU_Linear, const DOUBLE IUtoBLU_Rotary );
	// set IUtoBLU

	DOUBLE getIUtoBLU_Rotary( void );
	// get IUtoBLU for rotary axes

	INT getMechID( void );
	// get the ID of four axis mechanism

	INT getMechType( void );
	// get the type of four axis mechanism

	DOUBLE getMasterAxisAngleOffset( void );
	// get angle offset of master axis

	INT getRDOfFirst( void );
	// get rotation direction of first axis

	INT IsAlarm( void );
	// is alarm?

	BOOL IsValidSetting( void );
	// is valid setting for four axis

public:
	virtual void SetOffset( DOUBLE FirstOffset[] ) = 0;
	// set offset

	virtual void Kinematic( CVector3d &ToolTipPosition, DOUBLE MasterRotAngle, CVector3d ControlPoint, DOUBLE ToolLength ) = 0;
	// Kinematic transformation
	// Compute Tool Tip Position
	// unit : BLU
	// right hand side

	virtual INT InverseKinematic( CVector3d ToolTipPosition, DOUBLE MasterRotAngle, CVector3d &ControlPoint, DOUBLE ToolLength ) = 0;
	// Inverse Kinmatic transformation 
	// Compute ControlPoint
	// unit : BLU
	// right hand side

	virtual INT InverseKinematic( CVector3d ToolTipPosition, CVector3d FeedDirection, DOUBLE LastMasterRotAngle, CVector3d &ControlPoint, DOUBLE &MasterRotAngle, DOUBLE ToolLength ) = 0;
	// Inverse Kinmatic transformation
	// Given Tool Tip Position and Feed Direction and last rotate angle
	// Compute Control point and RotateAngle
	// unit : BLU
	// right hand side

	virtual INT ComputeRotateAngle( CVector3d FeedDirection, DOUBLE LastMasterRotAngle, DOUBLE &MasterRotAngle ) = 0;
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle
	// unit : BLU
	// right hand side

	virtual void GetToolCoordUnderMachineCoord( DOUBLE MasterAngle, CMatrix3d &ToolCoord, EToolCoordType Type ) = 0;
	// get tool coord
	// right hand side

	virtual void MtoIJK( DOUBLE MasterAngle, CVector3d *RotAxis ) = 0;
	// convert Master angle to (I,J,K)
	// right hand side

protected:
	INT m_nMechID;
	// four-axis mechanism ID

	DOUBLE m_IUtoBLU_Linear;
	DOUBLE m_BLUtoIU_Linear;
	DOUBLE m_IUtoBLU_Rotary;
	DOUBLE m_BLUtoIU_Rotary;
	// IU to BLU

	INT m_nOrganization;
	// Organization

	CVector3d m_ToolAxisDirection;
	// tool Axis direction

	CVector3d m_ToolAxisRightAngleDirection1;

	CVector3d m_ToolAxisRightAngleDirection2;

	INT m_nToolDirection;
	// 1: x-axis
	// 2: y-axis
	// 3: z-axis

	DOUBLE m_MasterAxisAngleOffset;

	CVector3d m_DirectOfFirstRotAxis;
	// the direction of first rotation axis

	INT m_DirectionOfFRA;
	// the direction of first rotation axis
	// 1:X axis   2:Y axis   3:Z axis

	INT m_nRDOfFirst;
	// rotation direction of first rotation
	// 1: CCW
	// -1: CW

	DOUBLE m_FStart;
	// the start angle of permissible range for first rotation axis

	DOUBLE m_FEnd;
	// the end angle of permissible range for first rotation axis

	DOUBLE m_ToolHolderOffset;
	// tool holder offset, BLU

	EIntMode m_DefaultTCPQuatInt;
	// flag of default TCP Interpolation Mode

	ETableCoordSys m_TableCoordSys;
	// basic position of table coordinate system for RTCP

	// common utility function for 4 Axis and 5 five Axis
protected:
	void SetMasterRotMatrix( DOUBLE MasterRotAngle, CMatrix3d &MasterRotMatrix );
	// set master rotation matrix
	// point orientation
	// unit : BLU
	// right hand side

	INT IJKtoM( CVector3d FeedDirection, CVector3d ToolDirection, CVector3d DirectOfFirstRotAxis, DOUBLE LastMasterRotAngle, DOUBLE &MRotAngle );
	// i,j,k to rotate angle
	// unit : BLU
	// right hand side

	DOUBLE CorrespondingAngle( DOUBLE A, DOUBLE B );
	// return corresponding angle of A such that distance( A, B ) is the smallest
	// unit : BLU

	BOOL SolveQuadEq( DOUBLE A, DOUBLE B, DOUBLE C, DOUBLE &x1, DOUBLE &x2 );
	// return FALSE, if this equation has no real roots
	// return TRUE, if this equation has one or two roots
	// Ax^2 + Bx + C = 0

	DOUBLE Determinant( DOUBLE a11, DOUBLE a12, DOUBLE a21, DOUBLE a22 );
	// determinant

	void Permutation( INT type, INT Permutation[] );
	// permutation

	void ConvertAngleRange( DOUBLE &angle );
	// convert any angle to -PI ~ PI
	// unit : BLU

	void CalculateDirectionOfRotationAxis( DOUBLE DirectOfRotAxis[], DOUBLE RotationOffset[], INT Permutation[] );
	// calculate the direction of rotation axis.

	BOOL IsAtPermissibleRange( DOUBLE &Angle, DOUBLE start, DOUBLE end );
	// is the angle at permissible range
	// Unit : BLU
	// -PI ~ PI
	// right hand side
};

#endif	// !define( AFX_FOURAXISMECHANISM_H_)
