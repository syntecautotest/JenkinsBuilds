#pragma once

class CJRectLayout
{
public:
	CJRectLayout( LPRECT lprcClipMargin );
	~CJRectLayout(void);

	void placeRectangle( SIZE ptSize );
	// to add a new rectangle

	void placeRectangle( LONG nLeft, SIZE ptSize );
	// to add a new rectangle with predefined start position.

	void getLayoutRect( LPRECT lpRect );
	// to get result layout rectangle

	POINT m_Cursor;
	// the cursor position

private:
	RECT m_rcClipMargin;
	// the clip margin

	LONG m_nMarginWidth;
	// the clip margin width

	RECT m_rcLayoutAcc;
	// the layout rectangle accumulator

	RECT m_rcLineRect;
	// the recent line 

public:
	static void flipRect( LPRECT lpDestRect, LPRECT lpSrcRect );
	// to flip rectangle

	static void flipSize( LPSIZE lpDestSize, LPSIZE lpSrcSize );
	// to flip size
};
