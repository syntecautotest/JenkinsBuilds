// The EtherNet/IP Definition Declaration
#pragma once

#if defined( _ENIPAPI_DLLEXPORT ) // Build DLL
#define ENIPAPI __declspec( dllexport )
#else // Use DLL
#define ENIPAPI __declspec( dllimport )
#endif // _ENIPAPI_DLLEXPORT


typedef unsigned long long	ENIP_HANDLE;

#define ENIP_ERROR_HANDLE			( ( ENIP_HANDLE )0 )	// Error EnIP handle
#define ENIP_EXPMSG_BUFFER_SIZE		( 256 )					// Max buffer size of explicit message for request / response (unit: BYTE)
#define CIP_GENERAL_STATUS_SUCCESS	( 0 )					// CIP General Status Code for Success


#pragma pack( push, 1 ) // 1-byte Alignment

struct TEnIPSockAddr {
	SHORT sin_family;
	USHORT sin_port;
	DWORD sin_addr;
	BYTE sin_zero[ 8 ];
};

struct TEnIPRevision {
	BYTE nMajor;
	BYTE nMinor;
};

struct TEnIPDevInfo {
	WORD nProtocolVersion;
	TEnIPSockAddr SockAddr;
	WORD nVendorID;
	WORD nDeviceType;
	WORD nProductCode;
	TEnIPRevision Revision;
	WORD nStatus;
	DWORD nSerialNumber;
	CHAR szProductName[ 33 ];
	BYTE nState;
};

// EnIP Explicit Message Request Structure
struct TEnIPExpMsgReq {
	BYTE nService;			// Request Service Code
	BYTE nPaddingByte;		// Reserved
	WORD nClass;			// Request Path: Class
	DWORD nInstance;		// Request Path: Instance
	WORD nAttribute;		// Request Path: Attribute (0 is no Attribute)
	const void *pReqData;	// Request Data
	WORD nReqDataLength;	// Request Data Length (unit: BYTE)
};

// EnIP Explicit Message Response Structure
struct TEnIPExpMsgRsp {
	BYTE nService;					// Response service code is let the highest bit of request service code as 1 (same as plus 0x80)
	BYTE nPaddingByte;				// Reserved
	BYTE nGeneralSatus;				// Response CIP General Status Code
	BYTE nAdditionStatusSize;		// Additional Status Size (unit: WORD)
	const BYTE *pAdditionStatus;	// Addition Status
	INT nRspDataLength;				// Response Data Length (unit: BYTE)
	const BYTE *pRspData;			// Response Data
};

#pragma pack( pop )


extern "C" {

// List of device info from EnIP broadcast
struct ENIPAPI TEnIPDevInfoList {
	UINT nCount;				// Count of device
	TEnIPDevInfo *pDevInfo;		// Device info array
	TEnIPDevInfoList();			// Constructor
	~TEnIPDevInfoList();		// Destructor
};

}


enum EEnIPRecvState {
	EERS_SUCCESS,			// Recv Success
	EERS_WAITDATA,			// Wait Response Data
	EERS_TIMEOUT,			// Recv Time Out

	//== User Level Error
	EERS_OPERATE_ERROR,		// Operation Error

	//== Communication Level Error
	EERS_ENCAPMSG_ERROR,	// Encapsulation Message Error

	//== System Levle Error
	EERS_INTERNET_ERROR,	// Internet Error
};
