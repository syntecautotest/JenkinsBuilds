#if !defined(_ROBOTMOTIONDEF_H____INCLUDED_)
#define _ROBOTMOTIONDEF_H____INCLUDED_

#include "stdafx.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// robot not defined type
#define CHANNELMAP_NOT_DEFINED		( -1 )
#define JOINTMAP_NOT_DEFINED		( -1 )
#define SCREWJOINT_NOT_DEFINED		( -1 )

// zero band for ratio or weight...etc
#define EPSILON_RATIO_ZEROBAND		( DBL_EPSILON * 1.0e6 )

// conveyor tracking
#define NUMOF_CONVEYOR				( 4 )		// maximum number of conveyors

// feedrate
#define FEEDRATE_TOO_LOW			( 1.0e-9 )	// feedrate too low

// overlapping
#define MAX_POSITION_LEVEL			( 10 )		// maximum level of PL
#define MIN_POSITION_LEVEL			( 0 )		// minimum level of PL

// coordinate information
#define NUMOF_USERCOORD				( 41 )		// add one for USERCOR P0
#define NUMOF_VALID_USERCOORD		( 20 )
#define NUMOF_VALID_USEROFFSET		( 3 )
#define DEGREEOF_POSORI				( 6 )
#define INDEXOF_POS					( 0 )
#define INDEXOF_ORI					( 3 )
#define COORD_MULTIPLIER_POS		( 1000.0 )
#define COORD_MULTIPLIER_ORI		( 1000000.0 )

// define xml string length
// each one contains a NULL character '\0'
#define MAX_XMLDATA_LENGTH			( 32000 )
#define NUMOF_NAME					( 32 )
#define LENGTHOF_XMLVERSION			( 3 )		// ex: 1.0 equals to 10, version limit is 99
#define LENGTHOF_ROBOTTYPE			( 5 )		// ex: SCARA is 101
#define LENGTHOF_COORDNUMBER		( 3 )
#define LENGTHOF_POSORI_ELEMENT		( 16 )		// for example, -9999999.999999 is the minimum number that can be stored by the xml file.

// number of robot tools
#define NUMOF_ROBOT_TOOL			( 21 )
#define TOOL_FLANGE					( 0 ) // tool 0 is flange of the robot

// coordinate struct definition
struct TPosEuler {
	DOUBLE		X;
	DOUBLE		Y;
	DOUBLE		Z;
	DOUBLE		A;
	DOUBLE		B;
	DOUBLE		C;
};

// tool data structure
struct TToolData {
	TCHAR	Name[ NUMOF_NAME ];
	union {
		DOUBLE		XYZABC[ DEGREEOF_POSORI ];	// XYZABC has the same physical meaning as Frame (rotational unit in rad. )
		TPosEuler	PosOri;						// (rotational unit in rad. )
	};
	DOUBLE	EEfPosMaxError[ 3 ];	// Tool calibration EEf position max error in three dimension
	DOUBLE	EEfPosMeanError;		// Tool calibration EEf position mean error
};

struct TUserCoord {
	TCHAR			Name[ NUMOF_NAME ];
	CAxFrame		Frame;						// original user coordinate frame

	union {
		DOUBLE		XYZABC[ DEGREEOF_POSORI ];	// XYZABC has the same physical meaning as Frame (rotational unit in rad. )
		TPosEuler	PosOri;						// (rotational unit in rad. )
	};
};

struct TOffsetInfo {
	DOUBLE			Offset[ DEGREEOF_POSORI ];	// XYZABC (rotaional unit in rad )
};

enum EOffsetType {
	EOFST_User = 0,								// offset frame set by OFFSETON
	EOFST_Sys = 1,								// offset frame set by Conveyor Tracking
};

struct TCoordInfo {
	INT				nUserCoordID;
	LONG			nUserOffsetCount;
	TOffsetInfo		UserOffset[ NUMOF_VALID_USEROFFSET ];
	TOffsetInfo		SysOffset;
};

enum EIncMovType {
	EINCMOV_ObjectCoord = 1,	// incremental move in object coordinate, object coordinate = user coordinate + offset
	EINCMOV_ToolCoord = 2,		// incremental move in tool coordinate
};

//struct TObjCoord {
//	TCHAR			Name[ NUMOF_NAME ];
//	CAxFrame		ObjFrame;						// original object coordinate frame
//
//	union {
//		double			XYZABC[ DEGREEOF_POSORI ];	// XYZABC has the same physical meaning as Frame
//		TPositionOrientation PosOri;
//	};
//};

#endif // !defined(_ROBOTMOTIONDEF_H____INCLUDED_)
