#if !defined(AFX_SINGLESPINDLETILTINGTYPE_H__INCLUDED_)
#define AFX_SINGLESPINDLETILTINGTYPE_H__INCLUDED_

class CSingleSpindleTiltingType : public CFourAxisMechanism
{
public:
	CSingleSpindleTiltingType( INT nID );
	// constructor

	virtual ~CSingleSpindleTiltingType( void );
	// destructor

	void SetOffset( DOUBLE FirstOffset[] );
	// FirstOffset = ToolHolderToMaster

	void Kinematic( CVector3d &ToolTipPosition, DOUBLE MasterRotAngle, CVector3d ControlPoint, DOUBLE ToolLength );
	// Kinematic transformation for SingleSpindle Tilting Type Machine
	// Compute Tool Tip Position
	// unit : BLU
	// right hand side

	INT InverseKinematic( CVector3d ToolTipPosition, DOUBLE MasterRotAngle, CVector3d &ControlPoint, DOUBLE ToolLength );
	// Inverse Kinmatic transformation for SingleSpindle Tilting Type Machine
	// Compute WorkPieceToMaster
	// unit : BLU
	// right hand side
	
	INT InverseKinematic( CVector3d ToolTipPosition, CVector3d FeedDirection, DOUBLE LastMasterRotAngle, CVector3d &ControlPoint, DOUBLE &MasterRotAngle, DOUBLE ToolLength );
	// Inverse Kinmatic transformation for SingleSpindle Tilting Type Machine
	// Given Tool Tip Position and Feed Direction and last rotate angle
	// Compute ControlPoint and RotateAngle
	// unit : BLU
	// right hand side

	INT ComputeRotateAngle( CVector3d FeedDirection, DOUBLE LastMasterRotAngle, DOUBLE &MasterRotAngle );
	// Given FeedDirection and last rotate angle
	// Compute RotateAngle
	// unit : BLU
	// right hand side

	void MtoIJK( DOUBLE MasterAngle, CVector3d *RotAxis );
	// convert Master angle to (I,J,K)
	// right hand side

	void GetToolCoordUnderMachineCoord( DOUBLE MasterAngle, CMatrix3d &ToolCoord, EToolCoordType Type );
	// get tool coord
	// right hand side

private:
	CVector3d m_ToolHolderToMaster;
	// the vector from tool holder to master axis
};

#endif // !defined(AFX_SINGLESPINDLETILTINGTYPE_H__INCLUDED_)
