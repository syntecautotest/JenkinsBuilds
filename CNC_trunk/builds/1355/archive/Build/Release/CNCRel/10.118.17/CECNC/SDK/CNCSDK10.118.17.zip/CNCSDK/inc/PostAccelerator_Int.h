// !!! This is obsolete code, don't use this file. !!!
//
// PostAccelerator_Int.h: interface for the CPostAccelerator_Int class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POSTACCELERATOR_INT_H__39FF655E_3B6E_4663_B5D8_6BCED3B0D734__INCLUDED_)
#define AFX_POSTACCELERATOR_INT_H__39FF655E_3B6E_4663_B5D8_6BCED3B0D734__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPostAccelerator_Int  
{
public:

	CPostAccelerator_Int( long nTimeBase, long MaxMovingAverageTime = 2000000 );
	// constructor, default max time is two second

	virtual ~CPostAccelerator_Int();
	// destructor

	void setTimeBase( long nTimeBase );
	// set timebase

	void Reset( void );
	// reset object
	// Use thread: <= motion plan

	int IsIdle( void );
	// query whether there are no command queue inside?
	// Use thread: <= motion plan

	void PutAccelerationTime( long TA );
	// set post acceleration time
	// Use thread: <= motion plan

	long GetAccelerationTime();
	// get actual post acceleration time
	// Use thread: <= motion plan

	void Smooth( LONG &displacement );
	// do post acceleration
	// Use thread: interpolation

	void GetQueuedCommand( long &command );
	// query pending commands in queue
	// Use thread: <= interpolation

private:

	long *m_lpData;
	// buffer for calculate moving average

	int m_MaxDataLen;
	// moving average buffer size

	int m_DataLen;
	// moving average length

	int m_Index;
	// next index of moving average calculation

	long m_nTimeBase;
	// time unit of post-acceleration buffer 

	long m_TA;
	// post acceleration time

	long m_Sum;
	// moving average buffer command displacement sum.

	long m_QueuedCommand;
	// current queued command

	long m_OutRemainder;
	// output pulse remainder

	int m_ZeroCycleCount;
	// zero cycle count

	CRTMutex m_cs;
	// mutex for object state consistent
};

#endif // !defined(AFX_POSTACCELERATOR_INT_H__39FF655E_3B6E_4663_B5D8_6BCED3B0D734__INCLUDED_)
