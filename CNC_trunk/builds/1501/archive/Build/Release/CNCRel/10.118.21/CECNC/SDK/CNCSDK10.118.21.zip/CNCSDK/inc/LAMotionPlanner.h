#if !defined(_LAMOTIONPLANNER_H____INCLUDED_)
#define _LAMOTIONPLANNER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLookAheadPipe;
class CFeedLimit;
class CFeedControl;
class CInterpolator;
class CTrajectoryNormal;
class CLANodePool;

class CLAMotionPlanner : public CMotionPlanner
{
public:
	CLAMotionPlanner( IFuncCallHandler *pFuncCallHandler, CLANodePool *pLAPool, double SafityTime, unsigned QueueSize, unsigned StackSize, long IntQueueSize, long IntStackSize, long QueueReadySize, int nEventCoordID );
	// constructor

	virtual ~CLAMotionPlanner( void );
	// destructor

	virtual void setWPInfo( const int nXAxis, const int nYAxis, const int nZAxis );
	// set work plane info

	virtual void putMaxCompFeedrate( const double Fmax );
	// put maximum feedrate in IU / us

public:
	virtual BOOL isIdle( void );
	// is idle

public:
	virtual void Start( void );
	// cycle start

public:
	virtual void putExactStop( void );
	// put exact stop

	virtual void putEOBMark( const TPacketInfo &PacketInfo );
	// put EOB mark

	virtual void TrajPlanTick( void ) = 0;
	// trajectory plan tick

	virtual BOOL isReadyForRecord( void );
	// is ready for record, this function is used for record mode

public:
	virtual void get_SnapshotQueTime( long *lpdwRaw, long *lpdwMature );
	// to get remain queue time inside queue.

	void putWPInfo( long *Para );
	// put work plane information

protected:
	virtual void Reset( void );
	// reset

	virtual void Abort( void );
	// abort

	BOOL ExecuteFuncCall( double Timebase, BOOL bMovement );
	// execute func call
	// return TRUE: skip while-loop of this motion planner
	// return FALSE: do while-loop continuously

	void PutFuncCall( const EFUNCID FuncID, long lpvarArgs[], int cArgs, EStopType nStopType, const TPacketInfo *pPacketInfo = NULL );
	// to put function call node

	virtual void IssueFuncCall( TLANode *pNode );
	// issue func call from LANode to MicroCode

	virtual BOOL isIntReady( void );
	// is interpolation ready

	virtual void dispatchLANode( TLANode *pNode ) = 0;
	// dispatch LA node

	void IssueCornerBlock( double EnterLen, double eEnter[], double EnterVc, double LeaveLen, double eLeave[], double LeaveVc, long Mode );
	// issue corner block

	virtual void decideMaxVelocity( TLANode *pNode, double &Vmax1, double &Vmax2 );
	// decide maximum velocity

	void clearCornerLeaveFeature( void );
	// clear corner leave feature

	virtual void WriteToInterpolator( double Ax[], TPVTSheet &sheet );
	// write to interpolator

	virtual void addChannel( int index );
	// to add specified axis

	virtual void set_ChannelCount( const int nCount );
	// to set channel count

protected:
	void putMaxAxisFeedrate( const double AxFmax[] );
	// put maximum axis feedrate in IU / us

	virtual void putMaxCompAcceleration( const DOUBLE Amax );
	// put maximum acceleration in IU / us ^ 2

	void putMaxCompJerk( const double Jmax );
	// put maximum jerk in IU / us ^ 3

	void putMaxAxisJerk( const double AxJmax[] );
	// put maximum axis jerk in IU / us ^ 3

	TLANode *PeekLANode( void );
	// peek look ahead node

protected:
	double m_SafityTime;
	// safity time

	int m_nChannelCount;
	// channel count

	long m_nIntQueueSize;
	// interpolator queue size

	long m_nIntStackSize;
	// interpolator stack size

	int m_nQueueReadySize;
	// command queue ready size

	double m_LeaveLength;
	double m_LeaveVc;
	double m_eLeave[NUMOF_AXIS];
	// corner leave feature

	double m_LastVc;
	// last vc

	CFeedLimit *m_pFL;
	CFeedControl *m_pFC;
	// look ahead pipe

	CInterpolator *m_pInterpolator[NUMOF_AXIS];
	// Interpolator

	CTrajectoryNormal *m_pTrajNormal;
	// trajectory normal

	BOOL m_bTrajStartExecuted;
	// Execute TrajPlanTick
	// ISSUE-5284 added this flag, Avoid different motionplanner issue FUNCID_SingleStepInhibit in different thread.
};
#endif // !defined(_LAMOTIONPLANNER_H____INCLUDED_)
