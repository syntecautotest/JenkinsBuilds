// MpHomeSearch.h: interface for the CMpHomeSearch class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MPHOMESEARCH_H__07678D2F_F6FC_4F1E_BFF0_DFFCC2467A8B__INCLUDED_)
#define AFX_MPHOMESEARCH_H__07678D2F_F6FC_4F1E_BFF0_DFFCC2467A8B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CManualAxis;
class ITransformDesk;

class CMpHomeSearch : public CHomeSearchCore
{
public:
	enum EHomeMethod {
		HM_IndexByDog,				// 0: Homing on the index pulse and index pulse.
		HM_Index,					// 1: Homing on the index pulse without home switch(dog).
		HM_IndexByDogWithPreset,	// 2: Homing on the home switch(dog) and index pulse.
		HM_Dog,						// 3: Homing on the home switch(dog) without index pulse.
		HM_AbsIndex,				// 4: Only for abs-encoder home searching by index pulse.
		HM_AbsIndexByDog,			// 5: Only for abs-encoder home searching by index pulse with home switch(dog).
	};

public:
	CMpHomeSearch( IHomeSearchInfo *pHomeSearchInfo );
	virtual ~CMpHomeSearch();

	void InterpolationTick( void );
	// interpolation time tick.
	// Use threads: interpolation

	DOUBLE getDisplacement( void );
	// get displacement
	// Use threads: interpolation

	void NormalPLCScan( void );
	// Use threads : normal plc scan

	int IsIdle( void );
	// check whether this object is idle, before switch
	// to next task, you must continue call this method
	// at motion planning time tick to make sure this
	// object has finished its task
	// Use threads: motion plan

	int IsHomeFound( void );
	// check whether this object has found and reach home
	// in the last home search process, please call this
	// method only when this object is idle.
	// Use threads: motion plan

	void Start( THomingInfo HomingInfo );
	// start home search process, before call this method.
	// please make sure this object is idle.
	// Use threads: <= motion plan

	void Stop( void );
	// stop home search process, this method will decelerate
	// to stop smoothly.
	// Use threads: <= motion plan

	void setHomeMethod( int method );
	// set home serach method

	int getHomeMethod( void );
	// set home serach method

	double getHomePreset( void );
	// to get home preset value

	void Reset( void );
	// clear internal state suddenly, this function is
	// usually used for emergency stop.
	// Use threads: <= motion plan

	void PutHomeOffset( double offset );
	// set home offset
	// offset		in BLU.
	// Use threads: <= motion plan

	void PutHomeDirection( int direction );
	// set home direction
	// direction	1 for positive direction,
	//				-1 for negative direction.
	// Use threads: <= motion plan

	void PutFeedrateBeforeDog( double feedrate );
	// set feedrate of the first travel( before reach dog )
	// feedrate		in BLU per minute.
	// Use threads: <= motion plan

	void PutFeedrateAfterDog( double feedrate );
	// set feedrate of the second travel( after reach dog )
	// feedrate		in BLU per minute.
	// Use threads: <= motion plan

	void PutDogProtectRev( long revolution );
	// set homing 2nd protect revolution( after reach dog )
	// revolution		in Rev.
	// Use threads: <= motion plan

	void PutOverride( double Override );
	// set feedrate override
	// Override		0%~MAXOVERRIDE%
	// Use threads: <= motion plan

	double getFeedrateBeforeDog( void );
	// get feedrate of the first travel( before reach dog )
	// feedrate		in BLU per minute.
	// Use threads: <= motion plan

	double getFeedrateAfterDog( void );
	// get feedrate of the second travel( after reach dog )
	// feedrate		in BLU per minute.
	// Use threads: <= motion plan

	void GetHomeOffset( double &offset );
	// get home offset

	void EnableHomeGrid();
	// enable home grid function

	void DisableHomeGrid();
	// disable home grid function

	void GetHomeGrid( DOUBLE *HomeGrid );
	// get last home action grid amount
	// HomeGrid		last home action grid amount, in BLU
	// Use threads: <= motion plan

	double ReadHomePosition( void );
	// read	home position, in BLU
	// this function must be used when home idle and
	// home found
	// Use threads: <= interpolation

protected:
	enum EHomingState {
		STATE_Idle,
		STATE_Init,
		STATE_WaitHoming,
		STATE_StopFirstTravel,
		STATE_WaitFirstTravelStop,
		STATE_PrepareSecondTravel,
		STATE_PrepareFinalMovement,
		STATE_WaitMotionCommandComplete,
		STATE_WaitHomeComplete,
		STATE_WaitMotionStop,
	};
	// homing state

protected:
	int m_HomeMethod;
	// home search method

	double m_HomeOffset;
	// home offset, in BLU.

	int m_HomeDirection;
	// home direction, 1 for positive, -1 for negative

	BOOL m_bPresetOffset;
	// direct home offset movement

	double m_FeedrateBeforeDog;
	// first home travel feedrate, in BLU per minute.

	double m_FeedrateAfterDog;
	// second home travel feedrate, in BLU per minute.

	double m_EncoderResolution;
	// counts per encoder revolution

	int m_HomeFound;
	// flags to record whether home found ?

	double m_HomeGrid;
	// measurement home grid distance, in BLU

	double m_MinHomeGrid;
	// minimum allowable home grid distance

	double m_DogPosition;
	// last latched dog position, in BLU

	BOOL m_bLatchDogPosition;
	// enable dog position latch task

	int	m_State;
	// home search state variable

	long m_TA;
	// acceleration time in micro-second

	long m_TS;
	// S-curve acceleration time in micro-second

	CTimeBase m_TimeBase;
	// help object: time base object

	CSCurveTrajectory m_LinearPlan;
	// help object: motion planning object

	CInterpolator m_Interpolator;
	// help object: interpolator object

	CRTMutex m_cs;
	// mutex for object state consistent

	virtual void DoHoming( void );
	// home search finite-state machine
	// Use threads: motion plan

private:
	int m_NextState;
	// home search next state variables

	double	m_HomeReferenceShift;
	// home reference shift in BLU

	int m_fHomeGrid;
	// flag for is home grid function is enabled

	double m_StartPosition;
	// absolute counter value at start postion before home process
	// in BLU

	double m_DistributedSegment;
	// distributed segment length in this travel
	// in BLU.

	double m_DistributedSegmentAcc;
	// total distributed segment length from start of homing process,
	// in BLU.

	BOOL IsOnHomeDog( void );
	// query whether current is above home dog
	// Use threads: <= interpolation

	THomingInfo m_HomingInfo;
	// homing information

// implement failure report
public:
	enum EFailureReason {
		ERROR_NoError,
		ERROR_IndexMiss,
		ERROR_ZeroSpeedTimeout,
		ERROR_LeaveFail,
		ERROR_HomeSignalFail
	};

	int getFailureReason( void );
	// to get failure reason

private:

	int m_nFailureReason;

// implement wait speed zero timeout detection
private:
	void resetZeroSpeedTimeoutCheck( void );
	// to reset zero speed timeout check

	void startZeroSpeedTimeoutCheck( void );
	// to start zero speed timeout check

	BOOL isZeroSpeedTimeout( void );
	// query whether zero speed check has timeout

	void initZeroSpeedTimeoutCheck( void );
	// to initialize  zero speed timeout check

private:

	BOOL m_bZeroSpeedTimeoutCheck;
	LONG m_nZeroSpeedTimer;
	LONG m_nTimeoutOfZeroSpeedCheck;

// implement for index failure check
private:
	double m_TravelStartPosition;
	// the start position for security check, in BLU

	BOOL m_bCheckSensorFailure;
	// the enable flag for check sensor failure

	double m_HomeSignalProtectDisp;
	// the maximum travel BLU for home dog signal failure check

	double m_MaxTravelDisp;
	// the maximum travel BLU for sensor failure check

	long m_DogProtectRev;
	// the maximum travel revolution for sensor failure check

	double m_MaxDogProtectDisp;
	// the maximum protect BLU for sensor can not leave home dog check

	void resetSensorFailureCheck( void );
	// to reset sensor failure check

	void startSensorFailureCheck( void );
	// to start sensor failure check

	BOOL isHomeSignalFailure( void );
	// query whether home dog signal failure

	BOOL isSensorFailure( void );
	// query whether the sensor has failure

	BOOL isLeaveFailure( void );
	// query whether the sensor can not leave home dog
};

#endif // !defined(AFX_MPHOMESEARCH_H__07678D2F_F6FC_4F1E_BFF0_DFFCC2467A8B__INCLUDED_)
