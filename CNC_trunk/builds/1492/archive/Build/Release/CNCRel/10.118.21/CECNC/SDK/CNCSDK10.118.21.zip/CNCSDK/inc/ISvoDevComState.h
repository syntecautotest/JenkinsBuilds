#if !defined(_ISVODEVCOMSTATE_H_INCLUDED_)
#define _ISVODEVCOMSTATE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISvoDevComState
{
public:
	virtual ~ISvoDevComState( void ) {}
	// destructor

	virtual LONG GetSvoDevName( void ) = 0;
	// J5, get servo device name

	virtual LONG GetTypeOfChannel( void ) = 0;
	// J6, get type of channel

	virtual LONG GetIUDecimalPrecision_forMachPos( void ) = 0;
	// J10, get IU Decimal Precision for machine position

	virtual LONG GetIUDecimalPrecision_forProgPos( void ) = 0;
	// J11, get IU Decimal Precision for program position

	virtual DOUBLE GetMachinePosInIU( void ) = 0;
	// J12, get current machine position

	virtual DOUBLE GetFeedbackMotorRotatingVelocity( void ) = 0;
	// J40, get feedback rotating velocity of motor side, in rev/min (RPM)

	virtual DOUBLE GetMotorInertia( void ) = 0;
	// J41, get motor inertia Rotary [kg-m^2], Linear [kg]

	virtual DOUBLE GetRatedTorque( void ) = 0;
	// J42, get rated torque : Rotary [Nm], Linear [N]

	virtual BOOL IsServoOn( void ) = 0;
	// J43, is servo on

	virtual LONG GetEncCompSituation( void ) = 0;
	// J81, Get encoder compensation situation

	virtual BOOL IsEnableEncEccComp( void ) = 0;
	// J82, Is encoder enable eccentric compensation
};

#endif // _ISVODEVCOMSTATE_H_INCLUDED_
