// Matrix4d.h: interface for the CMatrix4d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATRIX3D_H__EF74CBBC_A7F2_4832_8A10_E97CBEB0C88F__INCLUDED_)
#define AFX_MATRIX3D_H__EF74CBBC_A7F2_4832_8A10_E97CBEB0C88F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "nstdlib.h"
#define UTILAPI
class CVector3d;
class CPoint3d;
class CTuple3d;

class UTILAPI CMatrix3d  
{
public:
	CMatrix3d();
	// Constructs and initializes a Matrix4d to all zeros.

	CMatrix3d( CMatrix3d &m );
	// constructs and initializes matrix from another matrix

	virtual ~CMatrix3d();
	// destructor

	double getElement( int row, int column );
	// get the specified element value

	void mul( CMatrix3d &m );
	// Sets the value of this matrix to the result of multiplying
	// itself with matrix m.

	void mul( CMatrix3d &m1, CMatrix3d &m2 );
	// Sets the value of this matrix to the result of multiplying
	// the two argument matrices together.

	void set( CMatrix3d &m );
	// Sets the value of this matrix to a copy of the passed matrix m

	void set( double a[] );
	// Sets the value of this matrix to form specified 1-dimensional array
	// the data sequence is a11, a12, a13, a14, a21, a22, .., a41, a42, a43, a44.
	// the translation vector is (a14,a24,a34)

	void set( CVector3d &v1, CVector3d &v2, CVector3d &v3 );
	// v1, v2, v3 be column vector of this matrix

	void set( int ntype, double angle );
	// type = 1, rotate matrix around x axis
	// type = 2, rotate matrix around y axis
	// type = 3, rotate matrix around z axis
	// unit : radius

	void set( CVector3d &v, double angle );
	// rotate matrix around the vector v
	// unit : radius

	void setPDiffwrtAngle( CVector3d &v, DOUBLE angle );
	// rotate matrix around the vector v, partial differentiated with respect to angle
	// unit : radius

	void get( CMatrix3d &m );
	// Getts the value of this matrix into specified matrix

	void get( double a[] );
	// Gets the value of this matrix into specified 1-dimensional array
	// the data sequence is a11, a12, a13, a14, a21, a22, .., a41, a42, a43, a44.
	// the translation vector is (a14,a24,a34)

	void setElement( int row, int column, double value );
	// set element value;

	void setZero( void );
	// Sets this matrix to all zeros.

	void setIdentity( void );
	// Sets this Matrix4d to identity.

	void transform( CTuple3d &vec );
	// Transforms the vec tuple with this Matrix3d and places
	// the result back into vec.

	void transform( CTuple3d &vec, CTuple3d &vecOut );
	// Transforms the vec tuple with this Matrix3d and places
	// the result into ptOut.

	void transform( CPoint3d &pt );
	// Transforms the pt point with this Matrix3d and places
	// the result back into pt.

	void transform( CPoint3d &pt, CPoint3d &ptOut );
	// Transforms the pt point with this Matrix3d and places
	// the result into ptOut.

	void transform( CVector3d &normal );
	// Transforms the normal vector with this Matrix4d and places
	// the result back into normal.

	void transform( CVector3d &normal, CVector3d &normalOut );
	// Transforms the normal vector with this Matrix4d and places
	// the result into ptOut.

	void invert( CMatrix3d &m );
	// Inverts matrix m and places the new values into this matrix

	void transpose( CMatrix3d &m );
	// Transport matrix m and places the new values into this matrix
	
private:

	enum EMaxBound {
		MATDIM = 3
	};

	// private data member
	double m_matrix[MATDIM][MATDIM];

private:

	int LUD( double LU[MATDIM][MATDIM], double permutation[MATDIM] );
	// LU Decomposition; this matrix must be a square matrix; the LU matrix
	// parameter must be the same size as this matrix

	static void LUDBackSolve( double x[MATDIM], double LU[MATDIM][MATDIM], double b[MATDIM], double permutation[MATDIM] );
	// LU Decomposition Back Solve; this method takes the LU matrix and the
	// permutation vector produced by the GMatrix method LUD and solves the
	// equation (LU)*x = b by placing the solution vector x into this vector

	static int ludcmp(double a[MATDIM][MATDIM], int *indx, double *d);
	// Given a matrix a[1..3][1..3], this routine replaces it by the LU
	// decomposition of rowwise permutation of itself.
	// a and n are input. The matrix a will be overwritten as the combination
	// of a lower diagonal and upper diagonal matrix decompostion of this
	// matrix; the diagonal elements of L (unity) are not stored, the layout
	// as following:
	//							b11	b12 b13
	//							a21 b22 b23
	//							a31 a32 b33
	// indx[1..3] is an output vector that records the row permutation
	// effected by the partial pivoting;
	// d is output as 1/-1 depending one whether the number of row
	// interchanges was even or odd, respectively.

	static void lubksb(double a[MATDIM][MATDIM], int *indx, double b[MATDIM]);
	// Solve the set of n linear equation A.X = B.
	// a[1..3][1..3] is input, not as the matrix A but rather as its LU
	// decomposition.
	// indx[1..3] is input as the permutation vector.
	// b[1..3] is input as the right-hand side vector B, and return with
	// the solution vector X.
	// a,indx are not modified by this routine and can be left in place
	// for successive calls with different right-hand sides b.
	// This routine takes into account the possibility that b will begin
	// with many zero elements, so it is efficient for use in matrix
	// inversion.
	
	static const double LUD_Tiny;
	// a small number for LU decomposition
};

#endif // !defined(AFX_MATRIX3D_H__EF74CBBC_A7F2_4832_8A10_E97CBEB0C88F__INCLUDED_)
