#if !defined(_SVODEVSTATEDEF_H_INCLUDED_)
#define _SVODEVSTATEDEF_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// 1~200 for common state variable
#define SvoDev_VAR_NAME_ID						( 5 )	// ID of axis name
#define SvoDev_VAR_CHANNEL_TYPE					( 6 )	// channel type
#define SvoDev_VAR_IUDecimalPrecisionMachPos	( 10 )	// IU Decimal precision for machine position
#define SvoDev_VAR_IUDecimalPrecisionProgPos	( 11 )	// IU Decimal precision for program position
#define SvoDev_VAR_MachinePosition				( 12 )	// machine position (LIU)
#define SvoDev_VAR_IsServoOn					( 39 )	// is servo on
#define SvoDev_VAR_MOTOR_ROTATING_VEL			( 40 )	// feedback rotating velocity of motor side, in rev/min (RPM)
#define SvoDev_VAR_MotorInerita					( 41 )	// motor inertia( rotaty: kg-m^2, linear: kg )
#define SvoDev_VAR_RatedTorque					( 42 )	// rated torque( rotary: N-m, linear: N )
#define SvoDev_VAR_EncCompSituation				( 81 )	// Encoder compensation situation
#define SvoDev_VAR_EncEccCompEnable				( 82 )	// Encoder eccentric compensation enable
#define SvoDev_VAR_MAX_No						( 200 )	// max common state number

// 201~ state variable for each device
// Axis State variable
#define AX_VAR_FricComp_Method					( 201 )	// glitch compensation method(Pr2921~)
#define AX_VAR_IsDrvSupportTFF					( 202 )	// is driver support TFF function
#define AX_VAR_TFFGlitchCompLStatus				( 203 )	// TFF Glitch compensator learning status
#define AX_VAR_IsDrvSupportVFF					( 265 )	// is driver support VFF function
#define AX_VAR_PCOMP_SPACE						( 266 )	// pitch error compensation space (IU)
#define AX_VAR_PCOMP_HOMEIDX					( 267 )	// pitch error compensation origin no.
#define AX_VAR_IS_INVISIBLE						( 268 )	// is axis invisible
#define AX_VAR_AXIS_HOMING_STATE				( 269 )	// return the homing state of axis
// 271, 272 reserved

#endif // _SVODEVSTATEDEF_H_INCLUDED_