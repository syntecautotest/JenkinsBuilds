#if !defined(_ROBOTINTERPOLATIONDEF_H____INCLUDED_)
#define _ROBOTINTERPOLATIONDEF_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_INTERPOLATION_BUCKET		( 5 )	// define max number of buckets for segment storage
												// 4 buckets for interpolation across two blocks ( Cur + Ovl )
												// 1 bucket for joint compensation
												// total = 4 + 1 = 5

#define NUMOF_MOVL_CHCNT_QUAT			( 4 )
#define NUMOF_MOVL_CHCNT_LINEAR			( 6 )

struct TRobotSegmentNode {
	double						MoveTime;
	CCJerkHelicalInt::TCtlBlk	CtlBlk;
};

struct TIntBuffer {
	double				SegmentRemainTime;
	double				SegmentMoveTime;
	double				NowTimeCursor; // for debug

	struct {
		double			LocalLen;				// records local current accumulated length
		double			LocalStart[ 2 ];
		double			LocalCenter[ 2 ];
		double			LocalEnd[ 2 ];			// records local points to describe the arc
		double			Length;
		double			ArcAngle;				// records the MOVC arc length and angle
		double			LastLocalMovcAX[ 2 ];	// records the last Local MovcAX
		CMatrixN		CoordFrame;				// stores each MOVC coord frame
		CMatrixN		LocalVec;				// stores each MOVC local movement vector
		CMatrixN		WorldVec;				// stores each MOVC world movement vector
	}Movc;

	CCJerkHelicalInt	awt;
};

struct TInterpolationBlock {
	int					nNextIndex;							// records the index of SegmentNode while interpolation
	int					nCount;								// records how many segemnts in one block
	double				NodeTime;							// records move time of the block
	double				RotAngleAccumlator;					// records accumulated rotation angle of the block while interpolation; unit:deg
	double				NowTimeCursor;						// records time cursor in the block
	TRobotSegmentNode	SegmentNode[ MAX_NumOfPVTSegment ];	// records SegmentNodes of the block
	TIntBuffer			*pIntBuffer;
};

struct TRobotMicroCode {
	int								ClassID;
	int								Opcode;
	union {
		// MOTOP
		struct {
			void					*pMotionHandler;
			double					duration;

			// Normal
			struct {
				long				Flags;								// working flag
				BOOL				bJointCompensationInhibit;			// joint compensation inhibit, MOVC mid point and during CVT is true, others are false

				double				StartJointPos[ NUMOF_ROBOT_AXIS ];	// joint position at the beginning of the block
				TTrajDisp			IntDisp;							// internal displacement
				TTrajDisp			ExtDisp;							// external displacement
				TTrajDisp			RemainIntDisp;						// remain internal displacement
				TTrajDisp			RemainExtDisp;						// remain external displacement
				double				MOVC_GeomLen;						// MOVC arc length (XYZ)
				double				OverlapStartTime[ 2 ];				// overlapping start time

				TQuaternionInfo		QInfo;								// rotation quaternion
				TQuaternionInfo		StartQInfo;							// start quaternion
				TWaitSigInfo		OvlWaitSigInfo;						// SWAITSIG: robot wait signal info. for overlapping next block or not
				TIOFcnLink			IOFcnLink;			// IO related function pointers
			};

			TInterpolationBlock		IntBlock;
		};

		// FUNCCALL
		struct {
			int					nExecute;
			union {
				// [case(FUNCID_PacketInfo)]
				TPacketInfo		PacketInfo;

				// [default]
				long			lParam[ IFuncCallHandler::MAX_NumOfArg ];
			};
		};
	};
};

// defines robot interpolation type for orientation
enum EInterpolationType {
	EINT_TYPE_LINEAR = 0,
	EINT_TYPE_QUATERNION = 1,
};

// motion segment storage comprise internal and external displacement for DispBucket
// !! internal trajspace also indicates which motion mode contributes the displacement !!
struct TMotionDisp {
	TTrajDisp IntDisp;				// ( internal )robot displacement storage
	TTrajDisp ExtDisp;				// ( external )external axes displacement storage
};

// store motion segment for forward/inverse transform
struct TOneTickDisp {
	// Joint displacement
	BOOL	fDispMovJ_Joint;					// flag of MoveJ Joint space movement existence
	DOUBLE	DispMovJ_Joint[ NUMOF_AXIS ];		// in IU, Joint space disp contributed by MOVJ

	BOOL	fDispMovL_Joint;					// flag of MoveL Joint space movement existence
	DOUBLE	DispMovL_Joint[ NUMOF_AXIS ];		// in IU, Joint space disp contributed by MOVL
	
	// Cartesian displacement
	BOOL	fDispMovL_Cartesian;				// flag of MoveL Catesian space movement existence
	DOUBLE	DispMovL_Cartesian[ NUMOF_AXIS ];	// in IU, Cartesian space disp contributed by MOVL ( dx, dy, dz...etc. )
};

#endif // !defined(_ROBOTINTERPOLATIONDEF_H____INCLUDED_)
