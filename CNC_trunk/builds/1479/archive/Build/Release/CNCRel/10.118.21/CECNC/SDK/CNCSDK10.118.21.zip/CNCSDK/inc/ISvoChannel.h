// ISvoChannel.h: interface for the ISvoChannel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISVOCHANNEL_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_)
#define AFX_ISVOCHANNEL_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"
#include "ISerialParamChannel.h"
#include "SvoUtilityDef.h"

// notification constant
#define MCINOTIFY_EStopON			1
#define MCINOTIFY_EStopOFF			2

// loss pulse check latency time, 1 second
#define TIME_LossPulseCheck			1000000L

// number of debug data for SYNTEC spindle
#define NUMOF_DEBUGDATA_SYNTEC_SPINDLE			16

// CNC SvoDriver interface IOCTL code
// syntax:
// #define IOCTL_SVODRIVER_FunctionName				0x00000001

// CNC SvoChannel interface IOCTL code
#define IOCTL_SVOCHANNEL_IsSpdOrientationed			0x00000002
#define IOCTL_SVOCHANNEL_IsVelocityReadched			0x00000003
#define IOCTL_SVOCHANNEL_IsCommReady				0x00000004
#define IOCTL_SVOCHANNEL_IsPowerOn					0x00000005
#define IOCTL_SVOCHANNEL_DoSpdOrientation			0x00000006
#define IOCTL_SVOCHANNEL_IsSupportDriverSOS			0x00000007
#define IOCTL_SVOCHANNEL_IsSupportCruise			0x00000008
#define IOCTL_SVOCHANNEL_SetCruiseData				0x00000009
#define IOCTL_SVOCHANNEL_IsCruisePositionReach		0x0000000A
#define IOCTL_SVOCHANNEL_GetCommErrorCount			0x0000000B
#define IOCTL_SVOCHANNEL_ClearMultiTurnAbsEncoder	0x0000000C
#define IOCTL_SVOCHANNEL_IsSyntecDriver				0x0000000D

// Serial device information
#define IOCTL_SVOCHANNEL_ExistNonSyntecPackageMotor				0x0000001A
#define IOCTL_SVOCHANNEL_CheckNonSyntecPackageParamRestore		0x0000001B

#define IOCTL_SVOCHANNEL_clearErrorCounter			0x00000050

// ==serial param function==
#define IOCTL_PARAM_GET_CAPACITY					0x00000021
#define IOCTL_PARAM_DUMP							0x00000022
#define IOCTL_PARAM_GET_VALUE						0x00000023
#define IOCTL_PARAM_PUT_VALUE						0x00000024
#define IOCTL_PARAM_GET_STATUS						0x00000025
#define IOCTL_PARAM_IS_READY						0x00000026
#define IOCTL_PARAM_AX_INTERFACE					0x00000027
#define IOCTL_PARAM_SPD_INTERFACE					0x00000028
#define IOCTL_PARAM_SET_LISTENER					0x00000029
#define IOCTL_PARAM_INIT							0x00000030
#define IOCTL_PARAM_GET_INIT_STATUS					0x00000031
#define IOCTL_PARAM_RELOAD_VALUE					0x00000032
#define IOCTL_PARAM_MEMORY_SAVE						0x00000033
#define IOCTL_PARAM_SAVE_RESULT						0x00000034
#define IOCTL_PARAM_GET_ACTIVE_ENC					0x00000035
#define IOCTL_PARAM_GET_RESOLUTION					0x00000036
#define IOCTL_PARAM_SUPPORT_INIT					0x00000037
#define IOCTL_PARAM_RESTORE_START					0x00000038
#define IOCTL_PARAM_RESTORE_END						0x00000039
#define IOCTL_PARAM_DRVPARAMSYNC_INTERFACE			0x0000003A
#define IOCTL_PARAM_NEED_MEMORY_SAVE				0x0000003B

// ==torque/velocity related function==
#define IOCTL_SVOCHANNEL_ISSUPPORT_TLIM				0x00000040
#define IOCTL_SVOCHANNEL_ISSUPPORT_TFF				0x00000041
#define IOCTL_SVOCHANNEL_GET_MOTORINFO				0x00000043
#define IOCTL_SVOCHANNEL_ISSUPPORT_VFF				0x00000044

#define IOCTL_STATE_VAR_SUPPORT						0x00000051
#define IOCTL_STATE_VAR_GET_CAPACITY				0x00000052
#define IOCTL_STATE_VAR_DUMP						0x00000053
#define IOCTL_STATE_VAR_GET_VALUE					0x00000054
#define IOCTL_STATE_VAR_RELOAD_VALUE				0x00000055
#define IOCTL_STATE_VAR_RELOAD_FINISH				0x00000056

// ==bode plot and resonance suppression function==
#define IOCTL_BODE_GetBodeFrequency					0x00000060
#define IOCTL_BODE_GetNotchFilterData				0x00000061
#define IOCTL_BODE_SetNotchFilterData				0x00000062
#define IOCTL_BODE_AdjustVelChirpSignal				0x00000063

// ==driver control paramter function==
#define IOCTL_SVOCHANNEL_GetCtrlParamNum			0x00000070
#define IOCTL_SVOCHANNEL_GetCtrlParamMask			0x00000071
#define IOCTL_SVOCHANNEL_PutCtrlParam				0x00000072
#define IOCTL_SVOCHANNEL_SwitchCtrlParam			0x00000073

// ==syntec vendor function==
#define IOCTL_SVOCHANNEL_ISSUPPORT_POWEROFFPULLUP	0x00000080
#define IOCTL_SVOCHANNEL_INHIBIT_POWEROFFPULLUP		0x00000081
#define IOCTL_SVOCHANNEL_ISSUPPORT_POWEROFFRETURN	0x00000082
#define IOCTL_SVOCHANNEL_SETPOWEROFFRETURN			0x00000083

// ==fractional delay compensation
#define IOCTL_SVOCHANNEL_GetDrvCommDelay			0x00000090

// == syntec encoder update==
#define IOCTL_ENCUPDATE_IsEncInfoReady				0x00000100
#define IOCTL_ENCUPDATE_GetEncInfo					0x00000101
#define IOCTL_ENCUPDATE_StartUpdate					0x00000102
#define IOCTL_ENCUPDATE_GetResult					0x00000103

// ==Encoder Tuning function==
#define IOCTL_SVOCHANNEL_GetEncCompSituation		0x00000120
#define IOCTL_SVOCHANNEL_EnableEncEccComp			0x00000121
#define IOCTL_SVOCHANNEL_GetEncInfo					0x00000122

enum EDriverEncoderType {
	EET_NotDefine = -1,
	EET_Inc = 0,
	EET_Abs,
	EET_Num,
};

enum EProtocolType {
	EPTYPE_NOT_SUPPORT = 0,
	EPTYPE_M2 = 1,
	EPTYPE_M3 = 2,
	EPTYPE_ECAT = 3,
	EPTYPE_RTEX = 4,
	EPTYPE_CNC2 = 5,
};

enum ESvoIOSignal {
	ESIO_T_LIM = 1,
	ESIO_EXT1,
	ESIO_BRK_ON,
};

enum EClearMultiTurnAbsEncResult {
	EMTAE_NOT_SUPPORT = 0,
	EMTAE_NOT_SV_OFF,
	EMTAE_SUCCESS,
};

// do spindle orientation
struct TSVOCHANNEL_DoSpdOrientation {
	long nTargetPos;	// in
	long nTargetVel;	// in
	long nMotorGear;	// in
	long nScrewGear;	// in
};

// ==serial param structure==

// param get capacity
struct TPARAM_GET_CAPACITY
{
	long nLength;	// out
};

// param dump
struct TPARAM_DUMP
{
	LONG nLength;		// in
	BOOL bParamNoHex;	// out
	void *pBuffer;		// out
	INT nStatus;		// out
};

// param get value
struct TPARAM_GET_VALUE
{
	DWORD nNo;			// in
	INT nStatus;		// out
	TOcVariant Value;	// out
};

// param put value
struct TPARAM_PUT_VALUE
{
	DWORD nNo;				// in
	BOOL isParamRestore;	// in
	TOcVariant Value;		// in
	BOOL isParamSave;		// in
	INT nStatus;			// out
};

// param reload value
struct TPARAM_RELOAD_VALUE {
	DWORD nNo;		// in
	int nStatus;	// out
};

// param status
struct TPARAM_GET_STATUS
{
	WORD nNo;		// in
	int nStatus;	// out
};

// param is ready
struct TPARAM_IS_READY
{
	BOOL bReady;	// out
};

// axis param interface
struct TPARAM_AX_INTERFACE
{
	void *pInterface;	// in
};

// driver param sync interface
struct TPARAM_DRVPARAMSYNC_INTERFACE
{
	void *pInterface;	// in
};

// spindle param interface
struct TPARAM_SPD_INTERFACE
{
	void *pInterface;	// in
};

// spindle param interface
struct TPARAM_SET_LISTENER
{
	void *pListener;	// in
};

// get param init status
struct TPARAM_GET_INIT_STATUS
{
	int nStatus;
};

// get active encoder type
struct TPARAM_GET_ACTIVE_ENC
{
	BOOL isAbsolute;
};

// get bode plot frequency
struct TPARAM_GET_BODE_FREQ
{
	LONG nBodeFreq;		// out
};

// get notch filter data
struct TPARAM_GET_NOTCH_DATA
{
	int nFilterID;		// in
	BOOL bParamExist;	// out
	void *pFilterData;	// out
};

// set notch filter data
struct TPARAM_SET_NOTCH_DATA
{
	int nFilterID;		// in
	BOOL bParamExist;	// out
	void *pFilterData;	// in
};

// set velocity chirp signal
struct TPARAM_SET_VEL_CHIRP
{
	LONG nStartFreq;	// in
	LONG nEndFreq;		// in
	LONG nDuringTime;	// in
	LONG nMagnitude;	// in
};

// state variables support
struct TSTATEVAR_GET_SUPPORT
{
	BOOL	bSuccess;	// out
};

// state variables get capacity
struct TSTATEVAR_GET_CAPACITY
{
	BOOL	bSuccess;	// out
	LONG	nLength;	// out
};

// state variables dump
struct TSTATEVAR_DUMP
{
	LONG	nLength;		// in

	BOOL	bSuccess;		// out
	INT		nStatus;		// out
	BOOL	bParamNoHex;	// out
	void	*pBuffer;		// out
};

// state variables get value
struct TSTATEVAR_GET_VALUE
{
	LONG		nLength;	// in

	BOOL		bSuccess;	// out
	INT			nStatus;	// out
	TOcVariant	*pValue;	// out
};

// state variables reload
struct TSTATEVAR_RELOAD_VALUE
{
	BOOL	bSuccess;	// out
};

// state variables reload finish or not
struct TSTATEVAR_RELOAD_FINISH
{
	BOOL	bSuccess;	// out
	BOOL	bFinish;	// out
};

//  Prototype delcaration
class ISvoDriver;
class IServoLink;
class ISerialPLCChannel;
class IMPGChannel;
class ILaserChannel;
class ITuningChannel;
class IGalvoChannel;
class ISerialParamChannel;
class ISerialDAQChannel;

#ifndef TDRIVEROBJECT_DEFINE
#define TDRIVEROBJECT_DEFINE 1

struct TDriverObject {
	HINSTANCE		m_hModule;			// module handle of this driver

	void (PFNCNCAPI *DriverUnload)( TDriverObject *pDriverObject );
	// driver unload function, this function will be called when specified
	// driver been unload.

	DWORD			m_DriverData[10];	// private storage for driver usage
};
// data structure for device driver

typedef BOOL (PFNCNCAPI *TPFNDriverLoad)( TDriverObject *pDriverObject, char *RegistryPath );
// typedef for DriverLoad entry point
// Note: the DriverLoad entry ordinal number should be @1

#endif // TDRIVEROBJECT_DEFINE

#ifndef TSENSORTYPE_ENUM_
#define TSENSORTYPE_ENUM_
enum EEncoderType {
	SENSORTYPE_IncEncoder,
	SENSORTYPE_Ruler,
	SENSORTYPE_Null,
	SENSORTYPE_AbsoluteEncoder
};
#endif // TSENSORTYPE_ENUM_


class ISvoChannel
{
public:
	enum EOpMode {
		OPMODE_Position,
		OPMODE_Velocity,
		OPMODE_Torque,
		OPMODE_Tracking,
		OPMODE_SpdOrientation,
		OPMODE_Posing,
		OPMODE_HOLD,
		OPMODE_ServoOn,
		OPMODE_Cruise,
		OPMODE_PowerOffReturn,
	};
	// operation mode

	enum ESoftLoopingLevel {
		SLL_Position,
		SLL_Velocity,
		SLL_Torque,
	};
	// software looping level

	enum EInterfaceType {
		INTERFACE_Voltage,
		INTERFACE_CWCCW,
		INTERFACE_PulseDir,
		INTERFACE_Sercos
	};
	// interface type

	enum EDataAccessStatus
	{
		STATUS_NoOperation = -1,
		STATUS_Fail = 0,
		STATUS_Success,
		STATUS_Busy,
		STATUS_NotSuuport,
	};
	// servo data access status

	enum EChannelType {
		CHTPYE_General = 0,
		CHTPYE_DELTA_Flexray = 1,
		// for M2 device
		CHTPYE_YASKAWA_M2_Sigma5 = 21,
		CHTPYE_SYNTEC_M2 = 22,
		CHTPYE_YASKAWA_M2_Sigma7 = 23,
		CHTPYE_CTB_M2 = 24,
		CHTPYE_YASKAWA_M2_SigmaM = 25,
		CHTPYE_YASKAWA_M2_Sigma7S_FT20 = 26,
		CHTPYE_SYNTEC_3rd_PARTY_M2 = 27,
		CHTPYE_SYNTEC_M2_V2 = 28,
		// for M3 device
		CHTPYE_YASKAWA_M3_Sigma5 = 31,
		CHTPYE_SYNTEC_M3 = 32,
		CHTPYE_YASKAWA_M3_Sigma7S = 33,
		CHTPYE_YASKAWA_M3_Sigma7W = 34,
		CHTPYE_YASKAWA_M3_SigmaM = 35,
		CHTPYE_YASKAWA_M3_Sigma7S_FT20 = 36,
		CHTPYE_SYNTEC_3rd_PARTY_M3 = 37,
		// for ECAT device
		CHTYPE_DELTA_ECAT_ASDA_A2_E = 51,
		CHTYPE_PANASONIC_ECAT_MINAS_A5B = 52,
		CHTYPE_PANASONIC_ECAT_MINAS_A6B = 53,
		CHTYPE_SERVOTRONIX_ECAT_CDHD = 54,
		CHTYPE_MITSUBISHI_ECAT_J4 = 55,
		CHTYPE_INVENTOR_ECAT_DA200 = 56,
		CHTYPE_INOVANCE_ECAT_IS620N = 57,
		// for RTEX device
		CHTYPE_PANASONIC_RTEX_MINAS_A6N = 81,
		// for CNC2 device
		CHTPYE_SYNTEC_CNC2_Galvo = 91,
		// for not defined serial servo
		CHTPYE_Not_Defined = 99
	};

	enum EAlarmWarnigType {
		TYPE_NONE = 0,
		TYPE_ALARM = 1,
		TYPE_WARNING = 2,
	};

public:
	virtual ~ISvoChannel( void ) {}
	// destructor

	virtual void CNCAPI PutDMR( long data ) = 0;
	// To set the decoding factor of encoder.
	// Selection: x1, x2, x4.

	virtual void CNCAPI PutCMR( long multiplier, long divisor ) = 0;
	// set pulse command mutiply ratio

	virtual void CNCAPI PutEncoderResolution( long data ) = 0;
	// To set the resolution of encoder with DMR
	// Unit: pulses per revolution.

	virtual void CNCAPI PutEncoderType( int type ) = 0;
	// To set the type of encoder

	virtual void CNCAPI PutControlType( int type ) = 0;
	// put position loop control type

	virtual void CNCAPI PutProportionalGain( long nGain ) = 0;
	// set position proportional gain, in micro-voltage/pulse
	
	virtual void CNCAPI PutDifferentialGain( long nGain ) = 0;
	// set DDA voltage skew, in voltage per second

	virtual void CNCAPI setLossPulseWindow(long window) = 0;
	// set loss pulse window in pulse counts
	
	virtual void CNCAPI SetOpMode( int mode ) = 0;
	// set operation mode

	virtual void CNCAPI PutPositionCommand( long pulse ) = 0;
	// put position command
	// unit: counts, same as encoder resolution with DMR

	virtual void CNCAPI PutVelocityCommand( long MicroVolt ) = 0;
	// put velocity command
	// unit: 0.001 RPM

	virtual void CNCAPI PutTorqueCommand( long RatedTRQ ) = 0;
	// put torque command in 0.01% rated torque

	virtual void CNCAPI PutTorqueLimit( long RatedTRQLimit ) = 0;
	// put torque limit in 0.01% rated torque

	virtual void CNCAPI PutTorqueFeedforward( long nTRQFeedforward ) = 0;
	// put torque feedforward in 0.01% rated torque

	virtual void CNCAPI PutVelocityFeedforward( double VelFeedforward ) = 0;
	// put velocity feedforward in rev/s

	virtual void CNCAPI PutVToRPMGain( long gain ) = 0;
	// set voltage to RPM conversion factor
	// unit: RPM per voltage
	
	virtual void CNCAPI SetServoOn( BOOL bOn ) = 0;
	// set servo ON/OFF

	virtual BOOL CNCAPI IsServoOn( void ) = 0;
	// query servo on states

	virtual BOOL CNCAPI GetServoIOSignal( int nIOSignal ) = 0;
	// get servo IO signal

	virtual long CNCAPI ReadPositionError( void ) = 0;
	// read position loop error counts

	virtual long CNCAPI ReadRealPosition( void ) = 0;
	// read absolute counter

	virtual void CNCAPI SetRealPosition( long position ) = 0;
	// set absolute counter

	virtual INT CNCAPI GetNumOfLatchFunction( void ) = 0;
	// get number of latch function

	virtual BOOL CNCAPI StartSignalCapture( INT nSelect, ELatchSource nLatchSource, EEventMode nEventMode = EEM_Trigger ) = 0;
	// start signal position capture

	virtual BOOL CNCAPI IsSignalCaptured( INT nSelect, ELatchSource nLatchSource ) = 0;
	// check whether signal has been latched?

	virtual void CNCAPI ResetSignalCapture( INT nSelect ) = 0;
	// reset signal position capture

	virtual long CNCAPI ReadSignalPosition( INT nSelect, ELatchSource nLatchSource ) = 0;
	// read index position

	virtual long CNCAPI ReadSignalLatchedCount( INT nSelect, ELatchSource nLatchSource ) = 0;
	// read index latched count

	virtual long CNCAPI ReadTorqueLoad( void ) = 0;
	// read torque load in 0.01% rated torque

	virtual long CNCAPI ReadDACommand( void ) = 0;
	// read DA command value, in mini-voltage

	virtual long CNCAPI ReadDeviceDebugData( int nIndex ) = 0;
	// read device debug data
	
	virtual long CNCAPI ReadAlarmFlags( void ) = 0;
	// read alarm flags

	virtual void CNCAPI RefreshAlarmFlags( void ) = 0;
	// clear all unpending alarm

	virtual int CNCAPI ReadHomeSensorState( void ) = 0;
	// read home sensor status

	virtual long CNCAPI clearQueuedCommand( void ) = 0;
	// clear command in waiting queue
	// return the canceled command count

	virtual int CNCAPI GetNumOfQueuedCommand( void ) = 0;
	// get number for queued command, including driver and hardware

	virtual void CNCAPI setPulseOutMode( int nMode ) = 0;
	// to select pluse output mode

	virtual int CNCAPI ReadServoData( WORD index, BYTE sub_index, long *value, BYTE* data_len, DWORD* cookie = NULL ) = 0;
	// read servo data from encoder

	virtual int CNCAPI WriteServoData( WORD index, BYTE sub_index, long value, BYTE data_len, DWORD* cookie = NULL ) = 0;
	// write servo data to encoder

	virtual BOOL CNCAPI AbortServoDataAccess( DWORD* cookie ) = 0;
	// abort servo data read/write access
	
	virtual int CNCAPI TypeOfChannel( void ) = 0;
	// get type of channel

	virtual BOOL CNCAPI CNCDeviceIoControl( ULONG dwIoControlCode, void *lpArgBuf, UINT nArgBufSize ) = 0;
	// Device IO control, OCDevice interface

	virtual long CNCAPI GetWarningID( void ) = 0;
	// get warning id

	virtual void CNCAPI SyncSyntecSOSOffset( LONG nOffset ) = 0;
	// synchronize syntec s.o.s offset to drv.
};

#endif // !defined(AFX_ISVOCHANNEL_H__CA0342CD_B3AB_40D5_9334_AA449B421912__INCLUDED_)
