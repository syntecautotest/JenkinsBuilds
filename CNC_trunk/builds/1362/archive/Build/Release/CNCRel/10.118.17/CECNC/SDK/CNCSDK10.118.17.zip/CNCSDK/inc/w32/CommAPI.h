// CommAPI.h: interface for the communication API.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_COMMAPI_INCLUDED_)
#define _COMMAPI_INCLUDED_

#include "nstdlib.h"

#ifdef __cplusplus
extern "C" {
#endif

extern HANDLE CNCAPI CreateComm(
	LPCTSTR lpFileName		// pointer to name of the file
);
// open comm device
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

extern BOOL CNCAPI CloseComm(
	HANDLE hFile			// handle to communications device
);
// close comm device
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

extern BOOL CNCAPI WriteComm(
	HANDLE hFile,					// handle to communications device
	LPCVOID lpBuffer,				// pointer to data to write to file
	DWORD nNumberOfBytesToWrite,	// number of bytes to write
	LPDWORD lpNumberOfBytesWritten	// pointer to number of bytes written
);
// writes data to the communication device.
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

extern BOOL CNCAPI ReadComm(
	HANDLE hFile,					// handle to communications device
	LPVOID lpBuffer,				// pointer to buffer that receives data
	DWORD nNumberOfBytesToRead,		// number of bytes to read
	LPDWORD lpNumberOfByteRead		// pointer to number of bytes read
);
// read data from the communication device.
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

#ifdef __cplusplus
}
#endif 

#endif // !defined(_COMMAPI_INCLUDED_)
