// StringConverter.h: interface for the CStringConverter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_STRINGCONVERTER_H_)
#define _STRINGCONVERTER_H_

class CStringConverter
{
public:
	static LONG tstol( const TCHAR* tstring );
	// tstring to long

	static DOUBLE tstod( const TCHAR* tstring );
	// tstring to double

	static LONG tstol_hex( const TCHAR* tstring );
	// hex tstring to long

	static LONG stol( const CHAR *string );
	// string to long

	static LONG stol_hex( const CHAR *string );
	// hex string to long

	static void toLower( CHAR *string );
	// convert string to lower case

	static void toUpper( CHAR *string );
	// convert string to upper case
};

#endif // !defined(_STRINGCONVERTER_H_)
