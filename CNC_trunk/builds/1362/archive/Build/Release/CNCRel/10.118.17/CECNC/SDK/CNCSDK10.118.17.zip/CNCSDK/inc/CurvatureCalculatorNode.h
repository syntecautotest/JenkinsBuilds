// CurvatureCalculatorNode.h: interface for the CCurvatureCalculatorNode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_CURVATURECALCULATORNODE_H____INCLUDED_)
#define _CURVATURECALCULATORNODE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCurvatureCalculatorNode : public CKickNode
{
public:
	CCurvatureCalculatorNode(void);
	// constructor

	~CCurvatureCalculatorNode(void);
	// destructor

	void set( CCurvatureCalculatorNode &node );
	// set curvature calculator node

	void set( CKickNode &node, int &nNumOfContainedNodes, double Fclamp );
	// set curvature calculator node

	void set( CKickNode &node, double Length, int &nNumOfContainedNodes, double Fclamp );
	// set curvature calculator node

public:
	double m_Length;
	// vector length

	int m_nNumOfContainedNodes;
	// number of contained nodes

	double m_Fclamp;
	// maximum clamping feedrate in this CCNode
};

#endif // !defined(_CURVATURECALCULATORNODE_H____INCLUDED_)
