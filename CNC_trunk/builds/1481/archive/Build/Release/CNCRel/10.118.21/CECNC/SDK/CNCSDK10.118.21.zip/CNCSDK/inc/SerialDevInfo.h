// SerialDevInfo.h: interface for the CSerialDevInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERIALDEVINFO_H__9F91C651_85A4_4a2d_936B_12F09D896853__INCLUDED_)
#define AFX_SERIALDEVINFO_H__9F91C651_85A4_4a2d_936B_12F09D896853__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define Size_DeviceInfoStrData		( 32 )
#define Size_DeviceInfoStr			( Size_DeviceInfoStrData + 1 ) // data + '\0'
#define NUM_OF_ECAT_DeviceInfo		( EDI_ECAT_ProductCode - EDI_ECAT_VendorID + 1 )

class CSerialDevInfo
{
public:
	// construction
	CSerialDevInfo( void );

	// destruction
	~CSerialDevInfo( void );

	// put device info data by using long
	void PutDeviceInfo( EDeviceInfo eInfoType, LONG nInfoData );

	// put device info data by using char
	void PutDeviceInfo( EDeviceInfo eInfoType, CHAR *pInfoStr, LONG nSize );

	// get device info string data
	BOOL GetDeviceInfo( EDeviceInfo eInfoType, CHAR *pInfoStr, LONG nSize );

	// get ethercat device info: vendor id, device type, product code
	LONG GetECATDeviceInfo( EDeviceInfo eInfoType );

private:
	// storage of device info in string
	CHAR m_szDeviceInfo[ EDI_Num ][ Size_DeviceInfoStr ];

	// storage of device info in LONG for EtherCAT
	LONG m_nDeviceInfo[ NUM_OF_ECAT_DeviceInfo ];

private:
	// process empty part in string
	BOOL ProcessEmptyString( CHAR *pString, INT nStringSize );

};
#endif // !defined(AFX_SERIALDEVINFO_H__9F91C651_85A4_4a2d_936B_12F09D896853__INCLUDED_)
