#if !defined(_ROBOTMRPQUEUE_H____INCLUDED_)
#define _ROBOTMRPQUEUE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRobotMRPPool;
class CRobotMRPQueue
{
public:
	CRobotMRPQueue( int nSize );
	~CRobotMRPQueue( void );

	BOOL isEmpty( void );
	// query whether queue is empty

	BOOL isFull( void );
	// query whether queue is full

	void freeAll( CRobotMRPPool *pRobotMRPPool );
	// abort all query.

	void add( TRobotMRP *pRobotMRP );
	// add specified node into queue tail

	int getCount( void );
	// return the number of node inside queue

	int getFreeCount( void );
	// return the number of free node inside queue

	TRobotMRP *remove( void );
	// remove and return head node.

	TRobotMRP *peek( int index );
	// to peek a node with specified index relative to queue head, index is 0 for head node.

	TRobotMRP *rpeek( int index );
	// to peek a node with specified index relative to queue tail, index is 0 for tail node.

protected:
	CRTMutex m_cs;
	// mutex for object state

	TRobotMRP **m_ppBuffer;
	// queue buffer

	int m_nSize;
	// queue size

	int m_nHead;
	// index of queue header

	int m_nCount;
	// the number of node in this queue
};

#endif // !defined(_ROBOTMRPQUEUE_H____INCLUDED_)
