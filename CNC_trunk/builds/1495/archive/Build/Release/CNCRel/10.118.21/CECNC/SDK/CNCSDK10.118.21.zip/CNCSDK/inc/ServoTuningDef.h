#if !defined(_SERVOTUNINGDEF_H____INCLUDED_)
#define _SERVOTUNINGDEF_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_SPRING_CNT						( 20 )
#define MAX_VFF_PARAM_CNT					( 12 )
#define VEL_GLITCH_PARAM_PosPeakHeight		( 0 )
#define VEL_GLITCH_PARAM_PosRiseTime		( 20 )
#define	VEL_GLITCH_PARAM_PosHoldTime		( 40 )
#define	VEL_GLITCH_PARAM_PosDecayTime		( 60 )
#define	VEL_GLITCH_PARAM_PosDelayTime		( 80 )
#define	VEL_GLITCH_PARAM_PosRiseType		( 100 )
#define	VEL_GLITCH_PARAM_NegPeakHeight		( 120 )
#define	VEL_GLITCH_PARAM_NegRiseTime		( 140 )
#define	VEL_GLITCH_PARAM_NegHoldTime		( 160 )
#define	VEL_GLITCH_PARAM_NegDecayTime		( 180 )
#define	VEL_GLITCH_PARAM_NegDelayTime		( 200 )
#define	VEL_GLITCH_PARAM_NegRiseType		( 220 )

#define DefaultPosLoopGain					( 40 )			// unit 1/s
#define DefaultSpeedLoopGain				( 40 )			// unit:Hz
#define DefaultSpeedIntegralTime			( 3979 )		// unit:0.01ms
#define DefaultIntertiaRatio				( 0 )			// unit:%
#define DefaultSpeedFilterTime				( 1 )			// unit:0.01ms
#define DefaultTorqueFilterTime				( 99 )			// unit:0.01ms
#define DefaultMotorInertia					( 0.442e-4 )	// unit:linear motor: kg, rotary motor: kg-m^2
#define DefaultMotorType					( 0 )			// 0:rotary motor type

const INT VFF_PARAM_BASE_NUM[ MAX_VFF_PARAM_CNT ] = { VEL_GLITCH_PARAM_PosPeakHeight, VEL_GLITCH_PARAM_PosRiseTime, 
VEL_GLITCH_PARAM_PosHoldTime, VEL_GLITCH_PARAM_PosDecayTime, VEL_GLITCH_PARAM_PosDelayTime, VEL_GLITCH_PARAM_PosRiseType,
VEL_GLITCH_PARAM_NegPeakHeight, VEL_GLITCH_PARAM_NegRiseTime, VEL_GLITCH_PARAM_NegHoldTime, VEL_GLITCH_PARAM_NegDecayTime,
VEL_GLITCH_PARAM_NegDelayTime, VEL_GLITCH_PARAM_NegRiseType };

// data struct of Friction glitch compensation param, but only with one direction
struct TTFFCoeff
{
	double Kspring[ MAX_SPRING_CNT ];
	double Alpha[ MAX_SPRING_CNT ];
	double Ratio;
	double SlipGain;
	double StaticFric;
	double CoulombFric;
	double Vs;
	double Sigma;
	int nKNum;
};

// data struct of motor serial parameter
struct TDrvParam {
	double ePositionLoopGain;	// (1/s)
	double eSpeedLoopGain;		// (1/s)
	double eSpeedIntegralTime;	// (s)
	double eSpeedFilterTime;	// (s)
	double eTorqueFilterTime;	// (s)
	double eInertiaRatio;		// (1 / 100)
	double eMotorInertia;		// linear motor: kg, rotary motor: kg-m^2
};

// enum for friction adjust
enum EFricComp {
	FRIC_OFF = -1,
	FRIC_POS,
	FRIC_VFF,
	FRIC_TFF,
};

enum ERecordDataType {
	ERT_Cmd = 0,
	ERT_Fbk,
	ERT_VelErr,
	ERT_VFFComp,
	NUMOF_RecordType,
};

enum EFricAdjustAxisIndex {
	EFAI_1stAxis = 0,
	EFAI_2ndAxis,
	NUMOF_FricAdjustAxis,
};

enum EGlitchDir {
	EGD_Pos = 0,
	EGD_Neg,
	NUMOF_GlitchDir,
};

enum EReserveDir {
	ERD_NEG = -1,
	ERD_POS = 1,
	NUMOF_ReverseCntPerAxis = 2,
};

enum ECircularSignalType {
	ECST_COS = 0,
	ECST_SIN,
	NUMOF_CircularSignalType
};

// data struct of VFF glitch compensation param, but only with one direction
struct TVFFParam {
	LONG	nPeakHeight;	// (um/sec)
	LONG	nRiseTime;		// (us)
	LONG	nHoldTime;		// (us)
	LONG	nDecayTime;		// (us)
	LONG	nDelayTime;		// (us)
	LONG	nRiseType;
	DOUBLE	RiseRatio;
	DOUBLE	DecayRatio;
};

// friiction adjust status
enum EFricAdjustDataStatus {
	EFADS_Processing = 0,
	EFADS_ArrangeDisplayDataSuccess,
	EFADS_CalFricCoeffSuccess,
	EFADS_CalFricCoeffFail,
	EFADS_FeedRateLimited,
	EFADS_NotSupportDriverParam,
	EFADS_NotSupportMotorInfo,
};

#endif // !defined(_SERVOTUNINGDEF_H___INCLUDED_)
