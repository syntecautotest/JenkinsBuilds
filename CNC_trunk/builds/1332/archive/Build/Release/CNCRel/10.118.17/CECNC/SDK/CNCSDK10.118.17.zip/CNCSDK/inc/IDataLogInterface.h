// IDataLogInterface.h: interface for the IDataLogInterface class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IDATALOGINTERFACE_H__INCLUDED_)
#define AFX_IDATALOGINTERFACE_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IDataLogInterface
{
public:
	virtual ~IDataLogInterface() {}

	virtual int InitLogger( int nQueueLen, int nPackLen, BOOL bSuspend = FALSE ) = 0;
	// init Data Logger

	virtual BOOL DeinitLogger( int nLoggerID ) = 0;
	// destroy Data Logger

	virtual BOOL RegisterDataLogEvt( int nLoggerID, TEvtInfo tEvtInfo, TCatchInfo tCatchInfo, BOOL bCritical ) = 0;
	// register log event

	virtual BOOL UnregisterDataLogEvt( int nLoggerID, TEvtInfo tEvtInfo, TCatchInfo tCatchInfo ) = 0;
	// unregister log event

	virtual BOOL DumpLogData( int nLoggerID, BYTE *byte, const int nInSize, int *nReadSize ) = 0;
	// dump recorded data log

	virtual BOOL SetLoggerAlive( int nLoggerID ) = 0;
	// reset auto-deinit watch dog

	virtual BOOL IsLogCritical( int nLoggerID ) = 0;
	// wether critical evt data being recoreded

	virtual BOOL ClearDataQueue( int nLoggerID ) = 0;
	// clear data queue of the logger
};

#endif // !defined(AFX_IDATALOGINTERFACE_H__INCLUDED_)
