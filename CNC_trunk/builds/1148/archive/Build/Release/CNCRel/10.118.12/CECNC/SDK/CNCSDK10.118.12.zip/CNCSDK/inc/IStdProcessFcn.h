// IStdProcessFcn.h: interface for the IStdProcessFcn abstract.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ISTDPROCESSFCN_H____INCLUDED_)
#define _ISTDPROCESSFCN_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum EProcessResponse {
	EPR_NoSupport = 0,
	EPR_SuccessProcess = 1,
	EPR_QueueFull = 2,
};

class IStdProcessFcn
{
public:
	virtual BOOL processMRP( TMotReqPkt *pMRP ) = 0;
	// process MRP in dispatchMRP
	// use threads: motion plan

	virtual INT processRobotMRP( TRobotMRP *pRobotMRP, TRobotMRP *pNextRobotMRP ) = 0;
	// process look ahead node in peekRobotMRP
	// use threads: trajectory plan
	
	//virtual void execFuncCall( LONG nFuncID, LONG lParam[] ) = 0;
	// process function call in execControlInstruction
	// use threads: interpolation

	virtual void processMicroCode( TRobotMicroCode *pNowTapeHead ) = 0;
	// process micro code in ExecuteNextMicroCode
	// use threads: interpolation

	virtual void processElapse( DOUBLE Elapse, DOUBLE NowTimeCursor ) = 0;
	// process micro code by time elapse in DoInterpolation
	// use threads: interpolation
};

#endif // !defined(_ISTDPROCESSFCN_H____INCLUDED_)
