// PID.h: interface for the CPID class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PID_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_)
#define AFX_PID_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPID
{
public:
	CPID();
	// Constructs

	virtual ~CPID();
	// destructor

	void Reset( void );
	// reset

	void SetTimebase( long Timebase );
	// set timebase

	void SetPGain( double PGain );
	// set P gain

	void SetIGain( double IGain );
	// set I gain

	void SetDGain( double DGain );
	// set D gain

	void SetOutputLimit( double MaxValue, double MinValue );
	// set output limit

	double GetOutput( double E );
	// get PID output

private:

	double m_TimeBase;
	// sampling timebase

	double m_PGain;
	// PID P gain

	double m_IGain;
	// PID I gain

	double m_DGain;
	// PID D gain

	double m_MaxOutput, m_MinOutput;
	// maximun and minium integral output

	double m_LastIntegralOutput;
	// last integral part output

	double m_LastE;
	// last input
};

#endif // !defined(AFX_PID_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_)
