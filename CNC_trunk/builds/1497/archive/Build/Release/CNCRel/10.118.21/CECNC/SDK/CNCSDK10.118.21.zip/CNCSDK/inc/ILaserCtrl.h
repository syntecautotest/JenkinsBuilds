#if !defined(_ILASERCTRL_H_INCLUDED_)
#define _ILASERCTRL_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ILaserCtrl
{
public:
	virtual ~ILaserCtrl( void ) {}
	// destructor

	virtual void setLaserHomePosition( INT nAxisID ) = 0;
	// set laser home position

	virtual BOOL getLaserDebugData( LONG *pDebugData, LONG nDataLen ) = 0;
	// get laser debug data

	virtual INT getStatus( void ) = 0;
	// get status 0: not ready 1: ready 2: busy 3: manual

	virtual LONG queryLaserFreeBufferSize( void ) = 0;
	// query laser free buffer size

	virtual void putPrintData( BYTE *pData, LONG nSize ) = 0;
	// put data needed in print mode

	virtual void SetGalvoServoOn( BOOL bOn ) = 0;
	// set galvo module servo ON/OFF for all axis

	virtual BOOL GetGalvoServoState( void ) = 0;
	// get galvo module servo ON/OFF state

	virtual void GalvoHomeSetting( void ) = 0;
	// clear galvo module absolute count for all axis

	virtual BOOL SetTableMode( LONG nMode ) = 0;
	// set mode

	virtual BOOL SetFocalLength( LONG nFocalLength ) = 0;
	// set focal length

	virtual BOOL SetDesiredCentralLength( LONG nLength ) = 0;
	// set desired central line length

	virtual BOOL SetGridCount( LONG nCount ) = 0;
	// set grid count

	virtual BOOL SetActualCentralLength( LONG nCount, LONG *pLength ) = 0;
	// set actual length of central line

	virtual BOOL SetBarrelFactor( DOUBLE BFx[], DOUBLE BFy[] ) = 0;
	// set barrel factor

	virtual BOOL SetRotationInfo( LONG nAngle, LONG nCenterX, LONG nCenterY ) = 0;
	// set rotation angle and center

	virtual BOOL SetGeomAdjustParam( LONG nSelect, LONG nFactorX, LONG nFactorY ) = 0;
	// set geometry adjustment parameter

	virtual BOOL SetScaleAndOffset( LONG nCount, LONG *pSetting ) = 0;
	// set offset value

	virtual BOOL SetZAxisInfo( LONG nZCount, LONG *pZPos, LONG nZAngleMin, LONG nZAngleMax ) = 0;
	// set z axis information

	virtual BOOL AdjustSpecifiedPoint( LONG nXCount, LONG nYCount, LONG nMaxSize, LONG PosCmd[], LONG ActualPos[] ) = 0;
	// adjust specified angle due to error of end point

	virtual LONG GetTableMode( void ) = 0;
	// get table mode

	virtual LONG GetFocalLength( void ) = 0;
	// get focal length

	virtual LONG GetDesiredCentralLength( void ) = 0;
	// get desired length

	virtual LONG GetGridCount( void ) = 0;
	// get grid count

	virtual LONG GetActualCentralCount( void ) = 0;
	// get actual cnetral length count

	virtual void GetActualCentralLength( LONG *pLength ) = 0;
	// get central length

	virtual void GetBarrelFactor( DOUBLE BFx[], DOUBLE BFy[] ) = 0;
	// get barrel factor

	virtual void GetRotationInfo( LONG &nAngle, LONG &nCenterX, LONG &nCenterY ) = 0;
	// get rotation infomation

	virtual void GetGeomAdjustParam( LONG nSelect, LONG &nFactorX, LONG &nFactorY ) = 0;
	// get geometry adjustment parameter

	virtual LONG GetZAxisCount( void ) = 0;
	// get z-axis count

	virtual void GetZAxisInfo( LONG *pZPos, LONG &nZAngleMin, LONG &nZAngleMax ) = 0;
	// get z axis information

	virtual void GetScaleAndOffset( LONG *pSetting ) = 0;
	// get scale and offset

	virtual BOOL PutDCTParam( BYTE *pData, LONG nSize ) = 0;
	// put DCT parameter

	virtual BOOL GetDCTParamCount( LONG &nSize ) = 0;
	// get DCT parameter count

	virtual BOOL GetDCTParam( BYTE *pData ) = 0;
	// get DCT parameter

	virtual BOOL SaveDCTData( LONG nDestination ) = 0;
	// save DCT data

	virtual BOOL ClearDCTData( LONG nDestination ) = 0;
	// clear DCT data

	virtual BOOL SetDCTUserStrokeLimit( LONG nDir, LONG nMin, LONG nMax ) = 0;
	// set DCT user defined stroke limit
	// nDir is valid for 1~3

	virtual BOOL GetDCTUserStrokeLimit( LONG nDir, LONG &nMin, LONG &nMax ) = 0;
	// get DCT user defined stroke limit
	// nDir is valid for 1~3

	virtual BOOL SetRLDCTAdjScaleAndOffset( LONG nScaleX, LONG nScaleY, LONG nOffsetX, LONG nOffsetY ) = 0;
	// set scale and offset for adjusting range of DCT
	// nScaleX, nScaleY: unit: 0.001
	// nOffsetX, nOffsetY: unit: 1 BLU(um)

	virtual BOOL GetRLDCTAdjScaleAndOffset( LONG &nScaleX, LONG &nScaleY, LONG &nOffsetX, LONG &nOffsetY ) = 0;
	// get scale and offset for adjusting range of DCT
	// nScaleX, nScaleY: unit: 0.001
	// nOffsetX, nOffsetY: unit: 1 BLU(um)

	virtual BOOL SetDCTType( LONG nType ) = 0;
	// set type of DCT

	virtual BOOL GetDCTType( LONG &nType ) = 0;
	// set type of DCT

	virtual BOOL CopyDCTDataFromLsrToRL( void ) = 0;
	// Copy DCT data from laser to red light

	virtual void TrackingModeRequest( BOOL bRequest ) = 0;
	// tracking mode request

	virtual void putFileName( char name[], INT nCount ) = 0;
	// put file name

	virtual BOOL isListFull( void ) = 0;
	// query is list full

	virtual BOOL isMotionFinish( void ) = 0;
	// query is motion finish

	virtual void SetSyncChecked( void ) = 0;
	// set synchronization with CNC and galvo checked in laser fly mode

	virtual BOOL isWaitSync( void ) = 0;
	// query is wait sync

	virtual void NotifyStagePathFinished( void ) = 0;
	// notify stage path finished

	virtual BOOL GetObjectQueueRemNum( LONG &nRemNum ) = 0;
	// get reminder number of object queue

	virtual BOOL SetObjectOffsetAndAngle( BOOL bDetectRes, LONG nObjNum, TObjOffsetAng2D *ObjData ) = 0;
	// set object offset and angle in camera frame

	virtual BOOL GetObjectLostNum( LONG &nLostNum ) = 0;
	// get number of object which is failed to laser scanning

	virtual BOOL ResetObjectLostNum( void ) = 0;
	// reset number of object which is failed to laser scanning

public:
	virtual DOUBLE GetDynStageSpeed( void ) = 0;
	// get stage speed, unit:mm/min

	virtual DOUBLE getMachPosition( int nAxisID ) = 0;
	// get machine position

	virtual DOUBLE getFeedbackPosition( int nAxisID ) = 0;
	// get feedback position

	virtual BYTE getLastEnergyCmd( void ) = 0;
	// get last energy command
};

#endif // !defined(_ILASERCTRL_H_INCLUDED_)
