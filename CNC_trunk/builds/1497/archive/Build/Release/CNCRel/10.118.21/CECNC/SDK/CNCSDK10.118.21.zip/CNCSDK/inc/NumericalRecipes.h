// NumericalRecipes.h: interface for the CNumericalRecipes class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NUMERICALRECIPES_H__015B6801_0D9C_11D3_840D_0000E86B4150__INCLUDED_)
#define AFX_NUMERICALRECIPES_H__015B6801_0D9C_11D3_840D_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class CComplex;

class CNumericalRecipes
{
public:

	//--------------------------------------------------------------------
	//  Numerical Recipes utility routines

	static double *create_vector(long nl, long nh);
	// allocate a double vector with subscript range v[nl..nh]

	static void free_vector(double *v, long nl, long nh);
	// free a double vector allocated with vector()

	static double **create_matrix(long nrl, long nrh, long ncl, long nch);
	// allocate a double matrix with subscript range m[nrl..nrh][ncl..nch]

	static void free_matrix(double **m, long nrl, long nrh, long ncl, long nch);
	// free a double matrix allocated by dmatrix()

	//--------------------------------------------------------------------
	//  Solution of Linear Algebraic Equations

	static int ludcmp(double **a, int n, int *indx, double *d);
	// Given a matrix a[1..n][1..n], this routine replaces it by the LU
	// decomposition of rowwise permutation of itself.
	// a and n are input. The matrix a will be overwritten as the combination
	// of a lower diagonal and upper diagonal matrix decompostion of this
	// matrix; the diagonal elements of L (unity) are not stored, the layout
	// as following:
	//							b11	b12 b13 b14
	//							a21 b22 b23 b24
	//							a31 a32 b33 b34
	//							a41 a42 a43 b44
	// indx[1..n] is an output vector that records the row permutation
	// effected by the partial pivoting;
	// d is output as 1/-1 depending one whether the number of row
	// interchanges was even or odd, respectively.

	static void lubksb(double **a, int n, int *indx, double b[]);
	// Solve the set of n linear equation A.X = B.
	// a[1..n][1..n] is input, not as the matrix A but rather as its LU
	// decomposition.
	// indx[1..n] is input as the permutation vector.
	// b[1..n] is input as the right-hand side vector B, and return with
	// the solution vector X.
	// a,n,indx are not modified by this routine and can be left in place
	// for successive calls with different right-hand sides b.
	// This routine takes into account the possibility that b will begin
	// with many zero elements, so it is efficient for use in matrix
	// inversion.

	static double REENTRYAPI pythag(double a, double b);
	// calculate (a^2+b^2)^{1/2} without destructive underflow or overflow

	static int svdcmp(double **a, int m, int n, double w[], double **v);
	// singular value decomposition of a matrix
	// Given a matrix a[1..m][1..n], this routine computes its singular value
	// decomposition, A = U * W * Vt(transpose of V).
	// The matrix U replaces a on output.
	// The diagonal matrix of singular value W is output as a vector w[1..n].
	// The matrix V is output as v[1..n][1..n]

	static void svbksb(double **u, double w[], double **v, int m, int n, double b[], double x[]);
	// Solves AX = B for vector X,
	// whether A is specified by the arrays u[1..m][1..n], w[1..n], v[1..n][1..n].
	// m and n are the dimensions of a, and will be equal for square matrix.
	// b[1..m] is the input right-hand size.
	// x[1..n] is the output solution vector.
	// No input quantities are destroyed, so the routine may be called sequentially
	// with different b's.

	static void tred2(double **a, int n, double d[], double e[]);
	// Householder reduction of a real, symmetric matrix a[1..n][1..n]. On output, a is replaced
	// by the orthogonal matrix Q effecting the transformation. d[1..n] returns the diagonal ele-
	// ments of the tridiagonal matrix, and e[1..n] the off-diagonal elements, with e[1] = 0. Several
	// statements, as noted in comments, can be ommitted if only eigenvalues are to be found, in which
	// case a contains no useful information on output. Otherwise they are to be included.

	static BOOL tqli(double d[], double e[], int n, double **z);
	// QL algorithm with implicit shifts, to determine the eigenvalues and eigenvectors of a real, sym-
	// metric, tridiagonal matrix, or of a real, symmetric matrix previously reduced by tred2(). On
	// input, d[1..n] contains the diagonal elements of the tridiagonal matrix. On output, it returns
	// the eigenvalues. The vector e[1..n] inputs the subdiagonal elements of the tridiagonal matrix,
	// with e[1] arbitary. On out e is destroyed. When finding only the eigenvalues, several lines
	// may be ommited, as noted in the comments. If the eigenvectors of a tridiagonal matrix are de-
	// sired, the matrix z[1..n][1..n] is input as the identity matrix. If the eigenvectors of a matrix
	// that has been reduced by tred2() are required, then z is input as the matrix output by tred2()
	// In ether case, the kth column of z returns the normalized eigenvector corresponding to d[k]

	static void daub4(double a[], unsigned long n, int isign, double wksp[] );
	// Applies the Daubechies 4-coefficient wavelet filter to data vector a[1..n] (for isign=1) or
	// applies its transpose (for isign=-1). Used hierarchically by routines wt1 and wtn.

	static void Get_QuadLoc_QuadWt( int QuadPtNum, double *QuadWt, double *QuadLoc );
	// Input QuadPtNum and get information of Quadrature rule about weight and location.

	static void poldiv( double *u, int degu, double *v, int degv, double *q, double *r );
	// Polynomial division u(x) = v(x) * q(x) + r(x)

	static void func( double *Coeff, int degree, double x, double &f );
	// Evaluating a polynomial f(x)

	static void func( double *Coeff, int degree, CComplex x, CComplex &f );
	// Evaluating a polynomial f(x)

	static void funcd( double *Coeff, int degree, double x, double &f, double &df );
	// Evaluating a polynomial f(x) and its derivative f'(x)

	static void derivatef( double *Coeff, int degree, double *dCoeff, int &ddegree );
	// Get derivate of polynomial f(x)

	static double rtsafe( void (*funcd)( double *, int, double, double &, double & ), double *Coeff, int degree, double lowbound, double upbound );
	// Using a combination of Newton-Raphson and bisection, find the root of a function bracketed between upbound and lowbound
	// Restriction: f(lowbound) * f(upbound) < 0

	static double rtsafe( void (*funcd)( double *, int, double, double &, double & ), double *Coeff, int degree, double f, double df, double lowbound, double upbound, double xacc, double Tol );
	// Using a combination of Newton-Raphson and bisection, find the root of a function bracketed between upbound and lowbound
	// Restriction: 1. f(lowbound) < 0 && f(upbound) > 0
	//              2. f and df be an input for initial condition

private:
	enum EMaxBounds {
		NR_NodeHeadExtra = 1
	};

	static const double LUD_Tiny;
	// a small number for LU decomposition
};

#endif // !defined(AFX_NUMERICALRECIPES_H__015B6801_0D9C_11D3_840D_0000E86B4150__INCLUDED_)
