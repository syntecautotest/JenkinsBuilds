#if !defined(_FEEDCONTROL_H____INCLUDED_)
#define _FEEDCONTROL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLANodePool;
class CFeedLimit;
class CRTMutex;

class CFeedControl : public CLAFilter
{
public:
	CFeedControl( int nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool, BOOL bDumpData = TRUE );
	// constructor

	~CFeedControl( void );
	// destructor

	void SetFeedLimit( CFeedLimit *pFL );
	// set corresponding feed limit module

	void set_ChannelCount( const int nCount );
	// to set channel count

	void putGeomAxis( const int XAxis, const int YAxis, const int ZAxis );
	// to put geometry axis index

	void putMaxCompAcceleration( DOUBLE Amax );
	// to put maximum geometry-space-related compound acceleration, in IU / us ^ 2.

	void putMaxCompJerk( const double Jmax );
	// to put the maximum jerk in IU / us ^ 3

	void get_SnapshotQueTime( long *lpdwRaw, long *lpdwMature );
	// to get remain queue time inside queue.

public:
	TLANode *PeekNode( int nIndex );
	// peek the node in raw queue
	// nIndex = 0: head node

	TLANode *PeekHeadNode( BOOL bForceFlush = TRUE );
	// peek the head node in mature queue
	// if mature queue has no element, then do backward

	TLANode *PeekFuncCall( void );
	// peek function call in mature queue
	// if it meets non-function call, return NULL

	TLANode *PeekEOB( void );
	// peek first end-of-block node not executed in raw queue

	TLANode *PeekEOB_Reverse( void );
	// check if there exists EOB after(including) the last cutting node in raw queue

	virtual void Remove( void );
	// remove

	TLANode *GetLastCuttingNode( void );
	// get last cutting node in raw queue and return it

public:
	BOOL IsEmpty( void );
	// query whether the pipe is empty

	virtual void Abort( void );
	// abort, it will cause all queued node be discard

	void Reset( void );
	// reset

	BOOL IsBufferSufficient( void );
	// return is sufficient

public:
	virtual void putLANode( TLANode *pNode, double eParam1 = 0 );
	// put look ahead node to feed control module

	virtual void setExactStop( void );
	// set exact stop

	virtual void setEOBMark( const TPacketInfo &PacketInfo );
	// set EOB Mark

	virtual int getFreeCountOfRawQue( void );
	// get free count in the raw queue

protected:
	virtual void NotifyDecToZero( void ) = 0;
	// notify decelerate to zero

	TLANode *ReversePeek( void );
	// peek the last node in feed control module

	virtual void onBeginDispatchBlock( BOOL bForceFlush = TRUE ) = 0;
	// trajectory planning tick call back

	BOOL CalcReasonableVelocity( double &Vel_High, const double Vel_Low, const double TwoLengthAcc );
	// return TRUE if Vel_High is clamped down, else return FALSE

	BOOL CalcReasonableVelSqur( double &VelSqur_High, const double VelSqur_Low, const double TwoLengthAcc );
	// return TRUE if VelSqur_High is clamped down, else return FALSE

	int CalcSafetyCount( void );
	// find the first non-function-call block
	// return the number of count should be release from raw queue.

	void AddIntoRawQueue( TLANode *pNode );
	// Add pNode into raw queue and update the raw time accumulator

	void RemoveFromRawQueue( TLANode *&pNode );
	// Remove one node from raw queue and update the raw time accumulator

	void AddIntoMatureQueue( TLANode *pNode );
	// Add pNode into mature queue and update the mature time accumulator

	void RemoveFromMatureQueue( TLANode *&pNode );
	// Remove one node from mature queue and update the mature time accumulator

#ifndef NDEBUG
	void EnsureDisplacementTheSame( TLANode *&pNode );
	// make sure displacement is keep the same
#endif

private:
	void AddToMatureTimeAcc( double &Elapse );
	// Add to mature time accumulator

	void SubtractFromMatureTimeAcc( double &Elapse );
	// Subtract from mature time accumulator

protected:
	CRTMutex m_cs;
	// mutex for protected queue in feedcontrol

	CFeedLimit *m_pFL;
	// corresponding feed limit module

	int m_nChannelCount;
	// number of axis

	int m_XAxis;
	int m_YAxis;
	int m_ZAxis;
	// geometry axes index

	double m_Amax;
	// maximum acceleration in IU / us ^ 2

	double m_Jmax;
	// maximum jerk in IU / us ^ 3

#ifndef NDEBUG
	double m_IssuedVc;
	// corner velocity of last issued block
#endif

	CLAQueue<TLANode> m_RawQue;
	CLAQueue<TLANode> m_MatureQue;
	// working queue

	BOOL m_bBufferSufficient;
	// indicate if under sufficient status
	// ( velocity is not been clamped down by immature status or can plan to feedlimit by FL module )

private:
	double m_MatureTimeAcc;
	// estimated elapse time accumulator of mature queue, in micro-second

	double m_RawTimeAcc;
	// estimated elapse time accumulator of raw queue, in micro-second

	CRTMutex m_csElapseAcc;
	// mutex for protected elapse accumulator

	CKinematicDataDump *m_pKDataLogger;
	// dump kinematic data logger
};

#endif // !defined(_FEEDCONTROL_H____INCLUDED_)
