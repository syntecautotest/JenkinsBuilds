#if !defined(AFX_ISERIALPLCCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
#define AFX_ISERIALPLCCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "nstdlib.h"

class ISerialPLCCenter {
public:
	virtual ~ISerialPLCCenter( void ) {}
	// destructor

	virtual BOOL CNCAPI isRunning( int nID ) = 0;
	// is running

	virtual BOOL CNCAPI isFeedhold( int nID ) = 0;
	// is feedhold

	virtual BOOL CNCAPI isInAlarm( int nID ) = 0;
	// is alarm

	virtual BOOL CNCAPI isReady( int nID ) = 0;
	// is ready

	virtual BOOL CNCAPI isReached( int nID ) = 0;
	// is in position or velocity reached

	virtual BOOL CNCAPI isAbsMode( int nID ) = 0;
	// is absolute mode

	virtual BOOL CNCAPI isServoOn( int nID ) = 0;
	// is servo on

	virtual BOOL CNCAPI GetServoIOSignal( int nID, int nIOSignal ) = 0;
	// get servo IO signal

	virtual LONG CNCAPI getOpMode( int nID ) = 0;
	// get operation mode

	virtual LONG CNCAPI getTargetPos( int nID ) = 0;
	// get target position in um, 0.001deg

	virtual LONG CNCAPI getTargetVel( int nID ) = 0;
	// get target velocity in mm / min, deg / min

	virtual LONG CNCAPI getCurPos( int nID ) = 0;
	// get current position in um, 0.001deg

	virtual LONG CNCAPI getActualVelocity( int nID ) = 0;
	// get actual velocity in mm / min, deg / min

	virtual BOOL CNCAPI isMPGCtrl( int nID ) = 0;
	// is MPG control

	virtual void CNCAPI GetTypeOfChArray( LONG nType[] ) = 0;
	// get type of channel array

	virtual BOOL CNCAPI TuningIsSupport( int nID ) = 0;
	// check SPLC tuning is supported

	virtual void CNCAPI TuningSet1stLimit( int nID ) = 0;
	// set 1st tuning stroke limit

	virtual void CNCAPI TuningSet2ndLimit( int nID ) = 0;
	// set 2nd tuning stroke limit

	virtual int CNCAPI TuningLimitCheck( int nID, double &MinRange, double &MaxRange ) = 0;
	// check tuning stroke limit

	virtual void CNCAPI TuningGetDefault( int nID, int &nTuningMode, int &nMachineType ) = 0;
	// get tuning default data

	virtual void CNCAPI TuningSetData( int nID, int nTuningMode, int nMachineType ) = 0;
	// set tuning data

	virtual BOOL CNCAPI TuningStartCheck( int nID ) = 0;
	// check tuning start position

	virtual void CNCAPI TuningStart( int nID ) = 0;
	// start tuning

	virtual void CNCAPI TuningStop( int nID ) = 0;
	// stop tuning

	virtual void CNCAPI TuningGetStatus( int nID, BOOL &isFinished, int &nResult ) = 0;
	// get tuning status

	virtual void CNCAPI setWatchMode( int nID, BOOL bWatchMode ) = 0;
	// set watch mode
};

#endif // !defined(AFX_ISERIALPLCCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)