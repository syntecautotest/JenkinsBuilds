//
//	CNCAPI.H
//
//	Open CNC Application Exported Interface
//

#if !defined(_CNCAPI_INCLUDED_)
#define _CNCAPI_INCLUDED_

#include "nstdlib.h"
#include "CommonStruct.h"
#include "OperationDef.h"
#include "InternalCNCAPI.h"


#ifndef EOCVARIANTTYPE_ENUM_
#define EOCVARIANTTYPE_ENUM_

enum EOcVariantType {
	OCVT_VACANT,
	OCVT_LONG,
	OCVT_DOUBLE,
	OCVT_STRING
};

#endif // EOCVARIANTTYPE_ENUM_

#ifndef TOCVARIANT_STRUCT_
#define TOCVARIANT_STRUCT_

typedef struct tagTOcVariant {
	short		m_type;
	union {
		long	m_long;
		DOUBLE	m_double;
	};
} TOcVariant;

#endif // TOCVARIANT_STRUCT_


class IParamListener;
class ISimulator;
class ISvoDriver;
class ICIODriver;
class IPLCDeviceProvider;
class INCGlobalVarProvider;
class INCGlobalVarContainer;
class IOnCncEvent;
class IUpdateDriver;
class IPhysicalDriver;
class ISerialPLCCenter;
class IRotCenter;
class IAlarmFilter;
class ISriDriver;
class ISerialParamListener;
class IListener;
class CParamManager;
class ITuningDevice;

//------------------------------------------------------------
// misc interface
//------------------------------------------------------------
extern "C" {
	void CNCAPI NcAddOnCncEvent( IOnCncEvent *pListener );
	// add OnCncEvent handler

	void CNCAPI NcRemoveOnCncEvent( IOnCncEvent *pListener );
	// remove OnCncEvent handler

	ISimulator * CNCAPI NcNewSimulator( void );
	// to new a simulator

	void CNCAPI NcReleaseSimulator( ISimulator *pSimulator );
	// to release a simulator

	ISimulator * CNCAPI NcGetSimulator( DWORD nSlotID );
	// to get a simulator from specific slotID

	BOOL CNCAPI NcIsSlotMatchKey( DWORD nSlotID, DWORD nHMIKey );
	// to check Handle and HMIKey is mapping correctly

	DWORD CNCAPI NcSaveSimuKeyMapping( ISimulator *pSimulator, DWORD nHMIKey );
	// save Handle and HMIKey mapping

	ISimulator * CNCAPI NcClearSimuKeyMapping( DWORD nSlotID );
	// clear Handle and HMIKey mapping
}

//------------------------------------------------------------
// driver provider interface
//------------------------------------------------------------
extern "C" {
	BOOL CNCAPI DrvRegistryIODevice( ICIODriver *pDevice );
	// registry I/O device

	BOOL CNCAPI DrvRegistryMCDevice( ISvoDriver *pDevice );
	// registry motion control device

	BOOL CNCAPI DrvRegistryUpdDevice( IUpdateDriver *pDevice );
	// registry update device

	BOOL CNCAPI DrvRegistrySriDevice( ISriDriver *pDevice );
	// registry sri device

	void CNCAPI DrvRegistryPhyscialDevice( IPhysicalDriver *pDevice );
	// registry physical device
}

//------------------------------------------------------------
// global variable provider interface
//------------------------------------------------------------
class INCGlobalVarContainer
{
public:
	virtual HRESULT CNCAPI AddProvider( INCGlobalVarProvider *pProvider, DWORD *pdwCookie ) = 0;
	// to add a global variable provider

	virtual HRESULT CNCAPI RemoveProvider( DWORD dwCookie ) = 0;
	// to remove a global provider

	virtual HRESULT CNCAPI GetProviderCount( long *pCount ) = 0;
	// to get provider count

	virtual HRESULT CNCAPI EnumProvider( long index, INCGlobalVarProvider **ppProvider ) = 0;
	// enumerate provider

	virtual HRESULT CNCAPI PutValue( long no, TOcVariant *pValue ) = 0;
	// put value into store

	virtual HRESULT CNCAPI GetValue( long no, TOcVariant *pValue ) = 0;
	// get value from store
};

class INCGlobalVarProvider
{
public:
	enum EStorageType {
		ST_VARIANT,
		ST_LONG
	};
	// constant for storage type

	virtual ~INCGlobalVarProvider( void ) {}
	// destructor

	virtual HRESULT CNCAPI GetStorageType( short *pType ) = 0;
	// get storage type

	virtual HRESULT CNCAPI GetRange( long *pLowNo, long *pUpNo ) = 0;
	// get occupied global variable number range

	virtual HRESULT CNCAPI PutValue( long no, TOcVariant *pValue ) = 0;
	// put value into store

	virtual HRESULT CNCAPI GetValue( long no, TOcVariant *pValue ) = 0;
	// get value from store
};

extern "C" {
	HRESULT CNCAPI RegGlobalVarProvider(INCGlobalVarProvider *pProvider, DWORD *pdwCookie);
	// register global variable provider

	HRESULT CNCAPI UnregGlobalVarProvider(DWORD dwCookie);
	// unregister global variable provider
}

//------------------------------------------------------------
// PLC device provider interface
//------------------------------------------------------------
struct TPLCOpSpec {
	ULONG		opid;				// the global op identifier
	ULONG		EventMask;			// requested event mask
};

// data structure for PLC register
struct TPLCRegState {
	long			value;			// register 32-bit value
	unsigned long	reserved;		// system reserved, don't use this field
};

union TPLCUpdateResult {
	long			nResult;

	struct {
		long CNC:1;
		long SPLC:1;
		long ROT:1;
		long LASER:1;
		long reserved:28;
	};
};

// data exchange block of FireEvent()
struct TPLCDeviceDXB {
	BOOL		acc;				// [in] current acc value
	ULONG		Event;				// [in] event flags, EPLCEventMask
	long		no;					// [in] device no, first is 1
	ULONG		opcode;				// [in] instruction opcode
	long		param[2];			// [in] argument one/two
	BOOL		retAcc;				// [out] return acc value
	long		alarm;				// [out] report alarm ID
	TPLCRegState *pReg;				// [in] pointer to internal R register device
};

class IPLCDeviceClass {
public:
	enum EPLCEventMask {
		EV_OnRiseEdge	= 0x0001,	// when input signal is rise up(L->H)
		EV_OnFallEdge	= 0x0002,	// when input signal is fall down(H->L)
		EV_OnHighLevel	= 0x0004,	// when input signal level is high
		EV_OnLowLevel	= 0x0008,	// when input signal level is low
		EV_OnAll		= 0x000F,	// all above events
		EV_OnEdge		= 0x0003,	// EV_OnRiseEdge | EV_OnFallEdge
		EV_OnLevel		= 0x000C	// EV_OnHighLevel | EV_OnLowLevel
	};
	// opcode event mask

public:
	virtual HRESULT CNCAPI GetClassID( ULONG *pID ) = 0;
	// get device class ID

	virtual HRESULT CNCAPI GetCapacity( ULONG *pCapacity ) = 0;
	// get device class capacity

	virtual HRESULT CNCAPI GetOpCodeSpec( ULONG *pCount, TPLCOpSpec **ppSpec ) = 0;
	// get opcode specification
};

class IPLCDeviceProvider {
public:
	enum EProviderType {
		PVTYPE_Class,		// whole class provider(full range)
		PVTYPE_Instance,	// one instance provider
		PVTYPE_Range,		// range instances provider
	};
	// device provider type

public:
	virtual HRESULT CNCAPI GetClassID( ULONG *pID ) = 0;
	// get associated device class ID

	virtual HRESULT CNCAPI GetClassInfo( IPLCDeviceClass **pCI ) = 0;
	// get device class access interface

	virtual HRESULT CNCAPI GetProviderType( ULONG *pType ) = 0;
	// get device provider type

	virtual HRESULT CNCAPI GetDeviceID( ULONG *pID ) = 0;
	// get device ID, for PVTYPE_Instance

	virtual HRESULT CNCAPI GetDeviceIDRange( ULONG *pStartID, ULONG *pCount ) = 0;
	// get device ID range, for PVTYPE_Range

	virtual HRESULT CNCAPI FireEvent( TPLCDeviceDXB *pDXB ) = 0;
	// fire opcode excution event
};

extern "C" {
	HRESULT CNCAPI RegPLCDeviceProvider(IPLCDeviceProvider *pProvider, DWORD *pdwCookie);
	// register PLC device provider

	HRESULT CNCAPI UnregPLCDeviceProvider(DWORD dwCookie);
	// unregister PLC device provider
}

//------------------------------------------------------------
// OpenCNC run-time extension(ORX) interface
//------------------------------------------------------------
extern "C" {
	BOOL WINAPI ORXInit( TCHAR *RegPath );
	void WINAPI ORXUnload( void );
	// ORX module export function
}

//------------------------------------------------------------
// Sri Driver Interface
//------------------------------------------------------------
extern "C" {
	void CNCAPI SriAddOnCncEvent( IOnCncEvent *pListener );
	void CNCAPI SriRemoveOnCncEvent( IOnCncEvent *pListener );
	ISriDriver * CNCAPI GetSriDriver( void );
}

//------------------------------------------------------------
// laser control API
//------------------------------------------------------------
extern "C" {
	void CNCAPI initLaserCtrlAPI( DWORD dwContext );
	void CNCAPI deinitLaserCtrlAPI( void );

	BOOL CNCAPI LaserIsMotionFinish( void );
	// query is laser motion finish

	BOOL CNCAPI LaserIsListFull( void );
	// query is laser list full

	void CNCAPI LaserPutFileName( char[], int nCount );
	// put laser file name

	void CNCAPI LaserTrackingRequest( BOOL bRequest );
	// tracking mocde request

	void CNCAPI LaserSetSyncChecked( void );
	// set laser sync checked

	BOOL CNCAPI LaserIsWaitSync( void );
	// query is laser waiting for sync
}

//------------------------------------------------------------
// Internal used API
//------------------------------------------------------------
extern "C" {
	BOOL CNCAPI KrnlAPI( DWORD dwCode, BYTE *pBufferIn, DWORD dwSizeIn, BYTE *pBufferOut, DWORD dwSizeOut );
	// Krnl API

	void CNCAPI NcStartControlSystem( void );
	// start control system

	long NcDosGetVersionNumber( void );
	// get control system version number

	void RtlChangeFileExt( char *dest, char *src, char *ext );
	// change file extension

	long RtlGetFileSize(char *filename);
	// get file size
	// if failure return -1

	void RtlSearchExecutable( LPCTSTR strFileName, TCHAR *lpBuffer, int nCount );
	// to search CNC system executable file

	void CNCAPI InitControlSystem(void);
	// init cnc kernel

	void CNCAPI DeinitControlSystem(void);
	// deinit cnc kernel
}

//------------------------------------------------------------
// the file archive interface, only internal used
//------------------------------------------------------------
typedef void arFILE;
// file pointer

extern "C" {
	arFILE * CNCAPI ar_fopen( char *filename, char *attrib );
	// open file from file archive

	int CNCAPI ar_fread( void *buffer, unsigned size, unsigned count, arFILE *arfp );
	// read file from file archive

	unsigned long CNCAPI ar_filelength( arFILE *arfp );
	// query file length

	void CNCAPI ar_fclose( arFILE *arfp );
	// close archive file

	int CNCAPI ar_fseek( arFILE *arfp, long offset, int origin );
	// seek cursor position to

	int CNCAPI ar_fgetc( arFILE *arfp );
	// get one character from archive
}

//------------------------------------------------------------
// CNC controller mode/status constant
//------------------------------------------------------------
#ifndef ECNCMODE_ENUM_
#define ECNCMODE_ENUM_

// CNC mode constant
enum ECNCMode {
		CNCMODE_NULL,
		CNCMODE_EDIT,
		CNCMODE_AUTO,
		CNCMODE_MDI,
		CNCMODE_JOG,
		CNCMODE_INCJOG,
		CNCMODE_MPG,
		CNCMODE_HOME
};

#endif // ECNCMODE_ENUM_

#ifndef ECNCSTATUS_ENUM_
#define ECNCSTATUS_ENUM_

// CNC status constant
enum ECNCStatus {
		CNCSTATUS_NOT_READY,
		CNCSTATUS_M_READY,
		CNCSTATUS_C_START,
		CNCSTATUS_FEEDHOLD,
		CNCSTATUS_B_STOP,
		CNCSTATUS_EXE_BLOCK,
		CNCSTATUS_RECORDING,
};

#endif // ECNCSTATUS_ENUM_

//-----------------------------------------------------------------
//  Run Time Library API
//-----------------------------------------------------------------
extern "C" {
	unsigned long CNCAPI RtlCalcCRCCheckSum( const void *data, const unsigned count );
	// calculate CRC check sum
	// data			pointer to source data buffer
	// count		the data length in source data to be calculated
	// return the CRC check sum

	long CNCAPI RtlMathRoundL( DOUBLE value );
	// calculate math round operation

	BOOL CNCAPI RtlMakeDirectory( char *pathname );
	// make a directory for specified pathname, if specified directory
	// not exist

	int CNCAPI SetupCheckIntegrity( char *pLocation );
	// check setup disk data integrity

	int CNCAPI ZipExtractUniZip( char *zipfile, char *destfile, unsigned long capacity, int fAppend );
	// extract uni-zip file, which has only one file inside, to specified
	// destination file

	int CNCAPI ZipGetLastErrorCode( void );
	// get last error code in zip archive
}

//------------------------------------------------------------
// configuration registry API
//------------------------------------------------------------
extern "C" {
	void initFram( DWORD dwContext );
	void initDriverManager( DWORD dwContext );
	void initCNC( DWORD dwContext );
	void initINIRegistryAPI( DWORD dwContext );
	void deinitINIRegistryAPI( void );
	// API initializer/deinitializer

	BOOL CNCAPI IniIsExist( char *RegistryName, char *section, char *key );

	char * CNCAPI IniGetString( char *RegistryName, char *section,
									   char *key, char *pDefault,
									   char *buffer, int count
									 );
	// get string value of specified key

	int CNCAPI IniGetInteger( char *RegistryName, char *section,
									 char *key, int Default
								   );
	// get integer value of specified key

	void CNCAPI IniPutString( char *RegistryName, char *section,
									 char *key, char *data
								   );
	// put string value of specified key

	void CNCAPI IniPutInteger( char *RegistryName,	char *section,
									  char *key, int value
									);
	// put integer value of specified key

	ERegSvoChIDResult registerSvoChID( INT nPortID, EDeviceType nDeviceType, INT nDeviceID, void *pSvoDevState, ITuningDevice *pTuingDevice );
	// register servo channel

	BOOL isCompositeDeviceType( EDeviceType nDeviceType, INT nDeviceID, EDeviceType nAnotherType );
	// whether this device is composite of two different types

	BOOL DeviceTypeMapping( EDeviceType nDeviceType, INT &nIndex );
	// mapping device type to index
}

//------------------------------------------------------------
// system parameter registry API
//------------------------------------------------------------
#define MINID_PARAM_TYPE			( 0 )

// maybe define a copy in MMI, please add in order, do not insert to the middle
enum EParamType {
	EPT_CNC = MINID_PARAM_TYPE,
	EPT_SPLCA = 1,
	EPT_SRI = 2,
	EPT_LASER = 3,
	EPT_LASER_GAX = 4,
	EPT_ROT = 5,
	EPT_COORD = 6,
	EPT_ROT_POS = 7,
	EPT_AXIS_VEL_GLITCH = 8,
	NUMOF_PARAM_TYPE,
};

struct TNumOfEachParamType {
	EParamType eType;
	INT nNum;
};

extern "C" {
	void CNCAPI initParamManagerAPI( DWORD dwContext );
	// init param manager API

	void CNCAPI deinitParamManagerAPI( void );
	// deinit param manager API

	void CNCAPI initParamAPI( EParamType eType, INT nID, DWORD dwContext );
	// init param API

	void CNCAPI deinitParamAPI( EParamType eType, INT nID );
	// deinit param API

	void CNCAPI ParamSetListener( EParamType eType, INT nID, IParamListener *pListener );
	// hook parameter event handler

	void CNCAPI ParamRemoveListener( EParamType eType, INT nID, IParamListener *pListener );
	// remove paramter listener

	BOOL CNCAPI ParamIsExist( LONG nNo );
	// query whether the parameter no is defined

	LONG CNCAPI ParamLookupMax( LONG nNo );
	// lookup maximum of parameter value

	LONG CNCAPI ParamLookupMin( LONG nNo );
	// lookup minimum of parameter value

	LONG CNCAPI ParamGetValue( LONG nNo );
	// get parameter value

	void CNCAPI ParamPutValue( LONG nNo, LONG nValue );
	// put parameter value

	BOOL CNCAPI CoordParamIsExist( INT nID, LONG nNo );
	// query whether the parameter no is defined

	LONG CNCAPI CoordParamGetValue( INT nID, LONG nNo );
	// get parameter value

	void CNCAPI CoordParamPutValue( INT nID, LONG nNo, LONG nValue );
	// put parameter value

	LONG CNCAPI SerialPLCParamGetValue( INT nID, LONG nNo );
	// get serial plc axis parameter value

	LONG CNCAPI RotParamGetValue( LONG nNo );
	// get rot parameter value

	LONG CNCAPI VelGlitchCompGetValue( LONG nNo );
	// get velocity glitch compensation value

	void CNCAPI VelGlitchCompSetAxisInfo( INT nAxisID, INT nAxisName );
	// set velocity glitch compensation axis id and axis name
}

//------------------------------------------------------------
// serial plc axis api
//------------------------------------------------------------
extern "C" {
	void initSerialPLCAxisAPI( ISerialPLCCenter *pSerialPLCCenter );
	void deinitSerialPLCAxisAPI( void );
}

//------------------------------------------------------------
// rot api
//------------------------------------------------------------
extern "C" {
	void initRotAPI( IRotCenter *pRotCenter );
	void deinitRotAPI( void );
}

//------------------------------------------------------------
// system registry API
//------------------------------------------------------------
extern "C" {
	void initGuardRegistryAPI(DWORD dwContext);
	void deinitGuardRegistryAPI( void );
	// API initializer/deinitializer

	long CNCAPI RegistryGetValue( long no );
	// get value from registry

	void CNCAPI RegistryPutValue( long no, long value );
	// put value into registry

	int CNCAPI RegistryGetVersion( void );
	// get registry version

	void CNCAPI RegistryPutString( long no, char *str, int size );
	// put string data into registry

	void CNCAPI RegistryGetString( long no, char *str, int size );
	// get string data from registry

	void CNCAPI RegistryForceCommit( void );
	// force to commit registry value

	unsigned long CNCAPI RegistryGetCommitCount( void );
	// get total commit count

	int CNCAPI RegistryImport( char *lpLocation );
	// import registry from external device

	int CNCAPI RegistryExport( char *lpLocation );
	// export registry to external device
}

//------------------------------------------------------------
// system Fram API
//------------------------------------------------------------
extern "C" {
	void CNCAPI FramGetValueArray( int StartNo, long *buffer, int count, long *pLengthRead );
	// get value array from Fram
	// no is between 0~7999

	void CNCAPI FramPutValueArray( int StartNo, long *buffer, int count, long *pLengthWrite );
	// put value array into Fram
	// no is between 0~7999

	void CNCAPI FramPutValueArrayEx( int StartNo, long *buffer, int count, long *pLengthWrite, BOOL bForceWrite );
	// put value array into Fram, and can force write back(for CRC calculate update)
	// no is between 0~7999

	void CNCAPI FramPutString( long no, char *str, int size );
	// put string data into Fram
	// no is between 0~7999

	long CNCAPI FramGetString( long no, char *str, int size );
	// get string data from Fram
	// no is between 0~7999

	BOOL CNCAPI FramPutData( int addr, long data );
	// set data to fram

	BOOL CNCAPI FramGetData( int addr, long *data );
	// get data from fram

	void CNCAPI SetSupportFram( BOOL bExist );
	// set if has fram device

	BOOL CNCAPI IsSupportFram( void );
	// get if has fram device

	BOOL CNCAPI IsFramTwoCRCError(void);
	// get if fram restore has two CRC error
}

//------------------------------------------------------------
// system Software Util API
//------------------------------------------------------------
extern "C" {
	void initSoftwareUtilAPI(DWORD dwContext);
	void deinitSoftwareUtilAPI( void );
	// API initializer/deinitializer

	void CNCAPI GetCRC32(const BYTE lpBuffer[], unsigned nLength , unsigned long *lpCrc );
	// get array crc value

	BOOL CNCAPI IsCRCCorrect(const BYTE lpBuffer[], unsigned nLength, unsigned long lCrc );
	// check if array crc value right

	int CNCAPI UT_getStatus(void);
	// query current status, in normal or in protect
	// use for if MMI lock the screen

	void CNCAPI UT_getPassSeed(char *UseSeed, int StrSize);   
	// 4chars for password encode

	unsigned long CNCAPI UT_getTimeStart(void);  
	// system can use date start date relative to year 1900

	unsigned long CNCAPI UT_getTimeSet(void);  
	// system use time set, in hour

	long CNCAPI UT_getTimeRemain(void);  
	// system can use time, in hour

	void CNCAPI UT_getFactoryID(char *FactoryID, int StrSize);   
	// get 4chars for Factory ID

	void CNCAPI UT_putUserID(char *UserName);   
	// Maker set UseID into system

	int CNCAPI UT_putPassKey(char *Password);  
	// Password to unlock Mac or Set Use time

	void CNCAPI UT_putInnerKey(char *InnerKey);   
	// put inner key, use to change password encrypt key

	void CNCAPI UT_putFactoryID(char *FactoryID);   
	// put Factory ID into system
}

//------------------------------------------------------------
// system Software Util API
//------------------------------------------------------------
extern "C" {
	void initProductInfoAPI( DWORD dwContext );
	void deinitProductInfoAPI( void );
	// API initializer/deinitializer

	void CNCAPI SWOP_getPassSeed( char *szUseSeed, int nStrSize );
	// 4chars for password encode

	void CNCAPI SWOP_getModel( char *szModelStr, int nStrSize );
	// option get Model string

	void CNCAPI SWOP_getMachine( char *szMachineStr, int nStrSize );
	// option get Machine string

	void CNCAPI SWOP_getSerialNo( char *szSerialStr, int nStrSize );
	// option get Serial No string

	int CNCAPI SWOP_putPassKey( char *szPassword );
	// Password to set serial No / Model / Option into controller

	int CNCAPI SWOP_isOptionEnabled( int nOptionID );
	// check if Option is enabled
	// 0: disabled, 1: enable, 2: bought but disable, 3: enable by try, 4: enable by try but can't use

	BOOL CNCAPI SWOP_isFunctionEnabled( INT nFunctionID );
	// if Function ID can be enabled

	int CNCAPI SWOP_getAxesGroupNumber( void );
	// get Model can use Axes Group number

	int CNCAPI SWOP_getWorkPieceNumber( void );
	// get Model can use work piece number

	INT CNCAPI SWOP_getEnabledAxes( void );
	// get system can use axes number

	INT CNCAPI SWOP_getEnabledSpds( void );
	// get system can use spindles number

	int CNCAPI SWOP_getSyncCuttingAxes( void );
	// get system can use sync. cutting axes number

	void CNCAPI SWOP_getEnabledPerformance( int nCoordID, int &nBPT_Normal, int &nBPT_HPCC, int &nLenMacroQue, int &nLenLAQue );
	// get enabled queue size level

	int CNCAPI SWOP_isInputCodeSupport( int nClassID, long nCode = -1 );
	// check if H,D,F,G,M,B,S,T Code Support in this model

	int CNCAPI SWOP_getNumOfOption( void );
	// get the number of option

	int CNCAPI SWOP_getOptionTryLeftTime( int nOptionID );
	// option try can use time, in hour

	BOOL CNCAPI SWOP_isDiskALimited( int &nLimit_MB );
	// check DiskA is limited or not, and get limited numbers
}

//------------------------------------------------------------
// system HardwareInfo API
//------------------------------------------------------------
extern "C" {
	void CNCAPI HW_GetPlatformName( char * buffer );
	// get CPU board platform name
	// buffer		buffer to store the platform name

	long CNCAPI HW_GetCPUTemperature( void );
	// get main board CPU temperature value

	long CNCAPI HW_GetSystemTemperature( void );
	// get main board system temperature value

	void CNCAPI HW_OnPanelBacklight( void );
	// on panel backlight

	void CNCAPI HW_OffPanelBacklight( void );
	// off panel backlight

	void CNCAPI HW_LEDSetStatus( long nID, long nType);
	// set LED mode
}

//------------------------------------------------------------
// logic controller API
//------------------------------------------------------------
extern "C" {
	void initLGCAPI(DWORD dwContext);
	void deinitLGCAPI( void );
	// API initializer/deinitializer

	HRESULT CNCAPI DevicePutIBitArray( int StartNo, unsigned char *data, int count );
	// set multiple PLC I bit-relay states by device

	HRESULT CNCAPI LgcPutIBitArray( int StartNo, unsigned char *data, int count, int mode );
	// set multiple PLC I bit-relay states

	HRESULT CNCAPI LgcPutOBitArray( int StartNo, unsigned char *data, int count, int mode );
	// set multiple PLC O bit-relay states

	void CNCAPI LgcPutCBitArray( int StartNo, unsigned char *data, int count );
	// set multiple PLC C bit-relay states

	void CNCAPI LgcPutSBitArray( int StartNo, unsigned char *data, int count );
	// set multiple PLC S bit-relay states

	void CNCAPI LgcPutRegisterArray( int StartNo, long *data, int count );
	// set multiple PLC register 32-bit-relay state

	void CNCAPI DevicePutIBit( int No, unsigned char data );
	// set a PLC I bit-relay state by device

	HRESULT CNCAPI LgcPutIBit( int No, unsigned char data, int mode );
	// set a PLC I bit-relay state

	void CNCAPI LgcPutCBit( int No, unsigned char data );
	// set a PLC C bit-relay state

	void CNCAPI LgcPutSBit( int No, unsigned char data );
	// set a PLC S bit-relay state

	void CNCAPI LgcPutRegister( int No, long data );
	// set a PLC register 32-bit-relay state

	void CNCAPI LgcPutRegisterBits( int No, long data, unsigned long bitmask );
	// set a PLC register 32-bit-relay state at specified bits

	void CNCAPI LgcGetIBitArray( int StartNo, unsigned char *buffer, int count );
	// get multiple PLC I bit-relay states

	void CNCAPI LgcGetOBitArray( int StartNo, unsigned char *buffer, int count );
	// get multiple PLC O bit-relay states

	void CNCAPI LgcGetSBitArray( int StartNo, unsigned char *buffer, int count );
	// get multiple PLC S bit-relay states

	void CNCAPI LgcGetCBitArray( int StartNo, unsigned char *buffer, int count );
	// get multiple PLC C bit-relay states

	void CNCAPI LgcGetABitArray( int StartNo, unsigned char *buffer, int count );
	// get multiple PLC A bit-relay states

	void CNCAPI LgcGetTimerArray( int StartNo, TLogicTimer *buffer, int count );
	// get multiple PLC timer device states

	void CNCAPI LgcGetCounterArray( int StartNo, TLogicCounter *buffer, int count );
	// get multiple PLC counter device states

	void CNCAPI LgcGetRegisterArray( int StartNo, long *buffer, int count );
	// get multiple PLC register 32-bit-relay states

	unsigned char CNCAPI LgcGetIBit( int No );
	// get a PLC I bit-relay state

	unsigned char CNCAPI LgcGetOBit( int No );
	// get a PLC O bit-relay state

	unsigned char CNCAPI LgcGetCBit( int No );
	// get a PLC C bit-relay state

	unsigned char CNCAPI LgcGetSBit( int No );
	// get a PLC S bit-relay state

	unsigned char CNCAPI LgcGetABit( int No );
	// get a PLC A bit-relay state

	void CNCAPI LgcGetTimer( int No, TLogicTimer *buffer );
	// get a PLC timer device state

	void CNCAPI LgcGetCounter( int No, TLogicCounter *buffer );
	// get a PLC counter device state

	long CNCAPI LgcGetRegister( int No );
	// get a PLC register 32-bit-relay state

	void CNCAPI LgcPutABit( int No, unsigned char data );

	void CNCAPI DevicePutOBit( int No, unsigned char data );
	// set multiple PLC O bit-relay states by device

	HRESULT CNCAPI LgcPutOBit( int No, unsigned char data, int mode );
	// set a PLC O bit-relay states

	void CNCAPI LgcEnableForceIOMode( BOOL bEnable );
	// enable/disable force input I/O functions

	void CNCAPI LgcReleaseIBit( int No );
	// release a I bit from being hold by force input function

	void CNCAPI LgcReleaseOBit( int No );
	// release a O bit from being hold by force input function

	void CNCAPI LgcReleaseIBits( void );
	// release all I bits from being hold by force input function

	void CNCAPI LgcReleaseOBits( void );
	// release all O bits from being hold by force input function

	HRESULT CNCAPI LgcGetHoldIBits( int *data, int countMax, int &countRead );
	// list all I bits from being hold by force input function

	HRESULT CNCAPI LgcGetHoldOBits( int *data, int countMax, int &countRead );
	// list all O bits from being hold by force input function

	void CNCAPI LgcGetBackgndExeInfo( int No, TBgndExeInfo *buffer );
	// get a PLC background executer device state

	void CNCAPI LgcBgndExeReqChecked( int No );
	// reset PLC request flag after been read and handled

	void CNCAPI NcSetCheckRegister( int *pMap, int nLength );
	// set check register

	int CNCAPI NcCheckRegisterMaxCount( void );
	// check register max count

	void CNCAPI NcGetEnvKeyName( char *KeyName );
	// get env key name

	void CNCAPI NcSetRegWriteInhibit( BOOL bInhibit );
	// set registry write inhibit
}

//------------------------------------------------------------
// CNC controller data structure
//------------------------------------------------------------
// data structure for reference point and workpiece coordinate zero-point
// offset table

#ifndef TREFERENCEPOINT_STRUCT_
#define TREFERENCEPOINT_STRUCT_

typedef struct {
		DOUBLE  Axis[NUMOF_AXIS];			// unit: mm or inch
} TReferencePoint;

#endif // TREFERENCEPOINT_STRUCT_

//------------------------------------------------------------
// CNC controller API
//------------------------------------------------------------
extern "C" {
	void CNCAPI NcPutRelativePosition( long Position[NUMOF_AXIS] );
	// set current relative position to new value
	// position     new relative position

	void CNCAPI NcGetRelativePosition( long Position[NUMOF_AXIS] );
	// get current relative position to new value
	// position     new relative position

	void CNCAPI NcResetCNC(void);
	// reset CNC controller

	void CNCAPI NcCycleStart(void);
	// cycle start from software, this function usually for demo purpose

	void CNCAPI NcFeedhold(void);
	// feedhold from software, this function usually for demo purpose

	void CNCAPI NcClearAccCycleTime(void);
	// clear accumulated cycle time

	void CNCAPI NcClearAccPowerOnTime(void);
	// clear accumulated power-on time

	void CNCAPI NcClearInstallationTime(void);
	// clear installation time

	BOOL CNCAPI NcIsCommPortOccupied( INT nPort );
	// query whether comm port is occupied
}

//------------------------------------------------------------
// workpiece and tool length table download API
//------------------------------------------------------------
extern "C" {
	void CNCAPI NcPutToolCompensation( int no, TToolOffset *value );
	// put tool compensation data

	HRESULT CNCAPI NcPutWorkpieceZero( int no, TWorkpieceFrame *value );
	// put workpiece zero offset data

	HRESULT CNCAPI NcPutExternWorkpieceZero( TWorkpieceFrame *value );
	// put external workpiece zero offset data

	HRESULT CNCAPI NcIsCoordSystemFrameWritable( ECSFrameType nType, INT nNo );
	// query whether Coordinate System Frame( external workpiece, workpiece, MPGShift ) is writable

	void CNCAPI NcGetWorkpieceZero( int no, TWorkpieceFrame *value );
	// get workpiece zero data

	void CNCAPI NcGetExternWorkpieceZero( TWorkpieceFrame *value );
	// get external workpiece zero data

	long CNCAPI NcGetWorkpieceTableSize( void );
	// get workpiece table size

	BOOL CNCAPI NcGetToolCompensation( int no, TToolOffset *value );
	// get tool compensation data

	void CNCAPI NcPutTemperatureShift( int AxisID, DOUBLE shift );
	// put temperature offset value
	// AxisID	the axis ID, base is one
	// shift	temperature shift value, in BLU.

	BOOL CNCAPI NcGetPrecisionParameter( int no, TPrecisionRecord *lpValue );
	// to get precision parameter

	BOOL CNCAPI NcPutPrecisionParameter( int no, TPrecisionRecord *lpValue );
	// to set precision parameter

	void CNCAPI NcRestorePrecisionParamDefault( void );
	// to restore PrecisionParam setting parameter default

	void CNCAPI NcLoadString( int nMode, long nNo, char *str, int size );
	// load string data from CNC
	// Mode	0	registry
	// Mode 1	global variable
	// Mode 2	PLC R Register

	void CNCAPI NcSaveString( int nMode, long nNo, char *str, int size );
	// save string into CNC
	// Mode	0	registry
	// Mode 1	global variable
	// Mode 2	PLC R Register

	void CNCAPI NcAxisPutMovement( int AxisID, DOUBLE segment );
	// put movement to axis
	// AxisID the axis ID, base is one
	// segment  in BLU.

	void CNCAPI NcDeskPutMovement( int AxisID, DOUBLE segment );
	// put movement to desk
	// AxisID the axis ID, base is one
	// segment  in BLU.

	void CNCAPI NcGetMachinePosition( int AxisID, DOUBLE *position );
	// get current motor command position, in BLU
	// AxisID the axis ID, base is one

	void CNCAPI NcAxisSetServoOn( int AxisID, BOOL bOn );
	// set axis servo on/off
	// AxisID: the axis ID, base is one
	// bOn	 : TRUE/FALSE

	void CNCAPI NcAxisOutputVelocity( int AxisID, DOUBLE rpm );
	// output velocity voltage command to velocity servo loop
	// AxisID : the axis ID, base is one

	int CNCAPI NcGetSysTimeBase( void );
	// get system time base

	void CNCAPI NcGetSimulatedProgPos( DOUBLE Pos[], int nCount );
	// get simulated program position
}

//------------------------------------------------------------
// NC program download API
//------------------------------------------------------------
enum NCHEADERTYPE {
		NCHEADER_ISO = 1,
		NCHEADER_SYNTECMACRO,
		NCHEADER_EXTERNALMACRO
};

extern "C" {
	BOOL CNCAPI NcGetModeGroupCoordNum( int nModeGroupID, int &nNum );
	// get mode group coordinate number

	void CNCAPI NcPutMainProgram( int nCoordID, char progname[], long nStartSeqNo, long nStartLineNo );
	// put main program

	void CNCAPI NcGetSysMainProgramName( int nCoordID, char progname[] );
	// get sys main program

	void CNCAPI NcGetMainProgramName( int nCoordID, char progname[] );
	// get main program

	void CNCAPI NcGetProgramName( int nCoordID, char progname[] );
	// get program name

	void CNCAPI NcPutBreakPoint( int nCoordID, long nBreakSeqNo, long nBreakLineNo );
	// put break point

	void CNCAPI NcExecuteBlocks( char *blocks );
	// execute blocks immediately, curent this is block

	void CNCAPI NcPutRequiredPartCount( long count );
	// put required part count

	void CNCAPI NcPutPartCount( long count );
	// put part count

	void CNCAPI NcPutTotalPartCount( long count );
	// put total part count

	long CNCAPI NcGetRequiredPartCount( void );
	// get required part count

	long CNCAPI NcGetPartCount( void );
	// get part count

	long CNCAPI NcGetTotalPartCount( void );
	// get total part count

	void CNCAPI NcClearHint( void );
	// clear hint

	void CNCAPI NcClearHistory( void );
	// clear history record

	void CNCAPI NcForceReNotifyAlarm( void );
	// force re-notify alarm

	TCHAR * CNCAPI NcFormatVersionText( TCHAR *lpszVersionText, long nVersion, TCHAR *szVersionTitle, TCHAR *szCandidateTitle );
	// to format version text

	void CNCAPI NcGetVersionInfo( TVersionInfo *lpBuffer, LONG nLengthToRead, LONG *lpnLengthRead );
	// get version information

	void CNCAPI NcSetMachinePosition( int nAxisID, long nPosition);
	// set machine position by AxisID

	long CNCAPI NcGetAxisTorqueLoad( int nAxisID );
	// gat axis torque load in 1% rated torque

	BOOL CNCAPI IsBlockGrammarError( char *blocks, int nHeaderType = NCHEADER_ISO );
	// check block grammar, default hearder type is SYNTEC ISO file
}

//------------------------------------------------------------
// System Event Register API
//------------------------------------------------------------
extern "C" {
	DWORD CNCAPI SysGetEvtTrgMgr( void );
	// system get event trigger manager
}

//------------------------------------------------------------
// Data Listener interface
//------------------------------------------------------------
#define MAX_LISTENER_NUMBER 20
// the maximum number of DumpBufferListener
#define MAX_EVENT_CATCH_DATA_TYPE 30
// the maximum types of data for each registered event need to catch

#define LEN_DEFAULT_QUEUE				( 1024 )	// default length of record queue
#define LEN_DEFAULT_BUFF_PACK			( 64 )		// default length of the buffer packet

extern "C" {
	int CNCAPI DtLogger_Init( int nQueueLen = LEN_DEFAULT_QUEUE, int nPackLen = LEN_DEFAULT_BUFF_PACK );
	// init Data Logger

	BOOL CNCAPI DtLogger_Deinit( int nLoggerID );
	// destroy Data Logger

	BOOL CNCAPI DtLogger_RegisterEvt( int nLoggerID, TEvtInfo tEvtInfo, TCatchInfo tCatchInfo, BOOL bCritical = FALSE );
	// register log event

	BOOL CNCAPI DtLogger_UnregisterEvt( int nLoggerID, TEvtInfo tEvtInfo, TCatchInfo tCatchInfo );
	// unregister log event

	BOOL CNCAPI DtLogger_DumpData( int nLoggerID, BYTE *byte, const int nInSize, int *nReadSize );
	// dump recorded data log

	BOOL CNCAPI DtLogger_SetAlive( int nLoggerID );
	// reset auto-deinit watch dog

	BOOL CNCAPI DtLogger_IsLogCritical( int nLoggerID );
	// check log state

	BOOL CNCAPI DtLogger_ClearDataQueue( int nLoggerID );
	// clear data queue of the logger

	void CNCAPI DtLogger_TransRecordAlignment( BYTE* byRawData, INT *nTotalSize );
	// re-arrange record data memory position within the buffer in order to fit the specification of mmi log file
}

//------------------------------------------------------------
// CE DNC service interface
//------------------------------------------------------------
extern "C" {
	long CNCAPI DNC_GetBufferSize( void );
	// get DNC buffer size

	int CNCAPI DNC_GetBlocks(long *lpnLineNo, char *buffer, int count);
	// get string from file stream data, and return length of data

	long CNCAPI DNC_PutBlocks(char *str);
	// put string to file stream data,return number of residual blocks

	void CNCAPI DNC_Reset( void );
	// to reset DNC channel, this will clear DNC stream data

	BOOL CNCAPI DNC_IsStreamEmpty( void );
	// check if the file stream is empty
}

//------------------------------------------------------------
// watch dog function API interface
//------------------------------------------------------------
extern "C" {
	void CNCAPI WatchDogEnable( void );
	// enable watch dog function.

	void CNCAPI WatchDogDisable( void );
	// disable watch dog function.
}

//------------------------------------------------------------
// data acquisition API interface
//------------------------------------------------------------
extern "C" {
	BOOL CNCAPI DQ_Init( long nFuncID[], long nArgument[], long nNumOfChannel, long nDataLength, long nSampleInterval, long nBufferLength );
	// to init data acquisition function
	// return TRUE when success, FALSE when failure.
	// nFuncID		The function ID, please refer to Function ID Table.
	// nArgument		The argument of FuncID.
	// nNumOfChannel	The number of acquisition channel.
	// nDataLength		The length of sampling data per channel.
	// nSampleInterval	The sample interval, it must be multiple of the sampling timebase.

	BOOL CNCAPI DQ_IsBusy( void );
	// to query whether acquisition function is in work.
	// return TURE when busy, FALSE when idle,

	LONG CNCAPI DQ_GetProgressPercentage( void );
	// to get progress in percentage
	// return percentage in progress, 0~100.

	LONG CNCAPI DQ_GetTimeBase( void );
	// to get sampling time base .
	// return sampling time base, in micro-second

	void CNCAPI DQ_Start( void );
	// to start data acquisition function

	void CNCAPI DQ_Abort( void );
	// to abort current running data acquisition.

	LONG CNCAPI DQ_GetData( long *lpBuffer, LONG nLength );
	// to get sampling data, the buffer layout please refer to layout of sampling data
	// nLength		the length is nNumOfChannel * nDataLength

	LONG CNCAPI DQ_GetDataDouble( DOUBLE *lpBuffer, LONG nLength );
	// to get sampling data, the buffer layout please refer to layout of sampling data
	// nLength		the length is nNumOfChannel * nDataLength
}

//------------------------------------------------------------
// global variable acccess API
//------------------------------------------------------------
extern "C" {
	void CNCAPI NcPutGlobalVariable( int no, TOcVariant *value );
	// assign global variable value

	int CNCAPI NcGetGlobalVariable( int no, TOcVariant *value );
	// get global variable value
	// return TRUE when variable exist, else return FALSE

	int CNCAPI NcGetGlobalAsDouble( int no, DOUBLE *value );
	// get global variable as double
	// return TRUE when variable exist, else return FALSE

	int CNCAPI NcGetGlobalAsLong( int no, long *value );
	// get global variable as long
	// return TRUE when variable exist, else return FALSE

	BOOL CNCAPI NcPutSystemVar( INT nCoordID, INT nNo, TOcVariant *value );
	// get system variable value
	// return TRUE when variable exist, else return FALSE

	BOOL CNCAPI NcGetSystemVar( INT nCoordID, INT nNo, TOcVariant *value );
	// get system variable value
	// return TRUE when variable exist, else return FALSE

	void CNCAPI NcSetCryptologyKey( char *pKey );
	// to set DES key

	void CNCAPI GetDesKey( char *pKey, unsigned int count );
}

//------------------------------------------------------------
// alarm API
//------------------------------------------------------------
extern "C" {
	void * CNCAPI AlmGetPendingAlarmStore( void );
	// get pending alarm store interface pointer

	IAlarmFilter * CNCAPI AlmGetPendingAlarmFilter( void );
	// get pending alarm filter interface pointer

	void * CNCAPI AlmGetHistoryAlarmStore( void );
	// get history alarm store interface pointer

	IAlarmFilter * CNCAPI AlmGetHistoryAlarmFilter( void );
	// get history alarm filter interface pointer

	BOOL CNCAPI AlmIsDirty( void );
	// query whether alarm store is dirty, need to be check

	BOOL CNCAPI IsUnderMOTAlarm( void );
	// query whether under MOT alarm

	void CNCAPI SetOpAlarm( int nNo );
	// set operation alarm

	void CNCAPI ResetOpAlarm( int nNo );
	// set operation alarm

	void CNCAPI AssociateAlarmQuerier( DWORD dwContext );
	// associate alarm querier
}

//------------------------------------------------------------
// Servo Data API
//------------------------------------------------------------
extern "C" {
	ISvoDriver * CNCAPI getMCIDriver( void );
	// get mci driver

	IPhysicalDriver * CNCAPI getPhysicalDriver( void );
	// get physical driver

	void CNCAPI SSV_GetDeviceInfo( int nAxisID, int nFunctionCode, char *pBuffer, int nStrSize );
	// get inforamtion of serial servo device
}

//------------------------------------------------------------
// Latch-Control API
//------------------------------------------------------------
extern "C" {
	BOOL CNCAPI RegistryLatchIBit( int nIBit, int nAxisID, LONG nRNo );
	// registry latch I bit

	void CNCAPI UnregistryLatchIBit( int nIBit, int nAxisID );
	// unregistry latch I bit

	BOOL CNCAPI RegistryLatchDrvSgl( INT nAxisID, INT nSelect, INT nSignal, LONG nRBit, LONG nRCount );
	// registry latch driver signal

	void CNCAPI UnregistryLatchDrvSgl( INT nAxisID, INT nSelect );
	// unregistry latch driver signal
}

//------------------------------------------------------------
// C-bit keyboard API
//------------------------------------------------------------
extern "C" {
	int CNCAPI CPadIsKeyReady( void );
	// is key ready in C-bit keyboard

	int CNCAPI CPadGetScanCode( void );
	// get C-bit scan code
}

//------------------------------------------------------------
// running information and debug information dump API
//------------------------------------------------------------
#define SIZE_NCRunningState		500
#define SIZE_NCDebugData		880

//  debug privilege level constant
#ifndef EDEBUGPRIVILEGE_ENUM_
#define EDEBUGPRIVILEGE_ENUM_

enum EDebugPrivilege {
	DBGPRIVILEGE_SYSTEM,
	DBGPRIVILEGE_APPLICATION,
	DBGPRIVILEGE_ENDUSER
};

#endif // EDEBUGPRIVILEGE_ENUM_

extern CNCKEDATAAPI long CNCDATAAPI NcStateTable[SIZE_NCRunningState];
// running state table

extern "C" {
	void CNCAPI NcPutDebugPrivilege( int PrivilegeLevel );
	// put debug privilege level

	void CNCAPI NcDumpDebugData( long *buffer );
	// dump debug data

	void CNCAPI NcGetDebugData( long no, long *buffer );
	// use no to get debug data

	long CNCAPI NcGetInterpolationCount( void );
	// to get Interpolation Count

	ULONGLONG CNCAPI NcGet64BitsInterpolationCount( void );
	// to get Interpolation Count in 64-bits

	long CNCAPI NcGetIoScanTime( void );
	// to get Io scan time, in micro-second

	long CNCAPI NcGetMacroExecuterTime( void );
	// to get macro executer time, in micro-second

	HRESULT CNCAPI NcGetFreeSpace( __int64 *lpFreeBytesAvailable );
	// to get NCFile free space

	void CNCAPI RealtimeAssert( long nCounter, BOOL bAssertCondition );
	// use PLC register to implement realtime debug counter

	void CNCAPI RealtimeAssertCounterReset( long nCounter );
	// to reset assertion debug counter
	HRESULT CNCAPI XMLDB_SetDatabaseLocation( LPCTSTR lpszLocation );
	HRESULT CNCAPI XMLDB_AddDatabaseLocation( LPCTSTR lpszLocation, DWORD& );
	HRESULT CNCAPI XMLDB_SetSchemaLocation( LPCTSTR lpszLocation );
	HRESULT CNCAPI XMLDB_AddSchemaLocation( LPCTSTR lpszLocation );
	HRESULT CNCAPI XMLDB_SaveCycleData( LPCTSTR lpszTableName, LPCTSTR lpszCycleName, DWORD nKey );
	HRESULT CNCAPI XMLDB_LoadCycleData( LPCTSTR lpszTableName, TCHAR *lpCycleName, UINT nLength, DWORD nKey );
	HRESULT CNCAPI XMLDB_NewCycleData( LPCTSTR lpszCycleName, DWORD nKey );
	HRESULT CNCAPI XMLDB_DeleteTable( LPCTSTR lpszTableName, DWORD nKey );
	HRESULT CNCAPI XMLDB_GetTableList( LPCTSTR lpszTableDir, TCHAR * lpBuffer, UINT nLength, DWORD nKey );
	HRESULT CNCAPI XMLDB_GetXLDevice( long nNo, TCHAR *lpBuffer, UINT nLength, DWORD nKey );
	HRESULT CNCAPI XMLDB_PutXLDevice( long nNo, DWORD nKey, LPCTSTR lpszNewVal );
	HRESULT CNCAPI XMLDB_PutCycleData( LPCTSTR lpszCycleXml, TCHAR *lpCycleName, UINT nLength, DWORD nKey );
	HRESULT CNCAPI XMLDB_GetCycleData( LPCTSTR lpszCycleName, TCHAR *lpBuffer, UINT nLength, DWORD nKey );
	HRESULT CNCAPI XMLDB_GetDataBaseLocation(TCHAR *lpBuffer, DWORD nKey );
	HRESULT CNCAPI XMLDB_DeleteDataBaseLocation( DWORD nKey );
}

//------------------------------------------------------------
// Operation logger API
//------------------------------------------------------------
#ifdef UNDER_CE
#define OPLOG_MESSAGE(ID, arg)		( ((UINT32)(ID) << 16UL) | ((UINT32)(arg) & 0x0000FFFFUL) )
#define OPLOG_GETMESSAGE(ID, arg, message)	(ID)=(message)>>16;(arg)=(message)&0xFFFF
#define OPLOG_ID_ISERROR(ID)		((ID)&0x0800U)

// Kernel 0x0001~0x0FFF
#define OPLOG_ID_ISKERNEL(ID)		(((ID)&0xF000U)==0x0000U)
// System 0x0001~0x000F
#define OPLOG_ID_STARTUP			0x0002U
#define OPLOG_ID_SHUTDOWN			0x0003U
#define OPLOG_ID_KEYPRESSED			0x0005U
// PLC bit 0x0010~0x001F
#define OPLOG_ID_ISPLCBIT(ID)		(((ID)&0xFFF0U)==0x0010U)
#define OPLOG_ID_ISPLCBITON(ID)		!((ID)&0x0001U)
#define OPLOG_ID_ISPLCBITOFF(ID)	((ID)&0x0001U)
#define OPLOG_ID_PLC_I_OFF			0x0010U
#define OPLOG_ID_PLC_I_ON			0x0011U
#define OPLOG_ID_PLC_O_OFF			0x0012U
#define OPLOG_ID_PLC_O_ON			0x0013U
#define OPLOG_ID_PLC_C_OFF			0x0014U
#define OPLOG_ID_PLC_C_ON			0x0015U
#define OPLOG_ID_PLC_S_OFF			0x0016U
#define OPLOG_ID_PLC_S_ON			0x0017U
#define OPLOG_ID_PLC_A_OFF			0x0018U
#define OPLOG_ID_PLC_A_ON			0x0019U
#define OPLOG_ID_PLC_R				0x0020U
// Event triggered 0x0030~0x003F
#define OPLOG_ID_ParamOnChange				0x0030U
#define OPLOG_ID_WorkPieceOnChange			0x0031U
#define OPLOG_ID_ToolCompensationOnChange	0x0032U
#define OPLOG_ID_UserOnChange				0x0033U
#define OPLOG_ID_SetAbsoluteHome			0x0034U
// Date stamp 0x0300~0x03FF
//    0x03XXYYZZ	XX=Year, YY=Month, ZZ=Day
#define OPLOG_ID_ISDATESTAMP(ID)	(((ID)&0xFF00)==0x0300U)
#define OPLOG_ID_GETDATE(ID,arg,year,month,day)		(year)=(ID)&0x00FF;(month)=(arg)>>8;(day)=(arg)&0x00FF
#define OPLOG_ID_DATESTAMP			0x0300U
// Time stamp 0x0400~0x04FF
//    0x04XXYYZZ	XX=Second, YY=Hour, ZZ=Minute
#define OPLOG_ID_ISTIMESTAMP(ID)	(((ID)&0xFF00)==0x0400U)
#define OPLOG_ID_GETTIME(ID,arg,hour,minute,sec)	(sec)=(ID)&0x00FF;(hour)=(arg)>>8;(minute)=(arg)&0x00FF
#define OPLOG_ID_TIMESTAMP			0x0400U
// System Error 0x0801~0x080F
#define OPLOG_ID_OPLOGPOSTERROR		0x0804U
// Alarm 0x0C00~0x0CFF
// 0xWCXXYYYY, XX=ClassID, YYYY=ObjectID(6bit), AlarmID(10bit, 0~9 bit of AlarmID), W=(10~11 bit of AlarmID)
// need 12-bit to handle the AlarmID
#define OPLOG_ALARMMESSAGE(ClassID, ObjectID, AlarmID)	( 0x0C000000U | ( (UINT32)(ClassID)<<16 ) | ( (UINT32)(ObjectID)<<10 ) | ( AlarmID & 0x3FF ) | ( ( AlarmID & 0xC00 ) << 20 ) )
#define OPLOG_ID_ISALARM(ID)		( ( (ID)&0x0F00 ) == 0x0C00U )
#define OPLOG_ID_ALARM				0x0C00U

// MMI 0x1000~0x1FFF
#define OPLOG_ID_ISMMI(ID)			(((ID)&0xF000U)==0x1000U)
#define OPLOG_ID_MMI_STARTUP		0x1002U
#define OPLOG_ID_MMI_SHUTDOWN		0x1003U
#define OPLOG_ID_MMI_ACTION			0x1004U
//#define OPLOG_ID_MMI_SCREEN		0x1005U

#define OPLOG_LOG_PLC
#define OPLOG_LOG_ALARM
#define OPLOG_LOG_PARAM
#define OPLOG_LOG_TIMESTAMPTIMER	1800000U	// in milisecond
// Parameter for test only
//#define OPLOG_LOG_TIMESTAMPTIMER	60000U	// in milisecond

extern "C" {
	void OPLogInit(char *lpFileName, int nReadBufferBlockSize, int nFileBlockCountLimit, int nBackFileCount);
	void OPLogDeinit();
	HRESULT CNCAPI OPLogPostDate();
	HRESULT CNCAPI OPLogPostTime();
	HRESULT CNCAPI OPLogFlushFullBufferOnly();
	BOOL CNCAPI OPLog_isSetAxisPosition( int nNo );
	BOOL CNCAPI OPLog_isCBitEventNeedToBeLogged( int nNo );
	BOOL CNCAPI OPLog_isIBitEventNeedToBeLogged( int nNo );
}
#endif // #ifdef UNDER_CE
extern "C" {
	HRESULT CNCAPI OPLogDisable();
	HRESULT CNCAPI OPLogPost(UINT32 uLogData);
	HRESULT CNCAPI OPLogFlush();
	INT32 CNCAPI OPLogDump(UINT32 *hDumpHandle, UINT32 *lpLogData, UINT32 *lpuLogDataCount, BYTE bStart);
}

enum EOPLOGCBit {
	C_START = 0,				// C0
	FEEDHOLD = 1,				// C1
	E_STOP = 36,				// C36
	SET_AXIS_POS_1st = 25,		// C25
	SET_AXIS_POS_2nd = 26,		// C26
	SET_AXIS_POS_3rd = 27,		// C27
	SET_AXIS_POS_6th = 28,		// C28
	SET_AXIS_POS_4th = 230,		// C230
	SET_AXIS_POS_5th = 231,		// C231
	SET_AXIS_POS_7th = 232,		// C232
	SET_AXIS_POS_8th = 233,		// C233
	SET_AXIS_POS_9th = 234,		// C234
	SET_AXIS_POS_10th = 235,	// C235
	SET_AXIS_POS_11th = 236,	// C236
	SET_AXIS_POS_12th = 237,	// C237
	SET_AXIS_POS_13th = 238,	// C238
	SET_AXIS_POS_14th = 239,	// C239
	SET_AXIS_POS_15th = 240,	// C240
	SET_AXIS_POS_16th = 241		// C241
};

//------------------------------------------------------------
// System API
//------------------------------------------------------------
extern "C" {
	void CNCAPI GetSystemDateTime(LONG *wYear, LONG *wMonth, LONG *wDay, LONG *wHour, LONG *wMinute, LONG *wSecond);
	// get system date time function

	BOOL CNCAPI SetSystemDateTime(LONG wYear, LONG wMonth, LONG wDay, LONG wHour, LONG wMinute, LONG wSecond);
	// set system date time function
}

//------------------------------------------------------------
// Huge File Editor API
//------------------------------------------------------------
extern "C" {
	BOOL CNCAPI HugeNcExport( char *szSrc, char *szDst );
	// export huge nc file, if have HMF, merge HMF and export ncfile, or copy ncfile only.
}

//------------------------------------------------------------
// Event Trigger Manager API
//------------------------------------------------------------
extern "C" {
	void CNCAPI SetCncEvent( int nEvtID, DWORD dwParam );
	// to raise event to user mode
}

//------------------------------------------------------------
// Robot API
//------------------------------------------------------------
extern "C" {
	BOOL CNCAPI RobotCalKinematicTransform( const INT nCoordID, DOUBLE Input[], INT nLengthIn, DOUBLE Output[], INT &nLengthOut, BOOL bIKMode, INT &nAlarmID );
	// ( ROBOT used ) query robot FK/IK
	// if bIKMode is zero, get robot FK. Input is MCS, output is EndEffPosOri
	// Input = [C1,C2,C3,C4,C5,C6], Output = [X,Y,Z,A,B,C] ex: SCARA Input = [C1,C2,C3,C4,0,0], Output = [X,Y,Z,C,0,0]
	// else if bIKMode is ONE, get robot IK. Input is EndEffPosOri, output is MCS
	// Input = [X,Y,Z,A,B,C], Output = [C1,C2,C3,C4,C5,C6] ex: SCARA Input = [X,Y,Z,0,0,C], Output = [C1,C2,C3,C4,0,0]
	// when AlarmID is zero, means no error.

	BOOL CNCAPI RobotCalWeavingCrdAndDist( const INT nCoordID, DOUBLE StartPoint[], DOUBLE EndPoint[], DOUBLE &Distance, DOUBLE WeavingCoord[] );
	// ( ROBOT used ) calculate weaving coordinate and distance of start point and end point
	// CAUTION: this API will be delete after the weaving function move into kernel

	BOOL CNCAPI RobotToolCrdCalib4PtTeach( const INT nCoordID, INT nPoint, BOOL &bReady );
	// ( ROBOT used ) teach 4 TCP point and record

	BOOL CNCAPI RobotToolCrdCalib4PtDoCalibration( const INT nCoordID, DOUBLE ToolData[], DOUBLE EEfPos[], DOUBLE EEfPosMaxError[], DOUBLE &EEfPosMeanError );
	// ( ROBOT used ) Calibrate Tcp Point

	BOOL CNCAPI RobotToolCrdCalib4PtSaveToolData( const INT nCoordID, INT nNo, TCHAR Name[] );
	// ( ROBOT used ) Save ToolData

	BOOL CNCAPI RobotProtectZoneSet( const INT nCoordID, const INT nID );
	// ( ROBOT used ) call paramsync to get variables and set into superzision zone

	BOOL CNCAPI RobotProtectZoneCheckState( const INT nCoordID, BOOL State[], INT nLength );
	// ( ROBOT used ) query whether the zone is working

	BOOL CNCAPI RobotUserCrdCalib3PtTeach( const INT nCoordID, INT nStep );
	// ( ROBOT used ) teach target point

	BOOL CNCAPI RobotUserCrdCalib3PtCalAndSave( const INT nCoordID,INT nNo, TCHAR Name[] );
	// ( ROBOT used ) calculate the result and save

	BOOL CNCAPI RobotUserCrdGetData( const INT nCoordID, INT nNo, TCHAR Name[], DOUBLE XYZABC[] );
	// ( ROBOT used ) get user coordinate data, in IU

	BOOL CNCAPI RobotUserCrdSetData( const INT nCoordID, INT nNo, TCHAR Name[], DOUBLE XYZABC[] );
	// ( ROBOT used ) set user coordinate data, in IU

	BOOL CNCAPI RobotUserCrdClearAll( const INT nCoordID );
	// ( ROBOT used ) clear all user coordinates

	BOOL CNCAPI RobotUserCrdSetActiveID( const INT nCoordID, INT nUserCoordID );
	// ( ROBOT used ) change user coordinate

	BOOL CNCAPI RobotToolCrdGetData( const INT nCoordID, INT nNo, TCHAR Name[], DOUBLE XYZABC[] );
	// ( ROBOT used ) return tool coordinate data

	BOOL CNCAPI RobotToolCrdSetData( const INT nCoordID, INT nNo, TCHAR Name[], DOUBLE XYZABC[] );
	// ( ROBOT used ) set tool coordinate data

	BOOL CNCAPI RobotToolCrdClearAll( const INT nCoordID );
	// ( ROBOT used ) clear all tool coordinates

	BOOL CNCAPI RobotToolCrdSetActiveID( const INT nCoordID, INT nToolID );
	// ( ROBOT used ) change tool coordinate
}

//------------------------------------------------------------
// MPG API
//------------------------------------------------------------
extern "C" {
	BOOL CNCAPI IsExistMPG( int nMPGId );
	// is exist MPG

	int CNCAPI getMPGIncUnit( int nMPGId );
	// get MPG jog incremental unit

	DOUBLE CNCAPI getMPGDisplacement( int nMPGId );
	// get MPG Displacement

	DOUBLE CNCAPI getMPGOverride( int nMPGId );
	// get MPG Override
}

//------------------------------------------------------------
// Kernel Log API
//------------------------------------------------------------
extern "C" {
	void CNCAPI setKernelLogInhibit( BOOL bInhibit );
	// set kernel log inhibit
}

//------------------------------------------------------------
// Loader API
//------------------------------------------------------------
extern "C" {
	long CNCAPI GetLoaderAxesNumber( void );
	// get loader axes number
}

//------------------------------------------------------------
extern "C" {
	long UpdatePLC( void );
	// update PLC
}

//------------------------------------------------------------
// SerialParam API
//------------------------------------------------------------
extern "C" {
	int CNCAPI SerialSetPrmValue( EDeviceType nDeviceType, int nDeviceID, int nNo, long nValue, BOOL isParamSave = FALSE, BOOL isParamRestore = FALSE );
	// set serial device param value

	int CNCAPI SerialGetPrmValue( EDeviceType nDeviceType, int nDeviceID, int nNo, long &nValue );
	// get serial device param value

	int CNCAPI SerialGetPrmStatus( EDeviceType nDeviceType, int nDeviceID, int nNo );
	// set serial device param status

	int CNCAPI SerialParamReloadValue( EDeviceType nDeviceType, int nDeviceID, int nNo );
	// request param reload value

	BOOL CNCAPI SerialParamIsReady( EDeviceType nDeviceType );
	// is serial param ready

	BOOL CNCAPI ServiceReg( EDeviceType nDeviceType, INT nDeviceID, LONG &nHandle );
	// register to service order of serial devices

	BOOL CNCAPI ServiceUnReg( LONG nHandle );
	// un-register from service order of serial devices

	LONG CNCAPI StateVarGetCapacity( LONG nHandle );
	// state variable get capacity

	INT CNCAPI StateVarDump( LONG nHandle, INT nLength, BOOL &bParamNoHex, void *pBuffer );
	// state variable dump

	INT CNCAPI StateVarGetValue( LONG nHandle, INT nLength, LONG *pValue );
	// get state variable value
}

//------------------------------------------------------------
// SerialDevice API, for SyntecM3 Scope
//------------------------------------------------------------
extern "C" {
	ESupportStatus CNCAPI SerialIsSupportDAQ( EDeviceType nDeviceType, int nDeviceID );
	// whether DAQ channel is supported

	LONG CNCAPI SerialGetSampleFrequency( EDeviceType nDeviceType, int nDeviceID );
	// get sampling frequency, unit: Hz

	BOOL CNCAPI SerialGetSampleTime( EDeviceType nDeviceType, int nDeviceID, LONG &nMinPeriod, LONG &nActivePeriod );
	// get serial device sample time, unit: 0.01us

	BOOL CNCAPI SerialSetSampleDivider( EDeviceType nDeviceType, int nDeviceID, LONG nDivider );
	// set sampling divider

	BOOL CNCAPI SerialPutDAQChSetting( EDeviceType nDeviceType, int nDeviceID, int nDAQCh, BOOL bEnable, EDAQ_SELECT_TYPE nSelectType, LONG nMapIndex, EDAQ_Data_Type nDataType );
	// put DAQ channel setting

	BOOL CNCAPI SerialGetDAQChSetting( EDeviceType nDeviceType, int nDeviceID, int nDAQCh, BOOL &bEnable, LONG &nMapIndex, EDAQ_Data_Type &nDataType );
	// get DAQ channel setting

	BOOL CNCAPI SerialEnableDAQChannel( EDeviceType nDeviceType, int nDeviceID, int nDAQCh, BOOL bEnable );
	// enable DAQ channel to stand by

	BOOL CNCAPI SerialEnableSampleData( EDeviceType nDeviceType, int nDeviceID, BOOL bEnable );
	// enable serial device scope to get sample data

	BOOL CNCAPI SerialEnableAuxiliarySignal( EDeviceType nDeviceType, int nDeviceID, BOOL bEnable, EAUX_SIGNAL_TYPE nType );
	// enable auxiliary signal

	LONG CNCAPI SerialGetNumDAQChannel( EDeviceType nDeviceType, int nDeviceID );
	// get number of scope data acquisition channel

	BOOL CNCAPI SerialAdjustVelChirp( EDeviceType nDeviceType, int nDeviceID, LONG nStartFreq, LONG nEndFreq, LONG nDuringTime, LONG nMagnitude );
	// adjust the setting of velocity chirp signal
}

//------------------------------------------------------------
// ExtensionAPI
//------------------------------------------------------------
extern "C" {
	HRESULT CNCAPI ExtensionAPI( DWORD dwCode, BYTE *pBufferIn, DWORD dwSizeIn, BYTE *pBufferOut, DWORD dwSizeOut );
	// Extension API
}

//------------------------------------------------------------
// bode plot API
//------------------------------------------------------------
extern "C" {
	void CNCAPI BodeStartSampling( EDeviceType nDeviceType, int nDeviceID );
	// start sampling data for bode plot

	void BodeGetNotchDisplay( TNotchFilterData FilterData, TDisplayBoundary *pBoundData );
	// get notch filter display boundary
}

//------------------------------------------------------------
// APP Store API
//------------------------------------------------------------
extern "C" {
	BOOL CNCAPI InitialExtIODev( INT nDeviceID, INT nPortID, LONG nWriteStartRbit, LONG nWriteLength, LONG nReadStartRbit, LONG nReadLength );
	// initialize externel IO device
}
//------------------------------------------------------------
// Friction Adjust
//------------------------------------------------------------
extern "C" {

	void CNCAPI SetFricAdjustOrder( int nArgL, int nArgP );
	// set friction adjust order from G10 L1711 and G10 L1712

	BOOL CNCAPI FricAdjustIsReadyForRecord( void );
	// Check if CFrictionAdjust ready for record

}
//------------------------------------------------------------
// MACRO I/O
//------------------------------------------------------------
extern "C" {

	BOOL CNCAPI setOpPLCOutput( LONG nSourceType, LONG nSignalNum, LONG nValue );
	// set OpPLC output
	// given source type( O bit, R bit ), signal number( ex: R50.1, nSignalNum = 5001 )
	// nValue( 0: signal off, 1:signal on )

	INT CNCAPI RegisterOpPLCScanInfo( LONG nFuncID, LONG nInputType, LONG nInputNum, LONG nEdgeCondition, LONG nHoldTime, LONG nOutputType, LONG nOutputNum );
	// register OpPLC scanning info
	// given nFuncID, source type( I bit, A bit, R bit )
	// given signal number( ex: R50.1, nSignalNum = 5001 ), nEdgeCondition( 0: edge rise, 1: edge fall ), HoldTime( unit:us )
	// when trigger condition happens, do what output signal do

	void CNCAPI UnRegisterOpPLCScanInfo( LONG nFuncID );
	// unregister OpPLC scanning info

	void CNCAPI ClearSyncOutCommand( LONG nCoordIDInBit );
	// clear specified coordinate's syncout command
}

#endif // _CNCAPI_INCLUDED_
