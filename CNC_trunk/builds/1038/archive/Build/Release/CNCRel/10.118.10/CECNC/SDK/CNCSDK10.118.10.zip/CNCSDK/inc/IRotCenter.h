#if !defined(AFX_IROTCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
#define AFX_IROTCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "nstdlib.h"

class IRotCenter {
public:
	virtual ~IRotCenter( void ) {}
	// destructor

	virtual LONG CNCAPI getOpMode( int nID ) = 0;
	// get operation mode

	virtual LONG CNCAPI getTargetToolNumber( int nID ) = 0;
	// get target tool number

	virtual LONG CNCAPI getCurToolNumber( int nID ) = 0;
	// get current tool number

	virtual LONG CNCAPI getTorqueLimit( int nID ) = 0;
	// get torque limit in 0.01% rated torque

	virtual LONG CNCAPI getFbkPosition( int nID ) = 0;
	// get feedback position in 0.001 deg

	virtual LONG CNCAPI getFbkVelocity( int nID ) = 0;
	// get feedback velocity in RPM

	virtual LONG CNCAPI ReadTorqueLoad( int nID ) = 0;
	// read torque load in 0.01% rated torque

	virtual BOOL CNCAPI isRunning( int nID ) = 0;
	// is running

	virtual BOOL CNCAPI isFeedhold( int nID ) = 0;
	// is feedhold

	virtual BOOL CNCAPI isInAlarm( int nID ) = 0;
	// is alarm

	virtual BOOL CNCAPI isReady( int nID ) = 0;
	// is ready

	virtual BOOL CNCAPI isInPosition( int nID ) = 0;
	// is in position

	virtual BOOL CNCAPI isServoOn( int nID ) = 0;
	// is servo on

	virtual BOOL CNCAPI isHomeLatched( int nID ) = 0;
	// is home latched

	virtual BOOL CNCAPI isManualContMove( int nID ) = 0;
	// is manual continuous move

	virtual BOOL CNCAPI isMPGCtrl( int nID ) = 0;
	// is MPG control

	virtual void CNCAPI GetTypeOfChArray( LONG nType[] ) = 0;
	// get type of channel array

	virtual BOOL CNCAPI TuningIsSupport( int nID ) = 0;
	// check SPLC tuning is supported

	virtual void CNCAPI TuningGetDefault( int nID, int &nTuningMode, int &nMachineType ) = 0;
	// get tuning default data

	virtual void CNCAPI TuningSetData( int nID, int nTuningMode, int nMachineType ) = 0;
	// set tuning data

	virtual void CNCAPI TuningStart( int nID ) = 0;
	// start tuning

	virtual void CNCAPI TuningStop( int nID ) = 0;
	// stop tuning

	virtual void CNCAPI TuningGetStatus( int nID, BOOL &bIsFinished, int &nResult ) = 0;
	// get tuning status

	virtual void CNCAPI setWatchMode( int nID, BOOL bWatchMode ) = 0;
	// set watch mode
};

#endif // !defined(AFX_IROTCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)