#pragma once

class CJAllocateOnlyHeap
{
public:
	CJAllocateOnlyHeap( DWORD dwNumOfElement, DWORD dwElementSize, BOOL bZeroMemory );
	~CJAllocateOnlyHeap(void);

	LPVOID allocate( DWORD nLength );
	void freeAll(void);
private:
	struct TNode {
		TNode *lpNext;
	};

	DWORD m_dwPageSize;
	UINT m_uMemFlags;
	TNode *m_lpMemList;

	LPBYTE m_lpCursor;
	LPBYTE m_lpBound;

	// helper method
	LPVOID newMemoryPage( void );
};
