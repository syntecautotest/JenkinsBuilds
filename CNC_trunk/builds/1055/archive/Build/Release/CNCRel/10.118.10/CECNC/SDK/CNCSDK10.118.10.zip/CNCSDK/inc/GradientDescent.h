#if !defined(_CGRADIENTDESCENT_H____INCLUDED_)
#define _CGRADIENTDESCENT_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_NUMOF_FCN					5

class CGradientDescent
{
public:
	CGradientDescent( int NumParam );
	// constructor

	virtual ~CGradientDescent( void );
	// destructor

	void SetMaxItr( int Itr );
	// set maximum iterations of optimization process

	void SetWeighting( double Weight[] );
	// set weightings of all objective functions, objective functions must be set first

	void SetObjFcn( IObjFcnEvaluator *pObjFcn );
	// set objective functions

	double EvalFcnValue( TOptParam *pPrm );
	// evaluate weighted function value

	void Optimize( double TargetFcnValue, double *pFcnVal, TOptParam *pPrm, TOptParam *pNormalizeFactor, TOptParam *pLowBound, TOptParam *pUpBound );
	// start optimization process

private:
	BOOL EvalParam( TOptParam *pPrm, TOptParam *pNormalizeFactor, TOptParam *pLowBound, TOptParam *pUpBound );
	// evaluate new parameters in steepest gradient direction

	double EvalTotalGradient( TOptParam *pGradient, TOptParam *pPrm );
	// evaluate weighted gradient vector, and return length of the vector

	void CalGradient( IObjFcnEvaluator *pObjFcn, TOptParam *pGradient, TOptParam *pPrm );
	// calculate gradient of function according to current parameters

	int m_nNumOfParam;
	// number of parameters

	int m_nNumObjFcn;
	// number of objective function

	double m_eWeight[MAX_NUMOF_FCN];
	// weightings of objective functions

	IObjFcnEvaluator *m_pObjFcnStore[MAX_NUMOF_FCN];
	// objective functions

	int m_nMaxItr;
	// maximum iterations of optimization process

	TOptParam m_NormalizeStep;
	// step size of normalized parameters
};

#endif // !defined(_CGRADIENTDESCENT_H____INCLUDED_)
