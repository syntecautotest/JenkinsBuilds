//
//  CIO(Common I/O Card Interface)
//

#ifndef _cio_h_
#define _cio_h_

#include "nstdlib.h"
#include "AlarmDef.h"

// alaram flag bit-mask				    
#define	ALARM_NoError					0L
#define	ALARM_IOTransmitFailure			0x00000001
#define	ALARM_M3IOCommErr				0x00000002
#define	ALARM_M3IOErr					0x00000004
#define	ALARM_IOOverload				0xFFFF0000

// alarm flag ID
#define	ALMID_IOTransmitFailure			1

#define MAX_DIO_LEN		( 32 )
#define MAX_AIO_LEN		( 16 )

#ifndef TDRIVEROBJECT_DEFINE
#define TDRIVEROBJECT_DEFINE 1

struct TDriverObject {
	HINSTANCE		m_hModule;			// module handle of this driver

	void (PFNCNCAPI *DriverUnload)( TDriverObject *pDriverObject );
	// driver unload function, this function will be called when specified
	// driver been unload.

	DWORD			m_DriverData[10];	// private storage for driver usage
};
// data structure for device driver

typedef BOOL (PFNCNCAPI *TPFNDriverLoad)( TDriverObject *pDriverObject, char *RegistryPath );
// typedef for DriverLoad entry point
// Note: the DriverLoad entry ordinal number should be @1

#endif // TDRIVEROBJECT_DEFINE

class IMPGChannel;
class ILatchIBitChannel;

//  Common I/O Interface
class ICIODriver
{
public:
	virtual void CNCAPI GetIOMapHint( LONG &nHintID ) = 0;
	// get io map hint

	virtual void CNCAPI getTableInfo( LONG nType, LONG &nLength_I, LONG &nLength_O, BOOL &bFileGood ) = 0;
	// get io map table info

	virtual BOOL CNCAPI CheckLength( LONG nType, LONG nLength_I, LONG nLength_O ) = 0;
	// check if length matched

	virtual BOOL CNCAPI LoadTable( LONG nType, TMapTable *pTable_I, TMapTable *pTable_O ) = 0;
	// load io map table

	virtual void CNCAPI RestoreDefaultTable( LONG nType, LONG &nMsgID ) = 0;
	// restore to default io map table

	virtual BOOL CNCAPI SaveTable( LONG nType, TReadWriteTable *pWriteTable_I, TReadWriteTable *pWriteTable_O, LONG &nErrorID, CHAR *pError ) = 0;
	// save io map table

	virtual BOOL CNCAPI IsSRIEnabled( void ) = 0;
	// is sri enabled in io mapping

	virtual BOOL CNCAPI IsRestorable( void ) = 0;
	// is io mapping restorable

	virtual void CNCAPI setFilterMethod( INT nMethod ) = 0;
	// set the digital filter method

	virtual LONG CNCAPI ReadAlarmFlags( void ) = 0;
	// to read current alram status

	virtual void CNCAPI RefreshAlarmFlags( void ) = 0;
	// to refresh resetable alarm flag

	virtual void CNCAPI ScanMatrixIO( void ) = 0;
	//  To request I/O driver to scan matrix I/O

	virtual void CNCAPI ScanISignal( void ) = 0;
	//  To request I/O driver to scan input signals.

	virtual void CNCAPI ScanOSignal( void ) = 0;
	//  To request I/O driver to scan output signals.

	virtual IMPGChannel * CNCAPI GetMPGChannel( INT nIBit ) = 0;
	// to get MPG channel

	virtual BOOL CNCAPI LockLatchIBitChannel( ILatchIBitChannel *&pLatchIBitChannel, INT nIBit ) = 0;
	// to lock LatchIBitchannel

	virtual BOOL CNCAPI UnlockLatchIBitChannel( INT nIBit ) = 0;
	// to unlock LatchIBitchannel
};

#endif	// _cio_h_
