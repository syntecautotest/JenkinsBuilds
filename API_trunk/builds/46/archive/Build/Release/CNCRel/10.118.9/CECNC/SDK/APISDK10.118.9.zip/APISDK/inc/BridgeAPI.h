#if !defined(_BridgeAPI_INCLUDE_)
#define _BridgeAPI_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef __cplusplus
extern "C" {
#endif

#ifndef TSHAREMEMORY_STRUCT_
#define TSHAREMEMORY_STRUCT_
// TSHAREMEMORY_STRUCT_
enum EDevice_Type {
	DEV_L_REGISTER = 0,
	DEV_GLOBAL_VARIABLE,
	DEV_R_REGISTER,
	DEV_SYSTEM_VARIABLE,
	DEV_I_BIT,
	DEV_O_BIT,
	DEV_C_BIT,
	DEV_S_BIT,
	DEV_A_BIT,
	DEV_STATE_VARIABLE,
	DEV_PARAM,
	DEV_COORD_VARIABLE,
	DEV_TIMER_STATE,
	DEV_TIMER_TYPE,
	DEV_TIMER_SETTING,
	DEV_TIMER_ELAPSE,
	DEV_COUNTER_STATE,
	DEV_COUNTER_TYPE,
	DEV_COUNTER_SETTING,
	DEV_COUNTER_COUNT,
	DEV_AX_VARIABLE,
	// add new device here
	DEV_NOT_DEFINE = 255
};

typedef struct {
	BYTE nDevType;
	BYTE nCoordID;
	BYTE nGroupID;
	BYTE nFormat;
	DWORD nNo;
} TDevice;

typedef struct {
	TDevice tDev;
	TOcVariant ocVal;
} TDeviceInfo;

#endif // TSHAREMEMORY_STRUCT_

extern DWORD WINAPI BridgeAPI_GetHMIKey( void );
extern BOOL WINAPI BridgeAPI_isTCPIPMode( void );
extern HRESULT WINAPI BridgeAPI_FetchValueFromDeviceBuffer( TDevice* lpDev, TOcVariant* lpVal );
extern HRESULT WINAPI BridgeAPI_RegisterDipoleDevice( HANDLE hWnd, LONG nLength, BYTE* pBuffer );
extern HRESULT WINAPI BridgeAPI_UnRegisterDipoleDevice( HANDLE hWnd );

#ifdef __cplusplus
}
#endif 
#endif // !defined(_BridgeAPI_INCLUDE_)
