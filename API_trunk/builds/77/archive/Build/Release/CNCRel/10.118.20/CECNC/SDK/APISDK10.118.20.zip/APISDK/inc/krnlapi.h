#if !defined(_KrnlAPI_INCLUDE_)
#define _KrnlAPI_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef __cplusplus
extern "C" {
#endif

#include "CommonStruct.h"

//------------------------------------------------------------
// CNC interface code

HRESULT WINAPI KrnlAPI_CncParamGetCapacity( /*out*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_CncParamDump( /*out*/ TParamSpec *lpBuffer, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_CncParamPutValue( /*in*/ LONG nNo, /*in*/ LONG newVal ); 
HRESULT WINAPI KrnlAPI_CncParamGetValue( /*in*/ LONG nNo, /*out*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_ParamGetCapacity( /*in*/ int nType, int nID, /*out*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_ParamDump( /*in*/ int nType, int nID, /*out*/ TParamSpec *lpBuffer, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_ParamPutValue( /*in*/ int nType, int nID, LONG nNo, /*in*/ LONG newVal ); 
HRESULT WINAPI KrnlAPI_ParamGetValue( /*in*/ int nType, int nID, LONG nNo, /*out*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_NcStateDump( /*in*/ LONG nFirst, /*out*/ LONG *lpBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_NcDebugDump( /*in*/ LONG nFirst, /*out*/ LONG *lpBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_NcStateGetValue( /*in*/ LONG nNo, /*out*/ LONG *lpVal, HANDLE hClientLink = NULL );
HRESULT WINAPI KrnlAPI_NcStateGetCapacity( /*out*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_NcDebugGetCapacity( /*out*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_PlcDumpIBits( /*in*/ LONG nFirst, /*out*/ BYTE *lpBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_PlcDumpOBits( /*in*/ LONG nFirst, /*out*/ BYTE *lpBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_PlcDumpCBits( /*in*/ LONG nFirst, /*out*/ BYTE *lpBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_PlcDumpSBits( /*in*/ LONG nFirst, /*out*/ BYTE *lpBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_PlcDumpABits( /*in*/ LONG nFirst, /*out*/ BYTE *lpBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_PlcDumpRRegister( /*in*/ LONG nFirst, /*out*/ DWORD *lpBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_PlcDumpTimer( /*in*/ LONG nFirst, /*out*/ TLogicTimer *lBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_PlcDumpCounter( /*in*/ LONG nFirst, /*out*/ TLogicCounter *lBuffer, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_PlcGetIBit( /*in*/ LONG nNo, /*out*/ BYTE *lpVal );
HRESULT WINAPI KrnlAPI_PlcPutIBit( /*in*/ LONG nNo, /*in*/ BYTE newVal );
HRESULT WINAPI KrnlAPI_PlcGetOBit( /*in*/ LONG nNo, /*out*/ BYTE *lpVal );
HRESULT WINAPI KrnlAPI_PlcGetCBit( /*in*/ LONG nNo, /*out*/ BYTE *lpVal );
HRESULT WINAPI KrnlAPI_PlcPutCBit( /*in*/ LONG nNo, /*in*/ BYTE newVal );
HRESULT WINAPI KrnlAPI_PlcGetSBit( /*in*/ LONG nNo, /*out*/ BYTE *lpVal );
HRESULT WINAPI KrnlAPI_PlcPutSBit( /*in*/ LONG nNo, /*in*/ BYTE newVal );
HRESULT WINAPI KrnlAPI_PlcGetABit( /*in*/ LONG nNo, /*out*/ BYTE *lpVal );
HRESULT WINAPI KrnlAPI_PlcGetRRegister( /*in*/ LONG nNo, /*out*/ DWORD *lpVal );
HRESULT WINAPI KrnlAPI_PlcPutRRegister( /*in*/ LONG nNo, /*in*/ DWORD newVal );
HRESULT WINAPI KrnlAPI_PlcGetTimer( /*in*/ LONG nNo, /*out*/ TLogicTimer *lpVal );
HRESULT WINAPI KrnlAPI_PlcGetCounter( /*in*/ LONG nNo, /*out*/ TLogicCounter *lpVal );
HRESULT WINAPI KrnlAPI_PlcGetCapacity( /*out*/ TPlcCapacity *lpVal );
HRESULT WINAPI KrnlAPI_NcGlobalDump( /*[in]*/ LONG nFirst, /*[out]*/ TOcVariant *lpBuffer, /*[in]*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_NcGlobalGetValue( /*[in]*/ LONG nNo, /*[out]*/ TOcVariant *lpVal );
HRESULT WINAPI KrnlAPI_NcGlobalPutValue( /*[in]*/ LONG nNo, /*[in]*/ TOcVariant *lpNewVal );
HRESULT WINAPI KrnlAPI_NcGlobalGetCapacity( /*[out]*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_NcDumpPendingAlarm( /*out*/ TOcAlarmInfo *lpBuffer, /*[in]*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_NcDumpAlarmHistory( /*out*/ TOcAlarmInfo *lpBuffer, /*[in]*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_NcDownloadMDIBlocks( /*in*/ LPCTSTR lpszBlocks );
HRESULT WINAPI KrnlAPI_NcGetMDIBlocks( /*out*/ TCHAR *lpBuffer, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_NcCoordVarDump( /*in*/ LONG CoordID, /*in*/ LONG nFirst, /*out*/ TOcVariant *lpBuffer, /*[in]*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_NcExecuteBlocks( /*in*/ LPCTSTR lpszBlocks );
HRESULT WINAPI KrnlAPI_NcPutWorkpieceZero( /*in*/ LONG nNo, /*in*/ TWorkpieceFrame *lpWF );
HRESULT WINAPI KrnlAPI_NcPutExternWorkpieceZero( /*in*/ TWorkpieceFrame *lpWF );
HRESULT WINAPI KrnlAPI_NcGetWorkpieceZero( /*in*/ LONG nFirst, /*out*/ TWorkpieceFrame *lpBuffer, /*[in]*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_NcGetExternWorkpieceZero( /*out*/ TWorkpieceFrame *lpWF );
HRESULT WINAPI KrnlAPI_NcCoordVarGetValue( /*in*/ LONG CoordID, /*in*/ LONG nNo, /*out*/ TOcVariant *lpVal );
HRESULT WINAPI KrnlAPI_NcCoordVarPutValue( /*in*/ LONG CoordID, /*in*/ LONG nNo, /*in*/ TOcVariant *lpNewVal );
HRESULT WINAPI KrnlAPI_CncRegistryPutValue( /*in*/ LONG nNo, /*in*/ LONG newVal );
HRESULT WINAPI KrnlAPI_CncRegistryGetValue( /*in*/ LONG nNo, /*out*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_CncSaveString( /*in*/ LONG nMode, /*in*/ LONG nNo, /*in*/ LPCTSTR lpszVal );
HRESULT WINAPI KrnlAPI_CncLoadString( /*in*/ LONG nMode, /*in*/ LONG nNo, /*out*/ TCHAR *lpBuffer, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_NcGetToolCompensation( /*in*/ LONG nNo, /*out*/ TToolOffset *lpBuffer );
HRESULT WINAPI KrnlAPI_NcPutToolCompensation( /*in*/ LONG nNo, /*in*/ TToolOffset *lpVal );
HRESULT WINAPI KrnlAPI_ParseMacro( /*in*/ LPCTSTR lpszVal, /*out*/ TCHAR *lpBuffer, /*[in]*/ LONG nLength, /*in*/ LONG NShift );
HRESULT WINAPI KrnlAPI_NcPutRelativePosition( /*in*/ DWORD mask,  /*in*/ LONG *lpVal, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_NcReset();
HRESULT WINAPI KrnlAPI_ParamImport( /*in*/ LPCTSTR lpszFilename );
HRESULT WINAPI KrnlAPI_ParamExport( /*in*/ LPCTSTR lpszFilename );
HRESULT WINAPI KrnlAPI_RegistryImport( /*in*/ LPCTSTR  lpszFilename );
HRESULT WINAPI KrnlAPI_RegistryExport( /*in*/ LPCTSTR lpszFilename );
HRESULT WINAPI KrnlAPI_NcGetPendingAlarmSize( /*out*/ LONG *lpVal );
HRESULT WINAPI KrnlAPI_NcClearHint();
HRESULT WINAPI KrnlAPI_NcClearHistory();
HRESULT WINAPI KrnlAPI_NcSetCryptologyKey( /*in*/ LPCTSTR lpszKeyValue );
HRESULT WINAPI KrnlAPI_NcGetPrecisionParameter( /*in*/ LONG nNo, /*out*/ TPrecisionRecord *lpPR );
HRESULT WINAPI KrnlAPI_NcGetVersionInfo( /*out*/ TVersionInfo *lpBuffer, /*[in]*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_UT_getPassSeed(/*out*/ TCHAR *lpPassSeed, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_SWOP_getSerialNo(/*out*/ TCHAR *lpSerialNo, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_SWOP_getModel(/*out*/ TCHAR *lpModel, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_SWOP_getMachine(/*out*/ TCHAR *lpMachine, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_SWOP_getEnabledAxes();
HRESULT WINAPI KrnlAPI_GetLoaderAxesNumber();
HRESULT WINAPI KrnlAPI_HW_GetPlatformName( /*out*/ TCHAR *lpBuffer, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_NcGetDesKey( TCHAR * lpszKeyValue, unsigned long count );
HRESULT WINAPI KrnlAPI_MultiTCPNcGetDirs( /*in*/ HANDLE hClientLink, /*in*/ LPCTSTR lpRegKey, /*out*/ TCHAR *lpBuffer, /*in*/ LONG nLength );
HRESULT WINAPI KrnlAPI_GetCncDirFilesInfo( /*in*/ LPCTSTR lpDir, /*in*/ LONG nLengthToRead, /*out*/ TOcMyFileInfo *lpBuffer, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI KrnlAPI_NcIsBlockGrammarError( /*in*/ LPCTSTR lpString, /*in*/ LONG nLengthToRead, /*out*/ BOOL *lpBuffer );
HRESULT WINAPI KrnlAPI_NcGetMainProgramName( /*in*/ int nCoordID, /*out*/ TCHAR *lpName );
HRESULT WINAPI KrnlAPI_CoordStateGetValue( /*in*/ LONG nCoordID, /*in*/ LONG nNo, TOcVariant *pValue );
HRESULT WINAPI KrnlAPI_NcGetEnvKeyName( char KeyName[] );
HRESULT WINAPI KrnlAPI_AxStateGetValue( /*in*/ LONG nCoordID, /*in*/ LONG nNo, TOcVariant *pValue );

//-------------------------------------------------------------
// CNC simulation interface
DWORD WINAPI KrnlAPI_SMCreate( void );
HRESULT WINAPI KrnlAPI_SMClose( /*in*/ DWORD dwHandle );
DWORD WINAPI KrnlAPI_SMUpdateKey( /*in*/ DWORD dwHandle );
HRESULT WINAPI KrnlAPI_SMPlay( /*in*/ DWORD dwHandle, LONG CoordID, LPCTSTR lpszProgName, LONG nSimuType );
HRESULT WINAPI KrnlAPI_SMStop( /*in*/ DWORD dwHandle );
HRESULT WINAPI KrnlAPI_SMGetBlockData( /*in*/ DWORD dwHandle, /*out*/ TNcBlockData *lpBuffer, /*in*/ DWORD nLengthToRead, /*out*/ LPDWORD lpnLengthRead, /*out*/ BOOL *lpbSucceeded );
HRESULT WINAPI KrnlAPI_SMGetAxisDimContexts( /*om*/ DWORD dwHandle, /*out*/ TAxisDimContext *lpBuffer, /*in*/ DWORD nLengthToRead, /*out*/ LPDWORD lpnLengthRead );
HRESULT WINAPI KrnlAPI_SMGetAlarmLocation( /*in*/ DWORD dwHandle, /*out*/ TCHAR *lpszProgName, /*in*/ LONG nLength, /*out*/ LPLONG lpnLineNo, /*out*/ LPLONG lpnSequenceNo );
HRESULT WINAPI KrnlAPI_SMSetSearchPath( /*in*/ DWORD dwHandle, /*in*/ LPCTSTR lpszPath );
HRESULT WINAPI KrnlAPI_SMGetSearchPath( /*in*/ DWORD dwHandle, /*out*/ TCHAR *lpBuffer, /*in*/ DWORD nLength );
HRESULT WINAPI KrnlAPI_SMIsEOF( /*in*/ DWORD dwHandle, /*out*/ BOOL *lpbEOF );
HRESULT WINAPI KrnlAPI_SMIsAlarm( /*in*/ DWORD dwHandle, /*out*/ BOOL *lpbAlarm );
HRESULT WINAPI KrnlAPI_SMPutMDIBlocks( /*in*/ DWORD dwHandle, /*in*/ LPCTSTR lpszBlocks );
HRESULT WINAPI KrnlAPI_SMGlobalGetValue( /*in*/ DWORD dwHandle, /*in*/ LONG nNo, /*out*/ TOcVariant *lpVal );
HRESULT WINAPI KrnlAPI_SMGetAlarmList( /*in*/ DWORD dwHandle, /*out*/ TOcAlarmInfo *lpBuffer, /*in*/ DWORD nLengthToRead, /*out*/ LPDWORD lpnLengthRead );
HRESULT WINAPI KrnlAPI_SMSetStartLineNo( /*in*/ DWORD dwHandle, LONG nLineNumber );
HRESULT WINAPI KrnlAPI_SMUpdateLife( void );
HRESULT WINAPI KrnlAPI_SMGetCycleTimeEstResult( /*in*/ DWORD dwHandle, /*out*/ TCycleTimeEstResult *lpBuffer );
//------------------------------------------------------------------
// XMLDB interface
HRESULT WINAPI KrnlAPI_XMLDB_SetDatabaseLocation( LPCTSTR lpszLocation );
HRESULT WINAPI KrnlAPI_XMLDB_SetSchemaLocation( LPCTSTR lpszLocation );
HRESULT WINAPI KrnlAPI_XMLDB_SaveCycleData( LPCTSTR lpszTableName, LPCTSTR lpszCycleName, DWORD nKey );
HRESULT WINAPI KrnlAPI_XMLDB_LoadCycleData( LPCTSTR lpszTableName, TCHAR *lpCycleName, UINT nLength, DWORD nKey );
HRESULT WINAPI KrnlAPI_XMLDB_NewCycleData( LPCTSTR lpszCycleName, DWORD nKey );
HRESULT WINAPI KrnlAPI_XMLDB_DeleteTable( LPCTSTR lpszTableName, DWORD nKey );
HRESULT WINAPI KrnlAPI_XMLDB_GetTableList( LPCTSTR lpszTableDirName, TCHAR * lpBuffer, UINT nLength, DWORD nKey );
HRESULT WINAPI KrnlAPI_XMLDB_GetXLDevice( long nNo, TCHAR *lpBuffer, UINT nLength, DWORD nKey );
HRESULT WINAPI KrnlAPI_XMLDB_PutXLDevice( long nNo, DWORD nKey, LPCTSTR lpszNewVal );

//------------------------------------------------------------
// OPLog interface code
HRESULT WINAPI KrnlAPI_OPLogFlush( void );

#ifdef __cplusplus
}
#endif 
#endif // !defined(_KrnlAPI_INCLUDE_)
