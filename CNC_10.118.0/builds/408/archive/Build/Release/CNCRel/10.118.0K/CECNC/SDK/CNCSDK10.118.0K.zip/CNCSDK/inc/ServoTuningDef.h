#if !defined(_SERVOTUNINGDEF_H____INCLUDED_)
#define _SERVOTUNINGDEF_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define UNIT_USECtoSEC			( 1e-6 )
#define UNIT_MINtoSEC			( 60 )

struct TFrictionCoeff
{
	double StaticFricPos;
	double StaticFricNeg;
	double Reserved[ 6 ];
};

// data struct of driver simulator
struct TDrvSimuParam {
	double Ad[ 16 ];
	double Bd[ 12 ];
	double Cd[ 16 ];
	double Dd[ 12 ];
	double BLUtoDrvInput;
	double RatedTRQtoNM;
};

enum EFricComp {
	FRIC_OFF = -1,
	FRIC_POS,
	FRIC_VFF,
	FRIC_TFF,
};

// data struct of speed glitch compensation param, but only with one direction
struct TVFFParam {
	LONG	nRiseTime;		// (ms)
	LONG	nHoldTime;		// (ms)
	LONG	nDecayTime;		// (ms)
	LONG	nDelayTime;		// (ms)
	LONG	nRiseType;
	LONG	nReserved;
	DOUBLE	RiseRatio;
	DOUBLE	DecayRatio;
	DOUBLE	PeakHeight;		// (um/sec)
};

#endif // _SERVOTUNINGDEF_H___INCLUDED_