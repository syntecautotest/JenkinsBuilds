#if !defined(_IFEEDBACKPOSITION_H____INCLUDED_)
#define _IFEEDBACKPOSITION_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IFeedbackPosition
{
public:
	virtual ~IFeedbackPosition( void ) {}
	// destructor

	virtual long getFeedbackPosition( void ) = 0;
	// get feedback position

	virtual long ReadAbsoluteCounter( void ) = 0;
	// get absolute counter
};
#endif // !defined(_IFEEDBACKPOSITION_H____INCLUDED_)
