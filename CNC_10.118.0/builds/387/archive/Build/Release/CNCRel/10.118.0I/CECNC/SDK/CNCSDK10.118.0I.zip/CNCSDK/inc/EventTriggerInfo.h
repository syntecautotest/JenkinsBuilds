#if !defined(_EVENTTRIGINFO_INCLUDE_)
#define _EVENTTRIGINFO_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// *** CAUTION:													 ***
// *** DO NOT CHANGE ANY MEMBER between No.1 to No.50			 ***
// *** because this need to be consistent with definition in mmi ***
enum EEventID
{
	EVT_tick1ms = 1,		// 1.
	EVT_tick2ms,			// 2.
	EVT_tick5ms,			// 3.
	EVT_tick10ms,			// 4.
	EVT_tick50ms,			// 5.
	EVT_tick100ms,			// 6.
	EVT_tick1000ms,			// 7.
	EVT_IBitOn,				// 8.
	EVT_IBitOff,			// 9.
	EVT_OBitOn,				// 10.
	EVT_OBitOff,			// 11.
	EVT_CBitOn,				// 12.
	EVT_CBitOff,			// 13.
	EVT_SBitOn,				// 14.
	EVT_SBitOff,			// 15.
	EVT_ABitOn,				// 16.
	EVT_ABitOff,			// 17.
	EVT_RegisterOn,			// 18.
	EVT_RegisterOff,		// 19.
							// 20. this number is no body use, can insert to here
	EVT_OnReady = EVT_RegisterOff + 2,	// 21. enter ready
	EVT_OnReadyToCStart,	// 22. start cycle start
	EVT_OnFHold,			// 23. enter feed hold
	EVT_OnFHoldToCStart,	// 24. from feed hold to cycle strat
	EVT_OnBStop,			// 25. enter bstop
	EVT_OnBStopToCStart,	// 26. from bstop to cycle start
	EVT_OnMOTAlarm,			// 27. motion alarm
	EVT_OnHoming,			// 28. homing
	EVT_OnG54_Change,		// 29. change G54Pxx
	EVT_OnG54_Setting,		// 30. set G54Pxx
	EVT_OnG92_Setting,		// 31. set G92 table
	EVT_OnExtOffset_Setting,// 32. set basic table
	EVT_OnToolLen_Setting,	// 33. set tool length
	EVT_OnToolNum_Change,	// 34. change tool number
	EVT_OnEnableHCS,		// 35. start HCS
	EVT_OnDisableHCS,		// 36. end HCS
	EVT_OnSetHCS,			// 37. set HCS setting
	EVT_OnPLCAxisExe,		// 38. execute PLC axis
	EVT_OnPLCAxisMoveTo,	// 39. PLC axis move to
	EVT_OnFullCouple,		// 40. full couple complete
	EVT_OnAlarm,			// 41. alarm happene
	EVT_SeqChange,			// 42. Execute to which program seqence number
	EVT_MCodeChange,		// 43. Execute to which MCode number
	EVT_SpindleRun,			// 44. if spindle is from stop to run
	EVT_SpindleStop,		// 45. if spindle is from run to stop
	EVT_Couple,				// 46. if tapping is from un-coupled to coupled
	EVT_NotCouple,			// 47. if tapping is from coupled to un-coupled
	EVT_ToolTableChange,	// 48. tool table changed
	EVT_OverHardPosLimit,	// 49. over positive hard limit
	EVT_OverHardNegLimit,	// 50. over negative hard limit
							// 51. this number reserved for represent as last event that mmi can recordnized
	EVT_OnSkipActive = EVT_OverHardNegLimit + 2,	// 52. on skip signal active
	EVT_OnDrvSkipActive,	// 53. on skip signal active by driver
	EVT_MotParamChanged,	// 54. motion parameters changed
	EVT_WPInfoChanged,		// 55. work plane changed
	EVT_RotAxesInfoChanged,	// 56. rotation axes information changed
	EVT_SetPathAxis,		// 57. set path axis selection 
	EVT_PutAxisRS,			// 58. put ratio square of virtual circle radius
	EVT_ResetAxisRS,		// 59. reset ratio square of virtual circle radius
	EVT_ChannelCountChanged,// 60. channel count changed
	EVT_ResetHappened,		// 61. on motion planner reset happened
	EVT_AbortHappened,		// 62. on motion planner abort happened
	EVT_DispatchMPChanged,	// 63. dispatch motion planner changed
	EVT_FControlModeChanged,// 64. feedrate control mode changed
	EVT_HPCCSwitchChanged,	// 65. HPCC switch changed
	EVT_MCodeGroupTableChanged,	// 66. M code group table changed
	EVT_NofityMPWaitFinished,	// 67. notify all objects that need to know the motion planner waiting status is finished
	EVT_OnCriticalAlarm,	// 68. on critical alarm
	EVT_BurnInModeRequest,	// 69. system burn-in mode request
	EVT_PartCountReached,	// 70. Part Count is reached
	EVT_PartCountStop,		// 71. Meet Part Count M Code and need to stop
	EVT_TrajMPChanged,		// 72. Trajectory motion planner changed
	EVT_PLCCallReset,		// 73. reset happened from MSTChannel
	EVT_IntMCodeReadSignal,	// 74. internal M code read signal
	EVT_CoordIDMSTSignal,	// 75. MST signals happen in which coordinate
	EVT_SpindleNumber,		// 76. which spindle is used in coordinate
	EVT_MBSTRequest,		// 77. M/B/S/T code request
	EVT_DenSignal,			// 78. DEN signal
	EVT_MBSTCode,			// 79. M/B/S/T code
	EVT_PartCountPulse,		// 80. part count pulse
	EVT_BPTLimitInhibit,	// 81. BPT limiter inhibit
	EVT_KinematicDataDumped,// 82. kinematic data dumped
	EVT_CNCFeedhold,		// 83. CNC has already entered feedhold state
	EVT_FFInhibitChanged,	// 84. Feed Forward inhibit changed
	EVT_ForcedReset,		// 85. Force Coordinate Reset
	EVT_OnModeChange,		// 86. CNC mode change
	EVT_RobotSyncCoordinate,// 87. robot sync. coordinate
	EVT_SerialSampleDataDumped,	// 88. Serial Sample data dump, Syntec M3
	EVT_Interpolation,		// 89. triggered once when interpolation tick fired
	EVT_SubInterpolation,	// 90. triggered once when sub-interpolation tick fired
	EVT_OnDateChange,		// 91  on date change
	EVT_IsInAlarm,			// 92  is system in alarm

	// for count enum
	EVT_Last,
};

int const COUNT_TMR_EVT = EVT_tick1000ms;
int const COUNT_SINGLE_EVT = EVT_Last - 1;

// *** CAUTION:													 ***
// *** DO NOT CHANGE ANY MEMBER between No.1 to No.26			 ***
// *** because this need to be consistent with definition in mmi ***
enum EDataType {
	DT_UNKNOWN = -1,
	DT_MACHINE_POS = 0,			// 0. Machine coordinate value
	DT_SETTABLE_OFFSET,			// 1. Settable offset
	DT_BASIC_OFFSET,			// 2. Basic offset
	DT_G92_OFFSET,				// 3. G92 offset
	DT_HCS_OFFSET,				// 4. Hand offset
	DT_HCS_CHANGE,				// 5. Hand change
	DT_SYSTIME,					// 6. System time
	DT_FEEDBACK,				// 7. Servo feedback
	DT_HOMING,					// 8. Homing info.
	DT_ALARM,					// 9. Axes alarm
	DT_TOOL_INFO,				// 10. Tool detail
	DT_COORD_INFO,				// 11. All coord information
	DT_SERVO_CMD,				// 12. Servo Command
	DT_DUAL_FEEDBACK,			// 13. Dual feedback
	DT_GLOBAL_VAR,				// 14. Value of setting Global variable
	DT_SYSTEM_VAR,				// 15. Value of setting System variable
	DT_DEBUG_VAR,				// 16. Value of setting Debug variable
	DT_I_BIT,					// 17. I bit value
	DT_O_BIT,					// 18. O bit value
	DT_C_BIT,					// 19. C bit value
	DT_S_BIT,					// 20. S bit value
	DT_A_BIT,					// 21. A bit value
	DT_SPINDLE_FEEDBACK_VEL,	// 22. spindle servo velocity feedback
	DT_SPINDLE_SERVOCMD_VEL,	// 23. spindle velocity servo command
	DT_REGISTER,				// 24. register value
	DT_DEVICE_VAL,				// 25. register. IOCSA value
	DT_ABSOLUTE_FEEDBACK,		// 26. Servo feedback with coordinate shift
								// 27. this number reserved for represent as last data type that can be recognized by mmi
	DT_KLOG_MRP = DT_ABSOLUTE_FEEDBACK + 2,	// 28. TMotReqPkt
	DT_KLOG_LARAW,							// 29. TLANode
	DT_KLOG_LAMAT,							// 30. TLANode
	DT_KLOG_PVT,							// 31. TPVTSegment
	DT_KLOG_SEG,							// 32. TCtrlBlk
	DT_KLOG_CMD,							// 33. TServoCommand
	DT_KLOG_DISP,							// 34. TDispCalculator
	DT_DATAAQ,					// 35, Serial data acquisiton , Syntec M3 Scope
	DT_POS_SERVO_CMD_HP,		// 36, High Precision Servo Position Command
	DT_POS_FEEDBACK_HP,			// 37, High Precision Servo Position Feedback
	DT_VFFCOMP_VALUE,			// 38, VFF glitch compensation value
	DT_POS_SERVO_CMD_HP_MULTI,	// 39. Multi Servo Command
	DT_POS_FEEDBACK_HP_MULTI,	// 40. Multi Servo feedback
	// add new data type at here.

	DT_Last,					// for count enum

	DT_BUFFER_OVERFLOW = 500	// for marking error
};

int const CONST_DATA_TYPE_NUMBER = DT_Last;
int const CONST_KLOG_BASE = DT_KLOG_MRP;
int const CONST_KLOG_NUMBER = DT_KLOG_DISP - DT_KLOG_MRP + 1;

#endif // !defined(__EVENTTRIGINFO_INCLUDE_)

