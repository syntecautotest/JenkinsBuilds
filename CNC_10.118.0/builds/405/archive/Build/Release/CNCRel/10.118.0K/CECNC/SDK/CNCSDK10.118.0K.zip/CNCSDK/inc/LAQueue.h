#if !defined(_LAQUEUE_H____INCLUDED_)
#define _LAQUEUE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLANodePool;
class CLAQueue
{
public:
	CLAQueue( int size );
	~CLAQueue(void);

	BOOL isEmpty( void );
	// query whether queue is empty

	BOOL isFull( void );
	// query whether queue is full

	void FreeAll( CLANodePool *pLAPool );
	// abort all query.

	void add( TLANode *pNode );
	// add specified node into queue tail

	int getCount( void );
	// return the number of node inside queue

	int getFreeCount( void );
	// return the number of free node inside queue

	TLANode *remove( void );
	// remove and return head node.

	TLANode *peek( int index );
	// to peek a node with specified index relative to queue head, index is 0 for head node.

	TLANode *rpeek( int index );
	// to peek a node with speciifed index relative to queue tail, index is 0 for tail node.

private:
	CRTMutex m_cs;
	// mutex for object state

	TLANode **m_ppBuffer;
	// queue buffer

	int m_size;
	// queue size

	int m_head;
	// index of queue header

	int m_count;
	// the number of node in this queue
};

#endif // !defined(_LAQUEUE_H____INCLUDED_)
