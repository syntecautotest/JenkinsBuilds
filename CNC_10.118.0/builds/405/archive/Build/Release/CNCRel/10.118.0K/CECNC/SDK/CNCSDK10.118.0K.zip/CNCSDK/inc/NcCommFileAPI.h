//
//	NcCommFileAPI.H
//
//	Nc Comm File Exported Interface
//

#if !defined(_NCCOMMFILEAPI_INCLUDED_)
#define _NCCOMMFILEAPI_INCLUDED_

#include "nstdlib.h"

#ifdef __cplusplus
extern "C" {
#endif

struct TNCCFDCB {
	DWORD	BaudRate;				// current baud rate
	BYTE	ByteSize;				// number of bits/byte, 4-8
	BYTE	Parity;					// 0-4=no,odd,even,mark,space
	BYTE	StopBits;				// 0,1,2 = 1, 1.5, 2
	BYTE	DCType;					// device type
	BYTE	fDC3Parity;				// the parity of device control code 3
	BYTE	DCRole;					// the role of device control protocol
	BYTE	EOBOut;					// end-of-block output code
	BYTE	FlowControl;			// flow control method
	BYTE	DataCode;				// Data output code
};
// CNC communication device control block

#define NCCF_DCROLE_CNC		0
#define NCCF_DCROLE_DEVICE	1
// the role of DC1-DC4 device control protocol

#define NCCF_DATACODE_ASCII	0
#define NCCF_DATACODE_EIA	1
#define NCCF_DATACODE_ISO	2
// data encode mode

#define NCCF_FC_NONE		0
#define NCCF_FC_CTS_RTS		1
#define NCCF_FC_XON_XOFF	2
#define NCCF_FC_RS485		3
// flow control mode

#define NCCF_ROLE_NC		0
#define NCCF_ROLE_PC		1
// communication role

#define NCCF_DCTYPE_NO		0
#define NCCF_DCTYPE_DC2		1
#define NCCF_DCTYPE_DC4		2
#define NCCF_DCTYPE_DC2DC4	3
// device control code DC2/DC4 type

#define NCCF_EOBOUT_LF		0
#define NCCF_EOBOUT_CR_LF	1
// EOB code

HANDLE CNCAPI NcCommFileOpen(
	int channel,
	int oflag
);
// open NC commication device
// channel		1 for COM1, 2 for COM2
// if the function succeeds, then return the file handle
// if the function fails, the return value is zero.

// open flag constant
#define NCCF_OPEN_READ	0
#define NCCF_OPEN_WRITE	1

BOOL CNCAPI NcCommFileClose(
	HANDLE hFile				// handle to communications device
);
// close NC commication device
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

BOOL CNCAPI NcCommFilePurge(
	HANDLE hFile				// handle to communications device
);
// discard all characters from the output or input buffer of a specified
// communications resource. It can also terminate pending read or write
// operations on the specified resource. the NC communication channel
// should be reopen.
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

BOOL CNCAPI NcCommFileSetState(
	HANDLE hFile,				// handle to communications device
	TNCCFDCB *lpDCB
);
// fills in a device-control block with the current control settings for
// a specified NC communications device.
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

BOOL CNCAPI NcCommFileGetState(
	HANDLE hFile,				// handle to communications device
	TNCCFDCB *lpDCB
);
// configures a NC communications device according to the specifications
// in a device-control block. The function reinitializes all hardware
// and control settings, but it does not empty output or input queues
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

BOOL CNCAPI NcCommFileClearError(
	HANDLE hFile,				// handle to communications device
	LPDWORD lpErrors,			// pointer to variables to receive error codes
	LPCOMSTAT lpComStat			// pointer to buffer for communications status
);
// retrieves information about a communications error, The function is called
// when a communications error occurs, and it clears the device error
// flag to enable additional input and output(I/O) operations.
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

BOOL CNCAPI NcCommFileGetModemStatus(
	HANDLE hFile,				// handle to communications device
	LPDWORD lpModemStat			// pointer to control-register values
);
// retrieves modem control-register values
// if the function succeeds, then return value is nonzero.
// if the function fails, the return value is zero.

char * CNCAPI NcCommFileGets(
	HANDLE hFile,				// handle to communications device
	char *string,
	int maxchar
);
// get string from this communication file

int CNCAPI NcCommFilePuts(
	HANDLE hFile,				// handle to communications device
	const char *string
);
// put a string into this communication file

int CNCAPI NcCommFileIsGetReady(
	HANDLE hFile				// handle to communications device
);
// query whether is ready to call gets method

int CNCAPI NcCommFileIsPutReady(
	HANDLE hFile				// handle to communications device
);
// query whether is ready to call puts method

int CNCAPI NcCommFileEOF(
	HANDLE hFile				// handle to communications device
);
// query whether is end of file

int CNCAPI NcCommFileFlush(
	HANDLE hFile				// handle to communications device
);
// query whether is ready to call close method

DWORD CNCAPI NcCommFileGetTxCount(
	HANDLE hFile				// handle to communications device
);
// get transmission count

DWORD CNCAPI NcCommFileGetRxCount(
	HANDLE hFile				// handle to communications device
);
// get receiving count

#ifdef __cplusplus
}
#endif 

#endif // _NCCOMMFILEAPI_INCLUDED_
