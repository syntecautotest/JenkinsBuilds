// MultiPassMovingAverageFilter.h: interface for the CMultiPassMovingAverageFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MULTIPASSMOVINGAVERAGEFILTER_H__83840379_9BE0_42E9_9368_8815013F4F79__INCLUDED_)
#define AFX_MULTIPASSMOVINGAVERAGEFILTER_H__83840379_9BE0_42E9_9368_8815013F4F79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMultiPassMovingAverageFilter
{
public:

	CMultiPassMovingAverageFilter( long nTimeBase, long nMaxTimeInterval, long nPassOfFilter );
	// constructor

	virtual ~CMultiPassMovingAverageFilter();
	// destructor

	void empty( void );
	// empty object

	int isEmpty( void );
	// query whether there are no command queue inside?

	void set_TimeConstant( double TA );
	// set time constant of multiple-pass filter, in usec

	void shiftCommand( double &command );
	// do post acceleration

	void shiftCommand( double InCommand, double &OutCommand );
	// do post acceleration

	double get_QueuedCommand( void );
	// query pending commands in queue

private:
	CMovingAverageFilter **m_objFilter;
	// acceleration object

	double m_TA;
	// time constant of multiple-pass filter

	int m_nPassOfFilter;
	// number of multiple-pass moving average filters
};

#endif // !defined(AFX_MULTIPASSMOVINGAVERAGEFILTER_H__83840379_9BE0_42E9_9368_8815013F4F79__INCLUDED_)
