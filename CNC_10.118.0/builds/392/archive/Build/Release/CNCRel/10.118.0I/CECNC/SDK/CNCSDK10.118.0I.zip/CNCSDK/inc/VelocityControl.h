// SCurve.h: interface for the CSCurve class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VELOCITYCONTROL_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_)
#define AFX_VELOCITYCONTROL_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CVelocityControl
{
public:
	CVelocityControl();
	// constructor

	virtual ~CVelocityControl();
	// destructor

	void SetAmax( double Value );
	// set acceleration maximun

	void SetJmax( double Value );
	// set jerk maximun

	void SetTargetVelocity( double TargetVelocity );
	// set target velocity

	double GetNextVelocity( double TimeElapse );
	// get next velocity

	void SetTimebase( double nTimebase );
	// set timebase

public:
	void SetInitCondition( double Velocity, double Acceleration );
	// set current velocity and acceleration

	void GetCurrentState( double *Velocity, double *Acceleration );
	// get current velocity and acceleration

private:

	double m_Amax;
	// max acceleration, in um / usec^2.

	double m_Jmax;
	// max jerk, in um / usec^3.

	double m_TimeBase;
	// timebase, in micro second

	double m_TargetVelocity;
	// target velocity

	double m_CurrentVelocity;
	double m_CurrentAcceleration;
	// member data of speed S_Curve control
};

#endif // !defined(AFX_VELOCITYCONTROL_H__E8901742_6F8A_4AC1_932F_8F07C1267D35__INCLUDED_)