#if !defined(DUMPDBG_H_)
#define DUMPDBG_H_

// debug page 11
#define DEBUG_PAGE_11_COL_1_BASE	( 800 )

// class declaration
class CControlSystem;
class CTimeBase;
class CAsynQueue;
class CInterpolator;
class CMotionPlanner;
class CCoordinate;
class CNCExecutive;
class CCNCCenter;

// dump debug information interface
extern void DumpDebugData( CTimeBase *pTimebase, long *data );
extern void DumpDebugData( CAsynQueue *pQueue, long *data );
extern void DumpDebugData( CInterpolator *pInterpolator, long *data );
extern void DumpDebugData( CMotionPlanner *pMotionPlanner, long *data );
extern void DumpDebugData( CNCExecutive *pExecutive, long *data );
extern void DumpDebugData( CControlSystem *pControl, long *buffer );
extern void GetDebugData( CControlSystem *pControl, long *buffer );
extern void GetOtherDebugData( CControlSystem *pCtrl, long no, long *buffer );
extern void GetRefDebugData( CControlSystem *pCtrl, long no, long *buffer );

// dump running state interface
extern void DumpRunningState( CControlSystem *pControl, long *buffer );

// inside aid function
void GetFollowingError( CCNCCenter *pCNC, long no, long *buffer );
void GetFollowingErrorLimit( CCNCCenter *pCNC, long no, long *buffer );
void GetFeedbackPosition( CCNCCenter *pCNC, long no, long *buffer );
void GetTheoryFollowingError( CCNCCenter *pCNC, long no, long *buffer );
void GetServoCommand( CCNCCenter *pCNC, long no, long *buffer );
void ReadIndexPosition( CCNCCenter *pCNC, long no, long *buffer );
void GetHomeGrid( CCNCCenter *pCNC, long no, long *buffer );
void GetForwardFollowingError( CCNCCenter *pCNC, long no, long *buffer );
void GgetDebugRTTrackingError( CCNCCenter *pCNC, long no, long *buffer );
void GetMPGAbsoluteCounter( CControlSystem *pCtrl, long no, long *buffer );
void GetSpindleSynchError( CCNCCenter *pCNC, long no, long *buffer );
void GetMachinePosition( CCNCCenter *pCNC, long no, long *buffer );
void GetDualPositionError( CCNCCenter *pCNC, long no, long *buffer );
void GetFeedbackPosition( CCNCCenter *pCNC, long no, long *buffer );
void GetDualFeedbackPosition( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesMachinePosition( CCNCCenter *pCNC, long no, long *buffer );
void Read16AxesIndexPosition( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesFollowingError( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesFeedbackPosition( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesFeedbackPositionEx( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesServoCommand( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesTheoryFollowingError( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesFollowingErrorLimit( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesFollowingErrorEx( CCNCCenter *pCNC, long no, long *buffer );
void Get16AxesForwardFollowingError( CCNCCenter *pCNC, long no, long *buffer );
void Read16AxesDACommand( CCNCCenter *pCNC, long no, long *buffer );
void Read16AxesHomeGrid( CCNCCenter *pCNC, long no, long *buffer );
void Read16AxesIndexPositionEx( CCNCCenter *pCNC, long no, long *buffer );
void GetEstimateLoopGain( CCNCCenter *pCNC, long no, long *buffer );

#endif  // DUMPDBG_H_
