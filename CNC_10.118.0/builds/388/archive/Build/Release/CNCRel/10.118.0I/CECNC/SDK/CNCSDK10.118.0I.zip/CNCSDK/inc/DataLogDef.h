#if !defined(AFX_DATALOGDEF_H__9B635BD4_0F7C_4526_BC1B_7B8EC5617C47__INCLUDED_)
#define AFX_DATALOGDEF_H__9B635BD4_0F7C_4526_BC1B_7B8EC5617C47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#pragma warning( disable: 4996 )

#define FLAG_DEBUG_DATALOG				( 0 )

#define SIZE_UNIT_BUFFER_PACKET			( 4 )		// size of unit buffer packet
#define SIZE_UNIT_CLUSTER				( 4096 )	// cluster size : 4k
#define SIZE_WRITER_BUFF				( 32768 )

#define FLAG_RECORD_QUEUE_FULL			( 1 )
#define NUM_RECORD_QUEUE				( 2 )		// number of queue used in recorder
#define NUM_MAX_DUMP_RETRY				( 10 )

#define LEN_LOGGER_QUEUE				( 2048 )
#define LEN_LOGGER_QUEUE_EXT			( LEN_LOGGER_QUEUE ) * ( 4 )

#pragma pack(push)
#pragma pack(1)

// -----------Internal Structure-------------------
typedef struct
{
	int		nID;		// axis ID
	float	nValue;		// position value
} TAxisPos;

typedef struct
{
	int		nID;		// axis ID
	float	nValue;		// position offset value 
} TAxisPosOffset;

typedef struct
{
	long	nGroupID;	// axes group
	long	nPNum;		// G54Pxx
} TG54SetInfo;

typedef struct
{
	int		nID;		// spindle ID
	float	nValue;		// velocity value
} TSpindleVel;

typedef struct
{
	int		nID;		// spindle ID
	union {
		float	nPos;
		float	nVel;		// velocity or position value
	};
} TSpindleCmd;

// -----------External Structure-------------------

// axes position struct
typedef struct
{
	int			nCount;
	TAxisPos	tPosition[16];
} TAxesPos;

// G54Pxx offset struct
typedef struct
{
	TG54SetInfo		tSetInfo;
	int				nCount;
	TAxisPosOffset	tOffset[16];
} TSettableOffset;

// offset struct
typedef struct
{
	long			nGroupID;
	int				nCount;
	TAxisPosOffset	tOffset[16];
} TOffset;

// tool info. struct
typedef struct
{
	long			nGroupID;
	long			nToolNo;
	int				nAxisID;
	float			nLen;
	float			nWear;
} TToolInfo;

// Set HCS struct 
typedef struct
{
	long			nGroupID;
	int				nAxisID;
	float			nValue;
} THCSChange;

// general variable struct
typedef struct
{
	long			nNo;
	long			nValue;
} TVariable;

// system variable
typedef struct
{
	long nNo;
	int nGroupID;
	TOcVariant Data;
} TSystemVar;

// global variable
typedef struct
{
	long nNo;
	TOcVariant Data;
} TGlobalVar;

// servo spindle feedback velocity struct
typedef struct
{
	int				nCount;
	TSpindleVel		tVelocity[6];
} TSrvSpindleFeedbackVel;

// servo spindle command struct
typedef struct
{
	int				nCount;
	TSpindleCmd		tCommand[6];
} TSpindleSrvCmd;

// general device value struct
typedef struct
{
	long			nNo;
	long			nValue;
} TDeviceVal;

typedef struct
{
	int nAxisID;
	long nIndexPosition;
	float HomeGrid;
} THoming;

typedef struct
{
	int nAxisID;
	long nIndexPosition;
} TAlarm;

// struct for data record package
// 1: info. header part
// ***** struct size must be the multiple of 4 *****
typedef struct
{
	ULARGE_INTEGER TimeTick;	// 8 byte
	DWORD	DataType;			// 4 byte
	USHORT	DataArg;			// 2 byte
	USHORT	EventID;			// 2 byte
	USHORT	RecordSize;			// 2 byte
	USHORT	_RESERVED_[ 3 ];	// 6 byte
} TRecordHeader;
// 2: data part
struct TRecordData {

	BYTE byData[ SIZE_UNIT_BUFFER_PACKET ];
	// context unit is 4 bytes 

	TRecordData* pNext;
};
// data record package: 2 + (1*n)
struct TRecordPack {
	TRecordHeader tRecHead;
	TRecordData* pDataContext;
};

// *** CAUTION:													 ***
// *** DO NOT CHANGE ANY MEMBER in this struct					 ***
// *** because this need to be consistent with definition in mmi ***
typedef struct
{
	USHORT	RecordSize;			// 2 byte
	ULARGE_INTEGER TimeTick;	// 8 byte
	DWORD	DataType;			// 4 byte
	USHORT	EventID;			// 2 byte
	USHORT	DataArg;			// 2 byte
} TMmiLogHeader;

#pragma pack(pop)

// Kinematic data logger parameter tables
//		0: MRP,						1: LARAW,					2: LAMAT,					3: PVT,						4: SEG,
//		5: CMD,						6: DISP
static int g_KLogQueueSizeTable[ CONST_KLOG_NUMBER ] =
	{	LEN_LOGGER_QUEUE,			LEN_LOGGER_QUEUE,			LEN_LOGGER_QUEUE,			LEN_LOGGER_QUEUE_EXT,		LEN_LOGGER_QUEUE,
		LEN_LOGGER_QUEUE_EXT,		LEN_LOGGER_QUEUE };

static int GetLogQueueSize( EDataType type ) {
	if( type < CONST_KLOG_BASE ) {
		return LEN_DEFAULT_QUEUE;
	}
	if( type == DT_DATAAQ ) {
		return LEN_LOGGER_QUEUE_EXT * 4;				// 4 channel, 8192 for each
	}
	return g_KLogQueueSizeTable[ type - CONST_KLOG_BASE ];
}

union UDataPack {
	TAxesPos					MACHINE_POS;				// 0. Machine coordinate value
	TSettableOffset				SETTABLE_OFFSET;			// 1. Settable offset
	TOffset						BASIC_OFFSET;				// 2. Basic offset
	TOffset						G92_OFFSET;					// 3. G92 offset
	TOffset						HCS_OFFSET;					// 4. Hand offset
	THCSChange					HCS_CHANGE;					// 5. Hand change
	// use header only			//DT_SYSTIME,				// 6. System time
	TAxesPos					FEEDBACK;					// 7. Servo feedback
	THoming						HOMING;						// 8. Homing info.
	TAlarm						ALARM;						// 9. Axes alarm
	TToolInfo					TOOL_INFO;					// 10. Tool detail
	// create another 4 pieces of record: DT_SETTABLE_OFFSET, DT_BASIC_OFFSET, DT_G92_OFFSET, DT_HCS_OFFSET
								//DT_COORD_INFO,			// 11. All coord information
	TSpindleSrvCmd				SERVO_CMD;					// 12. Servo Command	// mmi doesn't recognize this data type
	TAxesPos					DT_DUAL_FEEDBACK;			// 13. Dual feedback	// mmi doesn't recognize this data type
	TGlobalVar					GLOBAL_VAR;					// 14. Value of setting Global variable	// mmi doesn't recognize this data type
	TSystemVar					SYSTEM_VAR;					// 15. Value of setting System variable	// mmi doesn't recognize this data type
	TVariable					DEBUG_VAR;					// 16. Value of setting Debug variable	// mmi doesn't recognize this data type
	TDeviceVal					I_BIT;						// 17. I bit value	// mmi doesn't recognize this data type
	TDeviceVal					O_BIT;						// 18. O bit value	// mmi doesn't recognize this data type
	TDeviceVal					C_BIT;						// 19. C bit value	// mmi doesn't recognize this data type
	TDeviceVal					S_BIT;						// 20. S bit value	// mmi doesn't recognize this data type
	TDeviceVal					A_BIT;						// 21. A bit value	// mmi doesn't recognize this data type
	TSrvSpindleFeedbackVel		SPINDLE_FEEDBACK_VEL;		// 22. spindle servo velocity feedback	// mmi doesn't recognize this data type
	TSpindleSrvCmd				SPINDLE_SERVOCMD_VEL;		// 23. spindle velocity servo command	// mmi doesn't recognize this data type
	TDeviceVal					REGISTER;					// 24. register value	// mmi doesn't recognize this data type
	TDeviceVal					DEVICE_VAL;					// 25. register. IOCSA value
	TAxesPos					ABSOLUTE_FEEDBACK;			// 26. Servo feedback with coordinate shift	// mmi doesn't recognize this data type
	struct { TMotReqPkt			KLOG_MRP; };
	struct { TLANode			KLOG_LAX; };
	TPVTSegment					KLOG_PVT;
	TCtrlBlk					KLOG_SEG;
	TServoCommand				KLOG_CMD;
	TCvsBlk						KLOG_DIS;
	TSynScopeChInfo				DATAAQ;
};
typedef UDataPack *PDataPack;

#endif // !defined(AFX_DATALOGDEF_H__9B635BD4_0F7C_4526_BC1B_7B8EC5617C47__INCLUDED_)
