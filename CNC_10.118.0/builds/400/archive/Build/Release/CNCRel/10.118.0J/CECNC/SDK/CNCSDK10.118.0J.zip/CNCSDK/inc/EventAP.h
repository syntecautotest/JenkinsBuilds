#if !defined(_EVENTAP_INCLUDE_)
#define _EVENTAP_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "_Event.h"

#define EVENT_TRIGGER( nEvtID, nEvtArg, ... ) ( TriEvt( ( nEvtID ), ( nEvtArg ), __VA_ARGS__ ) )
#define EVENT_TRIGGERMIX( nEvtID, nEvtArg, nStartID, nStartArg, nEndID, nEndArg, var ) ( TriMixEvt( ( nEvtID ), ( nEvtArg ), ( nStartID ), ( nStartArg ), ( nEndID ), ( nEndArg ), ( var ) ) )
#define EVENT_REGISTER( nEvtID, nEvtArg, pListener ) ( RegEvt( ( nEvtID ), ( nEvtArg ), ( pListener ) ) )
#define EVENT_REGISTERMIX( nEvtID, nEvtArg, nStartID, nStartArg, nEndID, nEndArg, pListener ) ( RegEvt( ( nEvtID ), ( nEvtArg ), ( nStartID ), ( nStartArg ), ( nEndID ), ( nEndArg ), ( pListener ) ) )
#define EVENT_UNREGISTER( nEvtID, nEvtArg, pListener ) ( UnregEvt( ( nEvtID ), ( nEvtArg ), ( pListener ) ) )
#define EVENT_UNREGISTERMIX( nEvtID, nEvtArg, nStartID, nStartArg, nEndID, nEndArg, pListener ) ( UnregEvt( ( nEvtID ), ( nEvtArg ), ( nStartID ), ( nStartArg ), ( nEndID ), ( nEndArg ), ( pListener ) ) )

void setEvtTrgMgr( CEvtTrgMgr *pEvtTrgMgr );
// set event trigger manager

BOOL RegEvt( INT nEvtID, INT nEvtArg1, IListener * pListener );
// register single-event, type like: C0-on

BOOL RegEvt( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg, IListener * pListener );
// register mix-event, mix-event

BOOL UnregEvt( INT nEvtID, INT nEvtArg, IListener * pListener );
// unregister single-event, type like: C0-on

BOOL UnregEvt( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg, IListener * pListener );
// unregister mix-event

void TriEvt( INT nEvtID, INT nEvtArg, ... );
// trigger when event is happened

void TriMixEvt( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg, va_list var );
// trigger when event is happened

#endif // !defined(_EVENTAP_INCLUDE_)
