#if !defined(_MOTUTILITY_H__INCLUDED_)
#define _MOTUTILITY_H__INCLUDED_

#include "nstdlib.h"

// from Utility: mathematical tools
#include "ZMath.h"
#include "Point2d.h"
#include "Vector2d.h"
#include "Matrix2d.h"
#include "Point3d.h"
#include "Vector3d.h"
#include "Matrix3d.h"
#include "Tuple3d.h"
#include "MatrixN.h"
#include "QuickMatrixN.h"
#include "Quaternion.h"
#include "AxFrame.h"
#include "PolynomialRootSolver.h"

// from Utility
#include "AlarmDef.h"
#include "CommonStruct.h"
#include "TZPlex.h"
#include "AsynQueue.h"
#include "_UNCC.h"
#include "ZRtl.h"
#include "JFileInfo.h"

// from Operation
#include "cncapi.h"

// from WinPal
#include "RTMutex.h"

// from InternalCNCAPI
#include "InternalCNCAPI.h"

// from Event
#include "EventAP.h"

// definition
#include "MotionPlanDef.h"
#include "RobotMotionDef.h"
#include "TrajectoryDef.h"

// interface
#include "IMotionPlanner.h"
#include "ITrajectoryInt.h"
#include "IObjFcnEvaluator.h"
#include "IHomeSearchInfo.h"
#include "ISpindleLink.h"
#include "ITrajInterpolator.h"
#include "IFeedbackPosition.h"
#include "ISvoChannel.h"
#include "ISvoLink.h"
#include "ISvoDriver.h"
#include "IFuncCallHandler.h"
#include "IStdProcessFcn.h"

// others
#include "ADQueue.h"
#include "ArcFeature.h"
#include "CJerkLineInt.h"
#include "CJerkHelicalInt.h"
#include "Trajectory.h"
#include "TrajectoryChopping.h"
#include "TrajectoryNormal.h"
#include "TrajectorySyncTracking.h"
#include "TrajectoryTapping.h"
#include "TrajectoryThread.h"
#include "SCurveTrajectory.h"
#include "LAQueue.h"
#include "RobotMRPQueue.h"
#include "MotionPlanner.h"
#include "LAFilter.h"
#include "LAMotionPlanner.h"
#include "LANodePool.h"
#include "RobotMRPPool.h"
#include "KickNode.h"
#include "CurvatureCalculatorNode.h"
#include "CurvatureCalculator.h"
#include "FeedControl.h"
#include "FCCutCSlope.h"
#include "FCCutSCurve.h"
#include "FCCutString.h"
#include "FCCutSmoothSCurve.h"
#include "FCThreadNormal.h"
#include "FeedLimit.h"
#include "BPTLimiter.h"
#include "FLCutCSlope.h"
#include "FLCutCSlopeForSpring.h"
#include "FLCutSCurve.h"
#include "FLCutString.h"
#include "FLThreadNormal.h"
#include "GradientDescent.h"
#include "HelicalPlan.h"
#include "HomeSearchCore.h"
#include "Interpolator.h"
#include "OneBlockInterpolator.h"
#include "RobotInterpolator.h"
#include "TimeBase.h"
#include "MpHomeSearch.h"
#include "MpHoming.h"
#include "PostAccelerator_Int.h"
#include "VelocityControl.h"
#include "DelayFilter.h"
#include "MovingAverageFilter.h"
#include "MultiPassMovingAverageFilter.h"
#include "VelAccMeter.h"
#include "ZeroSpeedCheck.h"
#include "SyncTracking.h"
#include "PlayModeInterpolator.h"

// others: Robot only
#include "RobotWaitSignalManager.h"
#include "InterruptSignalManager.h"

#endif // !defined(_MOTUTILITY_H__INCLUDED_)
