// InterruptSignalManager.h: implementation of the CInterruptSignalManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_INTERRUPTSIGNALMANAGER_H____INCLUDED_)
#define _INTERRUPTSIGNALMANAGER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define NUMOF_INTERRUPTINFO				( 1 )

// define reserved signal index
#define SIGNAL_INDEX_NOTDEFINED			( -1 )
#define SIGNAL_INDEX_SUBPROGRAMCALL		( 0 )

enum EScanMode {
	SCAN_ONESHOT = 0,		// only one interrupt request at a time
	SCAN_MULTISHOT,			// multiple interrupt requests at a time
	// for count enum
	SCAN_MODELAST,
};

class CInterruptSignalManager
{
//--------------------------------------------------functions--------------------------------------------------
public:
	CInterruptSignalManager( void );
	// constructor

	~CInterruptSignalManager( void );
	// destructor

	BOOL isInterruptCallEnabled( void );
	// is interrupt manager enable

	INT getTriggerCount( void );
	// query is there any interrupt signal triggered

	INT getAndClearTrigger( void );
	// get triggered interrupt index, then set triggered signal back to idle

	void scanInterruptState( void );
	// scan all source signal, use thread: InterpolationTick

	void reset( void );
	// reset

public:
	void setInterruptManagerEnable( BOOL bEnable );
	// set manager enable to trace interrupt signal

	BOOL setInterruptScanMode( int nMode );
	// set interrupt manager scan mode

	BOOL setInterruptInfo( int nIndex, int nType, int nNum, int nCond, int nLastTime );
	// set interrupt signal information

	BOOL clearInterruptInfo( int nIndex );
	// clear interrupt information by specified ID

private:
	BOOL isInterruptInfoValid( int nIndex, int nType, int nNum, int nCond, int nLastTime );
	// check interrupt signal information is valid

	void setAllSignalIdle( void );
	// set all interrupt state to SIG_IDLE, forcing rescan

	void oneShotTrigger( void );
	// only one interrupt is observable in a time

	void multiShotTrigger( void );
	// multiple interrupts are observable in a time

	void updateInterruptState( int nIndex );
	// update interrupt signal trigger state

	BOOL detectBitCondition( int nIndex );
	// detect source signal state change

private:
//-------------------------------------------------struct & enum----------------------------------------------
	struct TIntSigInfo {
		// [ signal property ]
		INT		Num;		// signal number
		INT		LastTime;	// signal last time( us )
		BYTE	BitNum;		// bit number if R bit used
		BYTE	Source;		// 0: C bit, 1: I bit, 2: R bit, 3: A bit
		BYTE	Condition;	// 0: off; 1: on
		BYTE	Reserved;	// padding
		// [ signal state ]
		BOOL	Enable;		// signal enable
		BOOL	PrevCond;	// previous signal condition
		INT		State;		// trigger state
		INT		Elapse;		// elapse time( us )
	};

	// interrupt signal soutce
	enum ESigSource {
		SIG_TYPE_CBIT = 0,
		SIG_TYPE_IBIT,
		SIG_TYPE_RBIT,
		SIG_TYPE_ABIT,
		// for count enum
		SIG_TYPE_LAST,
	};

	// interrupt signal state
	enum EInterruptSignalState {
		SIG_WAIT_EDGE = 0,
		SIG_CHECK_ELAPSE,
		SIG_TRIGGERED,
	};

//--------------------------------------------------variables--------------------------------------------------
private:
	CRTMutex m_cs;
	// object state consistent mutex

private:
	TIntSigInfo		m_IntSigInfo[ NUMOF_INTERRUPTINFO ];
	// packed info. of the interrupt signal

	INT				m_nTriggerIndex;
	// in request signal index

	INT				m_nTriggerCount;
	// in request signal count

private:
	BOOL			m_bInterruptEnable;
	// interrupt manager enable / disable

	INT				m_nScanMode;
	// interrupt request scan mode

	LONG			m_nTimebase;
	// interpolation time base (usec)
};

#endif // !defined(_INTERRUPTSIGNALMANAGER_H____INCLUDED_)
