// ZMath.h: interface for the CZMath class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZMATH_H__BAD2D914_042C_11D3_83FA_0000E86B4150__INCLUDED_)
#define AFX_ZMATH_H__BAD2D914_042C_11D3_83FA_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

#define MAX_TrianglarFuncDomain	9223372036854775808.0
// 2^63 = 9223372036854775808 for triangular functions bound

#define MAX_PowerOfExp			709.782712893383996
// e ^ 709.78271289338399678331927717938 = MAX_double

#define zdPI					3.14159265358979323846
// �k

#define zdInvPI					0.31830988618379068794
// 1/�k

#define zdToDeg					57.2957795130823208768
// convert from radian to degree, multiply by 180/�k.

#define zdToRad					0.01745329251994329577
// convert from degree to radian, multiply by �k/180.

class UTILAPI CZMath  
{
public:

	static const double EPSILON_double;
	// epsilon amount for double value

	static const double MAX_double;
	// maximum of double value

	static const double zPI;
	// �k value

	static const double zInvPI;
	// 1/�k value

	static const double zToDeg;
	// 180/�k value

	static const double zToRad;
	// �k/180 value

	static long zRound( double value );
	// round to long

	static long zSymmetricalRound( double value );
	// round to long

	static long zBoundTo( double &value, double bound );
	// truncate value to [-bound~bound] and return quotient

	static double REENTRYAPI zFabs( double x );
	// Calculates the absolute value of the floating-point argument.

	static long zFabs( long x );
	// Calculates the absolute value of the floating-point argument.

	static double REENTRYAPI zSqrt( double x );
	// Calculates the square root

	static double REENTRYAPI zSquare( double a );
	// Calculate the square

	static int zMin( int a, int b );
	// calculate the minimum of a and b

	static int zGCD( int a, int b );
	// caculate Greatest Common Divisor

	static double REENTRYAPI zMin( double a, double b );
	// calculate the minimum of a and b

	static double REENTRYAPI zMax( double a, double b );
	// calculate the maximum of a and b

	static double REENTRYAPI zSign( double a, double b );
	// return value a with sign of b

	static double REENTRYAPI zSin( double x );
	// Calculate sines

	static double REENTRYAPI zCos( double x );
	// Calculate the cosine

	static double REENTRYAPI zTan( double x );
	// Calculate the tangent

	static double REENTRYAPI zASin( double x );
	// Returns the arc sine of an angle, in the range of -pi/2
	// through pi/2

	static double REENTRYAPI zACos( double x );
	// calculate the arccosine
	// The acos function returns the arccosine of x in the range
	// 0 to PI radians

	static double REENTRYAPI zATan2( double y, double x );
	// Calculates the arctangent of y/x
	// The atan2 function returns the arctangent of y/x in the range
	// -PI to PI radians

	static double REENTRYAPI zATan( double x );
	// Calculates the arctangent of x
	// The atan2 function returns the arctangent of x in the range
	// -PI/2 to PI/2 radians

	static double REENTRYAPI zFloor( double x );
	// The floor function returns a floating-point value representing
	// the largest integer that is less than or equal to x.

	static double REENTRYAPI zCeil( double x );
	// The ceil function returns a double value representing the
	// smallest integer that is greater than or equal to x.

	static double REENTRYAPI zPow( double x, double y );
	// Calculates a non-negative x raised to the power of y

	static double zPwr( double x, long y );
	// Calculates x raised to the power of long integer y

	static double REENTRYAPI zExp( double x );
	// Calculates e raised to the power of x

	static double REENTRYAPI zLog10( double x );
	// Calculates logarithms base 10 of x

	static double REENTRYAPI zLog( double x );
	// Calculates logarithms base e of x

	static void zLongCopy( long &dest, long &src );
	// atomic long variable copy

	static long zBinCoef( const long x, const long y );
	// calculate the Binomial distribution coefficient, i.e. equal to x!/((x-y)!*y!).
};

#endif // !defined(AFX_ZMATH_H__BAD2D914_042C_11D3_83FA_0000E86B4150__INCLUDED_)
