// HugeLinePage.h: interface for the CHugeFileEditor class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_HUGEFILEEDITOR_H__30455CDF_5C50_4139_86CE_42EE38D6F2F5__INCLUDED_)
#define AFX_HUGEFILEEDITOR_H__30455CDF_5C50_4139_86CE_42EE38D6F2F5__INCLUDED_

#include "ILineStore.h"
#include "FileEditor.h"
#include "HugeFileReader.h"
#include "nstdlib.h"


class CHugeFileEditor : public IFileEditor
{
private:
	CHugeFileReader m_HReaderLocal;
	// use for, if no Shared Reader
	CHugeFileReader *m_HReader;
	// Reader point, ReaderLocal or ReaderShared, use for get data

public:		// constructor and destructor
	CHugeFileEditor( long nMaxEditTableSize = 1024 );
	virtual ~CHugeFileEditor();
	
public:		// implement ILineStore interface
	int CNCAPI readLine( long lineno, void *buffer, int count );
	// return the character(with terminate char) counts in specified line,
	// when count is 0 and buffer is NULL then return the actual size
	// of specified line

	long CNCAPI getLineCount( void );
	// return the total line count

	void CNCAPI clearAll(void);
	// clear all content

	BOOL CNCAPI insert( long lineno, void *data, int size );
	// this function not support in this class
	// insert data before specified line number.
	// return TRUE, when successful, others, return FALSE.

	BOOL CNCAPI append( void *data, int size );
	// this function not support in this class
	// append specified data at the tail of whole data.

	BOOL CNCAPI deleteLine( long lineno );
	// this function not support in this class
	// delete specified line, this function will all behind line move
	// forward one line

	BOOL CNCAPI put( long lineno, void *data, int size );
	// this function not support in this class
	// put specified data into specified line

	BOOL CNCAPI erase( long lineno );
	// this function not support in this class
	// erase specified line data, this function just rease specified
	// line data, and no move behind line forward.

public:		// connection interface
	BOOL CNCAPI connect( char *filename );
	// connect to specified filename
	// return TRUE when success, FALSE when failure

	BOOL tconnect( TCHAR *filename );
	// connect to specified filename
	// return TRUE when success, FALSE when failure

	void CNCAPI disconnect( void );
	// disconnect with current connected file

	void setHReader( CHugeFileReader *HReader );
	// set associate hugeFileReader object pointer

	BOOL savefile( void );
	// to save file data, when dirty

	BOOL savefileto( TCHAR *lpszFilename );
	// to save specified file to assign path

	BOOL exportFile( char *szSrc, char *szDst, PFNPROGRESS pFn );
	// export huge file to destination.
	// if exist HMF file, merge file, or copy only.

	BOOL texportFile( TCHAR *szSrc, TCHAR *szDst, PFNPROGRESS pFn );
	// export huge file to destination.
	// if exist HMF file, merge file, or copy only.

	int GetDataPos( int lineno );
	// get data position in file by line number


public:
	BOOL m_bDirty;
	// dirty flag

	int m_nlock;
	// hugefileeditor be reference count

private:	// object state

	long m_nFinalCount;

	long m_nTableSizeCount;

	long m_nMaxEditTableSize;
	// maximum edit table size

	TCHAR m_filename[256];
	// associated huge file's filename

	struct editTable_item{
		long line_No;			// the line number
		long line_Count;		// line count
		int line_Operator;		// edit operator
		int line_size;			// data length in char
		char line_Data[512];	//line data
    
		editTable_item *fore;
		editTable_item *next;	
	};

	editTable_item m_TableHead;
	// circle double linked list

	editTable_item *m_pLastFound;
	// last search found node cache, for speed up line search algorithm

private: // object private method

	void editFileTable (long linenumber, int editOperator, void *tableData, int editSize);
	//build editFileTable

	void mergeEditTable( void );
	// merge edit table

	editTable_item * searchEditTable( long lineno );
	// search specified line from edit table, return associated node

	BOOL loadEditTable(char *filename, char *lpSignature);
	// to load edit table from specified file, if exist.

	BOOL tloadEditTable( TCHAR *filename, TCHAR *lpSignature);
	// to load edit table from specified file, if exist.

	BOOL saveEditTable(char *filename, char *lpSignature);
	// to save edit table into specified file

	BOOL tsaveEditTable( TCHAR *filename, TCHAR *lpSignature);
	// to save edit table into specified file

	void freeEditTable( void );
	// to free edit table

	BOOL GetFileSignature( char *lpszFilename, char *lpBuffer, int nCount );
	// to get file signature

	BOOL tGetFileSignature( TCHAR *lpszFilename, TCHAR *lpBuffer, int nCount );
	// to get file signature

	BOOL ReadHmfSignature( char *szSrc, char *lpBuffer, int nCount );
	// to read hmf file signature

	BOOL tReadHmfSignature( TCHAR *szSrc, TCHAR *lpBuffer, int nCount );
	// to read hmf file signature

	BOOL checkHMF( char *szSrc );
	// check HMF exist and correct.
	// return TRUE is exist and correct, FALSE is not exist or incorrect.

	BOOL tcheckHMF( TCHAR *szSrc );
	// check HMF exist and correct.
	// return TRUE is exist and correct, FALSE is not exist or incorrect.

	BOOL copyFile( char *szSrc, char *szDst, PFNPROGRESS pFn );
	// copy file only.

	BOOL tcopyFile( TCHAR *szSrc, TCHAR *szDst, PFNPROGRESS pFn );
	// copy file only.

	BOOL copyLineByLine( char *szSrc, char *szDst, PFNPROGRESS pFn );
	// copy huge file line by line.

	BOOL tcopyLineByLine( TCHAR *szSrc, TCHAR *szDst, PFNPROGRESS pFn );
	// copy huge file line by line.

	LONG fileLength( FILE *fp );
	// get file length.
};

#endif // !defined(AFX_HUGEFILEEDITOR_H__30455CDF_5C50_4139_86CE_42EE38D6F2F5__INCLUDED_)
