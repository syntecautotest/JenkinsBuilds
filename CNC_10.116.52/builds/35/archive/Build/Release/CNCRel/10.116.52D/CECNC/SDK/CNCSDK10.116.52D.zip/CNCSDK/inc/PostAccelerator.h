// PostAccelerator.h: interface for the CMovingAverageFilter and C2ndOrderMovingAverageFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POSTACCELERATOR_H__83840379_9BE0_42E9_9368_8815013F4F79__INCLUDED_)
#define AFX_POSTACCELERATOR_H__83840379_9BE0_42E9_9368_8815013F4F79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "RTMutex.h"

class CDelayFilter
{
public:

	CDelayFilter( long nTimeBase, long nMaxTimeInterval );
	// constructor

	CDelayFilter( int nCapacity );
	// constructor with parameter capacity

	virtual ~CDelayFilter();
	// destructor

	void set_TimeConstant( double TA );
	// set time constant

	virtual void empty( void );
	// empty object

	BOOL isEmpty( void );
	// query whether there are no command queue inside?

	double get_QueuedCommand( void );
	// to get remain data

	virtual void shiftCommand( double &command );
	// to shift new command

	virtual void shiftCommand( double InCommand, double &OutCommand );
	// to shift new command

protected:

	long m_nTimeBase;
	// time unit of post-acceleration buffer 

	double m_TA;
	// time constant

	double *m_MovingQueue;
	// buffer for calculate moving average

	int m_nLength;
	// moving average length

	int m_nTail;
	// index to next empty slot of queue

	double m_QueuedCommand;
	// the remain data amount.

	int m_nCapacity;
	// the capacity

	CRTMutex m_cs;
	// mutex for object state consistent

	int m_ZeroInputCount;
	// count input zero times
};

class CMovingAverageFilter : public CDelayFilter
{
public:

	CMovingAverageFilter( long nTimeBase, long nMaxTimeInterval );
	// constructor

	CMovingAverageFilter( int nCapacity );
	// constructor with parameter capacity

	virtual ~CMovingAverageFilter();
	// destructor

	void empty( void );
	// empty object

	void shiftCommand( double &command );
	// to shift new command

	void shiftCommand( double InCommand, double &OutCommand );
	// to shift new command

private:

	double m_Accumulator;
	// moving average buffer data sum.
};

class CMultiPassMovingAverageFilter
{
public:

	CMultiPassMovingAverageFilter( long nTimeBase, long nMaxTimeInterval, long nPassOfFilter );
	// constructor

	virtual ~CMultiPassMovingAverageFilter();
	// destructor

	void empty( void );
	// empty object

	int isEmpty( void );
	// query whether there are no command queue inside?

	void set_TimeConstant( double TA );
	// set time constant of multiple-pass filter, in usec

	void shiftCommand( double &command );
	// do post acceleration

	void shiftCommand( double InCommand, double &OutCommand );
	// do post acceleration

	double get_QueuedCommand( void );
	// query pending commands in queue

private:
	CMovingAverageFilter **m_objFilter;
	// acceleration object

	double m_TA;
	// time constant of multiple-pass filter

	int m_nPassOfFilter;
	// number of multiple-pass moving average filters
};

#endif // !defined(AFX_POSTACCELERATOR_H__83840379_9BE0_42E9_9368_8815013F4F79__INCLUDED_)
