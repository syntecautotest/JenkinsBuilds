// ISriChannel.h: interface for the ISriChannel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ISRICHANNEL_H____INCLUDED_)
#define _ISRICHANNEL_H____INCLUDED_

class ISriChannel
{
public:
	virtual BOOL writeData( int nIdx, WORD *pData, WORD Size ) = 0;
	// write data for hardware scan

	virtual BOOL readData( int nIdx, WORD *pData, WORD Size ) = 0;
	// read data for hardware scan

	virtual BOOL writeData( BYTE *pData,WORD Size ) = 0;
	// write data for software communication

	virtual BOOL readData( BYTE *pData, WORD &Size ) = 0;
	// read data for software communication

public:
	virtual void setCommProperty( int nControlMode, BYTE ProtocolType, DWORD Baudrate, DWORD ScanTime, DWORD Timeout ) = 0;
	// set communication property for each communication

	virtual void setRegionProperty( int nRegion, WORD Addr, WORD Size, WORD Station, int nRW, int nMaxError, int nRetry ) = 0;
	// set region property for each region, it is used for hard scan

	virtual BOOL SwitchSoftModeRequest( BOOL bEnable, int nTimeout = 0 ) = 0;
	// switch to soft communication mode request

	virtual BOOL IsInSoftMode( void ) = 0;
	// query whether it is in soft mode

public:
	virtual BOOL readCommReady( void ) = 0;
	// query whether communication is ready by bit

	virtual DWORD getRealScanTime( void ) = 0;
	// get real scan time for each communication

	virtual DWORD readError( void ) = 0;
	// query whether it is error by bit (region1~32) for each communication

	virtual DWORD readTimeout( void ) = 0;
	// query whether it is timeout by bit (region1~32) for each communication

	virtual DWORD readCRCError( void ) = 0;
	// query whether it is CRC error by bit (region1~32) for each communication

	virtual DWORD readByteError( void ) = 0;
	// query whether it is byte error by bit (region1~32) for each communication

	virtual WORD readErrorCode( int nRegion ) = 0;
	// read error code for each region

	virtual DWORD readErrorCount( int nRegion ) = 0;
	// read error count for each region

	virtual DWORD readTimeoutCount( int nRegion ) = 0;
	// read timeout count for each region

	virtual DWORD readCRCErrorCount( int nRegion ) = 0;
	// read CRC error count for each region

	virtual DWORD readByteErrorCount( int nRegion ) = 0;
	// read byte count error count for each region
};
#endif //(_ISRICHANNEL_H____INCLUDED_)