#if !defined(_ILASERCHANNEL_H_INCLUDED_)
#define _ILASERCHANNEL_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum ELaserCtrlType {
	EL_NONE = -1,
	EL_FREQ_CTRL = 0,
	EL_DUTY_CYCLE = 1,
	EL_PULSE_HEIGHT = 2,
};
// laser control type

class ILaserChannel
{
public:
	virtual ~ILaserChannel( void ) {}
	// destructor

	virtual void CNCAPI setLaserEnergyTable( BYTE *pEnergy, int nCount ) = 0;
	// set laser energy table in gray scale
	// input range: 0 ~ 255

	virtual void CNCAPI setLaserEnergyInPcnt( WORD *pEnergy, int nCount ) = 0;
	// set laser energy table in percentage (0.01%)
	// input range: 0 ~ 10,000

	virtual void CNCAPI setLaserFeqRange( WORD nMaxKHz, WORD nMinKHz ) = 0;
	// set laser max frequency and min frequency

	virtual void CNCAPI putLaserEnergyCount( long nFineDDACount ) = 0;
	// put laser energy count

	virtual void CNCAPI setLaserMode( int nMode ) = 0;
	// set laser mode

	virtual void CNCAPI setLaserQSwitchDelay( WORD nDelay ) = 0;
	// set laset Q-Switch daley count

	virtual void CNCAPI setLaserFpkLength( WORD nLength ) = 0;
	// set laser first pulse killer length count

	virtual void CNCAPI setLaserStandbyCount( WORD nPeriodCnt, WORD nWidthCnt ) = 0;
	// set laset standby period / width count

	virtual void CNCAPI setLaserDelayCount( WORD nOnCnt, WORD nOffCnt ) = 0;
	// set laser delay on / off count

	virtual void CNCAPI setDelayTime( int nTime ) = 0;
	// set laser delay time, in 0.1ms

	virtual BOOL CNCAPI isIdle( void ) = 0;
	// is idle

	virtual void CNCAPI setLaserCtrlType( ELaserCtrlType nType ) = 0;
	// set laser control type

	virtual void CNCAPI setLaserWorkingCondition( int nCnfgParam, WORD nData ) = 0;
	// set laser working condition

	virtual void CNCAPI putLaserCMD( WORD nData ) = 0;
	// put laser command

	virtual WORD CNCAPI getLaserDelayedCMD( void ) = 0;
	// get laser command after delay queue in laserchannel
};

#endif // _ILASERCHANNEL_H_INCLUDED_
