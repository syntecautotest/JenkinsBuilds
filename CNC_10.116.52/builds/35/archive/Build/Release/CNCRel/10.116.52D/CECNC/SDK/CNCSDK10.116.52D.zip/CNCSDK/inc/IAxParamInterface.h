// IAxParamInterface.h: interface for the IAxParamInterface class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IAXPARAMINTERFACE_H__INCLUDED_)
#define AFX_IAXPARAMINTERFACE_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class IAxParamInterface
{
public:
	virtual ~IAxParamInterface( void ) {}
	// destructor

	virtual void put_SensorResolution( long nResolution, long nScale ) = 0;
	// set encoder resolution

	virtual void put_SensorType( int nType ) = 0;
	// set sensor type

	virtual void put_LoopGain( double eLoopGain ) = 0;
	// set loop gain Kp

	virtual void put_DriverFeedforwardGain( long nFFGain ) = 0;
	// set driver feedforward gain

	virtual void notifyAbsHomeSettingChanged( void ) = 0;
	// notify absolute encoder home setting changed,
	// which cause home position will be shift

	virtual void notifyEncTypeChanged( void ) = 0;
	// notify encoder type is changed

	virtual long GetTypeOfChannel( void ) = 0;
	// get type of channel

	virtual void notifyParamInitialized( void ) = 0;
	// notify param initialized

	virtual long GetDriverResolution( void ) = 0;
	// get driver resolution

	virtual void SyncParamResolution( void ) = 0;
	// sync. resolution
};

#endif // !defined(AFX_IAXPARAMINTERFACE_H__INCLUDED_)
