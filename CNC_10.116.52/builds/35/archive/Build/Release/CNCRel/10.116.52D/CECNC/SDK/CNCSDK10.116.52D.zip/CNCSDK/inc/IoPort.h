// IoPort.h: interface for the IoPort API.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_IOPORT_INCLUDED_)
#define _IOPORT_INCLUDED_

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned char PortReadByte( unsigned short port );
// read byte data from specified port

extern void PortWriteByte( unsigned short port, unsigned char data );
// write byte data into specified port

extern unsigned short PortReadWord( unsigned short port );
// read byte data from specified port

extern void PortWriteWord( unsigned short port, unsigned short data );
// write byte data into specified port

#ifdef __cplusplus
}
#endif 

#endif // !defined(_IOPORT_INCLUDED_)
