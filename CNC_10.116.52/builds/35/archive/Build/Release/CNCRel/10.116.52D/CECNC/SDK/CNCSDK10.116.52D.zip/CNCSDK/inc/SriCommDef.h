#if !defined(_SRICOMMDEF_H____INCLUDED_)
#define _SRICOMMDEF_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "commonstruct.h"

#define MAX_COMM				3
#define MAX_STATIONPERCOMM		16
#define MAX_MODULEPERSTATION	16
#define MAX_DEVICE				768
#define MAX_REGIONPERCOMM		32
#define MAX_REGION				256
#define MAXSIZE_ADDR			256

#define INDICATOR_RUN			0xFF
#define INDICATOR_IDLE			0x00

enum {
	MODE_SOFT = 0,
	MODE_HARD
};

enum {
	DATA_RD = 1,
	DATA_WT,
	DATA_RW
};

enum EComState {
	// shared states
	COM_IDLE			= 0,
	COM_SENDCOMMAND		= 1,
	COM_WAITRECEIVE		= 2,
	// panel states
	COM_RECEIVING		= 3,
	COM_ERROR			= 16, // 0x10
};
// comm state constants

struct TModuleInfoEx {
	WORD Addr_read;
	WORD Addr_write;
	BYTE RunIndicator;
	BYTE Status;
	BYTE Reserved[2];
};

// PLC data in hardware mode
typedef struct {
	int nCount;
	WORD RBit[MAXSIZE_ADDR];
} TInputRBitTable;

typedef struct {
	int nCount;
	WORD RBit[MAXSIZE_ADDR];
	WORD RBitCache[MAXSIZE_ADDR];
} TOutputRBitTable;

struct THardwareData {
	TInputRBitTable		tInputRBitTable;
	TOutputRBitTable	tOutputRBitTable;
};

// PLC data in software mode
struct TSoftwareData {
	TSRIPLCInput		tInputData;
	int					nStateAddr;
	int					nErrAddr;
	int					nRxCompleteAddr;
	int					nRetLength;
};

// communication data for each mode
struct TPlcCommInfo {
	int nMode;
	BOOL bEnabled;
	union {
		THardwareData tHardware;
		TSoftwareData tSoftware;
	};
};

#endif //(_SRICOMMDEF_H____INCLUDED_)
