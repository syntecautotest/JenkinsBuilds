// LadderDef.h: interface for the CLadderDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LADDERDEF_H__CF8722F3_1236_11D3_8413_0000E86B4150__INCLUDED_)
#define AFX_LADDERDEF_H__CF8722F3_1236_11D3_8413_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// cell layout---------------------------------------------------------
//  Byte 0			should be zero for ladder parsing purpose
//	Byte 1			cell operation code
//  Byte 2~3		argument one adress
//  Byte 4~5		argument two address
//  Byte 6~7		argument three address
//
//  Notes:
//		Byte 7[7]		bicell marker, the requirement is not necessary
//						for OpencPLC parser and its editor tool(build 39 or later)
//
//---------------------------------------------------------------------
// address mapping for uni-cell operation, e.g. coil/contact
//	0		~	511			I0 ~ I511
//	512		~	1023		O0 ~ O511
//	1024	~	1535		C0 ~ C511
//	1536	~	2047		S0 ~ S511
//	2048	~	2559		A0 ~ A511
//	2560	~	4095		(reserved)
//	4096	~	24575		R0 ~ R639
//	24576	~	32767		(reserved)
//	32768	~	65535		(reserved)
//
// address mapping for bi-cell operation, that is, register address number.
//	0		~	4095		R0 ~ R4095
//	4096	~	32767		(reserved)
//	32768	~	65535		(reserved)
//
// Notes:
//   need to consider register device buffer size, 64K problem under DOS.
//
//---------------------------------------------------------------------

class CLadderDef
{
public:
	enum EWorkRegisterFileSize {
		SIZE_WorkRegisterFile = 32
	};

	enum EDeviceCapacity {
		CAPACITY_PLCTimer	= 256,
		CAPACITY_PLCCounter	= 256,
		CAPACITY_PLCIBit	= 512,
		CAPACITY_PLCOBit	= 512,
		CAPACITY_PLCCBit	= 512,
		CAPACITY_PLCSBit	= 512,
		CAPACITY_PLCABit	= 512,
		CAPACITY_PLCRegister = 65536,
		CAPACITY_PLCBitRegister = 640,
		CAPACITY_PLCAxis	= 20,
		CAPACITY_KEYSCAN	= 2,
		CAPACITY_RS232TX	= 3,
		CAPACITY_FILESYSTEM	= 6,
		CAPACITY_EXTERNFUNC = 256,
		CAPACITY_MODBUSLEN = 16,
		CAPACITY_BackgndExecuter = 20,
		CAPACITY_SRICOM		= 8,
		CAPACITY_SRILEN		= 256
	};
	// device capacity constant

	enum EPLCOpCode {

		// op code base for bi-cell element
		LOP_NULL			= 0,
		LOP_BICELL			= 0x20,
		LOP_EOF				= 0xFE,

		// build-in op code
		LOP_EndOfProgram	= 0x1F,	// end of program
		LOP_LoadFromReg		= 0x1E,	// Acc := Reg
		LOP_SaveToReg		= 0x1D,	// Reg := Acc
		LOP_OrFromReg		= 0x1C,	// Acc := Acc .OR. Reg
		LOP_AndFromFunc		= 0x1B,	// Acc := Acc .AND. Func()

		// uni-cell extended op code
		LOP_IOCSAOpen		= 0x01,
		LOP_IOCSAClose		= 0x03,
		LOP_TimerOpen		= 0x09,
		LOP_TimerClose		= 0x0A,
		LOP_CounterOpen		= 0x0B,
		LOP_CounterClose	= 0x0C,
		LOP_HorzontalLine	= 0x0D,
		LOP_CoilFollow		= 0x0E,
		LOP_CoilInverse		= 0x10,
		LOP_CoilPulseOnRise	= 0x05,
		LOP_CoilPulseOnFall	= 0x07,
		LOP_CoilLatch		= 0x12,
		LOP_CoilUnLatch		= 0x14,

		// bicell extended op code
		LOP_ADDRR			= 0x21,
		LOP_ADDIR			= 0x27,
		LOP_SUBRR			= 0x33,
		LOP_SUBIR			= 0x39,
		LOP_MULRR			= 0x45,
		LOP_MULIR			= 0x4B,
		LOP_DIVRR			= 0x57,
		LOP_DIVIR			= 0x5D,
		LOP_CMPGRR			= 0x5E,
		LOP_CMPLRR			= 0x62,
		LOP_CMPERR			= 0x66,
		LOP_CMPGIR			= 0x6A,
		LOP_CMPLIR			= 0x6C,
		LOP_CMPEIR			= 0x6E,
		LOP_MOVEIR			= 0x70,
		LOP_MOVERR			= 0x72,
		LOP_ANDRR			= 0x81,
		LOP_ANDIR			= 0x87,
		LOP_ORRR			= 0x93,
		LOP_ORIR			= 0x99,
		LOP_XORRR			= 0xA5,
		LOP_XORIR			= 0xAB,
		LOP_ToolRotate		= 0xB0,
		LOP_AxisRunProgI	= 0xB8,
		LOP_AxisRunProgR	= 0xB9,
		LOP_AxisStop		= 0xBB,
		LOP_AxisMoveTo		= 0xBC,
		LOP_KeyScan			= 0xBD,
		LOP_FSSYSTEM		= 0xBE,
		LOP_TIM1msI			= 0xC2,
		LOP_TIM10msI		= 0xC3,
		LOP_TIM100msI		= 0xC4,
		LOP_TIM1sI			= 0xC5,
		LOP_TIM1msR			= 0xE7,
		LOP_TIM10msR		= 0xE2,
		LOP_TIM100msR		= 0xE3,
		LOP_TIM1sR			= 0xE4,
		LOP_CNTUpI			= 0xC6,
		LOP_CNTDownI		= 0xC7,
		LOP_CNTReset		= 0xC9,
		LOP_CNTRingUpI		= 0xE0,
		LOP_CNTRingDownI	= 0xE1,
		LOP_CNTUpR			= 0xE5,
		LOP_CNTDownR		= 0xE6,
		LOP_CNTRingUpR		= 0xE9,
		LOP_CNTRingDownR	= 0xEA,
		LOP_JMP				= 0xCA,
		LOP_JSR				= 0xCB,
		LOP_LAB				= 0xD5,
		LOP_RTS				= 0xD0,
		LOP_EXTERNFUNC		= 0xD7,
		LOP_RS232Tx			= 0xD8,
		LOP_RSASC2BIN		= 0xD9,
		LOP_RSBIN2ASC		= 0xDA,
		LOP_RSPUTCHAR		= 0xDB,
		LOP_RSGETCHAR		= 0xDC,
		LOP_HEX2BIN			= 0xDD,
		LOP_MODRD			= 0xDE,
		LOP_MODWR			= 0xDF,
		LOP_END				= 0xCF,
		LOP_MODRS			= 0xEB,
		LOP_SRI				= 0xEC,
		LOP_BgndRunProgI	= 0xF0,
		LOP_BgndStop		= 0xF1,

		// the FASTEND opcode will be removed out by PLC loader,
		// so it will not appear during compile phase or runtime
		// phase.
		LOP_FASTEND			= 0xFD
	};
	// PLC op code constant

#pragma pack(2)

	struct TConnect {
		unsigned char	r_u_dir:1;        // Right Up Connected
		unsigned char	r_d_dir:1;        // Right Down Connected
		unsigned char	l_u_dir:1;        // Left Up Connected
		unsigned char	l_d_dir:1;        // Left Down Connected
		unsigned char	rwalk:1;          // right walked flag
		unsigned char	lwalk:1;          // left walked flag
		unsigned char	rstatus:1;        // right connection status
		unsigned char	lstatus:1;        // left connection status
	};

	struct TCell {
		TConnect		connect;
		unsigned char	code;
		short			arg1;
	};

	struct TLabelCell {
		TConnect		connect;
		unsigned char	code;
		char			name[6];
	};

	struct TFuncCell {
		TConnect		connect;
		unsigned char	code;
		short			arg1;
		short			arg2;
		short			arg3;
	};

#pragma pack()
};

#endif // !defined(AFX_LADDERDEF_H__CF8722F3_1236_11D3_8413_0000E86B4150__INCLUDED_)
