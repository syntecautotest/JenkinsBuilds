// NulMCIChannel.h: interface for the CNulMCIChannel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NULMCICHANNEL_H__626238AC_11F4_45D2_BD37_2F9F99A0A1BF__INCLUDED_)
#define AFX_NULMCICHANNEL_H__626238AC_11F4_45D2_BD37_2F9F99A0A1BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CNulMCIChannel : public ISvoChannel  
{
public:
	CNulMCIChannel();
	virtual ~CNulMCIChannel();

private:
	long m_AbsoluteCounter;
	// absolute counter

	long m_IndexPosition;
	// index position

	long m_LastIndexPosition;
	// last index position

	long m_IndexLatchedCount;
	// index latched count

	void CNCAPI PutVToRPMGain(long gain) {}
	// set V to RMP gain

	void CNCAPI PutDMR(long data) {}
	// To set the decoding factor of encoder.
	// Selection: x1, x2, x4.

	void CNCAPI PutCMR(long multiplier,long divisor) {}
	// set pulse command mutiply ratio

	void CNCAPI PutEncoderResolution(long data) {}
	// set the resolution of encoder.  Unit: pulses per revolution.
	// this amount already include encoder decoding factor
     
	void CNCAPI PutControlType( int type ) {}
	// put position loop control type

	void CNCAPI PutEncoderType(int type) {}
	// set the type of encoder.

	void CNCAPI PutProportionalGain( long nGain ) {}
	// Set the proportional gain to loop filter.
	// Unit: micro-voltage/pulse

	void CNCAPI PutDifferentialGain( long nGain ) {}
	// set DDA voltage skew, in voltage per second

	void CNCAPI setPulseOutMode( int nMode ) {}
	// to select pluse output mode

	void CNCAPI setLossPulseWindow( long window ) {}
	// set loss pulse window, in pulse
	
	void CNCAPI PutPositionCommand( long pulse );
	void CNCAPI PutVelocityCommand( long MicroVolt );
	void CNCAPI PutTorqueCommand( long RatedTRQ );
	void CNCAPI PutTorqueLimit( long RatedTRQLimit );
	void CNCAPI PutTorqueFeedforward( long nTRQFeedforward );
	void CNCAPI PutVelocityFeedforward( double VelFeedforward );
	long CNCAPI ReadPositionError( void );
	long CNCAPI ReadRealPosition( void );

	long CNCAPI ReadDACommand( void ) { return 0; }
	// read DA command value

	long CNCAPI ReadDeviceDebugData( int nIndex ) { return 0; }
	// read device debug data

	// set absolute counter to specified position, in pulse
	void CNCAPI SetRealPosition( long position );
	void CNCAPI StartIndexCapture( int nLatchSource = 0 );
	int  CNCAPI IsIndexCaptured( int nLatchSource = 0 );
	void CNCAPI AbortIndexCapture( void ) {}
	long CNCAPI ReadIndexPosition( int nLatchSource = 0 );
	long CNCAPI ReadIndexLatchedCount( void );
	long CNCAPI ReadTorqueLoad( void );
	void CNCAPI SetOpMode( int mode ) {}
	void CNCAPI SetServoOn( BOOL bOn );
	BOOL CNCAPI IsServoOn( void );
	BOOL CNCAPI GetServoIOSignal( int nIOSignal );
	void CNCAPI RefreshAlarmFlags( void ) {}
	long CNCAPI ReadAlarmFlags( void );
	int  CNCAPI ReadHomeSensorState( void ) { return 0; }
	// read home sensor state

	long CNCAPI clearQueuedCommand( void );
	// clear command in waiting queue

	int CNCAPI GetNumOfQueuedCommand( void );
	// get number for queued command, including driver and hardware

	int CNCAPI ReadServoData( WORD index, BYTE sub_index, long *value, BYTE* data_len, DWORD* cookie ) { return STATUS_Fail; };
	// read servo data from encoder

	int CNCAPI WriteServoData( WORD index, BYTE sub_index, long value, BYTE data_len, DWORD* cookie ) { return STATUS_Fail; }
	// write servo data to encoder

	BOOL CNCAPI AbortServoDataAccess( DWORD* cookie ) { return FALSE; }
	// abort servo data read/write access
	
	int CNCAPI TypeOfChannel( void ) {return CHTPYE_General;}

	BOOL CNCAPI CNCDeviceIoControl( ULONG dwIoControlCode, void *lpArgBuf, UINT nArgBufSize ) { return FALSE; }
	// Device IO control, OCDevice interface

	long CNCAPI GetWarningID( void ) { return 0; }
	// get warning id

	BOOL m_bServoOn;
	// servo on status
};

#endif // !defined(AFX_NULMCICHANNEL_H__626238AC_11F4_45D2_BD37_2F9F99A0A1BF__INCLUDED_)
