// ISriDriver.h: interface for the ISriDriver class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ISRIDRIVER_H____INCLUDED_)
#define _ISRIDRIVER_H____INCLUDED_

class ISriChannel;

class ISriDriver
{
public:
	virtual WORD get_VersionNumber( void ) = 0;
	// to get version number

	virtual ISriChannel *getSriChannel( int nPort ) = 0;
	// to get sri channel by comm port

	virtual void notifyInitFinish( void ) = 0;
	// notify initialization finish
};
#endif //(_ISRIDRIVER_H____INCLUDED_)