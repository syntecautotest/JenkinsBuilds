#if !defined(_MULTICASTAPI_INCLUDED_)
#define _MULTICASTAPI_INCLUDED_

#include "nstdlib.h"

#ifdef __cplusplus
extern "C" {
#endif

// available connection ID
#define MCCH_Foreground			0	// non-real-time, sleepable kernel job, and MMI task.
#define MCCH_HouseKeeping		1	// non-real-time, non-sleepable kernel job.
#define MCCH_PLC				2	// real time
#define MCCH_FastPLC			3	// real time
#define MCCH_Interpolation		4	// real time
#define MCCH_MacroExecuter		5	// real time
#define MCCH_RTCommNet			6	// real time
#define MCCH_FineDDA			7	// real time
#define MCCH_PreInterpolation	8	// real time
#define MCCH_1ms				9	// real time
#define MCCH_2ms				10	// real time
#define MCCH_5ms				11	// real time
#define MCCH_10ms				12	// real time
#define MCCH_50ms				13	// real time
#define MCCH_100ms				14	// real time
#define MCCH_1000ms				15	// real time
#define NUMOF_MultiCastChannel	16

// note: the connection functions should only use at construction phase
//		 in real-time channel for multi-thread safity consideration.

extern void McInit( void );
// init multi-cast library module

extern void McDeinit( void );
// deinit multi-cast library module

extern void McFire( int channel );
// call all multi-cast callback of specified channel

extern void CNCAPI McConnect( int channel, PFNSERVICE pfnService, LPVOID lpParameter, ULONG *pdwCookies );
// request multi-cast callback
// pfnService	pointer to service routine.
// lpParameter	pointer service parameter.
// pdwCookies	pointer to cookies, return non-zero when success, 0 for failure

extern void CNCAPI McDisconnect( int channel, ULONG dwCookies );
// cancel multi-cast callback

#ifdef __cplusplus
}
#endif 

#endif // _MULTICASTAPI_INCLUDED_