// ZeroSpeedCheck.h: interface for the CZeroSpeedCheck class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZEROSPEEDCHECK_H__INCLUDED_)
#define AFX_ZEROSPEEDCHECK_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IFeedbackPosition;

class CZeroSpeedCheck  
{
public:
	CZeroSpeedCheck( IFeedbackPosition *pFbkPos );
	virtual ~CZeroSpeedCheck( void );

	void MotionPlanTick( void );
	// Use threads: motion plan

	void setZeroSpeedWindow( long window );
	// window in pulse

	long getZeroSpeedWindow( void );
	// window in pulse

	BOOL IsZeroSpeed( void );
	// query whether this servo object is zero speed
	// Use threads: <= motion plan

	void setZeroSpeedCheck( BOOL bEnable );
	// set zero speed check

private:
	IFeedbackPosition *m_pFbkPos;
	// associated feedback position object

	static const long TIME_ZeroSpeedInterval;
	long EPSILON_ZeroSpeedBand;

	int m_ZeroSpeedCycle;
	// zero speed cycle count

	long *m_AbsCounterMin;
	long *m_AbsCounterMax;
	// buffer for zero speed calculation

	enum EZeroSpeedCheckState
	{
		EZSC_Idle,
		EZSC_Init,
		EZSC_Running,
	};

	EZeroSpeedCheckState m_ZeroSpeedCheckState;
	// zero speed check state
};

#endif // !defined(AFX_ZEROSPEEDCHECK_H__INCLUDED_)
