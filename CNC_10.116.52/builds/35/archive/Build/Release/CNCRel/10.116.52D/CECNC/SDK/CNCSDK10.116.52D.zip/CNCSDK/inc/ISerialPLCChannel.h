#if !defined(AFX_ISERIALPLCCHANNEL_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
#define AFX_ISERIALPLCCHANNEL_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISerialPLCChannel
{
public:
	virtual ~ISerialPLCChannel( void ) {}
	// destructor

	virtual int CNCAPI TypeOfChannel( void ) = 0;
	// get type of channel

	virtual void CNCAPI SetServoOn( BOOL bServoOn ) = 0;
	// set servo state

	virtual void CNCAPI RefreshAlarmFlags( void ) = 0;
	// refresh alarm flags

	virtual BOOL CNCAPI IsServoOn( void ) = 0;
	// is servo on

	virtual BOOL CNCAPI GetServoIOSignal( int IOSignal ) = 0;
	// get servo IO Signal

	virtual LONG CNCAPI ReadAlarmFlags( void ) = 0;
	// read alarm flags

	virtual LONG CNCAPI GetAlarmID( void ) = 0;
	// read alarm flags

	virtual LONG CNCAPI GetWarningID( void ) = 0;
	// get servo warning id

	virtual LONG CNCAPI ReadRealPosition( void ) = 0;
	// read real position

	virtual EDriverEncoderType CNCAPI getEncoderType( void ) = 0;
	// get encoder type

	virtual BOOL CNCAPI setPosingData( long Position, double Velocity, double Acc, double Dec ) = 0;
	// set posing data
	// position in pulse
	// velocity in pulse / s
	// acceleration in pulse / s ^ 2
	// deceleration in pulse / s ^ 2

	virtual BOOL CNCAPI setVelCtrlData( double Velocity, double AccTime, double DecTime ) = 0;
	// set velocity control data
	// velocity in pulse / s
	// acceleration time in ms
	// deceleration time in ms

	virtual void CNCAPI StartPosing( void ) = 0;
	// start posing

	virtual void CNCAPI FinishPosing( void ) = 0;
	// finish posing

	virtual void CNCAPI EmergyStop( void ) = 0;
	// emergency stop

	virtual void CNCAPI Stop( void ) = 0;
	// stop

	virtual BOOL CNCAPI IsHomeSearchFinish( void ) = 0;
	// is home search finish

	virtual BOOL CNCAPI IsPosingFinish( void ) = 0;
	// is posing finsih

	virtual BOOL CNCAPI IsVelocityReached( void ) = 0;
	// is velocity reached

	virtual BOOL CNCAPI IsHoldFinish( void ) = 0;
	// is hold finish

	virtual BOOL CNCAPI IsSupportROT( void ) = 0;
	// whether support ROT

	virtual BOOL CNCAPI IsSupportSPLCA( void ) = 0;
	// whether support serial plc axis

	virtual BOOL CNCAPI IsSupportMPG( void ) = 0;
	// whether support MPG

	virtual BOOL CNCAPI IsInitFinish( void ) = 0;
	// whether initial process finish

	virtual LONG CNCAPI getActualVelocity( void ) = 0;
	// get actual velocity in pulse / s

	virtual BOOL CNCAPI setPositionCheckWindow( LONG nWindow ) = 0;
	// set position check window in pulse

	virtual BOOL CNCAPI setVelocityCheckWindow( LONG nWindow ) = 0;
	// set velocity check window in mm / min

	virtual void CNCAPI StartHomeSearch( void ) = 0;
	// start home search

	virtual void CNCAPI FinishHomeSearch( void ) = 0;
	// finish home search

	virtual BOOL CNCAPI setHomeSearchFirstVelocity( LONG nVelocity ) = 0;
	// set home search first velocity in pulse / s

	virtual BOOL CNCAPI setHomeSearchSecondVelocity( LONG nVelocity ) = 0;
	// set home search second velocity in pulse / s

	virtual BOOL CNCAPI setHomeSearchDirection( LONG nDirection ) = 0;
	// set home search direction
	// 0 : forward, 1 : backward

	virtual BOOL CNCAPI setHomeOffset( LONG nOffset ) = 0;
	// set home offset in pulse

	virtual void CNCAPI PutTorqueLimit( long RatedTRQLimit ) = 0;
	// put torque limit in 0.01% rated torque

	virtual BOOL CNCAPI CNCDeviceIoControl( unsigned long dwIoControlCode, void *lpArgBuf, unsigned int nArgBufSize ) = 0;
	// Device IO control, OCDevice interface

	virtual BOOL CNCAPI IsIndexCaptured( int nLatchSource = 0 ) = 0;
	// is index captured

	virtual LONG CNCAPI ReadIndexPosition( int nLatchSource = 0 ) = 0;
	// read index position

	virtual void CNCAPI StartIndexCapture( int nLatchSource = 0 ) = 0;
	// start index position capture

	virtual void CNCAPI SetOpMode( int nMode ) = 0;
	// set operation mode

	virtual void CNCAPI PutPositionCommand( long pulse ) = 0;
	// put position command
	// unit: counts, same as encoder resolution with DMR

	virtual long CNCAPI ReadTorqueLoad( void ) = 0;
	// read torque load in 0.01% rated torque
};

#endif // !defined(AFX_ISERIALPLCCHANNEL_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
