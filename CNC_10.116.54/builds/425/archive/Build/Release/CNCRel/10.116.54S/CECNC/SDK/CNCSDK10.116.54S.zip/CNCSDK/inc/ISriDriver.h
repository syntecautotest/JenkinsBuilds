// ISriDriver.h: interface for the ISriDriver class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ISRIDRIVER_H____INCLUDED_)
#define _ISRIDRIVER_H____INCLUDED_

class ISriDriver
{
public:
	virtual INT GetSriNum( void ) = 0;
	// get support sri comm number

	virtual BOOL IsInSoftMode( INT nPort ) = 0;
	// query whether it is in soft mode

	virtual DWORD readError( INT nPort ) = 0;
	// query whether it is error by bit (region1~32) for each communication

	virtual BOOL writeData( INT nPort, BYTE *pData, WORD Size ) = 0;
	// write data for software communication

	virtual BOOL readData( INT nPort, BYTE *pData, WORD &Size ) = 0;
	// read data for software communication

	virtual BOOL readCommReady( INT nPort ) = 0;
	// query whether communication is ready by bit

	virtual BOOL ReadCommConfig( INT nPort, BOOL &bEnabled, LONG &ProtocolType, LONG &Baudrate, LONG &CtrlMode, LONG &ScanTime, LONG &Timeout ) = 0;
	// read communication config

	virtual BOOL WriteCommConfig( INT nPort, BOOL bEnabled, LONG ProtocolType, LONG Baudrate, LONG CtrlMode, LONG ScanTime, LONG Timeout ) = 0;
	// write communication config

	virtual BOOL ReadStationInfo( INT nPort, INT nStation, TStationInfo &OldInfo, TStationInfo &NewInfo ) = 0;
	// read station information

	virtual BOOL WriteStationInfo( INT nPort, INT nStation, TStationInfo StationInfo ) = 0;
	// read station information

	virtual BOOL SaveStationInfo( INT &nRepeatedRbit ) = 0;
	// save station info to sri config

	virtual BOOL ReadStationState( INT nPort, INT nStationID, TStationState &StationState ) = 0;
	// read station state

	virtual BOOL ReadCommDbState( INT nPort, BOOL &bRunning, LONG &RealScanTime ) = 0;
	// read comm port debug state

	virtual BOOL ReadStationDbState( INT nPort, INT nStationID, TStationDbState &StationDbState ) = 0;
	// read station debug state

	virtual void QueryModuleInfo( void ) = 0;
	// query module information

	virtual void UpdateFirmware( INT nPort, INT nStationID, BOOL bSelectSlot[], TCHAR FileName[] ) = 0;
	// update firmware

	virtual void UpdateFirmwareProgress( INT &nPercent, INT &nState ) = 0;
	// query the state during update firmware process

	virtual void add_OnCncEvent( IOnCncEvent *lpListener ) = 0;
	// to add cnc event listener

	virtual void remove_OnCncEvent( IOnCncEvent *lpListener ) = 0;
	// to remove cnc event listener

	virtual void setFilterMethod( INT nMethod ) = 0;
	// to set SRI filter method
};
#endif //(_ISRIDRIVER_H____INCLUDED_)