// LadderWRPool.h: interface for the CLadderWRPool class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LADDERWRPOOL_H__CF8722F4_1236_11D3_8413_0000E86B4150__INCLUDED_)
#define AFX_LADDERWRPOOL_H__CF8722F4_1236_11D3_8413_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLadderWRPool
{
public:
	CLadderWRPool( int Size );
	virtual ~CLadderWRPool();

	int New( void );
	// return a new free register index, this function will
	// automatically lock that register once
	// return -1 when there are no free register

	void Release( int Index );
	// release the register

	void Reset( void );
	// reset will free all registers and clean stack

	int IsReset( void );
	// is in reset state which all registers and stack are free

private:
	int *m_pLockCount;
	// lock count for each register

	int m_Top;
	// index of the top node stack which simulated by register file

	int m_Size;
	// the number od work register
};

#endif // !defined(AFX_LADDERWRPOOL_H__CF8722F4_1236_11D3_8413_0000E86B4150__INCLUDED_)
