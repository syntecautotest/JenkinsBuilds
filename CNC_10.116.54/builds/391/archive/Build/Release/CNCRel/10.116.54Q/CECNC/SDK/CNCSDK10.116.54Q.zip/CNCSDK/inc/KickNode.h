// KickNode.h: interface for the CKickNode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_KICKNODE_H____INCLUDED_)
#define _KICKNODE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CKickNode
{
public:
	CKickNode(void);
	// constructor

	~CKickNode(void);
	// destructor

	void set( CKickNode &node );
	// set kick node

	void set( CTuple3d &tuple );
	// set vector value

	void set( double tuple[] );
	// set vector value, tuple must be array of size 3

public:
	CVector3d m_Vector;
	// vector member

	double m_LenSquare;
	// vector length square
};

#endif // !defined(_KICKNODE_H____INCLUDED_)
