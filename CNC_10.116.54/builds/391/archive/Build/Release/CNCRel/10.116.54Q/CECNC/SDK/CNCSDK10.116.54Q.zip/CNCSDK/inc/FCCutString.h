#if !defined(_FCCUTSTRING_H____INCLUDED_)
#define _FCCUTSTRING_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFCCutString : public CLAFilter
{
public:
	CFCCutString( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	~CFCCutString( void );
	// destructor

	void set_ChannelCount( const int nCount );
	// to set channel count

	int getCount( void );
	// get count

	int getFreeCount( void );
	// get free count

	BOOL isEmpty( void );
	// is empty

	void Reset( void );
	// reset

public:
	void putLANode( TLANode *pNode, double eParam1 = 0 );
	// put LA Node

	void setExactStop( void );
	// set exact stop

	void setEOBMark( const TPacketInfo &PacketInfo );
	// set EOB Mark

	void putGeomAxis( const int XAxis, const int YAxis, const int ZAxis );
	// to put geometry axis index

private:
	void NotifyDecToZero( void );
	// notify decelerate to zero

	void FlushLANodeQueue( void );
	// flush look ahead queue

	void ForwardElimination( void );
	// do forward singular block elimination

	void BackwardElimination( void );
	// backward singular block elimination

	void FlushMatureNodes( void );
	// flush mature node

	BOOL CalcReasonableVelocity( double &Vel_High, const double &Vel_Low, const double &TwoLengthAcc );
	// return TRUE if Vel_High is clamped down, else return FALSE

	TLANode *GetLastCuttingNode( void );
	// get last cutting node in raw queue and return it

private:
	CLAQueue m_LANodeQueue;
	// look ahead queue

	int m_nChannelCount;
	// channel count
};

#endif // !defined(_FCCUTSTRING_H____INCLUDED_)
