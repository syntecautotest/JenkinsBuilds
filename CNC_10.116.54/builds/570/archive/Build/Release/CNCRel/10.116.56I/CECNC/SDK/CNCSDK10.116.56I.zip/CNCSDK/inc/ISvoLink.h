// ISvoLink.h: interface for the ISvoLink class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISVOLINK_H__9B161DD2_5E91_458a_BD83_90CCBEA2AE0C__INCLUDED_)
#define AFX_ISVOLINK_H__9B161DD2_5E91_458a_BD83_90CCBEA2AE0C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISvoDriver;
class ISvoChannel;

class IServoLink
{
public:

	enum EServoCommState {
		COMMSTATE_Idle = 0,
		COMMSTATE_Busy,
		COMMSTATE_Error,
		COMMSTATE_BatteryFailure
	};
	// communication state

	virtual ~IServoLink( void ) {}
	// destructor

	virtual void CNCAPI ServoOpen( INT nPortID ) = 0;
	// Open a servo communication;

	virtual void CNCAPI ServoClose( INT nPortID ) = 0;
	// Close a servo communication;

	virtual void CNCAPI UpdateAbsCounter( INT nPortID ) = 0;
	// absolute counter read request

	virtual INT CNCAPI GetAbsCommState( INT nPortID ) = 0;
	// Get absolute counter commmunication state

	virtual LONG CNCAPI GetAbsCounter( INT nPortID ) = 0;
	// Read absolute counter

	virtual void CNCAPI UpdateParam( int nCh, int nGroup, int nNo ) = 0;
	// Parameter read request

	virtual int CNCAPI GetParamCommState( int nCh, int nGroup, int nNo ) = 0;
	// Get parameter read state

	virtual long CNCAPI GetParam( int nCh, int nGroup, int nNo ) = 0;
	// Read parameter

	virtual void CNCAPI SetParam( int nCh, int nGroup, int nNo, long nValue ) = 0;
	// write parameter
	// after set parameter, call GetParamCommState to check write finish

	virtual LONG CNCAPI GetAlarmID( INT nPortID ) = 0;
	// Get Servo present alarm ID
};

#endif // !defined(AFX_ISVOLINK_H__9B161DD2_5E91_458a_BD83_90CCBEA2AE0C__INCLUDED_)
