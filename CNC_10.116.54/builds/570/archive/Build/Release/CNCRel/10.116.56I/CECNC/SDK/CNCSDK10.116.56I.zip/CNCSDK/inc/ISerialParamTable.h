// ISerialParamTable.h: interface for the ISerialParamTable class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERIALPARAMTABLE_H__INCLUDED_)
#define AFX_SERIALPARAMTABLE_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ISerialParamListener.h"

class ISerialParamTable
{
public:
	virtual ~ISerialParamTable( void ) {}
	// destructor

	virtual void SetListener( ISerialParamListener *pListener ) = 0;
	// parameter set listener

	virtual int PutValue( WORD nNo, long nValue, BOOL bRestore = FALSE ) = 0;
	// parameter put value

	virtual int GetValue( WORD nNo, long &nValue ) = 0;
	// parameter get value
};

#endif // !defined(AFX_SERIALPARAMTABLE_H__INCLUDED_)
