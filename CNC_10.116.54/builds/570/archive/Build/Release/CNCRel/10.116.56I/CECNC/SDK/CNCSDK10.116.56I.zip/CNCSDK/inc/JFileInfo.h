#if !defined(_JFILEINFO_H_INCLUDED_)
#define _JFILEINFO_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CJFileInfo
{
public:
	CJFileInfo(void);
	~CJFileInfo(void);

	enum ECOALITION {
		COAL_Native,
		COAL_FileName,
		COAL_ModifiedDate,
		COAL_FileSize
	};

	void set_Filter( LPCTSTR lpszFilename );
	void set_Coalition( int nCoalition );
	void invalidate( void );

	LONG get_Count( void );
	WIN32_FIND_DATA *get_Item( int nIndex );
	// to access specified item

	int Find( LPCTSTR lpszFilename );
	// to find specified file

	static BOOL getFileInfo( LPCTSTR lpszFilename, WIN32_FIND_DATA *pFI );
	// to get file information of specified filename
	// return TRUE when success, FALSE when failure

	static BOOL MakeFolder( LPCTSTR lpszFolder );
	// to make folder
private:
	BOOL m_bCachedValid;
	// flag for whether file information data cache is valid.

	int m_nCoalition;
	// coalition method of current file information data.

	int m_nRequireCoalition;
	// the required coalition method.

	TCHAR m_szFilenameFilter[MAX_PATH];
	// the filename filter

	LONG m_nDataCount;
	// file information count

	DWORD m_dwErrorCode;
	// the error code

	WIN32_FIND_DATA *m_lpFileInfoTable;
	DWORD m_dwFileInfoTableSize;

	WIN32_FIND_DATA **m_lpIndexTable;
	DWORD m_dwIndexTableSize;

private: // helper function

	HRESULT cacheFileInfo( void );
	// to cache file information data

	void sortCoalition( void );
	// to do coalition sort

	void prepareData( void );
	// to prepare data

	static int __cdecl compare_FileInfo_FileName( const void *arg1, const void *arg2 );
	// compare function for file infomation table sorting

	static int __cdecl compare_FileInfo_ModifiedDate( const void *arg1, const void *arg2 );
	// compare function for file infomation table sorting

	static int __cdecl compare_FileInfo_FileSize( const void *arg1, const void *arg2 );
	// compare function for file infomation table sorting
};

#endif // !defined(_JFILEINFO_H_INCLUDED_)
