// ITuningChannel.h: interface for the servo tuning.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_ITUNINGCHANNEL_H__INCLUDED_)
#define _ITUNINGCHANNEL_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ITuningChannel
{
public:
	virtual ~ITuningChannel( void ) {}
	// destructor

	virtual BOOL CNCAPI ChTuningIsSupport( void ) = 0;
	// check servo tuning is supported

	virtual void CNCAPI ChTuning1stLimit( void ) = 0;
	// set first tuning limit

	virtual void CNCAPI ChTuning2ndLimit( void ) = 0;
	// set second tuning limit

	virtual void CNCAPI ChTuningLimitCheck( int &nLimitCheck, long &nMinStroke, long &nMaxStroke ) = 0;
	// check tuning stroke limit

	virtual void CNCAPI ChTuningStartCheck( BOOL &bStartOK, long nCheckWindow ) = 0;
	// check tuning start point is near the second limit

	virtual void CNCAPI ChTuningGetDefault( int &nTuningMode, int &nMachineType ) = 0;
	// get tuning default data

	virtual void CNCAPI ChTuningData( int nTuningMode, int nMachineType ) = 0;
	// set tuning data

	virtual void CNCAPI ChTuningStart( void ) = 0;
	// start tuning

	virtual void CNCAPI ChTuningStop( void ) = 0;
	// stop tuning

	virtual void CNCAPI ChTuningGetStatus( BOOL &isFinished, int &nResult ) = 0;
	// get tuning status
};

#endif // _ITUNINGCHANNEL_H__INCLUDED_
