// ITrajInterpolator.h: interface for the ITrajInterpolator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ITRAJINTERPOLATOR_H__E9F08565_1681_11D3_B6E7_000000000000__INCLUDED_)
#define AFX_ITRAJINTERPOLATOR_H__E9F08565_1681_11D3_B6E7_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ITrajInterpolator
// trajectory interpolator interface
{
public:
	virtual ~ITrajInterpolator( void ) {}
	// destructor

	virtual void ConstantJerkPVTTo(double displacement, double from_velocity, double to_velocity, double time) = 0;
	// displacement		position displacement, in BLU.
	// from_velocity	velocity at time 0, in BLU per microsecond.
	// to_velocity		velocity at time T, in BLU per microsecond.
	// time				block move time, that is, T.

	virtual void ConstantJerkPVTToEx(int fBreakble, double displacement, double from_velocity, double to_velocity, double time) = 0;
	// fBreakable       whether current command is breakable by any block in queue.
	//					that is, this command will automatically abort when there
	//					are new commands put into queue.	
	// displacement		position displacement, in BLU.
	// from_velocity	velocity at time 0, in BLU per microsecond.
	// to_velocity		velocity at time T, in BLU per microsecond.
	// time				block move time, that is, T.

    virtual int GetFreeQueueSize( void ) = 0;
	// query the number of the empty slot in trojectory command
	// queue to store new trajectory commands.

    virtual void DelayTimeTo(double time) = 0;
	// delay the specified time, in micro-second
	// time				block move time, that is, T.

	virtual double getVelocity( void ) = 0;
	// get current velocity, in BLU per sample time
};

#endif // !defined(AFX_ITRAJINTERPOLATOR_H__E9F08565_1681_11D3_B6E7_000000000000__INCLUDED_)
