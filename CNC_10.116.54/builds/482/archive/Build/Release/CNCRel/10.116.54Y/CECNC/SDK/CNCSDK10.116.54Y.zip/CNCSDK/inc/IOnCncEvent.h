#if !defined(_IONCNCEVENT_INCLUDE_)
#define _IONCNCEVENT_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IOnCncEvent
{
public:
	// open run-time extension message definition
	//
	// Note:
	//	please don't not suspend on following non-suspendable message,
	//	this will cause internal critical running thread been suspend.
	enum ECncEvent {
		NCEV_Reset = 100,				// non-suspendable message
		NCEV_CycleStart,				// non-suspendable message
		NCEV_EStopPressed,				// non-suspendable message
		NCEV_EStopRelease,				// non-suspendable message
		NCEV_InputUnitChanged,			// non-suspendable message
		NCEV_ToolOffsetChanged,			// non-suspendable message
		NCEV_BeforeCycleStart,			// non-suspendable message
		NCEV_ParameterChanged,			// non-suspendable message
		NCEV_OnAlarm,					// non-suspendable message
		NCEV_CncModeChanged,			// non-suspendable message
		NCEV_CncStatusChanged,			// non-suspendable message
		NCEV_CheckedRegisterChanged,	// non-suspendable message
		NCEV_EventTrigger,				// non-suspendable message
		NCEV_OnSriEvent,				// non-suspendable message
		NCEV_OnAbsCoordChanged,			// non-suspendable message
		NCEV_SvoPowerOff				// non-suspendable message
	};

	virtual ~IOnCncEvent( void ) {}
	// destructor

	virtual void CNCAPI OnCncEvent( int nEventID, DWORD dwParam ) = 0;
};

#endif // _IONCNCEVENT_INCLUDE_
