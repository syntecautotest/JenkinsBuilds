// AsynQueue.h: interface for the CAsynQueue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ASYNQUEUE_H__D4E5F696_1A3A_11D3_841E_0000E86B4150__INCLUDED_)
#define AFX_ASYNQUEUE_H__D4E5F696_1A3A_11D3_841E_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct TZPlex;
class IMutex;

class CAsynQueue
{
public:
	static const unsigned SIZE_DataBuffer;

public:
	CAsynQueue( unsigned RecordSize, unsigned QueueSize, unsigned StackSize = 0, BOOL bCritcialSection = TRUE );
	// constructor

	virtual ~CAsynQueue( void );
	// destructor

	friend void DumpDebugData( CAsynQueue *pQueue, long *data );
	// open friend relationship to dump object state for debug purpose

	int		get_dataCount( void );
	// to get data count of stack and queue

	int		get_dataCount_stack( void );
	// to get data count of stack

	int		get_dataCount_queue( void );
	// to get data count of queue

	int		getFreeCount( void );
	// query free slot count
	// Use threads: >= low priority thread

	int		isFull( void );
	// whether the queue is full ?
	// Use threads: >= low priority thread

	int		isEmpty( void );
	// query whether queue is empty?
	// Use threads: >= low priority thread

	void *  writeLock( void );
	// lock for write block into queue
	// Use threads : low priority thread

	void    writeUnlock( void );
	// unlock for write operation finish
	// Use threads : low priority thread

	void *  readNext( void );
	// lock for read next block
	// Use threads : high priority thread

	void *	readPrev( void );
	// lock for read last block
	// Use threads : high priority thread

	void *	peekNext( void );
	// peek next block

	void *	peek( int nIndex );
	// peek according to nIndex
	// nIndex = 0 : Current Node
	// nIndex > 0 : Next nIndex Node
	// nIndex < 0 : Prev nIndex Node

	void	clear( void );
	// clear queue
	// Use threads: >= low priority thread

protected:
	int		m_BottomOfStack;	// index of bottom of stack
	int		m_NextUnReadBlock;	// index of next unread block
	int		m_NextFreeSlot;		// index of next free slot
	int		m_QueueSize;		// queue size
	int		m_StackSize;		// backtrace stack size
	void ** m_queue;			// queue pointer buffer

	TZPlex* m_pBlocks;
	// pointer to ZPlex blocks pool

	IMutex *m_cs;
	// mutex for object state consistent
};

#endif // !defined(AFX_ASYNQUEUE_H__D4E5F696_1A3A_11D3_841E_0000E86B4150__INCLUDED_)
