// DESObj.h: interface for the CDESObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DESOBJ_H__2C85D586_8721_4D6B_A412_FBB8ABD39357__INCLUDED_)
#define AFX_DESOBJ_H__2C85D586_8721_4D6B_A412_FBB8ABD39357__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define LEN_DESFILE_HEADER				8
#define LEN_DESFILE_SIZE				4
#define LEN_DESFILE_ALIGNMENT			8

class CDESObj
{
public:
	CDESObj();
	// constructor

	virtual ~CDESObj();
	// destructor

	USHORT CRC16( UCHAR *puchMsg, USHORT usDataLen );
	// 16 bit CRC error check, generate 2 bytes CRC data

	INT DES_EncryptionSingleBlock( UCHAR *source, UCHAR *result, UCHAR *key_use );
	// encrypt one block data, 8 bytes => 8 bytes using key_use

	INT DES_DecryptionSingleBlock( UCHAR *source, UCHAR *result, UCHAR *key_use );
	// decrypt one block data, 8 bytes => 8 bytes using key_use

	INT DES_EncryptionBlockDatas( UCHAR *sourceBlock, UCHAR *resultBlock, UCHAR *key_use, LONG BlockLength);
	// encrypt mass block data, use 8 bytes as 1 unit, must tell this function the block size by BlockLength

	INT DES_DecryptionBlockDatas( UCHAR *sourceBlock, UCHAR *resultBlock, UCHAR *key_use, LONG BlockLength);
	// decrypt mass block data, use 8 bytes as 1 unit, must tell this function the block size by BlockLength

	INT DES_EncryptionFile( CHAR *sourcePath, CHAR *resultPath, UCHAR *key_use );
	// use DES to encrypt file, input file path, output file path and using key

	INT DES_DecryptionFile( CHAR *sourcePath, CHAR *resultPath, UCHAR *key_use );
	// use DES to decrypt file, input file path, output file path and using key

	INT DES_DecryptionFileToBlockData( CHAR *sourcePath , UCHAR *returnBuffer, UCHAR *key_use, ULONG bufferSize, LONG *returnSize );
	// use DES to decrypt file, input file path, output buffer pointer,
	// the size of output buffer, and this function will return how many size the file decrypt

	BOOL DES_CheckCRC( UCHAR *pBlock );
	// check CRC for decrypted file data

private:
	// 56 => 48 bits key store, 16 keys 
	UCHAR m_key_array[ 16 ][ 6 ];

	/* Permutation input message bit, using different fixed table */
	INT RearrangeBits( UCHAR *source, UCHAR *result, UINT *array, INT length );

	/* rotate the input message bits */
	INT RotateLBits( UCHAR *source, UCHAR *result, INT RLBit, INT length );

	/* DES encode method using phase */
	INT S_Box( UCHAR *source , UCHAR *result );

	// output to global data, one encryption / decryption just one group key
	// input 56 bits key, output 48bits of 16 group key
	void GenerateKeyArray( UCHAR *keyinput );

	/* DES encode method using phase */
	INT Calculate_f( UCHAR *source, UCHAR *result, UCHAR *key_use );

	/* DES encode method using phase */
	INT Iteration( UCHAR *source, UCHAR *result, INT count );

	void ReleaseMemoryBuff( void );

	// 64K memory block use for store source and result block
	UCHAR *m_sourceBlock;
	UCHAR *m_resultBlock;
};

#endif // !defined(AFX_DESOBJ_H__2C85D586_8721_4D6B_A412_FBB8ABD39357__INCLUDED_)
