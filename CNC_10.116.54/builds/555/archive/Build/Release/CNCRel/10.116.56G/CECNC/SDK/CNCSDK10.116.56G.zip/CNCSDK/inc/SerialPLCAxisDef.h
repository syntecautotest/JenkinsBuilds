#if !defined(AFX_SERIALPLCAXISDEF_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
#define AFX_SERIALPLCAXISDEF_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define NUM_OF_SerialPLCAxis	32
#define MAX_PulseRange ( (double)LONG_MAX - (double)LONG_MIN + 1 )

#define BASE_HomeLatched		0
#define BASE_AbsOffset			50
#define BASE_OverflowLapCounter	60

#define ALMID_SPLCAXIS_ChannelSettingErr						1
#define ALMID_SPLCAXIS_RRegSettingErr							2
#define ALMID_SPLCAXIS_AccDecVelSettingErr						3
#define ALMID_SPLCAXIS_CheckWindowSettingErr					4
//#define ALMID_SPLCAXIS_FirstHomeSearchVelSettingErr			5
//#define ALMID_SPLCAXIS_SecondHomeSearchVelSettingErr			6
#define ALMID_SPLCAXIS_HomeOffsetSettingErr						7
#define ALMID_SPLCAXIS_AbsEncoderCannotUseHomeSearch			8
#define ALMID_SPLCAXIS_AbsEncoderNeedSettingZeroPoint			9
#define ALMID_SPLCAXIS_ParamChangedMustReopenAndHomeSearch		10
#define ALMID_SPLCAXIS_ServoChannelIDErr						11
#define ALMID_SPLCAXIS_AxPositiveSoftLimitExceed				12
#define ALMID_SPLCAXIS_AxNegativeSoftLimitExceed				13
#define ALMID_SPLCAXIS_CommunicationAlarm						14
#define ALMID_SPLCAXIS_SerialParameterWriteFail					15
#define ALMID_SPLCAXIS_HomeIndexMiss							16
#define ALMID_SPLCAXIS_HomeZeroSpeedTimeout						17
#define ALMID_SPLCAXIS_HomeLeaveFail							18
#define ALMID_SPLCAXIS_SvoPowerStatusError						19
#define ALMID_SPLCAXIS_ChannelNotSupport						20
#define ALMID_SPLCAXIS_AxMovementTooLong						21
#define ALMID_SPLCAXIS_NotSupportMPG							22

#endif // !defined(AFX_SERIALPLCAXISDEF_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
