// We define all variables and functions needed to solve radical solutions for second, third, and fourth degree polynomials.

#if !defined(_POLYNOMIALROOTSOLVER_INCLUDE_)
#define _POLYNOMIALROOTSOLVER_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Complex.h"
#include "NumericalRecipes.h"

class CPolynomialRootSolver
// NOTE: The answer solved by this module may exist great error.
//       Using this module needs to be careful, especially when
//       each coefficient's order is very different.
{
public:
	enum EErrorCode {
		ERRCODE_NoError = 0,		// for dump debug data
		ERRCODE_RootNotAccepted,	// 321 = 1, solve successfully but the root is not accepted
		ERRCODE_SolverFail,			// 321 = 2, solve unsuccessfully
		ERRCODE_DegUnreasonable		// 321 = 3, wrong input
	};

public:
	CPolynomialRootSolver();

	int SolveMinNonNegativeRoot( double &MinNonNegativeRoot, int degree, double Coefficient[] );
	// get the minimum non-negative root
	// if return a minus number, then it means there is no such root
	// return: error code

	int SolveMaxNonNegativeRoot( double &MaxNonNegativeRoot, int degree, double Coefficient[] );
	// get the maximum non-negative root
	// if return a minus number, then it means there is no such root
	// return: error code

	int SolveRealRoot( CComplex root[], int degree, double Coefficient[] );
	// get a real root
	// if return ERRCODE_RootNotExist, then it means there is no such root
	// return: error code

public:
	int SolveRoot( CComplex root[], int &degree, double Coefficient[], BOOL bDownDeg );
	// a function to solve radical solutions for 2-4 degree
	// coefficients for polynomials with Coefficient[i] being the i-th degree coefficient
	// return: error code

private:
	void SolveRoot1d( CComplex root[], double Coefficient[] );
	// compute radical solutions for the 1st degree polynomial
	// the coefficient of i-th degree is Coefficient[i]

	void SolveRoot2d( CComplex root[], double Coefficient[] );
	// compute radical solutions for the 2nd degree polynomial
	// the coefficient of i-th degree is Coefficient[i]

	void SolveRoot3d( CComplex root[], double Coefficient[] );
	// compute radical solutions for the 3rd degree polynomial
	// the coefficient of i-th degree is Coefficient[i]

	void SolveRoot4d( CComplex root[], double Coefficient[] );
	// compute radical solutions for the 4th degree polynomial
	// the coefficient of i-th degree is Coefficient[i]

	double Scale( double Coefficient[], double newCoeff[], int &degree );
	// scaling the coefficients of the polynomial
	// newCoeff[] is the input of SolveRoot function

	BOOL SetBound( double Coeff[], int degree, double &lowbound, double &upbound );
	// set upper bound and lower bound for rtsafe()

	int CheckAllRoots( CComplex root[], int degree, double Coeff[] );
	// check all roots solved by formula

	int ReduceDegAndSolveAgain( CComplex root[], CComplex R, int degree, double Coeff[] );
	// reduce polynomial and solve the quotient

	void Reduce( CComplex root, int degree, double Coeff[], int &quodeg, double quo[] );
	// get quotient by dividng the root
	// f(x) = (x-a) * q(x) + r or f(x) = (x^2-2ax+a^2+b^2) * q(x) + r(x)

	void CopyRoot( CComplex root[], int degree, CComplex R, CComplex subRoot[] );
	// integrate R and subRoot into root

private:
	static const CComplex Omega;
	static const CComplex OmegaSquare;
};

#endif // !defined(_POLYNOMIALROOTSOLVER_INCLUDE_)