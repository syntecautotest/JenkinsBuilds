// XSignal.h: interface for the XSignal API.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_XSIGNAL_INCLUDED_)
#define _XSIGNAL_INCLUDED_

#include "nstdlib.h"

#ifdef __cplusplus
extern "C" {
#endif

enum EXGNIRQLevel {
	XGN_IRQL_SystemTimer	= 0,
	XGN_IRQL_Keyboard		= 1,
	XGN_IRQL_RealtimeClock	= 2,
	XGN_IRQL_OldIRQ2		= 3,
	XGN_IRQL_Spare4			= 4,
	XGN_IRQL_Spare5			= 5,
	XGN_IRQL_Spare6			= 6,
	XGN_IRQL_Math			= 7,
	XGN_IRQL_HardDisk		= 8,
	XGN_IRQL_WatchDog		= 9,
	XGN_IRQL_COM2			= 10,
	XGN_IRQL_COM1			= 11,
	XGN_IRQL_LPT2			= 12,
	XGN_IRQL_Floppy			= 13,
	XGN_IRQL_LPT1			= 14,
	XGN_IRQL_Spare15		= 15,
	XGN_IRQL_Spare16		= 16,
	XGN_IRQL_Spare17		= 17,
	XGN_IRQL_Spare18		= 18,
	XGN_IRQL_Spare19		= 19,
	XGN_IRQL_Spare20		= 20,
	XGN_IRQL_Spare21		= 21,
	XGN_IRQL_Spare22		= 22,
	XGN_IRQL_Spare23		= 23,
	XGN_IRQL_Spare24		= 24,
	XGN_IRQL_Spare25		= 25,
	XGN_IRQL_Spare26		= 26,
	XGN_IRQL_Spare27		= 27,
	XGN_IRQL_Spare28		= 28,
	XGN_IRQL_Spare29		= 29,
	XGN_IRQL_Spare30		= 30,
	XGN_IRQL_Spare31		= 31,
};
// available interrupt request level, 0 is highest, 31 is lowest

extern void XgnInit( DWORD dwIXgnDevice );
// set associated IXgnDevice interface object

extern void CNCAPI XgnConnect( int Irql, PFNSERVICE pfnService, LPVOID lpParameter, int fFloatSave );
// connect to specified interrupt channel
// pfnService	pointer to service routine.
// lpParameter	pointer service parameter.
// fFloatSave	Specifies whether to save the floating-point stack

extern void CNCAPI XgnDisconnect( int Irql );
// disconnect from specified interrupt channel

extern void CNCAPI XgnFireInterrupt( int Irql );
// fire a interrupt

extern void CNCAPI XgnGetInfo( LPDWORD lpStackSize, LPDWORD lpStackFree );
// get running information

#ifdef __cplusplus
}
#endif 

#endif // !defined(_XSIGNAL_INCLUDED_)
