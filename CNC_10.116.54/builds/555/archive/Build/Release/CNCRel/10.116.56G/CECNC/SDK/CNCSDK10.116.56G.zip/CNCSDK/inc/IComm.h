// IComm.h: interface for the IComm class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ICOMM_H__87D1AF44_2F50_11D3_8440_0000E86B4150__INCLUDED_)
#define AFX_ICOMM_H__87D1AF44_2F50_11D3_8440_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IComm
{
public:
	virtual ~IComm( void ) {}
	// destructor

	virtual unsigned char readChar( void ) = 0;
	// read one character

	virtual void writeChar( unsigned char data ) = 0;
	// write one character

	virtual int isReadReady( void ) = 0;
	// query whether there are characters in read queue

	virtual int isWriteReady( void ) = 0;
	// query whether there are empty slot in write queue
};

#endif // !defined(AFX_ICOMM_H__87D1AF44_2F50_11D3_8440_0000E86B4150__INCLUDED_)
