#if !defined(_MODBUSCOMMAPI_INCLUDED_)
#define _MODBUSCOMMAPI_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

extern "C" {
// initialize
BOOL CNCAPI MODBUS_Init( const CHAR* port_name, ULONG baud_rate, INT byte_size, BYTE parity, BYTE stop_bits, DWORD nTimeOut = 1000, BOOL debug_mode = FALSE );

// de-initialize
void CNCAPI MODBUS_DeInit( void );

// function-code-01
INT CNCAPI MODBUS_FC01_ReadCoilStatus(
	BYTE nDevice_ID, USHORT nStart_Addr, USHORT nAddr_Num, BOOL* pValue, DWORD nTimeOut, 
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-02
INT CNCAPI MODBUS_FC02_ReadInputStatus(
	BYTE nDevice_ID, USHORT nStart_Addr, USHORT nAddr_Num, BOOL* pValue, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-03
INT CNCAPI MODBUS_FC03_ReadHoldingRegister(
	BYTE nDevice_ID, USHORT nStart_Addr, USHORT nAddr_Num, USHORT* pValue, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-04
INT CNCAPI MODBUS_FC04_ReadInputRegister(
	BYTE nDevice_ID, USHORT nStart_Addr, USHORT nAddr_Num, USHORT* pValue, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function code 05
INT CNCAPI MODBUS_FC05_WriteCoilStatus(
	BYTE nDevice_ID, USHORT nStart_Addr, BOOL bON, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-06
INT CNCAPI MODBUS_FC06_WriteSingleRegisters(
	BYTE nDevice_ID, USHORT nStart_Addr, USHORT nValues, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-07
INT CNCAPI MODBUS_FC07_ReadExceptionStatus(
	BYTE nDevice_ID, BYTE *pValues, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-08
INT CNCAPI MODBUS_FC08_Diagnostics(
	BYTE nDevice_ID, USHORT nAddr_Num, USHORT* pRDValue, USHORT* pWRValue, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-11
INT CNCAPI MODBUS_FC11_GetCommEventCounter(
	BYTE nDevice_ID, BYTE *pValues, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-15
INT CNCAPI MODBUS_FC15_WriteMultipleCoils(
	BYTE nDevice_ID, USHORT nStart_Addr, USHORT nAddr_Num, BOOL* pValue, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-16
INT CNCAPI MODBUS_FC16_WriteMultipleRegisters(
	BYTE nDevice_ID, USHORT nStart_Addr, USHORT nAddr_Num, USHORT* pValue, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-22
INT CNCAPI MODBUS_FC22_MaskWriteRegisters(
	BYTE nDevice_ID, USHORT nStart_Addr, USHORT* pValue, DWORD nTimeOut,
	INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );

// function-code-23
INT CNCAPI MODBUS_FC23_RDWRMultipleRegisters(
	BYTE nDevice_ID, USHORT nRD_Start_Addr, USHORT nWR_Start_Addr, USHORT nRD_Addr_Num, USHORT nWR_Addr_Num, USHORT* pRDValue, USHORT* pWRValue,
	DWORD nTimeOut, INT* result = NULL, PFNSERVICE callback = NULL, LPVOID param = NULL );
}

#endif
