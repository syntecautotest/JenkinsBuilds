// Tuple3d.h: interface for the CTuple3d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TUPLE3D_H__3D34F6EC_F7C7_42E8_A570_F63780332235__INCLUDED_)
#define AFX_TUPLE3D_H__3D34F6EC_F7C7_42E8_A570_F63780332235__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "nstdlib.h"
#define UTILAPI

class UTILAPI CTuple3d  
{
public:
	CTuple3d();
	// constructs and initialize it to zero

	CTuple3d( double x, double y, double z );
	// constructs and initializes the tuple from the specified
	// xyz coordinates.

	CTuple3d( double t[] );
	// Constructs and initializes a Tuple3d from the array of length 3.

	virtual ~CTuple3d();
	// destructor

	void add( CTuple3d &t );
	// Sets the value of this tuple to the sum of itself and t.

	void add( CTuple3d &t1, CTuple3d &t2 );
	// Sets the value of this tuple to the vector sum of tuples
	// t1 and t2.

	void negate( void );
	// Negates the value of this vector in place.

	void negate( CTuple3d &t );
	// Sets the value of this tuple to the negation of tuple t.

	void sub( CTuple3d &t );
	// Sets the value of this tuple to the vector difference of
	// itself and tuple t (this = this - t).

	void sub( CTuple3d &t1, CTuple3d &t2 );
	// Sets the value of this tuple to the vector difference of
	// tuple t1 and t2 (this = t1 - t2).

	void scale( double s );
	// Sets the value of this tuple to the scalar multiplication
	// of itself.

	void scale( double s, CTuple3d &t );
	// Sets the value of this tuple to the scalar multiplication
	// of tuple t.

	void scaleAdd( double s, CTuple3d &t );
	// Sets the value of this tuple to the scalar multiplication
	// of itself and then adds tuple t (this = s*this + t).

	void scaleAdd( double s, CTuple3d &t1, CTuple3d &t2 );
	// Sets the value of this tuple to the scalar multiplication of
	// tuple t1 and then adds tuple t2 (this = s*t1 + t2).

	void set( CTuple3d &t );
	// Sets the value of this tuple to the value of tuple t.

	void set( double x, double y, double z );
	// Sets the value of this tuple to the specified xyz coordinates.

	void set( double t[] );
	// Sets a Tuple3d from the array of length 3.

	void get( double t[] );
	// Copies the x,y,z coordinates of this tuple into the array t[]
	// of length 3.

	// public data member
	double m_x;
	double m_y;
	double m_z;
};

#endif // !defined(AFX_TUPLE3D_H__3D34F6EC_F7C7_42E8_A570_F63780332235__INCLUDED_)
