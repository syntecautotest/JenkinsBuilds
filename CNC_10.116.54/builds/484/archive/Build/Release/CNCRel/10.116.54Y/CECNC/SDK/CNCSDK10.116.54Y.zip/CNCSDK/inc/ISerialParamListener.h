// ISerialParamListener.h: interface for the ISerialParamListener class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISERIALPARAMLISTENER_H__INCLUDED_)
#define AFX_ISERIALPARAMLISTENER_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class ISerialParamListener
{
public:
	virtual ~ISerialParamListener( void ) {}
	// destructor

	virtual void CNCAPI initializeSerialParam( long nNo, long nValue ) = 0;
	// initialize serial parameter

	virtual void CNCAPI notifySerialParamChange( long nNo, long nValue ) = 0;
	// notify serial parameter change

	virtual void CNCAPI notifyParamInitialized( void ) = 0;
	// notify param initialized
};

#endif // !defined(AFX_ISERIALPARAMLISTENER_H__INCLUDED_)
