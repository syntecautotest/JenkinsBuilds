// IParamListener.h: interface for the IParamListener class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IPARAMLISTENER_H__8A82C0A6_216E_44E3_9CE8_CC187152650D__INCLUDED_)
#define AFX_IPARAMLISTENER_H__8A82C0A6_216E_44E3_9CE8_CC187152650D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class IParamListener
{
public:
	virtual ~IParamListener( void ) {}
	// destructor

	virtual void CNCAPI notifyParameterChange( long no ) = 0;
};

#endif // !defined(AFX_IPARAMLISTENER_H__8A82C0A6_216E_44E3_9CE8_CC187152650D__INCLUDED_)
