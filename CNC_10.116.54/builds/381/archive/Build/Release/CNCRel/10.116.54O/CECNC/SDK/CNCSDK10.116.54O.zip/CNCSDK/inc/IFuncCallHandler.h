#if !defined(_IFUNCCALLHANDLER_H____INCLUDED_)
#define _IFUNCCALLHANDLER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum EFuncCallState {
	EFCS_NotYetProcess = 0,
	EFCS_Executing,
	EFCS_Processed
};

class IFuncCallHandler
{
public:
	enum EMaxBounds {
		MAX_NumOfArg = SIZE_LAFuncCallArgs
	};

	struct TFuncCallParam {
		TPacketInfo PacketInfo;
		EFUNCID Opcode;
		long Param[MAX_NumOfArg];
		int nCount;
		EStopType nStopType;
	};

public:
	virtual EExecRetCode execControlInstruction(
		int opcode,					// micro opcode
		BOOL bForward,				// whether time is forward
		BOOL bMovement,				// whether has movement in this cycle
		int &state,					// instruction processing state
		long lParam[MAX_NumOfArg]	// instruction's arguments
	) = 0;

	virtual ~IFuncCallHandler( void ) {}
	// destructor

	virtual void ProcessPacketInfo( const BOOL bForward, const TPacketInfo &PacketInfo ) = 0;
	// process packet information

	virtual BOOL EnableOverlapping( long CurrMotionPlanner, long NextMotionPlanner ) = 0;
	// set overlapping motionplanner

	virtual void notifyCoordSyncEvent( void ) = 0;
	// notify coordinate synchronization event

	virtual void cancelQueuedCommand( void ) = 0;
	// cancel queued command

	virtual void notifyLatchSkipPos( void ) = 0;
	// notify latch skip positions, SkipPosition is in BLU

	virtual void InterpretFuncCall( TMotReqPkt *pMRP, TFuncCallParam &TFCP ) = 0;
	// interpret func call

	virtual void PostAlarm( int AlarmID ) = 0;
	// post alarm

	virtual BOOL IsSingleStepInhibit( void ) = 0;
	// get single step inhibit

	virtual void putSingleStepInhibit( BOOL bSingleStepInhibit ) = 0;
	// put single step inhibit

	virtual BOOL IsSingleStep( void ) = 0;
	// is single step?

	virtual void cancelAxisQueuedCommand( int nChannelCount ) = 0;
	// cancel queued command

	virtual void setMachinePosition( int nIndex, double Pos ) = 0;
	// set machine position to specified position

	virtual BOOL isFeedholdInhibit( void ) = 0;
	// is feedhold inhibit

	virtual BOOL isRecordMode( void ) = 0;
	// is in record mode

	virtual BOOL isSvoIOSignalON( ESvoIOSignal nIOSignal ) = 0;
	// is servo IO signal already on
};

#endif // !defined(_IFUNCCALLHANDLER_H____INCLUDED_)
