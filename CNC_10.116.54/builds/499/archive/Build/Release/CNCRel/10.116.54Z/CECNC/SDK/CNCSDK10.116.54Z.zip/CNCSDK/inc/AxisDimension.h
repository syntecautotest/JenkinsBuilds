// AxisDimension.h: interface for the CAxisDimension class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AXISDIMENSION_H__E49E7A1F_0AF6_43FC_B642_642EC305A78F__INCLUDED_)
#define AFX_AXISDIMENSION_H__E49E7A1F_0AF6_43FC_B642_642EC305A78F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// number of the member of EAxisType
#define NumOfAxisType 6

#include "CommonStruct.h"

#ifndef TModuloFactors_STRUCT_
#define TModuloFactors_STRUCT_

typedef struct tagModuloFactors {

	double AbsPosModuloLow;
	// modulo lowest value for absolute position round, in BLU

	double AbsPosModuloHigh;
	// modulo highest value for absolute position round, in BLU

	double MachPosModuloLow;
	// modulo lowest value for machine position round, in BLU

	double MachPosModuloHigh;
	// modulo highest value for machine position round, in BLU
} TModuloFactors;

#endif // ModuloFactors_STRUCT_

// Note:
// the parameter must consistency and storage in current
// radius/diameter unit. that is, if the axis is diameter
// axis, then its reference point, home offset, software
// limit, workpiece zero will store in diameter dimension,
// If there are necessary switch at run time for display and
// settting purpose, then I think it should be take care
// by MMI module, because the kernel must and only support a
// consistent state, which will not affect by user's desired
// display data format.
class CAxisDimension  
{
public:
	CAxisDimension();
	virtual ~CAxisDimension();

	void set( CAxisDimension *pSrc );
	// set the object internal state from pSrc object

	void set( TAxisDimContext *lpContext );
	// set axis dimension by specified context data

	void get( TAxisDimContext *lpContext );
	// get axis dimension into specified context structure

	//------------------------------------------------------------
	// plane conversion

	void PutDiameterProgramming( int Bool );
	// put diameter programming state

	void PutActiveDiameterProgramming( int Bool );
	// put active diameter programming state

	void RestoreParamDiameterProgramming( void );
	// restore param diameter programming state

	void putProgPlaneToWorkPlaneScale( double factor );
	double getProgPlaneToWorkPlaneScale( void );

	// program plane <=> work plane
	double ProgPlaneToWorkPlane( double value );
	double WorkPlaneToProgPlane( double value );

	// program plane <=> axis plane
	double AxisPlaneToProgPlane( double value );
	double ProgPlaneToAxisPlane( double value );

	// work plane <=> axis plane
	double AxisPlaneToWorkPlane( double value );
	double WorkPlaneToAxisPlane( double value );

	// like ProgPlaneToWorkPlane without programming scale
	double ToRadius( double value );

	// like WorkPlaneToProgPlane without programming scale
	double ToDiameter( double value );

	BOOL getDiameterProgramming( void );
	// get diameter programming state

	//------------------------------------------------------------
	// dimension conversion

	void ModuloPositionIU( double &position );
	// do modulo position in IU
	// position		in IU

	void ModuloPosition( double &position );
	// do modulo position in BLU
	// position		in BLU

	void ModuloMachineIU( double &position );
	// do modulo machine position in IU
	// position		in IU

	void ModuloMachine( double &position );
	// do modulo machine position in BLU
	// position		in BLU

	double CalcDisplacementIU( double from_pos, double to_pos, LONG OpCode, int Direction );
	// calculate displacement of two absolute position in IU
	// from_pos			from position in IU
	// to_pos			to position in IU

	double CalcDisplacement( double from_pos, double to_pos, LONG OpCode, int Direction );
	// calculate displacement of two absolute position in BLU
	// from_pos			from position in BLU
	// to_pos			to position in BLU

	void CalcDisplacementIU( double from_pos, double to_pos, double &displacement );
	// calculate displacement of two absolute position in IU
	// from_pos			from position in IU
	// to_pos			to position in IU

	void CalcDisplacement( double from_pos, double to_pos, double &displacement );
	// calculate displacement of two absolute position in BLU
	// from_pos			from position in BLU
	// to_pos			to position in BLU

	void AddDisplacement( double &position, double &displacement );
	// add displacement to position in BLU

	double CalcShortesDistanceBLU( double from_pos, double to_pos );
	// to calculate shortest distance for dual feedback compensation

	void setRotaryShift( double shift );
	// set rotary shift amount, in BLU

	double get_MachineUpperBound( void );
	// get machine upper bound

	DOUBLE fromBLUtoIU_forMachPos( DOUBLE position );
	// from BLU to IU for machine position

	DOUBLE fromBLUtoIU_forProgPos( DOUBLE position );
	// from BLU to IU for program position

	double fromBLUtoLIU_forMachPos( double position );
	// from BLU to LIU for machine position

	double fromBLUtoLIU_forProgPos( double position );
	// from BLU to LIU for program position

	LONG getIUDecimalPrecision_forMachPos( void );
	// get iu decimal precision for machine position

	LONG getIUDecimalPrecision_forProgPos( void );
	// get iu decimal precision for program position

	//------------------------------------------------------------
	// constant for input unit selection
	enum EAxisType {
		AXISTYPE_LINEAR = 0,
		AXISTYPE_ROTARYA,	// for orientation app.
		AXISTYPE_ROTARYB,	// for contouring app.
		AXISTYPE_ROTARYC,	// for direction-balance contouring app.
		AXISTYPE_ROTARYD,	// for linear-coordinate contouring app.
		AXISTYPE_ROTARYE	// for fix-reference linear-coordinate contouring app.
	};
	// axis type constant
	enum EInputUnit {
		IS_METRIC = 71,	// metric input unit or metric machine
		IS_INCH = 70	// inch input unit or inch machine
	};
	// machine type and input unit

	//------------------------------------------------------------
	// configuration interface for input unit delection
	// the following configuration functions should be called from
	// lowest priority thread amoung the threads which access
	// this object. because configuation function will update public
	// data member which will be access by higher priority thread,
	// so must be update by the lowest priority thread using critical
	// section lock method.

	void putInputUnit( LONG InputUnit );
	// set input unit.
	// IS_METRIC	for metric input.
	// IS_INCH		for inch input.
	// when the input unit changed, the coordinate
	// display, MPG incremental, incrmental JOG, part program
	// will be changed according the input unit.

	void putIncSystemType( LONG IncSystemType );
	// set the incremental system type.
	// 2			for low resolution,		0.01mm,   0.01 deg,  0.001 inch
	// 3			for normal resolution.	0.001mm,  0.001deg,  0.0001 inch
	// 4			for high resolution.	0.0001mm, 0.0001deg, 0.00001 inch

	void putAxisType( LONG AxisType );
	// put axis type.

	void notifyLinearAxisType( void );
	// notify AXISTYPE_LINEAR to axis

	void restoreAxisType( void );
	// restore axis type

	LONG getAxisType( void );
	// get axis type

	BOOL IsLinear( void );
	// query whether this axis is linear?

	BOOL IsDefLinear( void );
	// query whether the default state of this axis is linear?

	//------------------------------------------------------------
	// IU <=> BLU conversion
	double m_fromBLUtoIU_Linear;
	// convert to input unit from basic command unit for linear axis

	double m_fromBLUtoIU_Rotary;
	// convert to input unit from basic command unit for rotary axis

	double m_fromBLUtoIU;
	// convert to input unit from basic command unit

	double m_fromIUtoBLU_Linear;
	// convert to basic command unit from input unit for linear axis

	double m_fromIUtoBLU_Rotary;
	// convert to basic command unit from input unit for rotary axis

	double m_fromIUtoBLU;
	// convert to basic command unit from input unit

	//------------------------------------------------------------
	// IU <=> LIU conversion
	double m_fromLIUtoIU_Linear;
	// convert to input unit from least input unit for linear axis

	double m_fromLIUtoIU_Rotary;
	// convert to input unit from least input unit for rotary axis

	double m_fromLIUtoIU;
	// convert to input unit from least input unit

	double m_fromIUtoLIU_Linear;
	// convert to least input unit from input unit for linear axis

	double m_fromIUtoLIU_Rotary;
	// convert to least input unit from input unit for rotary axis

	double m_fromIUtoLIU;
	// convert to least input unit from input unit

	//------------------------------------------------------------
	// BLU <=> LIU conversion
	double m_fromLIUtoBLU_Linear;
	// convert to basic command unit from least input unit for linear
	// axis

	double m_fromLIUtoBLU_Rotary;
	// convert to basic command unit from least input unit for rotary
	// axis

	double m_fromLIUtoBLU;
	// convert to basic command unit from least input unit

	double m_fromBLUtoLIU_Linear;
	// convert to least input unit from basic command unit for linear
	// axis

	double m_fromBLUtoLIU_Rotary;
	// convert to least input unit from basic command unit for rotary
	// axis

	double m_fromBLUtoLIU;
	// convert to least input unit from basic command unit

	//------------------------------------------------------------
	// BLU to IU conversion factor for spindle
	double m_fromLinearIUtoCSSIU;
	// convert from Linear IU to CSS IU, CSS is constant surface speed length
	// unit

	//------------------------------------------------------------
	// BLU to MM conversion factor
	double m_fromMMtoBLU;
	// to convert mm into BLU

	//------------------------------------------------------------
	// MM to IU
	double m_fromMMtoIU;
	// to convert mm into IU

	//------------------------------------------------------------
	// IU decimal precision
	LONG m_IUDecimalPrecision_Linear;
	// get input unit decimal precision for linear axis

	LONG m_IUDecimalPrecision_Rotary;
	// get input unit decimal precision for rotary axis

	LONG m_IUDecimalPrecision;
	// get input unit decimal precision

	double m_TableNormalizeFactor;
	// for tool offset table and workpiece offset table must be convert into active diameter programming
	// dimension before use it when active diameter programming is different from parameter diameter
	// programming. because these table saved in the dimension accroding parameter setting.

private:
	BOOL m_fParamDiameterProgramming;
	// flag to record whether this axis is diameter programming

	BOOL m_fActiveDiameterProgramming;
	// flag to record whether this axis is diameter programming

	LONG m_IncSystemType;
	// incremental system type A/B/C

	LONG m_InputUnit;
	// Input Unit, 0 for metric, 1 for inch

	int m_DefAxisType;
	int m_AxisType;
	// axis type
	// CAxisCore::AXISTYPE_LINEAR for axis is linear,
	// CAxisCore::AXISTYPE_ROTARY for axis is rotary

	double m_RotaryShift;
	// rotary shift amount

	double m_ProgToWorkScale;
	// the program plane to work plane scale

	TModuloFactors m_ModuloFactors[NumOfAxisType];
	// modulo factors

	double m_ProgPlaneToWorkPlane;
	double m_WorkPlaneToAxisPlane;

	static const double EPSILON_Quantize;

private:
	void CalcConversionFactors( void );
	// decimal precision table according incremental system
	// type, machine type, and input unit.

	void syncPlaneConversionFactor( void );

	void updateModuloFactor( void );
	// update modulo factor

	void ChangeAxisType( LONG AxisType );
	// change axis type
	// AXISTYPE_LINEAR	for axis is linear.
	// AXISTYPE_ROTARYA	for axis is rotary.
	// AXISTYPE_ROTARYB	for axis is rotary.
	// AXISTYPE_ROTARYC	for axis is rotary.
	// AXISTYPE_ROTARYD	for axis is rotary.
	// AXISTYPE_ROTARYE	for axis is rotary.

};

#endif // !defined(AFX_AXISDIMENSION_H__E49E7A1F_0AF6_43FC_B642_642EC305A78F__INCLUDED_)
