// SpeedMeter.h: interface for the CSpeedMeter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPEEDMETER_H__B646AD87_C4D4_457B_97A7_A8A603541DA8__INCLUDED_)
#define AFX_SPEEDMETER_H__B646AD87_C4D4_457B_97A7_A8A603541DA8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IFeedbackPosition;
class CMovingAverageFilter;

#define TIME_SpeedMeterPeekInterval		100000

class CSpeedMeter  
{
public:
	CSpeedMeter( long PeekInterval = TIME_SpeedMeterPeekInterval );
	virtual ~CSpeedMeter();

	void setFbkPosInterface( IFeedbackPosition *pFbkPos );
	// set associated feedback position object

	double GetSpeed( void );
	// get real speed

	double GetSmoothedSpeed( void );
	// get speed which is smoothed by a 100ms moving averae filter.

	void SyncFbkAbsoultePos( void );
	// sync feedback absoulte position

	void InterpolationTick( void );
	// Use threads: interpolation

private:
	IFeedbackPosition *m_pFbkPos;
	// associated feedback position object

	CMovingAverageFilter *m_pSpeedSmoother;
	// the speed smoother

	double m_Speed;
	// speed in BLU

	double m_SmoothedSpeed;
	// speed in BLU

	long m_LastAbsolutePosition;
	// last absolute position in BLU

	long m_TimeBase;
	// speed timebase in micro-second
};

#endif // !defined(AFX_SPEEDMETER_H__B646AD87_C4D4_457B_97A7_A8A603541DA8__INCLUDED_)
