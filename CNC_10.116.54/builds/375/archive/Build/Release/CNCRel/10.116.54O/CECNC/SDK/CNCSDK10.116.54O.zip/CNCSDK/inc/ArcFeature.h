#if !defined(_ARCFEATURE_H____INCLUDED_)
#define _ARCFEATURE_H____INCLUDED_

class CArcFeature
{
public:
	CArcFeature(void);
	~CArcFeature(void);

	static void calcPerpendicularVector( double InVal[], double normal[], double OutVal[] );
	// to calculate vector which perpendicular to specified normal vector

	void set( int code, double displacement[], double center[], double vRefNormal[], long nNumOfRev );
	// to set 3-D arc data

	BOOL isValidArc( void );
	// check whether it is valid arc

	double getLength( void );
	// get length of arc

	double getAngleSpan( void );
	// get span angle

	double getWPQuantity( void );
	// get the workplane quantity amount

	double getZQuantity( void );
	// get the helical-Z axis quantity amount.this value may be negative,
	// when Z-axis displacement is different with its normal vector.

	double getStartRadius( void );
	// get start radius amount   

	double getEndRadius( void );
	// get end radius amount   

	void getTransform( /*[out]*/double Tx[] );
	// to get transform matrix

	void getEnterDirection( /*[out]*/double direction[] );
	// to get enter unit vector at start point

	void getLeaveDirection( /*[out]*/double direction[] );
	// to get leave unit vector at end point

	void queryPoint( /*[in]*/double ratio, /*[out]*/double displacement[] );
	// to query arc point, which has specified distance ratio retative to start point of arc.

private:
	long m_nNumOfRev;
	// number of revolutions

	CVector3d m_vDisplacement;
	// vector from start position to end position

	CVector3d m_vCenter;
	// vector from start position to center point

	CVector3d m_vStart;
	// vector from center point to start position

	CVector3d m_vEnd;
	// vector from center point to end position

	CVector3d m_vNormal;
	// normal vector working plane

	BOOL m_bValidArc;
	// flag for valid arc

	double m_RadiusDestortion;
	// radius distortion

	double m_AngleSpan;
	BOOL m_bAngleSpan;

	double m_WPQuantity;
	BOOL m_bWPQuantity;
	// length of projection on work plane

	double m_Length;
	BOOL m_bLength;
	// arc total length

	CVector3d m_vEnterDirection;
	BOOL m_bEnterDirection;
	// enter direction

	CVector3d m_vLeaveDirection;
	BOOL m_bLeaveDirection;
	// leave direction

	double m_Tx[9];
	BOOL m_bTx;
	// transform matrix

private:	// helper function
	void calcTransform( void );
	// to calculate transform matrix

	void doTransfrom( double &x, double &y, double &z );
	// do transform from arc coordinate to world coordinate
};

#endif // !defined(_ARCFEATURE_H____INCLUDED_)
