#if !defined(_Mix_INCLUDE_)
#define _Mix_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMixListener : public IListener
{
public:

	CMixListener();
	
	~CMixListener();

	void Trigger( TEvtInfo *pEvtArg, va_list var );

	void Register( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg );

	void Unregister( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg );

private:
	CObList *m_mixEvents;

	class CListenerInfo: public CObject {
	public:
		CListenerInfo( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg );

		// Event
		INT			m_nEvtID;
		INT			m_nEvtArg;

		// start rule
		INT			m_nStartID;
		INT			m_nStartArg;

		// end rule
		INT			m_nEndID;
		INT			m_nEndArg;

		// when start event is triggered and end event is not triggered
		BOOL		m_bReady;
	};

	BOOL checkReadyState( INT nEvtID, INT nEvtArg, CListenerInfo *info );
	// return TRUE:status change, return FALSE: status NOT change

	BOOL FindListenerInfo( INT nEvtID, INT nEvtArg, INT nStartID, INT nStartArg, INT nEndID, INT nEndArg, POSITION &position );

};

#endif // !defined(_Mix_INCLUDE_)
