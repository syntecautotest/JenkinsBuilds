// Matrix4d.h: interface for the CMatrix4d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATRIX4D_H__EF74CBBC_A7F2_4832_8A10_E97CBEB0C88F__INCLUDED_)
#define AFX_MATRIX4D_H__EF74CBBC_A7F2_4832_8A10_E97CBEB0C88F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class CAxisAngle4d;
class CVector3d;
class CPoint3d;
class CTuple4d;

class UTILAPI CMatrix4d  
{
public:
	CMatrix4d();
	// Constructs and initializes a Matrix4d to all zeros.

	CMatrix4d( CMatrix4d &m );
	// constructs and initializes matrix from another matrix

	CMatrix4d( CAxisAngle4d &a );
	// constructs and initializes matrix from the specified 
	// axis-angle specification

	virtual ~CMatrix4d();
	// destructor

	double getElement( int row, int column );
	// get the specified element value

	void mul( CMatrix4d &m );
	// Sets the value of this matrix to the result of multiplying
	// itself with matrix m.

	void mul( CMatrix4d &m1, CMatrix4d &m2 );
	// Sets the value of this matrix to the result of multiplying
	// the two argument matrices together.

	void set( CMatrix4d &m );
	// Sets the value of this matrix to a copy of the passed matrix m

	void set( CAxisAngle4d &a );
	// Sets the value of this matrix to the matrix conversion of
	// the double precision axis and angle argument.

	void set( double scale, CVector3d &v );
	// Sets the value of this transform to a scale and translation
	// matrix; the scale is not applied to the translation and all
	// of the matrix values are modified.

	void set( double a[] );
	// Sets the value of this matrix to form specified 1-dimensional array
	// the data sequence is a11, a12, a13, a14, a21, a22, .., a41, a42, a43, a44.
	// the translation vector is (a14,a24,a34)

	void get( CMatrix4d &m );
	// Getts the value of this matrix into specified matrix

	void get( double a[] );
	// Gets the value of this matrix into specified 1-dimensional array
	// the data sequence is a11, a12, a13, a14, a21, a22, .., a41, a42, a43, a44.
	// the translation vector is (a14,a24,a34)

	void setElement( int row, int column, double value );
	// set element value;

	void setTranslation( CVector3d &trans );
	// This method modifies the translational components of this matrix
	// to the values of the vector trans. The other values of this matrix
	// are not modified.

	void setZero( void );
	// Sets this matrix to all zeros.

	void setIdentity( void );
	// Sets this Matrix4d to identity.

	void transform( CTuple4d &vec );
	// Transforms the vec tuple with this Matrix4d and places
	// the result back into vec.

	void transform( CTuple4d &vec, CTuple4d &vecOut );
	// Transforms the vec tuple with this Matrix4d and places
	// the result into ptOut.

	void transform( CPoint3d &pt );
	// Transforms the pt point with this Matrix4d and places
	// the result back into pt. The fourth element of the point input
	// paramter is assumed to be one.

	void transform( CPoint3d &pt, CPoint3d &ptOut );
	// Transforms the pt point with this Matrix4d and places
	// the result into ptOut. The fourth element of the point input
	// paramter is assumed to be one.

	void transform( CVector3d &normal );
	// Transforms the normal vector with this Matrix4d and places
	// the result back into normal. The fourth element of the point input
	// paramter is assumed to be zero.

	void transform( CVector3d &normal, CVector3d &normalOut );
	// Transforms the normal vector with this Matrix4d and places
	// the result into ptOut. The fourth element of the point input
	// paramter is assumed to be zero.

	void invert( CMatrix4d &m );
	// Inverts matrix m and places the new values into this matrix

	void rotX(double angle);
	void rotY(double angle);
	void rotZ(double angle);
	// The rot methods construct rotation matrices that rotate in a
	// counterclockwise (right-handed) direction around the axis specified
	// as the last letter of the method name. The constructed matrix
	// replaces the value of the matrix this. The rotation angle is
	// expressed in radians.

	BOOL linefitting(double *lpData[3], int count, double orientation[3]);
	// do eigenvector line fitting

private:

	enum EMaxBound {
		MATDIM = 4
	};

	// private data member
	double m_matrix[MATDIM][MATDIM];

private:
	int LUD( double LU[MATDIM][MATDIM], double permutation[MATDIM] );
	// LU Decomposition; this matrix must be a square matrix; the LU matrix
	// parameter must be the same size as this matrix

	static void LUDBackSolve( double x[MATDIM], double LU[MATDIM][MATDIM], double b[MATDIM], double permutation[MATDIM] );
	// LU Decomposition Back Solve; this method takes the LU matrix and the
	// permutation vector produced by the GMatrix method LUD and solves the
	// equation (LU)*x = b by placing the solution vector x into this vector

	static int ludcmp(double a[MATDIM][MATDIM], int *indx, double *d);
	// Given a matrix a[1..4][1..4], this routine replaces it by the LU
	// decomposition of rowwise permutation of itself.
	// a and n are input. The matrix a will be overwritten as the combination
	// of a lower diagonal and upper diagonal matrix decompostion of this
	// matrix; the diagonal elements of L (unity) are not stored, the layout
	// as following:
	//							b11	b12 b13 b14
	//							a21 b22 b23 b24
	//							a31 a32 b33 b34
	//							a41 a42 a43 b44
	// indx[1..4] is an output vector that records the row permutation
	// effected by the partial pivoting;
	// d is output as 1/-1 depending one whether the number of row
	// interchanges was even or odd, respectively.

	static void lubksb(double a[MATDIM][MATDIM], int *indx, double b[MATDIM]);
	// Solve the set of n linear equation A.X = B.
	// a[1..4][1..4] is input, not as the matrix A but rather as its LU
	// decomposition.
	// indx[1..4] is input as the permutation vector.
	// b[1..4] is input as the right-hand side vector B, and return with
	// the solution vector X.
	// a,indx are not modified by this routine and can be left in place
	// for successive calls with different right-hand sides b.
	// This routine takes into account the possibility that b will begin
	// with many zero elements, so it is efficient for use in matrix
	// inversion.

	static void tred2(double a[MATDIM][MATDIM], double d[MATDIM], double e[MATDIM], int dim);
	// Householder reduction of a real, symmetric matrix a[1..n][1..n]. On output, a is replaced
	// by the orthogonal matrix Q effecting the transformation. d[1..n] returns the diagonal ele-
	// ments of the tridiagonal matrix, and e[1..n] the off-diagonal elements, with e[1] = 0. Several
	// statements, as noted in comments, can be ommitted if only eigenvalues are to be found, in which
	// case a contains no useful information on output. Otherwise they are to be included.

	static BOOL tqli(double d[MATDIM], double e[MATDIM], int dim, double z[MATDIM][MATDIM]);
	// QL algorithm with implicit shifts, to determine the eigenvalues and eigenvectors of a real, sym-
	// metric, tridiagonal matrix, or of a real, symmetric matrix previously reduced by tred2(). On
	// input, d[1..n] contains the diagonal elements of the tridiagonal matrix. On output, it returns
	// the eigenvalues. The vector e[1..n] inputs the subdiagonal elements of the tridiagonal matrix,
	// with e[1] arbitary. On out e is destroyed. When finding only the eigenvalues, several lines
	// may be ommited, as noted in the comments. If the eigenvectors of a tridiagonal matrix are de-
	// sired, the matrix z[1..n][1..n] is input as the identity matrix. If the eigenvectors of a matrix
	// that has been reduced by tred2() are required, then z is input as the matrix output by tred2()
	// In ether case, the kth column of z returns the normalized eigenvector corresponding to d[k]

	static const double LUD_Tiny;
	// a small number for LU decomposition
};

#endif // !defined(AFX_MATRIX4D_H__EF74CBBC_A7F2_4832_8A10_E97CBEB0C88F__INCLUDED_)
