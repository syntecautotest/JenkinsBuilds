#if !defined(AFX__IPHYSICALDRIVER_H__D8CFF4BF_81AC_4847_8853_465417944DC6__INCLUDED_)
#define AFX__IPHYSICALDRIVER_H__D8CFF4BF_81AC_4847_8853_465417944DC6__INCLUDED_

enum EPhyChType {
	EPCT_Svo = 0,
	EPCT_IO = 1,
	EPCT_DA = 2,
};

class IPhysicalDriver
{
public:
	virtual ~IPhysicalDriver( void ) {};
	// destructor

	virtual void* CNCAPI GetPhyChannel( EPhyChType nPhyChType, INT nPortID ) = 0;
	// To get the control of indicated physical channel.
};
#endif // AFX__IPHYSICALDRIVER_H__D8CFF4BF_81AC_4847_8853_465417944DC6__INCLUDED_
