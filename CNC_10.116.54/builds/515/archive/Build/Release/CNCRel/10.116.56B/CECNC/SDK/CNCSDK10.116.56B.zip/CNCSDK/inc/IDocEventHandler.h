#if !defined(_IDOCEVENTHANDLER_H_INCLUDED_)
#define _IDOCEVENTHANDLER_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IDocEventHandler
{
public:
	virtual ~IDocEventHandler( void ) {}
	// destructor

	virtual void OnDocChanged( LONG nStartLineNo ) = 0;
	// to notified document changed, the line schema also been changed

	virtual void OnDocValueChanged( LONG nLineNo ) = 0;
	// to notified value has changed of specified line

	virtual void OnDocumentClosed( void ) = 0;
	// to notified the document has closed
};

#endif // !defined(_IDOCEVENTHANDLER_H_INCLUDED_)

