// CFramStore.h: interface for the CFramStore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRAMSTORE_H__37CB3D22_5304_4a46_8A45_3E2342E6ED9F__INCLUDED_)
#define AFX_FRAMSTORE_H__37CB3D22_5304_4a46_8A45_3E2342E6ED9F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdio.h>
#include "RTMutex.h"

#define FRAM_ArrayUseSize					4000
// we offer 4000 array element for user
// the left 4000 use for mirror, 80 CRC check
#define FRAM_CrcCheckSumUnit				50
// each 50 Fram unit do CRC, and put in (no mode 50) position
#define FRAM_CrcArraySize					80
// 4000 element, 1 unit has 50 element, so array size is 80
#define FRAM_CrcStartPos					8001
#define FRAM_CrcMirStartPos					8101
// CRC array put from position 8001
// mirror data CRC array put from position 8101

class CZCRC32;
class CPlatform;

class CFramStore
{
public:
	CFramStore( void );
	// constructs a empty fram store

	virtual ~CFramStore();
	// destructs this object

	void putValueArray( int StartNo, long *buffer, int count, long *pLengthWrite );
	// put value into fram

	void putValueArrayEx( int StartNo, long *buffer, int count, long *pLengthWrite, BOOL bForceWrite );
	// put value into fram, and can force write back(for CRC calculate update)

	void getValueArray( int StartNo, long *buffer, int count, long *pLengthRead );
	// get value from fram

	void putString( long no, char *str, int size );
	// put string data into Fram

	long getString( long no, char *str, int size );
	// get string data from Fram

	BYTE PureReadData( WORD addr );
	// read single byte data from addr

	void PureWriteData( WORD addr, BYTE data );
	// write single byte data to addr

	BOOL IsTwoCRCError(void);
	// get if fram restore has two CRC error

private:
	unsigned long mCRCArray[FRAM_CrcArraySize];
	// use for record CRC Value

	unsigned long mCRCArray_Mir[FRAM_CrcArraySize];
	// use for record mirror CRC Value

	long m_pFramMemBuf[FRAM_ArrayUseSize * 2];
	// record Fram mem data, for dirty compare

	void writeFramTableBlockEx( int StartNo, long *buffer, int Length, BOOL bForceWrite );
	// put value and do CRC & mirror into fram

	long readFramTableBlock( int StartNo, long *buffer, int Length );
	// get value from fram and do CRC check

	void backupFram( void );
	// backup fram data to file, for ATOM system restore use

	void restoreFram( void );
	// restore fram data from file, when ATOM system CRC Error

	BOOL isATOMCpuBoard( void );
	// read mother board type, and check if it is ATOM

	BOOL m_bTwoCRCErr;
	// error count

	CPlatform *m_pPlatform;
	// platform api object.

	CRTMutex m_cs;
	// mutex for object state consistent

	CZCRC32 *m_CRC;
	// crc helper object

	void GetCRC32( const BYTE lpBuffer[ ], unsigned nLength, unsigned long *lpCrc );
	// get CRC encode value

	BOOL IsCRCCorrect( const BYTE lpBuffer[ ], unsigned nLength, unsigned long lCrc );
	// check if CRC value is correct
};


#endif // !defined(AFX_FRAMSTORE_H__37CB3D22_5304_4a46_8A45_3E2342E6ED9F__INCLUDED_)

