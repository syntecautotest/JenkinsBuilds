#if !defined(_IMPGCHANNEL_H_INCLUDED_)
#define _IMPGCHANNEL_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_MPGIOChannel		4

class IMPGChannel
{
public:
	virtual ~IMPGChannel( void ) {}
	// destructor

	virtual long CNCAPI getMpgAbsCounter( void ) = 0;
	// get mpg absolute counter
};

#endif // !defined(_IMPGCHANNEL_H_INCLUDED_)
