#if !defined(_ILASERCTRL_H_INCLUDED_)
#define _ILASERCTRL_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ILaserCtrl
{
public:
	virtual ~ILaserCtrl( void ) {}
	// destructor

	virtual void setLaserHomePosition( int nAxisID ) = 0;
	// set laser home position

	virtual int getStatus( void ) = 0;
	// get status 0: not ready 1: ready 2: busy 3: manual

	virtual long queryLaserFreeBufferSize( void ) = 0;
	// query laser free buffer size

	virtual void putPrintData( BYTE *pData, long nSize ) = 0;
	// put data needed in print mode

	virtual void SetGalvoServoOn( BOOL bOn ) = 0;
	// set galvo module servo ON/OFF for all axis

	virtual BOOL GetGalvoServoState( void ) = 0;
	// get galvo module servo ON/OFF state

	virtual void GalvoHomeSetting( void ) = 0;
	// clear galvo module absolute count for all axis

	virtual BOOL SetTableMode( long nMode ) = 0;
	// set mode

	virtual BOOL SetFocalLength( long nFocalLength ) = 0;
	// set focal length

	virtual BOOL SetDesiredCentralLength( long nLength ) = 0;
	// set desired central line length

	virtual BOOL SetGridCount( long nCount ) = 0;
	// set grid count

	virtual BOOL SetActualCentralLength( long nCount, long *pLength ) = 0;
	// set actual length of central line

	virtual BOOL SetBarrelFactor( double BFx[], double BFy[] ) = 0;
	// set barrel factor

	virtual BOOL SetRotationInfo( long nAngle, long nCenterX, long nCenterY ) = 0;
	// set rotation angle and center

	virtual BOOL SetGeomAdjustParam( long nSelect, long nFactorX, long nFactorY ) = 0;
	// set geometry adjustment parameter

	virtual BOOL SetScaleAndOffset( long nCount, long *pSetting ) = 0;
	// set offset value

	virtual BOOL SetZAxisInfo( long nZCount, long *pZPos, long nZAngleMin, long nZAngleMax ) = 0;
	// set z axis information

	virtual BOOL AdjustSpecifiedPoint( long nXCount, long nYCount, long nMaxSize, long PosCmd[], long ActualPos[] ) = 0;
	// adjust specified angle due to error of end point

	virtual long GetTableMode( void ) = 0;
	// get table mode

	virtual long GetFocalLength( void ) = 0;
	// get focal length

	virtual long GetDesiredCentralLength( void ) = 0;
	// get desired length

	virtual long GetGridCount( void ) = 0;
	// get grid count

	virtual long GetActualCentralCount( void ) = 0;
	// get actual cnetral length count

	virtual void GetActualCentralLength( long *pLength ) = 0;
	// get central length

	virtual void GetBarrelFactor( double BFx[], double BFy[] ) = 0;
	// get barrel factor

	virtual void GetRotationInfo( long &nAngle, long &nCenterX, long &nCenterY ) = 0;
	// get rotation infomation

	virtual void GetGeomAdjustParam( long nSelect, long &nFactorX, long &nFactorY ) = 0;
	// get geometry adjustment parameter

	virtual long GetZAxisCount( void ) = 0;
	// get z-axis count

	virtual void GetZAxisInfo( long *pZPos, long &nZAngleMin, long &nZAngleMax ) = 0;
	// get z axis information

	virtual void GetScaleAndOffset( long *pSetting ) = 0;
	// get scale and offset

	virtual BOOL PutDCTParam( BYTE *pData, long nSize ) = 0;
	// put DCT parameter

	virtual BOOL GetDCTParamCount( long &nSize ) = 0;
	// get DCT parameter count

	virtual BOOL GetDCTParam( BYTE *pData ) = 0;
	// get DCT parameter

	virtual BOOL SaveDCTData( long nDestination ) = 0;
	// save DCT data

	virtual BOOL ClearDCTData( long nDestination ) = 0;
	// clear DCT data

	virtual BOOL SetDCTUserStrokeLimit( LONG nDir, LONG nMin, LONG nMax ) = 0;
	// set DCT user defined stroke limit
	// nDir is valid for 1~3

	virtual BOOL GetDCTUserStrokeLimit( LONG nDir, LONG &nMin, LONG &nMax ) = 0;
	// get DCT user defined stroke limit
	// nDir is valid for 1~3

	virtual void TrackingModeRequest( BOOL bRequest ) = 0;
	// tracking mode request

	virtual void putFileName( char name[], int nCount ) = 0;
	// put file name

	virtual BOOL isListFull( void ) = 0;
	// query is list full

	virtual BOOL isMotionFinish( void ) = 0;
	// query is motion finish

	virtual void SetSyncChecked( void ) = 0;
	// set sync checked

	virtual BOOL isWaitSync( void ) = 0;
	// query is wait sync
};

#endif // !defined(_ILASERCTRL_H_INCLUDED_)
