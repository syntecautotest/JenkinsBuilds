#if !defined(_FLCUTSTRING_H____INCLUDED_)
#define _FLCUTSTRING_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCurvatureCalculator;
class CArcFeature;

class CFLCutString : public CFeedLimit
{
public:
	CFLCutString( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	~CFLCutString( void );
	// destructor

	void putLookAheadCondition( const double ChordErrorTol, const double CornerFeedrate, const double ArcRefRadius, const double ArcRefFeedrate );
	// set maximum allowable feedrate for motion block movement
	// chord error tolerance, in IU
	// corner feedrate at 120 degree, in IU / us
	// arc reference radius and reference feedrate, in IU, and IU / us

public:
	BOOL IsEmpty( void );
	// query whether the pipe is empty

	void Abort( void );
	// abort

	void Reset( void );
	// reset

public:
	void putLANode( TLANode *pNode, double eParam1 = 0 );
	// put look ahead node to feed limit module

	void PutLANodeToCurvPart( TLANode *pNode );
	// put look ahead node to curvature part of feed limit module

	void notifySingleStep( BOOL bSingleStep );
	// put single step 

public:
	void CalcBlockLength( TLANode *pNode, CArcFeature &af );
	// calculate block length.

	int getCount( void );
	// get count

protected:
	void FlushAllQueue( void );
	// flush queued nodes of feed limit module

	TLANode *ReversePeek( void );
	// peek the last node in feed limit module

	void CalcBlockMotionFeature( TLANode *pNode, CArcFeature &af );
	// calculate block motion feature

private:
	void ClampBlockFeedrateByProgramFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum programming feedrate

	void ClampBlockFeedrateByCompoundFeedrate( TLANode *pNode );
	// put a wait function node to process command in queue

	void ClampBlockFeedrateByAxisFeedrate( TLANode *pNode );
	// clamp block feedrate by maximum axis cutting feedrate

	void ClampBlockAcc( TLANode *pNode );
	// clamp block acceleration

	void ClampBlockJerk( TLANode *pNode );
	// clamp block jerk by maximum jerk and maximum axis jerk

protected:
	virtual void CalcCornerFeature( TLANode *pNode, double &eLastVc );
	// to calculate inter-block feature

private:
	BOOL CalculateCornerDeviation( TLANode *pNode, TLANode *pLNode, double &eDeviationLen, double eDeviation[] );
	// calculate corner deviation and its length

	void ClampCornerFeedrateBy406( TLANode *pNode, double eDeviationLen );
	// clamp corner feedrate by parameter 406

	void ClampCornerFeedrateByAxis406( TLANode *pNode, double eDeviation[] );
	// clamp corner feedrate by maximum feedrate difference of each axis

	void ClampCornerFeedrateByBlockFeedrate( TLANode *pNode, TLANode *pLNode );
	// clamp corner feedrate by block feedrate

private:
	CCurvatureCalculator *m_pCurvatureCalculator;
	// curvature calculator object pointer

private:
	enum ETimeAxCmd {
		COMMAND_INIT = -1,
		COMMAND_UNMODIFY,
		COMMAND_MODIFY
	};

	void PutCmdProcessFuncNode( ETimeAxCmd ModifyCmd );
	// put a shift function node to flush command

private:
	ETimeAxCmd m_LastTimeAxExist;
	// last node has displacement in time axis

	BOOL m_bSingleStepEvent;
	// single step event

	BOOL m_bSingleStepInhibit;
	// single step inhibit

};

#endif // !defined(_FLCUTSTRING_H____INCLUDED_)
