// Trajectory.h: interface for the CTrajectory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRAJECTORY_H__85B84D2F_E947_459E_AD27_FF6F9ACDA9B3__INCLUDED_)
#define AFX_TRAJECTORY_H__85B84D2F_E947_459E_AD27_FF6F9ACDA9B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CControlSystem;

#define PlanBlockDebugMode	0
#define TrajEpsilon			1.0e-11

class CTrajectory
{
public:
	enum EProfileType {
		PT_StrictMonotone,
		PT_FindVpeak,
		PT_Monotone,
		PT_TouchVmax
	};
	// profile type

	struct TTrajInfo {
		int		nLength;
		double	Displacement;
		TPVTSegment segment[4];
	};

	struct TBlkFeature {
		double P1;
		double P2;
		double A1;
		double A2;
		double J1;
		double J2;
		double V;
		double P3;

		TBlkFeature() { // init
			P1 = 0.0;
			P2 = 0.0;
			A1 = 0.0;
			A2 = 0.0;
			J1 = 0.0;
			J2 = 0.0;
			V = 0.0;
			P3 = 0.0;
		}
	};
	// data structure for profile characteristic
	// P1 : distance of the front part
	// P2 : rear part distance of the rear part
	// A1 : acceleration of the front part
	// A2 : acceleration of the rear part
	// J : jerk for full block
	// V : max/min velocity for full block, for find gaol veclocity case
	// P3 : distance of Vmax section, for find Vmax length case

public:
	CTrajectory();
	// constructor

	virtual ~CTrajectory();
	// destructor

	friend class CTrajectoryTest;

	friend void DumpDebugData(CControlSystem *pCtrl, long *buffer);
	friend void GetRefDebugData( CControlSystem *pCtrl, long no, long *buffer );
	// open friend relationship to dump object state for debug purpose

	long getSolveRootErrCode( void );
	// get error code of solving polynomial root for debug data

	double CalcSCurveVc_Acc( double V0, double P, double A, double J, double *Tout = NULL );
	// calculate Vc of acceleration S-curve programming under the constraint A0 = Ac = 0
	// initial velocity V0, distance P, maximum acceleration A, and maximum jerk J are known
	// return Vc

	double CalcSCurveVc_Dec( double V0, double P, double A, double J );
	// calculate Vc of deceleration S-curve programming under the constraint A0 = Ac = 0
	// initial velocity V0, distance P, maximum acceleration A, and maximum jerk J are known
	// this function process P < P_stop only
	// return Vc

	BOOL CalcSCurveVc_Dec( double V0, double P, double A, double J, double &V_low, double &V_high );
	// Calculate Vc of deceleration S-curve programming under the constraint A0 = Ac = 0
	// Initial velocity V0, distance P, maximum acceleration A, and maximum jerk J are known
	// P_stop : distance of decreasing velocity from V0 to 0 by this method of programming
	// V_low : the lower bound of the inhibit interval
	// V_high : the upper bound of the inhibit interval
	// this function process P >= P_stop only
	// return	TRUE	: could decelerate from V0 to 0 with the inhibit interval
	//			FALSE	: could decelerate from V0 to 0 without the inhibit interval

	double planStartupStopdown( double V0, double A0, double Vmax, double Amax, double Jmax, TTrajInfo *lpTraj );
	// plan from (V0, A0) to (Vmax, 0) with Amax and Jmax

public:
	double VelDiff_T( double A0, double Ac, double T );
	// velocity difference from acceleration A0 to Ac using time T

	double VelDiff_J( double A0, double Ac, double J );
	// velocity difference from acceleration A0 to Ac using jerk J

	double DistDiff_T( double V0, double A0, double Ac, double T );
	// distance difference from (V0, A0) to Ac using time T

	double DistDiff_J( double V0, double A0, double Ac, double J );
	// distance difference from (V0, A0) to Ac using jerk J

	double DistDiff_Back_T( double A0, double Vc, double Ac, double T );
	// distance difference from A0 to (Vc, Ac) using time T

	double DistDiff_Back_J( double A0, double Vc, double Ac, double J );
	// distance difference from A0 to (Vc, Ac) using jerk J

protected:
	void OutputPVT( TPVTSheet *pPVT, double P, double V, double T );
	// to output PVT segment into PVT sheet

	void packSheet( TPVTSheet *pPVT, double P, BOOL bNormalize = TRUE );
	// do final PVT sheet modification and packing before output
	// pPVT		[out] pointer to PVT segment buffer.
	// P		[in] the total compound displacement.
	// bNormalize	if normalize the value of P and V

	double OutputTrajData( TTrajInfo *&lpTraj, double dP[], double dV[], double dT[] );
	// output trajectory data and return total distance

public:
	void ConstructPVT( double V0, double Vc, double A0, double Ac, double Vmax, double Amax, int Type, TBlkFeature &BlkFeature, TPVTSheet *pPVT );
	// construct data structure PVT
	// In this object, T is the distance of the master axis

	void examSheet( TPVTSheet *pPVT, double P, double T );
	// exam the length P of the PVT
	// pPVT		[out] pointer to PVT segment buffer.
	// P		[in] the total compound displacement, in BLU.

protected:
	static long m_nSolveRootErrCode;
	// error code of solving polynomial root

protected:
	void OutputHalfSection( double &V0, double Vc, double A0, double Apeak, double Ac, double J, double P, double Amax, TPVTSheet *pPVT );
	// write PVT information for half section and accumulate V0

	void ThreeSections( double &V0, double Vc, double A0, double Apeak, double Ac, double J, double L, TPVTSheet *pPVT );
	// three PVM sections and accumulate V0

	void TwoSections( double &V0, double Vc, double A0, double Apeak, double Ac, double J, TPVTSheet *pPVT );
	// two PVM sections and accumulate V0

	void OneSection( double &V0, double A0, double Ac, double L, TPVTSheet *pPVT );
	// one PVT section and accumulate V0

private:
	void PlanWith_LAcc_LJerk( double &V0, double &A0, double &Vmax, double &Amax, double &Jmax, double dP[], double dV[], double dT[] );
	// plan with limited acceleration and limited jerk

	void PlanOnlyConstJerkRegions( double &V0, double &A0, double &Vmax, double &Jmax, double dP[], double dV[], double dT[] );
	// plan only constant jerk regions

	void PlanOnlyConstJerkRegions( double &V0, double &A0, double &Apeak, double &Vmax, double &Jmax, double dP[], double dV[], double dT[] );
	// plan only constant jerk regions with known Apeak

	double CalcVelOfCubic( double V0, double P, double J, BOOL bHigh );
	// calculate the velocity of cubic equation

	double CalcVelOfQuadratic( double V0, double P, double A, double J, BOOL bHigh );
	// calculate the velocity of quadratic equation

	double CalcMaxDecDist_Cubic( double V0, double J );
	// calculate max deceleration distance of cubic equation

	double CalcMaxDecDist_Quad( double V0, double A, double J );
	// calculate max deceleration distance of quadratic equation
};

#endif // !defined(AFX_TRAJECTORY_H__85B84D2F_E947_459E_AD27_FF6F9ACDA9B3__INCLUDED_)
