// IoPort.h: interface for the IoPort API.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_IOPORT_INCLUDED_)
#define _IOPORT_INCLUDED_

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned char PortReadByte( DWORD port );
// read byte data from specified port

extern void PortWriteByte( DWORD port, BYTE data );
// write byte data into specified port

extern unsigned short PortReadWord( DWORD port );
// read byte data from specified port

extern void PortWriteWord( DWORD port, WORD data );
// write byte data into specified port

#ifdef __cplusplus
}
#endif 

#endif // !defined(_IOPORT_INCLUDED_)
