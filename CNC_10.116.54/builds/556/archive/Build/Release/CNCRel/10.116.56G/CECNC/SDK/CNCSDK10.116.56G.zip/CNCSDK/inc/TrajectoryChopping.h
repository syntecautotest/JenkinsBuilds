// TrajectoryChopping.h: interface for the CTrajectoryChopping class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_TRAJECTORYCHOPPING_H____INCLUDED_)
#define _TRAJECTORYCHOPPING_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTrajectoryChopping : public CTrajectory
{
public:
	CTrajectoryChopping(void);
	~CTrajectoryChopping(void);

	void planBlock_chopping( double *Ac, double P, double Vmax, double Amax, double Jmax, TPVTSheet *pPVT );
	// to plan block, V0 = Vc = 0, A0 = Ac = unknown, return block end acceleration absolute value
	// type C:(always has solution)
	//			V0 = Vc = 0, Vmax
	//			Amax, Jmax, P
	// Note: Constrain is A0 = -Ac, which will be calculated from this planning.
	//
	// P	[in]	block distance
	// Ac	[out]	block end acceleration absolute value
	//
	// Acceleration profile               Velocity profile
	//      |			     |             |
	// A0   |---             |             |
	//      |   \            |             |       .-----.
	//      |    \           |             |      /       \
	//    --+----------------|-- t         |     /         \
	//      |           \    |             |    /           \
	//      |            \   |             |   /             \
	//      |             ---| -Ac        -+--/---------------\------ t
	//      |                |             | V0=0            Vc=0
	// the algorithm is refered to "Chopping 3"-"Conclusion"

	void planBlock_3_1( double A0, double Ac, double P, double Vmax, double Jmax, TPVTSheet *pPVT);
	// to plan block, V0 = Vc = 0, A0 > 0 and Ac < 0, all acceleration profile inside A0 and Ac
	// P	[in]	block distance
	// A0	[in]	block start acceleration, to be over than 0
	// Ac	[in]	block end acceleration, to be smaller than 0
	//
	// Acceleration profile               Velocity profile
	//      |			     |             |
	// A0   |---             |             |
	//      |   \            |             |      .------.
	//      |    \           |             |     /        `. 
	//    --+----------------|-- t         |    /           `.
	//      |           \    |             |   /              `.
	//      |            ----| -Ac        -+--/-----------------"----- t
	//      |                |             | V0=0              Vc=0
	// the algorithm is refered to "Chopping 3"-"Special Situation �V Connection_TwoDiffPlan"
};

#endif // !defined(_TRAJECTORYCHOPPING_H____INCLUDED_)
