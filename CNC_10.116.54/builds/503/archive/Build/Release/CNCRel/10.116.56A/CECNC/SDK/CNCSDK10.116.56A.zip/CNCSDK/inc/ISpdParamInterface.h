// ISpdParamInterface.h: interface for the ISpdParamInterface class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISPDPARAMINTERFACE_H__INCLUDED_)
#define AFX_ISPDPARAMINTERFACE_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class ISpdParamInterface
{
public:
	virtual ~ISpdParamInterface( void ) {}
	// destructor

	virtual void put_SensorResolution( long nResolution, long nScale ) = 0;
	// set encoder resolution

	virtual void PutSyntecSOSOffset( long nOffset ) = 0;
	// set syntec s.o.s offset for syntec driver in 0.001 deg

	virtual void notifyParamInitialized( void ) = 0;
	// notify param initialized

	virtual long GetTypeOfChannel( void ) = 0;
	// get type of channel

	virtual long GetDriverResolution( void ) = 0;
	// get driver resolution

	virtual void SyncParamResolution( void ) = 0;
	// sync. resolution
};

#endif // !defined(AFX_ISPDPARAMINTERFACE_H__INCLUDED_)
