// LadderCompiler.h: interface for the CLadderCompiler class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LADDERCOMPILER_H__CF8722F5_1236_11D3_8413_0000E86B4150__INCLUDED_)
#define AFX_LADDERCOMPILER_H__CF8722F5_1236_11D3_8413_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LadderParser.h"

enum EPreParseStatus{
	EPPS_PASS,
	EPPS_FASTEND,
	EPPS_SPLIT,
	EPPS_EOF,
	EPPS_OVERPAGE,
};

class CLadderCompiler : private CLadderDef, private CLadderParser::ICodeGen  
{
public:
	CLadderCompiler();
	virtual ~CLadderCompiler();

	int SyntaxCheck( const void *pLadderSource, long &CodeSize );
	// do syntax check and calculate output code size
	// pLadderSource		pointer to ladder source
	// CodeSize				to return the ouput code size
	// return TRUE for success, return FALSE for failure

	int compile( const void *pLadderSource, void *pBuffer );
	// do compile ladder program

	int getErrorLineNo( void );
	// get error line number

	int getErrorType( void );
	// get syntex error type

	int PreParseLadder( const void *pLadderSource, LONG nInSize, LONG &nBreakPos, char *&pBuffer, LONG &nBufPos, LONG nBufSize, LONG nSplitReserved = 0L );
	// pre-parse ladder : find fastend and skip comment
	// IN:	pLadderSource, nInSize, nBufSize, nSplitReserved
	// OUT:	nBreakPos, pBuffer, nBufPos
	// return:	Status

	BOOL SkipLeadingEnd( const void *pLadderSource );
	// skip leading end, return TRUE when skip leading end

	void AppendEOF( char *&pBuffer, LONG nEOFPos = 0 );
	// append EOF to buffer

private:
	enum ECompilerMode {
		MODE_SyntaxCheck,
		MODE_Compile
	};
	// object state constants

	enum EMaxBounds {
		SIZE_UnsolvedTable	= 256,
		SIZE_SymbolTable	= 256
	};

	struct TUnsolvedTable {
		long	Offset;		// unsolve JMP instruction offset
		int		Index;		// index of symbol table
		int		LineNo;		// the line number of jmp instruction
	};

	struct TSymbolTable {
		char	Name[12];	// label name
		long	Offset;		// label instruction offset
		int		fOffset;	// flag for offset appearance
	};

	int					m_Mode;
	// compiler mode

	int					m_fInstructionError;
	// flag to record instrcution addressing error

	int					m_ErrorLineNo;
	// record error line number

	int					m_ErrorType;
	// record syntex check error type

	TSymbolTable		*m_pSymbolTable;
	// label symbol table

	int					m_SymbolTableCount;
	// the data count in symbol table

	TUnsolvedTable		*m_pUnsolvedTable;
	// unsolved JMP instruction location table

	int					m_UnsolvedTableCount;
	// the data count in unsolved table

	long				m_ProgramCounter;
	// current program counter

	char				*m_OutBuffer;
	// output object code buffer

	int					m_LastOpCode;
	// last opcode

	int					m_LastRegNo;
	// last register no

	CLadderParser		*m_pParser;
	// ladder parser

	void generateCode( int LineNo, int OpCode, void *pParam );
	// code generate

	int DoCodeLink( void );
	// do ouput code link
	// return TRUE if success, return FALSE if failure.

	void Reset( void );
	// reset object state

	void OutShortInstruction( int LineNo, int OpCode, int Arg1 );
	// output short instruction

	void OutLongInstruction( int LineNo, int OpCode,int Arg1,int Arg2,int Arg3);
	// output long instruction

	int LookupSymbolTable( char *Name );
	// lookup string table
	// return the index of found record, return -1 when not found

	void AddToSymbolTable( char *Name );
	// add label into symbol table

	void AddToUnsolvedTable( int LineNo, char *Name );
	// add record into unsolved table

	void verifyInstruction( int LineNo, int OpCode, int Arg1, int Arg2, int Arg3 );
	// verify instruction
};

#endif // !defined(AFX_LADDERCOMPILER_H__CF8722F5_1236_11D3_8413_0000E86B4150__INCLUDED_)
