#if !defined(_FCTHREADNORMAL_H____INCLUDED_)
#define _FCTHREADNORMAL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFCThreadNormal : public CFeedControl
{
public:
	CFCThreadNormal( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	~CFCThreadNormal( void );
	// destructor

private:
	virtual void onBeginDispatchBlock( BOOL bForceFlush = TRUE );
	// trajectory planning tick call back

	virtual void NotifyDecToZero( void );
	// notify decelerate to zero

	void CalcCornerDistance( int nPos, TLANode *pNode );
	// calculate G33/G34 corner distance.
	// pNode: current node

	void modiPrimaryBlock( TLANode *pNode );
	// to modify primary block using corner acceleration distance

	void ScurveBackwardElimination( int nPos );
	// do S-curve backward singular block elimination

	void FlushMatureNodes( int count );
	// flush specified number of nodes inside raw queue into mature queue
};

#endif // !defined(_FCTHREADNORMAL_H____INCLUDED_)
