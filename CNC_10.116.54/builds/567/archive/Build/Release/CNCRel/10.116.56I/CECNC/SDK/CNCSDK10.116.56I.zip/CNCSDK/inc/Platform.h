// Platform.h: interface for the CPlatform class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLATFORM_H__4001B90A_DA42_47B4_AB74_56857E3504AB__INCLUDED_)
#define AFX_PLATFORM_H__4001B90A_DA42_47B4_AB74_56857E3504AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define S_NOSUPPORT				((HRESULT)0xFFFFFFFFL)
#define S_OK					((HRESULT)0x00000000L)
#define S_FALSE					((HRESULT)0x00000001L)

#define HWINFO_MacLength		6

//////////////////////////////////////////////////////////////////////////////////
// AM35x/AM335x Common Registers.

#define GPMC_CS2_CONFIG1			0x0C0
#define GPMC_CS2_CONFIG2			0x0C4
#define GPMC_CS2_CONFIG3			0x0C8
#define GPMC_CS2_CONFIG4			0x0CC
#define GPMC_CS2_CONFIG5			0x0D0
#define GPMC_CS2_CONFIG6			0x0D4
#define GPMC_CS2_CONFIG7			0x0D8

#define GPMC_CS3_CONFIG1			0x0F0
#define GPMC_CS3_CONFIG2			0x0F4
#define GPMC_CS3_CONFIG3			0x0F8
#define GPMC_CS3_CONFIG4			0x0FC
#define GPMC_CS3_CONFIG5			0x100
#define GPMC_CS3_CONFIG6			0x104
#define GPMC_CS3_CONFIG7			0x108

//////////////////////////////////////////////////////////////////////////////////
// AM35x Registers.

#define AM35x_GPMC_UA				0xBA100000	// 0x6E000000

// AM35x GPMC_FCLK is 6ns, 166MHz
#define AM35x_M2_080_CONFIG1			0x00601000		// 16 bit M2 interface, enable r/w wait pin.
#define AM35x_M2_080_CONFIG2			0x001F1F00		// CS OnTime 0ns, CS_RD/CS_WR OffTime 6*31ns
#define AM35x_M2_080_CONFIG3			0x00020201		// we don't use ADV
#define AM35x_M2_080_CONFIG4			0x1D021D02		// WE/OE OnTime 6*2ns, OffTime 6*29ns
#define AM35x_M2_080_CONFIG5			0x001A1F1F		// RD AccessTime 6*26ns, WR CycleTime 6*31ns, RD CycleTime 6*31ns
#define AM35x_M2_080_CONFIG6			0x02000580		// WR AccessTime 6*2ns, Delay 90ns between successive accesses to meet minimum cycle time
#define AM35x_M2_080_CONFIG7			0x00000F55		// Base Address is 0x15000000, 16MB Mask Address, GPMC_CSVALID

#define AM35x_M2_098_CONFIG1			0x00001200		// 16 bit Multiplexed interface, no r/w wait pin.
#define AM35x_M2_098_CONFIG2			0x001E1E0D		// CS OnTime 6*13ns, CS_RD/CS_WR OffTime 6*30ns
#define AM35x_M2_098_CONFIG3			0x001E1E0D		// ALE OnTime 6*13ns, ALE_RD/ALE_WR OffTime 6*30ns
#define AM35x_M2_098_CONFIG4			0x1E0D1E0D		// WE/OE OnTime 6*13ns, OffTime 6*30ns
#define AM35x_M2_098_CONFIG5			0x001B1E1E		// RD AccessTime 6*27ns, WR CycleTime 6*30ns, RD CycleTime 6*30ns
#define AM35x_M2_098_CONFIG6			0x1B0F0FC0		// WR AccessTime 6*27ns, WR Data On AD Mus Bus 6*15ns, Cyc2Cyc Delay 6*15ns, Cyc2Cyc Same/Diff CS enalbe.
#define AM35x_M2_098_CONFIG7			0x00000F55		// Base Address is 0x15000000, 16MB Mask Address, GPMC_CSVALID

#define AM35x_LX25_CONFIG1				0x00001200		// 16 bit Multiplexed interface, no r/w wait pin.
#define AM35x_LX25_CONFIG2				0x001E1E0D		// CS OnTime 6*13ns, CS_RD/CS_WR OffTime 6*30ns
#define AM35x_LX25_CONFIG3				0x001E1E0D		// ALE OnTime 6*13ns, ALE_RD/ALE_WR OffTime 6*30ns
#define AM35x_LX25_CONFIG4				0x1E0D1E0D		// WE/OE OnTime 6*13ns, OffTime 6*30ns
#define AM35x_LX25_CONFIG5				0x001B1E1E		// RD AccessTime 6*27ns, WR CycleTime 6*30ns, RD CycleTime 6*30ns
#define AM35x_LX25_CONFIG6				0x1B0F0FC0		// WR AccessTime 6*27ns, WR Data On AD Mus Bus 6*15ns, Cyc2Cyc Delay 6*15ns, Cyc2Cyc Same/Diff CS enalbe.
#define AM35x_LX25_CONFIG7				0x00000F50		// Base Address is 0x10000000, 16MB Mask Address, GPMC_CSVALID

//////////////////////////////////////////////////////////////////////////////////
// AM335x Registers.

#define AM335x_GPMC_UA				0xB4A00000	// 0x50000000

// AM335x GPMC_FCLK is 10ns, 100MHz
#define AM335x_M2_080_CONFIG1			0x00001000		// 16 bit M2 interface, no r/w wait pin.
#define AM335x_M2_080_CONFIG2			0x001F1F00		// CS OnTime 0ns, CS_RD/CS_WR OffTime 10*31ns
#define AM335x_M2_080_CONFIG3			0x00020201		// we don't use ADV
#define AM335x_M2_080_CONFIG4			0x1F001F00		// WE/OE OnTime 10*0ns, OffTime 10*31ns
#define AM335x_M2_080_CONFIG5			0x001E1F1F		// RD AccessTime 10*30ns, WR CycleTime 10*31ns, RD CycleTime 10*31ns
#define AM335x_M2_080_CONFIG6			0x1E0005C0		// WR AccessTime 10*30ns, Cyc2Cyc Delay 10*5ns, Cyc2Cyc Same/Diff CS enalbe.
#define AM335x_M2_080_CONFIG7			0x00000F55		// Base Address is 0x15000000, 16MB Mask Address, GPMC_CSVALID

#define AM335x_M2_098_CONFIG1			0x00001200		// 16 bit Multiplexed interface, no r/w wait pin.
#define AM335x_M2_098_CONFIG2			0x001E1E0D		// CS OnTime 10*13ns, CS_RD/CS_WR OffTime 10*30ns
#define AM335x_M2_098_CONFIG3			0x001E1E0D		// ADE OnTime 10*13ns, ADE_RD/ADE_WR OffTime 10*30ns
#define AM335x_M2_098_CONFIG4			0x1E0D1E0D		// WE/OE OnTime 10*13ns, OffTime 10*30ns
#define AM335x_M2_098_CONFIG5			0x001B1E1E		// RD AccessTime 10*27ns, WR CycleTime 10*30ns, RD CycleTime 10*30ns
#define AM335x_M2_098_CONFIG6			0x1B0F0FC0		// WR AccessTime 10*27ns, WR Data On AD Mus Bus 10*15ns, Cyc2Cyc Delay 10*15ns, Cyc2Cyc Same/Diff CS enalbe.
#define AM335x_M2_098_CONFIG7			0x00000F55		// Base Address is 0x15000000, 16MB Mask Address, GPMC_CSVALID

#define AM335x_LX25_CONFIG1				0x00001200		// 16 bit Multiplexed interface, no r/w wait pin.
#define AM335x_LX25_CONFIG2				0x001E1E0D		// CS OnTime 10*13ns, CS_RD/CS_WR OffTime 10*30ns
#define AM335x_LX25_CONFIG3				0x001E1E0D		// ALE OnTime 10*13ns, ALE_RD/ALE_WR OffTime 10*30ns
#define AM335x_LX25_CONFIG4				0x1E0D1E0D		// WE/OE OnTime 10*13ns, OffTime 10*30ns
#define AM335x_LX25_CONFIG5				0x001B1E1E		// RD AccessTime 10*27ns, WR CycleTime 10*30ns, RD CycleTime 10*30ns
#define AM335x_LX25_CONFIG6				0x1B0F0FC0		// WR AccessTime 10*27ns, WR Data On AD Mus Bus 10*15ns, Cyc2Cyc Delay 10*15ns, Cyc2Cyc Same/Diff CS enalbe.
#define AM335x_LX25_CONFIG7				0x00000F50		// Base Address is 0x10000000, 16MB Mask Address, GPMC_CSVALID

#define AM335x_DM9000_CONFIG1			0x00001000		// 16 bit DM9000 interface, no r/w wait pin.
#define AM335x_DM9000_CONFIG2			0x001F1F00		// CS OnTime 0ns, CS_RD/CS_WR OffTime 10*31ns
#define AM335x_DM9000_CONFIG3			0x00020201		// we don't use ADV
#define AM335x_DM9000_CONFIG4			0x1F001F00		// WE/OE OnTime 10*0ns, OffTime 10*31ns
#define AM335x_DM9000_CONFIG5			0x001E1F1F		// RD AccessTime 10*30ns, WR CycleTime 10*31ns, RD CycleTime 10*31ns
#define AM335x_DM9000_CONFIG6			0x1E0005C0		// WR AccessTime 10*30ns, Cyc2Cyc Delay 10*5ns, Cyc2Cyc Same/Diff CS enalbe.
#define AM335x_DM9000_CONFIG7			0x00000F55		// Base Address is 0x15000000, 16MB Mask Address, GPMC_CSVALID

// Hardware ID
#define HW_3Av1						0x00
#define HW_3Av2						0x10
#define HW_3Bv1						0x01
#define HW_3Bv2						0x11
#define HW_30GM						0x02
#define HW_HHB						0x03
#define HW_21A_M2_080				0x04
#define HW_11B						0x05
#define HW_M2_098_M3_IP				0x0B
#define HW_eHMC_Step				0x08
#define HW_4in1Driver				0x09 // ARM:	4 in 1 Driver			HW_ID:0x09
#define HW_HighEndFC				0x12
#define HW_FC_M3					0x15
#define HW_HHB_M3					0x16
#define HW_HighEndFCv2				0x22
#define HW_FCv2_M3					0x25
#define HW_ScanLaser_4in1			0x0A
#define HW_x8610A10B_Comp			0xF0 // ARM + ISA bus, for 10A/10B compatible
#define HW_x8620DHybrid_Comp		0xF1 // ARM + ISA bus, for 20 compatible
#define HW_x86RTEX_Comp				0xF5 // ARM + ISA bus, for RTEX compatible
#define HW_STARM					0xFF

//////////////////////////////////////////////////////////////////////////////////

class Cx86Platform;

class CPlatform
{
public:
	static CPlatform *getPlatform( void );
	// return platform api object.

	static void deletePlatform( void );
	// delete paltform api object

	HRESULT Initial( void );
	// register device driver, and open it.

	void Deinitial( void );
	// close device driver, but not deregister device driver.

	int GetMotherboardType( void );
	// return motherboard type.

	int GetExtensionboardType( void );
	// return extension board type.

	void GetMacAddress( UCHAR *buffer );
	// return mac address of CPU board

	ULONG *DeviceBaseAddr( int nDeviceID );
	// return device base address.

	BOOL isSupportDIOOverLoad( void );
	// check is support digital IO overload.

	BOOL isSupportSRI( void );
	// check whether it is support SRI

	BOOL isSupportFram( void );
	// check whether it is support Fram

	BOOL RegISRCallBack( LPVOID pfnExtISR, LPVOID dwContext );
	// registration ISR CallBack function.

	int GetFPGASupportFuncNum( int nFunc );
	// get FPGA support function number

	// PlatformAPI Driver interface
	HRESULT PlatformVersion( /*out*/ ULONG *lpnVersion );
	HRESULT PlatformApiVersion( /*out*/ ULONG *lpnApiVersion );
	HRESULT GetMotherboardName( /*out*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthRead );
	HRESULT GetExtentionboardName( /*out*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthRead );
	HRESULT SetExtentionboardName( /*in*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthWrite );
	HRESULT BackLightOn( void );
	HRESULT BackLightOff( void );
	HRESULT LEDSetStatus( /*in*/ LONG nID, /*in*/ LONG nType);
	HRESULT GetCpuClock( /*out*/ ULONG *lpnCpuClock );
	HRESULT GetCpuTemperture( /*out*/ LONG *lpnCpuTemperture );
	HRESULT GetSysTemperture( /*out*/ LONG *lpnSysTemperture );
	HRESULT FPGADownload( /*in*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength );
	HRESULT FramReadByte( /*in*/ ULONG nAddr, /*out*/ char* lpnVal );
	HRESULT FramWriteByte( /*in*/ ULONG nAddr, /*in*/ char nVal );
	HRESULT FramReadByteArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ char *lpBuffer );
	HRESULT FramWriteByteArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ char *lpBuffer );
	HRESULT FramReadLong( /*in*/ ULONG nAddr, /*out*/ ULONG* lpnVal );
	HRESULT FramWriteLong( /*in*/ ULONG nAddr, /*in*/ ULONG nVal );
	HRESULT FramReadLongArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ ULONG *lpBuffer );
	HRESULT FramWriteLongArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ ULONG *lpBuffer );
	HRESULT FramLock( void );
	HRESULT FramUnlock( void );
	HRESULT FramLockStatus( /*out*/ BOOL *lpbLockStatus );
	HRESULT FramSize( /*out*/ ULONG *lpnSize );
	HRESULT EEpromReadByteArray( /*in*/ BYTE nDevice, /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ BYTE *lpBuffer );
	HRESULT EEpromWriteByteArray( /*in*/ BYTE nDevice, /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ BYTE *lpBuffer );

public:
	enum ECPUBoardType {
		CPUBOARD_NotDef = 0,
		CPUBOARD_PCA6773,
		CPUBOARD_PCA6781,
		CPUBOARD_IPCLX800,
		CPUBOARD_STLX800,
		CPUBOARD_STLX900,
		CPUBOARD_IPCLX600,
		CPUBOARD_IPCLX900,
		CPUBOARD_IPCN450AD,
		CPUBOARD_IPCN450AE,
		CPUBOARD_STVX800,
		CPUBOARD_S3C6410 = 500,
		CPUBOARD_AM35x,
		CPUBOARD_AM335x,
		CPUBOARD_IMX6,
	};

	enum EExtensionBoardType {
		EXTBOARD_NotDef = 0,
		EXTBOARD_x8610A10B2987,		// X86:	10A/10B + UDN2987,		HW_ID:0x00
		EXTBOARD_x8620DHybrid,		// X86:	20D Hybrid + UDN2987,	HW_ID:0x01
		EXTBOARD_x86RTEX,			// x86:	RTEX					HW_ID:0x05

		EXTBOARD_x8610A10B_Comp,	// ARM + ISA bus for 10A/10B	HW_ID:0xF0
		EXTBOARD_x8620D_Comp,		// ARM + ISA bus for 20 series	HW_ID:0xF1
		EXTBOARD_x86RTEX_Comp,		// ARM + ISA bus for RTEX		HW_ID:0xF5

		EXTBOARD_ArmNotDef = 500,
		EXTBOARD_Arm3Av1,			// ARM:	3A/6A					HW_ID:0x00
		EXTBOARD_Arm3Av2,			// ARM:	3A/6A					HW_ID:0x10
		EXTBOARD_Arm3Bv1,			// ARM:	3B/6B/11A				HW_ID:0x01
		EXTBOARD_Arm3Bv2,			// ARM:	3B/6B/11A				HW_ID:0x11
		EXTBOARD_Arm30GM,			// ARM:	30GM					HW_ID:0x02
		EXTBOARD_ArmHHB,			// ARM:	Hand Holder Box			HW_ID:0x03
		EXTBOARD_Arm_M2_080,		// ARM:	21A						HW_ID:0x04
		EXTBOARD_Arm11B,			// ARM:	11B						HW_ID:0x05
		EXTBOARD_Arm_M2_098_M3_IP,	// ARM:	22A						HW_ID:0x0B
		EXTBOARD_eHMC_Step,			// ARM: EMB5 LX25 step motor	HW_ID:0x08
		EXTBOARD_Arm_4in1Driver,	// ARM:	4 in 1 Driver			HW_ID:0x09
		EXTBOARD_Arm_FC,			// ARM:	Hign end FC				HW_ID:0x12
		EXTBOARD_Arm_FCv2,			// ARM:	Hign end FC v2 general	HW_ID:0x22
		EXTBOARD_Arm_FC_M3,			// ARM:	Hign end FC M3			HW_ID:0x15
		EXTBOARD_Arm_FCv2_M3,		// ARM:	Hign end FC v2 M3		HW_ID:0x25
		EXTBOARD_Arm_HHB_M3,		// ARM: HHB	M3					HW_ID:0x16
		EXTBOARD_Arm_ScanLaser_4in1,// ARM: Scan laser 4 in 1		HW_ID:0x0A
		EXTBOARD_STARM,				// ARM:	STARM					HW_ID:0xFF

		// add new ext. board here.
		EXTBOARD_COUNT
	};

	enum EDevice {
		DEVICE_FRAM = 0,
		DEVICE_CNC2,
		DEVICE_M2,
		DEVICE_FLEXRAY,
		DEVICE_CPLD,
		DEVICE_M3,
		DEVICE_SRI,
		DEVICE_ECAT,
		DEVICE_GALVO,
		DEVICE_RTEX,
		DEVICE_CNC1,
	};

private:
	// enable 2-byte alignment
	#pragma pack(2)

	//============================================
	// function support register
	//============================================
	struct ASIC_FUNC_REGS {
		WORD		NUMOF_SRI:4;		// 0x0010
		WORD		NUMOF_DAC:4;
		WORD		NUMOF_ENC:4;
		WORD		NUMOF_DDA:4;
		WORD		NUMOF_HARDKEY:4;	// 0x0012
		WORD		NUMOF_LIO:4;
		WORD		NUMOF_RIO:4;
		WORD		NUMOF_IOENC:4;
		WORD		NUMOF_SCANHEAD:4;	// 0x0014
		WORD		reserved:12;
		WORD		FREQ_FPGA;			// 0x0016
	};

	// restore original alignment
	#pragma pack()

	volatile struct ASIC_FUNC_REGS*		m_pAsicFUNC;

private:
	BOOL m_bPlatformInit;
	// platform api initial flag.

	static CPlatform *m_pPlatform;
	// platform api object.

	Cx86Platform *m_pX86Platform;

	char m_PlatformName[80];
	// record CPU board type name

	UCHAR m_MacAddress[HWINFO_MacLength];
	// record CPU board mac address, use by getMac function

#if defined(DOSX286)
	CAAECPUBoard *m_pAaeCPUBoard;
	// Aae mac help object
#endif

	int m_MotherboardType;
	// record cpu board type
	// 1: PCA-6773
	// 2: PCA-6781
	// 3: IPC-LX800
	// 4: STLX800
	// 5: STLX900
	// 6: IPC-LX600
	// 7: IPC-LX900
	// 8: IPC-N450-AD
	// 9: IPC-N450-AE
	// 10: STVX800
	// 500: S3C6410
	// 501: AM35x
	// 502: AM335x

	int m_ExtensionBoardType;
	// record extension board type
	// 1: X86 + 10A/10B + UDN2987
	// 2: X86 + 20D Hybrid + UDN2987

	void UpdateMacAddr(void);
	// update Mac address

private:
	CPlatform();
	//virtual ~CPlatform();

	void InitArmGPMC();
	// initial ARM GPMC registers.

	void InitAM35xGPMC();
	// initial AM35x GPMC registers.

	void InitAM335xGPMC();
	// initial AM335x GPMC registers.

	ULONG *GetArmDeviceBaseAddr( int nDeviceID );
	// get ARM device base address.

	ULONG *GetAM35xDeviceBaseAddr( int nDeviceID );
	// get AM35x device base address.

	ULONG *GetAM335xDeviceBaseAddr( int nDeviceID );
	// get AM335x device base address.

	void InitFPGAFuncAddr( void );
	// initialize FPGA function address
};
#endif // !defined(AFX_PLATFORM_H__4001B90A_DA42_47B4_AB74_56857E3504AB__INCLUDED_)
