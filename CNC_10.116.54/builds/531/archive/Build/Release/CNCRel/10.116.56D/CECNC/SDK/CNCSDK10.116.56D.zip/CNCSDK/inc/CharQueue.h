// CharQueue.h: interface for the CCharQueue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHARQUEUE_H__618F6283_5B5A_11D3_8491_0000E86B4150__INCLUDED_)
#define AFX_CHARQUEUE_H__618F6283_5B5A_11D3_8491_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCharQueue  
{
public:
	enum EExtendChar {
		CH_EOF = -1
	};
	// extended character code

public:
	CCharQueue( int capacity = 2048 );
	// constructor

	virtual ~CCharQueue();
	// destructor

	void setCapacity( int capacity );
	// set character queue capacity

	int getCapacity( void );
	// get maximum number of charachers in queue.

	int getChar( void );
	// get one character from queue

	void putChar( int ch );
	// put one character into queue

	int getNumOfChar( void );
	// get number of character in queue

	int isFull( void );
	// query whether the queue is full

	int isEmpty( void );
	// query whether the queue is empty

	void empty( void );
	// empty all queue data

	int seekChar( int chKey );
	// to seek specified character
	// return position from queue head, position start from 0 , -1 for not found

private:
	int *m_data;
	// pointer to data buffer

	int m_tail;
	// queue tail index

	int m_head;
	// queue head index

	int m_capacity;
	// queue capacity, maximum number of characters in queue
};

#endif // !defined(AFX_CHARQUEUE_H__618F6283_5B5A_11D3_8491_0000E86B4150__INCLUDED_)
