#if !defined(_BINFILELOADER_H_INCLUDED_)
#define _BINFILELOADER_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_PATH_LENGTH			(256)

class CAsynQueue;

class CBinFileLoader
{
public:
	CBinFileLoader( unsigned long nMaxBlockSize, unsigned long nQueueLength, int nThread, int nMaxPutCount = 1 );
	// constructor

	virtual ~CBinFileLoader( void );
	// destructor

	BOOL OpenAndReadFileRequest( const char *pFilePath, unsigned long nHeaderSize, unsigned long nBlockSize );
	// issue open file request, then read file and divide it into a data queue

	void CloseFileRequest( void );
	// issue close file request

	BOOL GetFileSize( unsigned long &nFileSize );
	// get file size, unit: byte

	EDataStatus GetHeader( BYTE *pData, unsigned long nDataSize );
	// get header information

	EDataStatus GetData( BYTE *pData, unsigned int &nDataCount, unsigned long &nDataSize );
	// get a block of data from data queue, data count start form 1

	BOOL isIdle( void );
	// both reader state and request are idle

	BOOL isFinished( void );
	// file reading is ended and data queue is empty

private:
	BOOL isEmpty( void );
	// query is empty

	BOOL isRemainSizeEnough( void );
	// query is remain size enough

private:
	enum EReaderState
	{
		READER_IDLE = 0,
		READER_OPEN_FILE,
		READER_OPEN_FAIL,
		READER_PUT_DATA,
		READER_END_READING,
		READER_CLOSE_FILE,
	};
	
	struct TDataRegister
	{
		unsigned int nCount;
		unsigned long nDataSize;
		BYTE *pDataPointer;
	};

	void InitialReader( void );
	// initialize the state of reader

	static DWORD CNCAPI workThreadEntry( LPVOID dwContext );
	// call back function : using housekeeping or PLC thread

	void DoHouseKeeping( void );
	// do housekeeping

	void CalculateFileSize( void );
	// calculate size of file

	void ProcessHeader( void );
	// process header information

	BOOL PutDataQueue( void );
	// put file data into data queue

	void DetermineReadDataSize( unsigned long &nSize );
	// determine size of read data

	ULONG m_ThreadCookie;
	// cookie of connected thread

	CAsynQueue *m_pDataQueue;
	// data information queue

	BYTE *m_pDataArray;
	// data array

	unsigned long m_nMaxBlockSize;
	// max block size of data queue, unit: byte

	unsigned long m_nQueueLength;
	// max block counts of data queue

	EReaderState m_eReaderState;
	// reader state

	BOOL m_bReadRequest;
	// file read request

	BOOL m_bCloseRequest;
	// file close request

	FILE *m_pFile;
	// file object pointer

	char m_szFilePath[ MAX_PATH_LENGTH ];
	// file path

	BYTE *m_pHeader;
	// header information

	unsigned long m_nFileSize;
	// file size, unit: byte

	unsigned long m_nHeaderSize;
	// header size, unit: byte

	unsigned long m_nBlockSize;
	// each block size of data queue, unit: byte

	unsigned long m_nRemainSize;
	// remained file size for not yet reading, unit: byte

	unsigned long m_nCount;
	// total put count

	unsigned long m_nMaxPutDataSize;
	// max put data size

	int m_nMaxPutDataCount;
	// max put data count

	int m_nThread;
	// buffer for thread
};

#endif // _BINFILELOADER_H_INCLUDED_
