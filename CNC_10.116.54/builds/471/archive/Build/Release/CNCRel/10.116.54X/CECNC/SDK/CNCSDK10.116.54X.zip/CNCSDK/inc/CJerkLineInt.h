// CJerkLineInt.h: interface for the CCJerkLineInt class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CJERKLINEINT_H__1F17E3B6_131B_11D3_8414_0000E86B4150__INCLUDED_)
#define AFX_CJERKLINEINT_H__1F17E3B6_131B_11D3_8414_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// control block for constant jerk cubic curve interpolator
// constant jerk cubic curve interpolator
class CCJerkLineInt : public ITrajectoryInt
// Constant linear jerk cubic curve interpolator
{
private:
	static const double EPSILON_Jerk;
	// eplison jerk

public:
	CCJerkLineInt();
	virtual ~CCJerkLineInt();

public:
	struct TCtlBlk
	{
		double	V_0;		// velocity at time 0
		double	A_0;		// acceleration at time 0
		double	V_T;		// velocity at time T
		double	A_T;		// acceleration at time T
		double	C;			// jerk
		double	TM;			// block move time
	};

	struct TParam {
		double	P;			// displacement
		double	V_0;		// velocity at 0
		double	V_T;		// velocity at T
	};

public:

	static void getControlBlock( TCtlBlk *block, double P, double V_0, double V_T, double TM);
	// format(initialize) control block
	// block		pointer to control block
	// P			displacement
	// V_0			velocity at time 0
	// V_T			velocity at time T
	// TM			block movement time

	static void getControlBlock( TCtlBlk *block, TParam &param, double TM );
	// format(initialize) control block
	// block		pointer to control block
	// param		parameter control block
	// TM			block movement time

	void startBlock( ITrajectoryInt::TCtlBlk *block, int fBackward );
	// issue control block to start excute
	// block		pointer to control block
	// fBackward	flag fto indicate backward interpolation

	void getSegment( double time, double segment[] );
	// calculate next move segment
	// time		current time base
	// segment	pointer to buffer for store movement

private:
	double	m_RemainTime;	// remain time
	double	m_V0;			// velocity at time 0
	double	m_A0;			// acceleration at time 0
	double	m_C;			// jerk
	double	m_R;			// R recursive variable
	double	m_Q;			// Q recursive variable
	double	m_t0;			// Ti-1 time interval
	double	m_t1;			// Ti time interval
	int		m_State;		// recursive state variable
};

#endif // !defined(AFX_CJERKLINEINT_H__1F17E3B6_131B_11D3_8414_0000E86B4150__INCLUDED_)
