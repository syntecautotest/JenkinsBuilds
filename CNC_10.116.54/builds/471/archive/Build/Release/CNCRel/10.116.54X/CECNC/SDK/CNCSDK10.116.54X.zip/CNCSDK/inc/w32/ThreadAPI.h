//
//	ThreadAPI.H
//
//	Thread API Exported Interface
//

#if !defined(_THREADAPI_INCLUDED_)
#define _THREADAPI_INCLUDED_

#include "nstdlib.h"

#ifdef __cplusplus
extern "C" {
#endif

extern BOOL CNCAPI CloseThread(
	HANDLE hThread   // handle to thread to close
);
// The CloseThread function closes an open thread handle.
// If the function succeeds, the return value is nonzero.
// If the function fails, the return value is zero.

extern void GetAllThreadInfo(
	LPDWORD	lpStackSize,		// array to store thread stack size, in bytes
	LPDWORD	lpStackFree			// array to store thread stack free, in bytes
);
// query all thread information

extern void CNCAPI GetThreadInfo(
	LPDWORD	lpStackSize,		// storage to store thread stack size, in bytes
	LPDWORD	lpStackFree			// storage to store thread stack free, in bytes
);
// query my thread information

extern void CNCAPI NcSetThreadPriority( HANDLE hThread, int nPriority );
// set thread priority
#ifdef __cplusplus
}
#endif 

#endif // _THREADAPI_INCLUDED_
