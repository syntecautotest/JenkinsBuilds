// FFT.h: interface for the CFFT class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_FFT_H__INCLUDED_)
#define _FFT_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFFT
{
public:
	CFFT( void );
	// constructor

	~CFFT( void );
	// destructor

	void Transform( double Magnitude[], int nDataLength );
	// Computes the discrete Fourier transform (DFT) of the given real value array, storing the magnitude back into the array
	// The array can have any length. This is a wrapper function.

	void Transform( double Magnitude[], double Phase[], int nDataLength );
	// Computes the discrete Fourier transform (DFT) of the given real value array, storing the magnitude back into the array
	// Computes the discrete Fourier transform (DFT) of the given imaginary value array, storing the phase back into the array
	// The array can have any length. This is a wrapper function.

	void Transform( std::vector<double> &real, std::vector<double> &imag );
	// Computes the discrete Fourier transform (DFT) of the given complex vector, storing the result back into the vector.
	// The vector can have any length. This is a wrapper function.

	void InverseTransform( std::vector<double> &real, std::vector<double> &imag );
	// Computes the inverse discrete Fourier transform (IDFT) of the given complex vector, storing the result back into the vector.
	// The vector can have any length. This is a wrapper function. This transform does not perform scaling, so the inverse is not a true inverse.

	void TransformRadix2( std::vector<double> &real, std::vector<double> &imag );
	// Computes the discrete Fourier transform (DFT) of the given complex vector, storing the result back into the vector.
	// The vector's length must be a power of 2. Uses the Cooley-Tukey decimation-in-time radix-2 algorithm.

	void TransformBluestein( std::vector<double> &real, std::vector<double> &imag );
	// Computes the discrete Fourier transform (DFT) of the given complex vector, storing the result back into the vector.
	// The vector can have any length. This requires the convolution function, which in turn requires the radix-2 FFT function.
	// Uses Bluestein's chirp z-transform algorithm.

	void Convolve( const std::vector<double> &x, const std::vector<double> &y, std::vector<double> &out );
	// Computes the circular convolution of the given real vectors. Each vector's length must be the same.

	void Convolve( const std::vector<double> &xreal, const std::vector<double> &ximag, const std::vector<double> &yreal, const std::vector<double> &yimag, std::vector<double> &outreal, std::vector<double> &outimag );
	// Computes the circular convolution of the given complex vectors. Each vector's length must be the same.

private:
	size_t ReverseBits(size_t x, unsigned int n);
	// Private function prototypes
};

#endif // !defined(_FFT_H__INCLUDED_)
