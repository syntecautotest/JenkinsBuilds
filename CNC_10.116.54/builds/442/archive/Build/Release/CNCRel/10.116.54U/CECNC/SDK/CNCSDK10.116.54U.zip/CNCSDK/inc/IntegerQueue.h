// IntegerQueue.h: interface for the CIntegerQueue class.
//
//////////////////////////////////////////////////////////////////////

class CIntegerQueue  
{
public:
	CIntegerQueue( int capacity );
	// constructor

	virtual ~CIntegerQueue();
	// destructor

	int getCapacity( void );
	// to get data capacity

	int getSize( void );
	// to get data size

	long front( void );
	// get the head from queue

	long back( void );
	// get the tail from queue

	void pushFront( long data );
	// push data from head in queue

	void pushBack( long data );
	// push data from tail in queue

	long popFront( void );
	// pop data from head in queue

	long popBack( void );
	// pop data from tail in queue

	int isFull( void );
	// query whether the queue is full ?

	int isEmpty( void );
	// query whether the queue is full ?

	void empty();
	// empty queue

	long peek( int index );
	// get data from queue

private:
	long *m_data;
	// pointer to data buffer

	int m_capacity;
	// queue capacity

	int m_head;
	// queue head index

	int m_tail;
	// queue tail index
};
