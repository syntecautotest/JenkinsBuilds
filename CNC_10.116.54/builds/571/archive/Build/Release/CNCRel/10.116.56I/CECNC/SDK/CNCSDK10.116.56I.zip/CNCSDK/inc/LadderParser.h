// LadderParser.h: interface for the CLadderParser class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LADDERPARSER_H__CF8722F6_1236_11D3_8413_0000E86B4150__INCLUDED_)
#define AFX_LADDERPARSER_H__CF8722F6_1236_11D3_8413_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LadderDef.h"
#include "LadderWRPool.h"

class CLadderParser : private CLadderDef
{
public:
	class ICodeGen {
	public:
		virtual void generateCode( int LineNo, int OpCode, void *pParam ) = 0;
	};

	enum EMaxBound {
		SIZE_RBNStack = 16,
		SIZE_FBNStack = 16,
	};

	// node for ladder parser scan
	struct TTravelNode {
		TCell	*pCell;		// pointer to cell for scan start
		int		InitRegIdx;	// the initial value register index
		int		fShort;		// short circuit status
	};

	class CTravelStack  
	{
	public:
		CTravelStack(int Size);
		virtual ~CTravelStack();

		void Push( TCell *pCell, int InitRegIdx, int fShort );
		// push a cell into stack

		void Pop( TTravelNode &Node );
		// pop a node from stack
		// Node		to return the top node from stack

		void Peek( TTravelNode &Node );
		// peek the top node from stack
		// Node		to return node from stack but which not remove
		//			from stack

		int IsFull( void );
		// return TRUE when stack is full, else return FALSE

		int IsEmpty( void );
		// return TRUE when stack is empty, else return FALSE

		void Reset( void );
		// reset will clean out all stack data, the stack will become empty

	private:
		int		m_Size;
		// stack size

		int		m_Top;
		// index to the top empty element

		TTravelNode *m_pData;
		// pointer to node data buffer
	};

public:
	CLadderParser();
	virtual ~CLadderParser();

	void setICodeGen( ICodeGen *pICodeGen );
	// set ICodeGen interface

	int getErrorLineNo( void ) { return m_ErrorLineNo; }
	// get error line line number

	int getErrorType( void ) { return m_ErrorType; }
	// get error type

	int parse( TCell *pLadderSource );
	// parse ladder program

private:
	int doOpenCircuitCheck( void );
	// do open circuit check
	// return TRUE for success, FALSE for not pass, that is the circuit
	// is open 

	int doParse( void );
	// parse ladder program

	void Reset( void );
	// reset error state

private:

	ICodeGen *m_pICodeGen;
	// associated code generator interface

	TCell *m_pLadderSource;
	// pointer to teh start address of ladder source code 

	CTravelStack		m_FBNStack;
	// stack to store FBN node

	CTravelStack		m_RBNStack;
	// stack to store RBN node

	CLadderWRPool		m_WRPool;
	// working register pool

	int					m_ErrorLineNo;
	// the line number which error occurs

	int					m_ErrorType;
	// log the error type when error occurs

	int GetLineNo( TCell *pCell );
	// get line number of cell

	TCell *GetLeftAlignedDownNeighbor(TCell *pCell);
	// get the cell left-aligned down neighbor

	TCell *GetRightAlignedUpNeighbor(TCell *pCell);
	// get the cell right-aligned up neighbor

	int ExistRightAlignedUpNeighbor(TCell *pCell);
	// query whether there exists the cell right-aligned up
	// neighbor ?

	int ExistRightAlignedDownNeighbor(TCell *pCell);
	// query whether there exists the cell right-aligned down
	// neighbor ?

	TCell *GetNextFBN(TCell *pCell);
	// get next block FBN node

	void ClearWalkFlags( void );
	// clear the walk and status bits.
                                                                   
	int CheckCellOpen(TCell *pCell);
	// check the open connection of element
                                                                   
	int RightCheck(TCell *pCell);
	// check the right connection of element.

	int ExistRightUpNeighbor(TCell *pCell);
	// query whether there exists right up neighbor

	int ExistRightDownNeighbor(TCell *pCell);
	// query whether there exists right down neighbor

	TCell *GetRightUpNeighbor(TCell *pCell);
	// get the cell pointer of right-up non-empty cell

	TCell *GetRightDownNeighbor(TCell *pCell);
	// get the pointer of right-down non-empty cell

	int LeftCheck(TCell *pCell);
	// check the left connection of element.

	int ExistLeftUpNeighbor(TCell *pCell);
	// query whether there exists left up neighbor

	int ExistLeftDownNeighbor(TCell *pCell);
	// query whether there exists left down neighbor

	TCell *GetLeftUpNeighbor(TCell *pCell);
	// get the cell pointer of left-up non-empty cell

	TCell *GetLeftDownNeighbor(TCell *pCell);
	// get the cell pointer of left-down non-empty cell

	TCell *StepToRightAlignedUp( TCell *pCell );
	// step to right aligned up cell

	TCell *StepToRightAlignedDown( TCell *pCell );
	// step to right aligned down cell

	TCell *StepRight( TCell *pCell );
	// step to right cell

	TCell *StepRightUp( TCell *pCell );
	// setp to right up cell

	TCell *StepRightDown( TCell *pCell );
	// step to right down cell

	TCell *StepLeft( TCell *pCell );
	// step to left cell

	TCell *StepLeftUp( TCell *pCell );
	// step to left up cell

	TCell *StepLeftDown( TCell *pCell );
	// step to left down cell

	TCell *StepLeftAlignedUp( TCell *pCell );
	// step to left-aligned up cell

	TCell *StepLeftAlignedDown( TCell *pCell );
	// step to left-aligned down cell

	int IsNullCell(TCell *p);
	// query whether it is null cell

	int IsEOFCell(TCell *p);
	// query whether it is end-of-file cell
};

inline int CLadderParser::IsNullCell(TCell *p)
// query whether it is null cell
{
	return p->code == LOP_NULL;
}

inline int CLadderParser::IsEOFCell(TCell *p)
// query whether it is end-of-file cell
{
	return p->code == (unsigned char)LOP_EOF;
}

inline CLadderDef::TCell *CLadderParser::StepRight( TCell *pCell )
// step to right cell
{
	if( pCell->code >= LOP_BICELL ) {
		return pCell + 2;
	} else {
		return pCell + 1;
	}
}

inline CLadderDef::TCell *CLadderParser::StepRightUp( TCell *pCell )
// setp to right up cell
{
	if( pCell->code >= LOP_BICELL ) {
		return pCell - 8;
	} else {
		return pCell - 9;
	}
}

inline CLadderDef::TCell *CLadderParser::StepRightDown( TCell *pCell )
// step to right down cell
{
	if( pCell->code >= LOP_BICELL ) {
		return pCell + 12;
	} else {
		return pCell + 11;
	}
}

inline CLadderDef::TCell *CLadderParser::StepLeftUp( TCell *pCell )
// step to left up cell
{
	return StepLeft(StepLeftAlignedUp(pCell));
}

inline CLadderDef::TCell *CLadderParser::StepLeftDown( TCell *pCell )
// step to left down cell
{
	return StepLeft(StepLeftAlignedDown(pCell));
}

inline CLadderDef::TCell *CLadderParser::StepLeftAlignedUp( TCell *pCell )
// step to left-aligned up cell
{
	return pCell - 10;
}

inline CLadderDef::TCell *CLadderParser::StepLeftAlignedDown( TCell *pCell )
// step to left-aligned down cell
{
	return pCell + 10;
}

#endif // !defined(AFX_LADDERPARSER_H__CF8722F6_1236_11D3_8413_0000E86B4150__INCLUDED_)
