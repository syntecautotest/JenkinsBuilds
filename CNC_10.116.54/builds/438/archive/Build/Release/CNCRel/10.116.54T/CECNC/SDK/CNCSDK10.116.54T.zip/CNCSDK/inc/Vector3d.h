// Vector3d.h: interface for the CVector3d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VECTOR3D_H__280D3FDF_C1EE_4EC1_B1A3_4BDAEBE83BC2__INCLUDED_)
#define AFX_VECTOR3D_H__280D3FDF_C1EE_4EC1_B1A3_4BDAEBE83BC2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Tuple3d.h"

class UTILAPI CVector3d : public CTuple3d  
{
public:
	CVector3d();
	// constructs and initialize it to zero vector

	CVector3d( double x, double y, double z );
	// constructs and initialize vector from specified xyz value

	CVector3d( double v[] );
	// Constructs and initializes a Vector3d from the array of length 3.

	virtual ~CVector3d();
	// destructor

	double length( void );
	// calculate and return the length of vector

	double lengthSquared( void );
	// Returns the squared length of this vector

	double dot( CVector3d &v );
	// calculate and return the dot product of this vector and the 
	// specified vactor

	void cross( CVector3d &v1, CVector3d &v2 );
	// Sets this vector to the vector cross product of vectors v1 and v2.

	double angle( CVector3d &v );
	// calculate and return the angle between this vector and the
	// specified vector
	// return : the angle in radian, [0,PI]

	void normalize( void );
	// Normalizes this vector in place.

	void normalize( CVector3d &v );
	// Sets the value of this vector to the normalization of vector v.
	
	double distance( CVector3d &v );
	// calculate the distance between this vector and the
	// specified vector
	// return: the distance

	CVector3d operator+(const CVector3d &v);
	// vector additive
	// return = this + v

	CVector3d operator-(const CVector3d &v);
	// vector substract
	// return = this - v

	CVector3d operator*(double alpha);
	// scalar multiply
	// return = alpha * this

	CVector3d operator/(double alpha);
	// scalar divide
	// return = this / alpha

	double operator*(const CVector3d &v);
	// inner product
	// return = inner_dot(this,v)
};

#endif // !defined(AFX_VECTOR3D_H__280D3FDF_C1EE_4EC1_B1A3_4BDAEBE83BC2__INCLUDED_)
