// TrajectoryNormal.h: interface for the CTrajectoryNormal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_TRAJECTORYNORMAL_H____INCLUDED_)
#define _TRAJECTORYNORMAL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ComputeGoalVelocityMethod	1		// 0: numerical; 1: algebraic
#define CoefEpsilon					1.0e-8	// experiment data
#define IterEpsilon					5.0e-5	// epsilon for iteration
#define CalcErrTolerance			1.0e-4	// calculation error tolerance
#define SmallErrorTolerance			1.0e-12	// avoid outputMaxVelocity error
#define ALMID_CrdPolySolverError	139		// ALMID
#define TIMETOL_HighPrec			DBL_EPSILON //unit:us
#define TIMETOL_LowPrec				20 //unit:us

class CTrajectoryNormal : public CTrajectory
{
public:
	CTrajectoryNormal(void);
	~CTrajectoryNormal(void);

	friend void DumpDebugData(CControlSystem *pCtrl, long *buffer);
	// open friend relationship to dump object state for debug purpose

	BOOL planBlock( double V0, double A0, double Vc, double Ac, double P, double Vref1, double Vref2, double Amax, double Jmax, TPVTSheet *pPVT, BOOL bNormalPVT = TRUE, BOOL bAllowBreakAJ = TRUE );
	// to plan block trajectory
	// type A:
	//			V0, Vc, Vf1, Vf2
	//			A0, Ac, Amax, Jmax, P
	//
	// Acceleration profile                Velocity profile
	//      |			                      |
	// A0   |   ---                           |      .---.
	//      |  /   \                          |    .'     \
	//      | /     \____                     |   /        \
	//    --+------------\---------- t        |  /          \
	//      |             \      /         V0 |-'            \
	//      |              \    /             |               `-- Vc
	//      |               ---     -Ac      -+------------------------ t
	//      |                                 |
	// this algorithm is refered to "Motion Planning"-"Trajectory Planning" and "Constant Jerk Trajectory" / ���m��

	void genCornerAcceleration( TPVTSheet *pPVT, double Vbegin, double Vend, double P, double Ts, double Ta );
	// to generate corner acceleration trajectory for G62.1 and G33/G34.
	// pPVT		[out] pointer to PVT segment buffer.
	// Vbegin	[in] block velocity at begin, in BLU / micro-second
	// Vend		[in] block velocity at end, in BLU / micro-second
	// P		[in] startup distance
	// Ts		[in] bell-shaped acceleration time, in micro-second.
	// Ta		[in] acceleration time of fix time trajectory, in micro-second. Only use bell-shaped trajectory when Ta equal Ts.

	BOOL PlanConstVelEnd( double V0, double A0, double Vc, double Ac, double L, double Vmax, double &Amax, double &Jmax , double &Lout, double &Vout, double *Tout = NULL );
	// find the distance and velocity at the end of constant velocity
	// Tout is "estimated" moving time, not real interpolation time

	BOOL CalMaxVel( double &Vc, double &Ac, double V0, double A0, double P, double Amax, double Jmax, bool bHighPrecision = FALSE );
	// calculate max Vc and Ac from V0, A0 in length of P

private:
	BOOL PreModifyJerk( double V0, double A0, double Vmax, double &Vleast, double &J );
	// pre-modify jerk for unreasonable input

	BOOL Process7SectionsCase( double V0, double A0, double Vc, double Ac, double P, double V1, double V2, double A );
	// process seven sections case

	void OutputStartUp( double V0, double Vc, TTrajInfo &StartUp );
	// output startup profile

	void OutputStopDown( double V0, double Vc, TTrajInfo &StopDown );
	// output stopdown profile

	BOOL Process6SectionsCase( double V0, double A0, double Vc, double Ac, double P, double V, double A );
	// process six sections case

	BOOL Process3SectionsCase( double V0, double A0, double Vc, double Ac, double P, double A, double Jmax );
	// process three sections case

	BOOL ProceseBreakJerkCase( double V0, double A0, double Vc, double Ac, double P, double A );
	// process break jerk case

#if ComputeGoalVelocityMethod
	BOOL outputMaxVelocity( double V0, double A0, double Vc, double Ac, double P, double Vmax, double Amax, double Jmax, double &V );
	// output maximum velocity through algebraic method

	BOOL SolveVpeak_2ConstAccRegions( double V0, double Vc, double P, double Amax, double Jmax, double &Vpeak );
	// solve Vpeak for two sides with constant acceleration regions

	BOOL SolveVpeak_1ConstAccRegion( double V0, double Vc, double P, double Amax, double Jmax, double &V );
	// solve Vpeak for single side with constant acceleration region
	// when degenerate region 2, ( V0, Vc ) = ( V0_least, Vc_least )
	// when degenerate region 6, ( V0, Vc ) = ( Vc_least, V0_least )

	BOOL SolveVpeak_0ConstAccRegion( double V0, double Vc, double P, double Jmax, double &V );
	// solve Vpeak for two sides without constant acceleration region
#endif

	double searchMaxVelocity( double V0, double A0, double Vc, double Ac, double P, double V_low, double V_up, double Amax );
	// search maximum velocity through numerical method

	void MergeAndOutputPVT( double V0, double Vc, double V_Goal );
	// merge epsilon distance difference and output PVT

	void MergeEpsilonDist( TTrajInfo &Traj );
	// merge epsilon distance difference to Traj

	void MergeEpsilonDist( TTrajInfo &Traj1, TTrajInfo &Traj2, double dT, double V1, double V2 );
	// merge epsilon distance difference to Traj1 and Traj2 in Process7SectionCases

	BOOL ModifyJerk( double V0, double A0, double Vc, double Ac, double P, double A );
	// modify jerk

	BOOL ModifySmallJerk( double V0, double A0, double Vc, double Ac, double P, double A );
	// modify small jerk

	BOOL FindMiddleJerk( double V0, double A0, double P, double A, double &J );
	// find middle jerk

	BOOL ModifyBothJerks( double V0, double A0, double Vc, double Ac, double P, double A );
	// modify both jerks

	BOOL FindGoalJerk( double V0, double A0, double Vc, double Ac, double P, double A );
	// find goal jerk

	BOOL FindGoalJerk_Acc( double V0, double A0, double Vc, double Ac, double P, double A );
	// find goal jerk in acceleration case

	BOOL FindGoalJerk_Dec( double V0, double A0, double Vc, double Ac, double P, double A );
	// find goal jerk in deceleration case

	BOOL SolveJerk_1S2S( double V0, double A0, double P, double &J );
	// single side two sections

	BOOL SolveJerk_1S3S( double V0, double A0, double P, double A, double &J );
	// single side three sections

	BOOL SolveJerk_2S3S( double V0, double A0, double Vc, double Ac, double P );
	// two sides three sections

	BOOL SolveJerk_2S4S( double V0, double A0, double Vc, double Ac, double P, double A );
	// two sides four sections

private:
	int m_nMaxLoopCount;
	int m_nAvgLoopCount;
	int m_nSampleCount;
	int m_LoopCountAcc;

	TPVTSheet *m_pPVT;
	// PVT sheet

	double m_J1, m_J2;
	// jerks for startup and stopdown

	BOOL m_bModifyJ1, m_bModifyJ2;
	// flags for modifying J1 or J2

	double m_V1_least, m_V2_least;
	// least V1 and V2

	double m_dP;
	// distance difference

	TTrajInfo m_StartUp, m_StopDown;

	double m_V_low;
	// lower velocity

	BOOL m_bFrontOneSection;
	// flag for whether front is one section

	double m_Pbound;
	// distance boundary

	CPolynomialRootSolver m_PRS;
	// polynomial root solver

	double m_Coeff[5];
	// polynomial coefficients with m_Coeff[i] for i-th degree coefficient

	double m_P_up, m_P_low;
	// upper and lower distance difference in recursion

	double MakeVelWithinRange( double V, double V_high, double V_low );
	// ensure Vout is in the interval [Vmin, Vmax]
};

#endif // !defined(_TRAJECTORYNORMAL_H____INCLUDED_)
