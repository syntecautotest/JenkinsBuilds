// Point3d.h: interface for the CPoint3d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POINT3D_H__63CDE29A_9863_4280_B330_F89AD12D1904__INCLUDED_)
#define AFX_POINT3D_H__63CDE29A_9863_4280_B330_F89AD12D1904__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Tuple3d.h"
#include "ZMath.h"

class UTILAPI CPoint3d : public CTuple3d  
{
public:
	CPoint3d();
	// constructs and initialize point to zero

	CPoint3d( double x, double y, double z );
	// constructs and initialize point to specified position

	virtual ~CPoint3d();
	// destructor

public:

	double norm();

	double normsquare();

	double normsquare(CPoint3d &Pt);

	double distance(CPoint3d &t);
};

#endif // !defined(AFX_POINT3D_H__63CDE29A_9863_4280_B330_F89AD12D1904__INCLUDED_)
