#if !defined(_OCAPI_INCLUDE_)
#define _OCAPI_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef __cplusplus
extern "C" {
#endif

//Result of OCAPIInit
#define OC_OK					0L
#define OC_FAIL				    -1L
#define	OC_FINDCNCANOTHER		-2L
#define	OC_FINDMULTICNC			-3L
#define	OC_USERCANCELSEARCH		-4L
#define	OC_SEARCHTIMEOUT		-5L
#define	OC_DELAYTIMEFAIL		-6L

#ifndef _LPCNC_EVENT_LISTENER_TYPEDEF_
#define _LPCNC_EVENT_LISTENER_TYPEDEF_

typedef DWORD (WINAPI *LPCNC_EVENT_LISTENER)( LPVOID lpParam, UINT uEventID, DWORD dwParam );

#endif // _LPCNC_EVENT_LISTENER_TYPEDEF_

#ifndef _NCEVENT_DEFINE_
#define _NCEVENT_DEFINE_

#define NCEVENT_OnAlarmChanged					0x0001
#define NCEVENT_OnParamChanged					0x0002
#define NCEVENT_OnCncShutdown					0x0004
#define NCEVENT_OnResetHappen					0x0008
#define NCEVENT_OnCncModeChanged				0x0010
#define NCEVENT_OnCncStatusChanged				0x0020
#define NCEVENT_OnCheckedRegisterValueChanged	0x0040
#define NCEVENT_OnEventTrgHappen				0x0080
#define NCEVENT_OnSriEventHappen				0x0100
#define NCEVENT_OnAbsCoordChanged				0x0200
#define NCEVENT_SvoPowerOff						0x0400
#define NCEVENT_UseTimeSetStateChanged			0x1000
#define NCEVENT_MaxEventId						0x1000

#endif // _NCEVENT_DEFINE_

#if !defined(STRUCT_POINT_W)
#define STRUCT_POINT_W

typedef struct tagPOINT_W {
   double x;
   double y;
   double z;
} POINT_W;

#endif // STRUCT_POINT_W

// API initialization/de-initialization
HRESULT WINAPI OCAPIInit( BOOL bNcStart = TRUE );
void WINAPI OCAPIUninit( void );
// query Cnc controller at Lan and return its Serial Number
LONG WINAPI OCAPIQueryCNCatLan( TCHAR* pNewSerialNo/*out*/, int iLen);
HRESULT WINAPI OCAPIInitEx(UINT iRetriedTime, BOOL bNcStart = TRUE);

// TCP dipole interfaces
typedef VOID (WINAPI *LPTCNC_TCPRETRYINGEVENT)( LPVOID lpSender, UINT16 uErrorNO, LPCTSTR lpFunctionName, BOOL *bCancel);
typedef VOID (WINAPI *LPTCNC_TCPRETRIEDEVENT)( LPVOID lpSender, LPCTSTR lpFunctionName );
typedef VOID (WINAPI *LPTCNC_TCPCONFIRMRETRYEVENT)( LPVOID lpSender, BOOL bSuccess );
typedef VOID (WINAPI *LPTCNC_TCPFILETRANSFERSTOPPED)( UINT16 uErrorNO );
typedef VOID (WINAPI *LPTCNC_TCPFILETRANSFERUPDATEPROGRESS)( int nCurrent, int nTotal );

HRESULT WINAPI OCAPITCPInitEx( /*in*/ LPCTSTR lpszServerIP, /*in*/ LONG nTimeOut, /*in*/ LPCTSTR lpszInternalKey );
HRESULT WINAPI OCAPITCPInit( /*in*/ LPCTSTR lpszServerIP, /*in*/ LONG nTimeOut );
HRESULT WINAPI OCAPILocalInit();
void	WINAPI OCAPITCPUnInit();
BOOL	WINAPI OCAPITCPIsConnect();
HRESULT WINAPI OCAPIIsTCPMode( /*out*/ INT *Flag, /*in out*/ TCHAR *Address, /*in*/ LONG nLengthToRead, /*out*/ LONG *lpnLengthRead );
HRESULT WINAPI TCPGetKernelServerVersion( /*in*/ LPCTSTR wServerIP, /*in*/ UINT32 uTimeOut, /*out*/ UINT32 *uVer , /*out*/ UINT16 *uErr );
HRESULT WINAPI TCPSetRetriedCallback( /*in*/ LPTCNC_TCPRETRIEDEVENT lpRetried );
HRESULT WINAPI TCPSetConfirmRetryCallback( /*in*/ LPTCNC_TCPCONFIRMRETRYEVENT lpConfirm );
HRESULT WINAPI TCPFileExists( LPCTSTR lpFileName, BOOL* lpExists , UINT16 *uErr );
HRESULT WINAPI TCPDirExists( LPCTSTR lpDirName, BOOL* lpExists , UINT16 *uErr );
HRESULT WINAPI TCPDirCreate( LPCTSTR lpDirName, BOOL* lpSuccess, UINT16 *uErr );

// CNC interface
HRESULT WINAPI BridgeAPI( DWORD dwCode, BYTE *pBufferIn, DWORD dwSizeIn, BYTE *pBufferOut, DWORD dwSizeOut );
HRESULT WINAPI KrnlAPI( DWORD dwCode, BYTE *pBufferIn, DWORD dwSizeIn, BYTE *pBufferOut, DWORD dwSizeOut );
HRESULT WINAPI MultiTCPKrnlAPI( HANDLE hClientLink, DWORD dwCode, BYTE *pBufferIn, DWORD dwSizeIn, BYTE *pBufferOut, DWORD dwSizeOut );
HRESULT WINAPI NcShutdown( DWORD dwMilliseconds );
HRESULT WINAPI NcRestartCNC(DWORD dwDelayTimeMilliseconds, DWORD dwTimeOutMilliseconds, BOOL bForce, BOOL bRestartClient );
HRESULT WINAPI NcAdvise( LPCNC_EVENT_LISTENER lpfnListener, LPVOID lpParam, LPDWORD lpdwCookie );
HRESULT WINAPI NcUnadvise( DWORD dwCookie );
HRESULT WINAPI NcStartControlSystem();

//------------------------------------------------------------
// Multi Client TCP support
HRESULT WINAPI MultiTCPAddLinkEx( /*in*/ LPCTSTR lpszServerIP, /*out*/ HANDLE &hClientLink, /*in*/ DWORD nTimeout, /*in*/ LPCTSTR lpszInternalKey );
HRESULT WINAPI MultiTCPAddLink( /*in*/ LPCTSTR lpszServerIP, /*out*/ HANDLE &hClientLink, /*in*/ DWORD nTimeout );
HRESULT WINAPI MultiTCPRemoveLink( /*in*/ HANDLE hClientLink );
HRESULT WINAPI MultiTCPGetLinkHandle( /*in*/LPCTSTR wServerIP );
HRESULT WINAPI MultiTCPisHandleExit(/*in*/ HANDLE hClientLink );
HRESULT WINAPI MultiTCPConnect( /*in*/ HANDLE hClientLink, /*in*/ LPCTSTR wServerIP );
HRESULT WINAPI MultiTCPDisconnect(/*in*/ HANDLE hClientLink);
HRESULT WINAPI MultiTCPIsConnected( /*in*/ HANDLE hClientLink , /*out*/ BOOL *lpbConnected );
VOID WINAPI MultiTCPClose();
HRESULT WINAPI MultiTCPNcAdvise( /*in*/ HANDLE hClientLink, LPCNC_EVENT_LISTENER lpfnListener, LPVOID lpParam, LPDWORD lpdwCookie );
HRESULT WINAPI MultiTCPNcUnadvise( /*in*/ HANDLE hClientLink, DWORD dwCookie );
HRESULT WINAPI MultiTCPNcShutdown( /*in*/ HANDLE hClientLink, DWORD dwMilliseconds );
HRESULT WINAPI MultiTCPNcRestartCNC( /*in*/ HANDLE hClientLink, DWORD dwDelayTimeMilliseconds, DWORD dwTimeOutMilliseconds, BOOL bForce, BOOL bRestartClient );
HRESULT WINAPI MultiTCPResMgr_RemoteLookup( /*in*/ HANDLE hClientLink, LPCTSTR lpszKey, TCHAR *lpBuffer, LONG nLength );
//-------------------------------------------------------------------------------------
// TCP Support
//-------------------------------------------------------------------------------------
HRESULT WINAPI MultiTCPSetRetryingCallback( /*in*/ HANDLE hClientLink, /*in*/ LPTCNC_TCPRETRYINGEVENT lpRetrying );
HRESULT WINAPI MultiTCPFileSend( /*in*/ HANDLE hClientLink, LPCTSTR lpLocalFileName, LPCTSTR lpDestFileName, LPTCNC_TCPFILETRANSFERSTOPPED lpStoppedCallback, LPTCNC_TCPFILETRANSFERUPDATEPROGRESS lpUpdateProgress );
HRESULT WINAPI MultiTCPInstall( /*in*/ HANDLE hClientLink, UINT32 uMethod );
HRESULT WINAPI MultiTCPFileDownload( /*in*/ HANDLE hClientLink, LPCTSTR lpLocalFileName, LPCTSTR lpDestFileName, LPTCNC_TCPFILETRANSFERSTOPPED lpStoppedCallback, LPTCNC_TCPFILETRANSFERUPDATEPROGRESS lpUpdateProgress );
HRESULT WINAPI MultiTCPFileDelete( /*in*/ HANDLE hClientLink, LPCTSTR lpLocalFileName, BOOL* lpSuccess , UINT16 *uErr );
HRESULT WINAPI MultiTCPFileNew( /*in*/ HANDLE hClientLink, LPCTSTR lpFileName, BOOL* lpSuccess , UINT16 *uErr );
HRESULT WINAPI MultiTCPFileCopy( /*in*/ HANDLE hClientLink, LPCTSTR lpSrcFileName, LPCTSTR lpDstFileName, BOOL* lpSuccess , UINT16 *uErr );
HRESULT WINAPI MultiTCPFileMove( /*in*/ HANDLE hClientLink, LPCTSTR lpSrcFileName, LPCTSTR lpDstFileName, BOOL* lpSuccess , UINT16 *uErr );

void WINAPI ResMgr_PutLocaleID( LONG NewID );
LONG WINAPI ResMgr_GetLocaleID( void );
TCHAR * WINAPI ResMgr_Lookup( LPCTSTR lpszKey );
// Look up Remote ResMap
HRESULT WINAPI ResMgr_RemoteLookup( LPCTSTR lpszKey, TCHAR *lpBuffer, LONG nLength );

#if defined(UNDER_CE)

#define _MAX_DRIVE  3   /* max. length of drive component */
#define _MAX_DIR    256 /* max. length of path component */
#define _MAX_FNAME  256 /* max. length of file name component */
#define _MAX_EXT    256 /* max. length of extension component */

void __cdecl _tsplitpath (
	const TCHAR *path,
	TCHAR *drive,
	TCHAR *dir,
	TCHAR *fname,
	TCHAR *ext
	);

void __cdecl _tmakepath (
	TCHAR *path,
	const TCHAR *drive,
	const TCHAR *dir,
	const TCHAR *fname,
	const TCHAR *ext
	);

void * __cdecl bsearch (
	const void *key,
	const void *base,
	size_t num,
	size_t width,
	int (__cdecl *compare)(const void *, const void *)
	);

void * __cdecl _lfind (
	const void *key,
	const void *base,
	unsigned int *num,
	unsigned int width,
	int (__cdecl *compare)(const void *, const void *)
	);

void __cdecl _splitpath (
	const char *path,
	char *drive,
	char *dir,
	char *fname,
	char *ext
	);

void __cdecl _makepath (
	char *path,
	const char *drive,
	const char *dir,
	const char *fname,
	const char *ext
	);

#else // defined(UNDER_CE)

#include <search.h>

#endif // defined(UNDER_CE)

#ifdef __cplusplus
}
#endif 

#endif // !defined(_OCAPI_INCLUDE_)
