// FixPointNumber32.h: interface for the FixPointNumber32 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FIXPOINTNUMBER32_H__INCLUDED_)
#define AFX_FIXPOINTNUMBER32_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_MASK_BIT		( 32 )
#define MAX_SHIFT_BIT		( 31 )
#define MAX_LONG_32			( 2147483647 )
#define MIN_LONG_32			( -2147483647 - 1 )
#define VALUE_OF_2_PWR_31	( 0x80000000 ) // 2 ^ 31

class CFixPointNumber32
{
public:
	CFixPointNumber32( void );
	// constructor

	~CFixPointNumber32( void );
	// destructor

	void SetByDouble( double Data, int nQValue );
	// set data and Q Value of fix point number

	void SetZero( void );
	// set zero

	void Add( CFixPointNumber32 &Number1, CFixPointNumber32 &Number2 );
	// this = Number1 + Number2
	// for the sake of efficiency, this function adopt call by reference technique,
	// instead of return CFixPointNumber32 which is less efficienct but more readable

	void Subtract( CFixPointNumber32 &Number1, CFixPointNumber32 &Number2 );
	// this = Number1 - Number2
	// for the sake of efficiency, this function adopt call by reference technique,
	// instead of return CFixPointNumber32 which is less efficienct but more readable

	void Multiply( CFixPointNumber32 &Number1, CFixPointNumber32 &Number2, BOOL bAlignment = TRUE );
	// this = Number1 * Number2
	// for the sake of efficiency, this function adopt call by reference technique,
	// instead of return CFixPointNumber32 which is less efficienct but more readable

	void Multiply( CFixPointNumber32 &Number1, long Number2 );
	// this = Number1 * Number2
	// for the sake of efficiency, this function adopt call by reference technique,
	// instead of return CFixPointNumber32 which is less efficienct but more readable

	void Multiply( CFixPointNumber32 &Number1, double Number2 );
	// this = Number1 * Number2
	// for the sake of efficiency, this function adopt call by reference technique,
	// instead of return CFixPointNumber32 which is less efficienct but more readable

	void Divide( CFixPointNumber32 &Number1, CFixPointNumber32 &Number2, BOOL bAlignment = TRUE );
	// this = Number1 / Number2
	// for the sake of efficiency, this function adopt call by reference technique,
	// instead of return CFixPointNumber32 which is less efficienct but more readable

	void Left_Shift( int nShift );
	// left shift operation

	void Right_Shift( int nShift );
	// right shitf operation

	void getInteger( long &Number );
	// get integer part of fix point number

	void setFragment( CFixPointNumber32 &Number );
	// set fragment part of fix point number

private:
	long m_nFixPointNumber32;
	// Fix Point Number

	char m_nQValue;
	// Q value of fix point number
};

inline CFixPointNumber32::CFixPointNumber32( void )
// constructor
{
}

inline CFixPointNumber32::~CFixPointNumber32( void )
// destructor
{
}

inline void CFixPointNumber32::SetByDouble( double Data, int nQValue )
// set data and Q Value of fix point number
{
	ASSERT( nQValue >= 0 );

	if( nQValue >= MAX_MASK_BIT ) {
		unsigned long temp1, temp2;

		temp1 = 1 << ( nQValue - MAX_SHIFT_BIT );
		temp2 = VALUE_OF_2_PWR_31;

		m_nFixPointNumber32 = ( long )( Data * temp1 * temp2 );
	}
	else {
		m_nFixPointNumber32 = ( long )( Data * ( 1 << nQValue ) );
	}

	m_nQValue = nQValue;
}

inline void CFixPointNumber32::SetZero( void )
// set zero
{
	m_nFixPointNumber32 = 0;
	m_nQValue = 0;
}

inline void CFixPointNumber32::Add( CFixPointNumber32 &Number1, CFixPointNumber32 &Number2 )
// this = Number1 + Number2
// for the sake of efficiency, this function adopt call by reference technique,
// instead of return CFixPointNumber32 which is less efficienct but more readable
{
	if( Number1.m_nQValue == Number2.m_nQValue  ) {
		ASSERT( ( ( double )Number1.m_nFixPointNumber32 + Number2.m_nFixPointNumber32 < MAX_LONG_32 )
			 && ( ( double )Number1.m_nFixPointNumber32 + Number2.m_nFixPointNumber32 > MIN_LONG_32 ) );

		m_nFixPointNumber32 = Number1.m_nFixPointNumber32 + Number2.m_nFixPointNumber32;
		m_nQValue = Number1.m_nQValue;
	}
	else {
		if( Number1.m_nQValue > Number2.m_nQValue ) {
			ASSERT( ( ( double )Number2.m_nFixPointNumber32 * ( 1 << ( Number1.m_nQValue - Number2.m_nQValue ) ) + Number1.m_nFixPointNumber32 < MAX_LONG_32 )
				 && ( ( double )Number2.m_nFixPointNumber32 * ( 1 << ( Number1.m_nQValue - Number2.m_nQValue ) ) + Number1.m_nFixPointNumber32 > MIN_LONG_32 ) );

			m_nFixPointNumber32 = Number1.m_nFixPointNumber32 + ( Number2.m_nFixPointNumber32 << ( Number1.m_nQValue - Number2.m_nQValue ) );
			m_nQValue = Number1.m_nQValue;
		}
		// m_nQValue < Number.m_nQValue
		else {
			ASSERT( ( ( double )Number1.m_nFixPointNumber32 * ( 1 << ( Number2.m_nQValue - Number1.m_nQValue ) ) + Number2.m_nFixPointNumber32 < MAX_LONG_32 )
				 && ( ( double )Number1.m_nFixPointNumber32 * ( 1 << ( Number2.m_nQValue - Number1.m_nQValue ) ) + Number2.m_nFixPointNumber32 > MIN_LONG_32 ) );

			m_nFixPointNumber32 = ( Number1.m_nFixPointNumber32 << ( Number2.m_nQValue - Number1.m_nQValue ) ) + Number2.m_nFixPointNumber32;
			m_nQValue = Number2.m_nQValue;
		}
	}
}

inline void CFixPointNumber32::Subtract( CFixPointNumber32 &Number1, CFixPointNumber32 &Number2 )
// this = Number1 - Number2
// for the sake of efficiency, this function adopt call by reference technique,
// instead of return CFixPointNumber32 which is less efficienct but more readable
{
	if( Number1.m_nQValue == Number2.m_nQValue  ) {
		ASSERT( ( ( double )Number1.m_nFixPointNumber32 - Number2.m_nFixPointNumber32 < MAX_LONG_32 )
			 && ( ( double )Number1.m_nFixPointNumber32 - Number2.m_nFixPointNumber32 > MIN_LONG_32 ) );

		m_nFixPointNumber32 = Number1.m_nFixPointNumber32 - Number2.m_nFixPointNumber32;
		m_nQValue = Number1.m_nQValue;
	}
	else {
		if( Number1.m_nQValue > Number2.m_nQValue ) {
			ASSERT( ( ( double )Number2.m_nFixPointNumber32 * ( -1 << ( Number1.m_nQValue - Number2.m_nQValue ) ) + Number1.m_nFixPointNumber32 < MAX_LONG_32 )
				 && ( ( double )Number2.m_nFixPointNumber32 * ( -1 << ( Number1.m_nQValue - Number2.m_nQValue ) ) + Number1.m_nFixPointNumber32 > MIN_LONG_32 ) );

			m_nFixPointNumber32 = Number1.m_nFixPointNumber32 - ( Number2.m_nFixPointNumber32 << ( Number1.m_nQValue - Number2.m_nQValue ) );
			m_nQValue = Number1.m_nQValue;
		}
		// m_nQValue < Number.m_nQValue
		else {
			ASSERT( ( ( double )Number1.m_nFixPointNumber32 * ( -1 << ( Number2.m_nQValue - Number1.m_nQValue ) ) + Number2.m_nFixPointNumber32 < MAX_LONG_32 )
				 && ( ( double )Number1.m_nFixPointNumber32 * ( -1 << ( Number2.m_nQValue - Number1.m_nQValue ) ) + Number2.m_nFixPointNumber32 > MIN_LONG_32 ) );

			m_nFixPointNumber32 = ( Number1.m_nFixPointNumber32 << ( Number2.m_nQValue - Number1.m_nQValue ) ) - Number2.m_nFixPointNumber32;
			m_nQValue = Number2.m_nQValue;
		}
	}
}

inline void CFixPointNumber32::Multiply( CFixPointNumber32 &Number1, CFixPointNumber32 &Number2, BOOL bAlignment )
// this = Number1 * Number2
// for the sake of efficiency, this function adopt call by reference technique,
// instead of return CFixPointNumber32 which is less efficienct but more readable
{
	if( bAlignment == TRUE ) {
		if( Number2.m_nQValue >= 0 ) {
			ASSERT( ( double )Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32 / ( 1 << Number2.m_nQValue ) <= MAX_LONG_32
				 && ( double )Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32 / ( 1 << Number2.m_nQValue ) >= MIN_LONG_32 );

			// the Q value should be Number1.m_nQValue + Number2.m_nQValue
			// if bAlignment is equal to TRUE, the right shift operation is executed to keep Q value the same as Number1.m_nQValue
			m_nFixPointNumber32 = ( Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32 ) >> Number2.m_nQValue;
		}
		else {
			ASSERT( ( double )Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32 * ( 1 << -Number2.m_nQValue ) <= MAX_LONG_32
				 && ( double )Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32 * ( 1 << -Number2.m_nQValue ) >= MIN_LONG_32 );

			// the Q value should be Number1.m_nQValue + Number2.m_nQValue
			// if bAlignment is equal to TRUE, the left shift operation is executed to keep Q value the same as Number1.m_nQValue
			m_nFixPointNumber32 = ( Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32 ) << ( -Number2.m_nQValue );
		}
		m_nQValue = Number1.m_nQValue;
	}
	else {
		ASSERT( ( ( double )Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32 <= MAX_LONG_32 )
			 && ( ( double )Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32 >= MIN_LONG_32 ) );

		m_nFixPointNumber32 = Number1.m_nFixPointNumber32 * Number2.m_nFixPointNumber32;
		m_nQValue = Number1.m_nQValue + Number2.m_nQValue;
	}
}

inline void CFixPointNumber32::Multiply( CFixPointNumber32 &Number1, long Number2 )
// this = Number1 * Number2
// for the sake of efficiency, this function adopt call by reference technique,
// instead of return CFixPointNumber32 which is less efficienct but more readable
{
	ASSERT( ( ( double )Number2 * Number1.m_nFixPointNumber32 <= MAX_LONG_32 )
		 && ( ( double )Number2 * Number1.m_nFixPointNumber32 >= MIN_LONG_32 ) );

	m_nFixPointNumber32 = Number1.m_nFixPointNumber32 * Number2;
	m_nQValue = Number1.m_nQValue;
}

inline void CFixPointNumber32::Multiply( CFixPointNumber32 &Number1, double Number2 )
// this = Number1 * Number2
// for the sake of efficiency, this function adopt call by reference technique,
// instead of return CFixPointNumber32 which is less efficienct but more readable
{
	ASSERT( ( Number2 * Number1.m_nFixPointNumber32 <= MAX_LONG_32 )
		 && ( Number2 * Number1.m_nFixPointNumber32 >= MIN_LONG_32 ) );

	m_nFixPointNumber32 = ( long )( Number1.m_nFixPointNumber32 * Number2 );
	m_nQValue = Number1.m_nQValue;
}

inline void CFixPointNumber32::Divide( CFixPointNumber32 &Number1, CFixPointNumber32 &Number2, BOOL bAlignment )
// this = Number1 / Number2
// for the sake of efficiency, this function adopt call by reference technique,
// instead of return CFixPointNumber32 which is less efficienct but more readable
{
	ASSERT( Number2.m_nFixPointNumber32 != 0 );

	if( bAlignment == TRUE ) {
		if( Number2.m_nQValue >=0 ) {
			ASSERT( ( double )Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32 * ( 1 << Number2.m_nQValue ) <= MAX_LONG_32
				 && ( double )Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32 * ( 1 << Number2.m_nQValue ) >= MAX_LONG_32 );

			// the Q value should be Number1.m_nQValue - Number2.m_nQValue
			// if bAlignment is equal to TRUE, the left shift operation is executed to keep Q value the same as Number1.m_nQValue
			m_nFixPointNumber32 = ( Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32 ) << Number2.m_nQValue;
		}
		else {
			ASSERT( ( double )Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32 / ( 1 << -Number2.m_nQValue ) <= MAX_LONG_32
				 && ( double )Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32 / ( 1 << -Number2.m_nQValue ) >= MAX_LONG_32 );

			// the Q value should be Number1.m_nQValue - Number2.m_nQValue
			// if bAlignment is equal to TRUE, the right shift operation is executed to keep Q value the same as Number1.m_nQValue
			m_nFixPointNumber32 = ( Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32 ) >> ( -Number2.m_nQValue );
		}
		m_nQValue = Number1.m_nQValue;
	}
	else {
		ASSERT( ( double )Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32 <= MAX_LONG_32
			 && ( double )Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32 >= MIN_LONG_32 );

		m_nFixPointNumber32 = Number1.m_nFixPointNumber32 / Number2.m_nFixPointNumber32;
		m_nQValue = Number1.m_nQValue - Number2.m_nQValue;
	}
}

inline void CFixPointNumber32::Left_Shift( int nShift )
// left shift operation
{
	ASSERT( nShift > 0 );
	ASSERT( m_nQValue + nShift < MAX_MASK_BIT );

	m_nFixPointNumber32 = m_nFixPointNumber32 << nShift;
	m_nQValue += nShift;
}

inline void CFixPointNumber32::Right_Shift( int nShift )
// right shitf operation
{
	ASSERT( nShift > 0 );
	ASSERT( m_nQValue - nShift > -MAX_MASK_BIT );

	m_nFixPointNumber32 = m_nFixPointNumber32 >> nShift;
	m_nQValue -= nShift;
}

inline void CFixPointNumber32::getInteger( long &Number )
// get integer part of fix point number
{
	if( m_nQValue >= 0 ) {
		Number = m_nFixPointNumber32 >> m_nQValue;
	}
	else {
		Number = m_nFixPointNumber32 << ( -m_nQValue );
	}
}

inline void CFixPointNumber32::setFragment( CFixPointNumber32 &Number )
// set fragment part of fix point number from input number
{
	if( Number.m_nQValue >= 0 && Number.m_nQValue < MAX_MASK_BIT ) {
		// ( ( 1 << m_nQValue ) - 1 ) is the MASK, for example when m_nQValue = 5
		// ( ( 1 << m_nQValue ) - 1 ) = ( 1 << 5 ) - 1 = 32 - 1 = 31 = 0x000001F
		m_nFixPointNumber32 = Number.m_nFixPointNumber32 & ( ( 1 << Number.m_nQValue ) - 1 );
	}
	else {
		m_nFixPointNumber32 = 0;
	}

	m_nQValue = Number.m_nQValue;
}

#endif // !defined(AFX_FIXPOINTNUMBER32_H__INCLUDED_)
