// BitFilter.h: interface for the CBitFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BITFILTER_H__300FF148_002E_11D3_B6BF_000000000000__INCLUDED_)
#define AFX_BITFILTER_H__300FF148_002E_11D3_B6BF_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBitFilter  
{
public:
	enum EFilterMethod {
		FM_Best2Of3 = 0,
		FM_2Repeat  = 1,
		FM_3Repeat  = 2,
		FM_4Repeat  = 3
	};
	// constant for filter method selection

public:
	CBitFilter( int nNumOfChannel );
	// constructs bit digital filter

	virtual ~CBitFilter();
	// destructs this object

	void setFilterMethod( int method );
	// set filter method

	void filter( int channel, ULONG &data );
	// do filter

	void filter( int channel, unsigned short &data );
	// do filter

	void filter( int channel, unsigned char &data );
	// do filter
private:
	enum EMaxBound {
		FILTERLEVEL_4Repeat	= 5,
		FILTERLEVEL_3Repeat	= 3,
		FILTERLEVEL_2Repeat	= 1,
		MAX_FilterLength = FILTERLEVEL_4Repeat+1,
	};
	// constant for maximum bound

	enum EChannelState {
		STATE_NotYetUsed,
		STATE_Used
	};
	// constants for channel state

	int m_method;
	// current selected filter method

	int m_nNumOfChannel;
	// the number of channel

	int *m_ChannelState;
	// the channel state

	typedef ULONG TFilterChannelPipe[MAX_FilterLength];
	// type definition for filter channel data

	TFilterChannelPipe *m_DataPipe;
	// data pipe to store past bit state used for digital filter,
	// the zero index of channel buffer is result output value

	void resetAllChannelState( void );
	// reset all channel state
};

#endif // !defined(AFX_BITFILTER_H__300FF148_002E_11D3_B6BF_000000000000__INCLUDED_)
