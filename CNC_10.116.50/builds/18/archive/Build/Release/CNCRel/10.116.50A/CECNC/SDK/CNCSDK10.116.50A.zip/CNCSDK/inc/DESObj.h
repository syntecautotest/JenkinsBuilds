// DESObj.h: interface for the CDESObj class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DESOBJ_H__2C85D586_8721_4D6B_A412_FBB8ABD39357__INCLUDED_)
#define AFX_DESOBJ_H__2C85D586_8721_4D6B_A412_FBB8ABD39357__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define LEN_DESFILE_HEADER				8
#define LEN_DESFILE_SIZE				4
#define LEN_DESFILE_ALIGNMENT			8

class CDESObj  
{
public:
	CDESObj();
	// constructor

	virtual ~CDESObj();
	// destructor

	unsigned short CRC16(unsigned char *puchMsg, unsigned long usDataLen);
	// 16 bit CRC error check, generate 2 bytes CRC data

	int DES_EncryptionSingleBlock(unsigned char *source, unsigned char *result, unsigned char *key_use);
	// encrypt one block data, 8 bytes => 8 bytes using key_use

	int DES_DecryptionSingleBlock(unsigned char *source, unsigned char *result, unsigned char *key_use);
	// decrypt one block data, 8 bytes => 8 bytes using key_use

	int DES_EncryptionBlockDatas(unsigned char *sourceBlock, unsigned char *resultBlock, unsigned char *key_use, long BlockLength);
	// encrypt mass block data, use 8 bytes as 1 unit, must tell this function the block size by BlockLength

	int DES_DecryptionBlockDatas(unsigned char *sourceBlock, unsigned char *resultBlock, unsigned char *key_use, long BlockLength);
	// decrypt mass block data, use 8 bytes as 1 unit, must tell this function the block size by BlockLength

	int DES_EncryptionFile( char *sourcePath, char *resultPath, unsigned char *key_use);
	// use DES to encrypt file, input file path, output file path and using key

	int DES_DecryptionFile( char *sourcePath, char *resultPath, unsigned char *key_use);
	// use DES to decrypt file, input file path, output file path and using key

	int DES_DecryptionFileToBlockData( char *sourcePath , unsigned char *returnBuffer, unsigned char *key_use, unsigned long bufferSize, long *returnSize );
	// use DES to decrypt file, input file path, output buffer pointer,
	// the size of output buffer, and this function will return how many size the file decrypt

	BOOL DES_EncryptionCheckCRC( unsigned char *sourceBlock, unsigned char *key_use, unsigned long nFileSize );
	// check CRC for encryption file

private:
	// 56 => 48 bits key store, 16 keys 
	unsigned char m_key_array[16][6];

	/* Permutation input message bit, using different fixed table */
	int RearrangeBits( unsigned char *source , unsigned char *result, unsigned int *array ,int length );

	/* rotate the input message bits */
	int RotateLBits( unsigned char *source , unsigned char *result, int RLBit ,int length );

	/* DES encode method using phase */
	int S_Box( unsigned char *source , unsigned char *result );

	// output to global data, one encryption / decryption just one group key
	// input 56 bits key, output 48bits of 16 group key
	void GenerateKeyArray(unsigned char *keyinput);

	/* DES encode method using phase */
	int Calculate_f( unsigned char *source , unsigned char *result, unsigned char *key_use );

	/* DES encode method using phase */
	int Iteration( unsigned char *source , unsigned char *result, int count );

	void ReleaseMemoryBuff( void );

	// 64K memory block use for store source and result block
	unsigned char *m_sourceBlock;
	unsigned char *m_resultBlock;
};

#endif // !defined(AFX_DESOBJ_H__2C85D586_8721_4D6B_A412_FBB8ABD39357__INCLUDED_)
