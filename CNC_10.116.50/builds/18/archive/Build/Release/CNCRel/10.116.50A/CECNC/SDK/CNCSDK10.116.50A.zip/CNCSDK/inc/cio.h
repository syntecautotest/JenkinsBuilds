//
//  CIO(Common I/O Card Interface)
//

#ifndef _cio_h_
#define _cio_h_

#include "nstdlib.h"

// alaram flag bit-mask				    
#define	ALARM_NoError					0L
#define	ALARM_IOTransmitFailure			0x00000001
#define	ALARM_M3IOCommErr				0x00000002
#define	ALARM_M3IOErr					0x00000004
#define	ALARM_IOOverload				0xFFFF0000

// alarm flag ID
#define	ALMID_NoError					0
#define	ALMID_IOTransmitFailure			1

#ifndef TDRIVEROBJECT_DEFINE
#define TDRIVEROBJECT_DEFINE 1

struct TDriverObject {
	HINSTANCE		m_hModule;			// module handle of this driver

	void (PFNCNCAPI *DriverUnload)( TDriverObject *pDriverObject );
	// driver unload function, this function will be called when specified
	// driver been unload.

	DWORD			m_DriverData[10];	// private storage for driver usage
};
// data structure for device driver

typedef BOOL (PFNCNCAPI *TPFNDriverLoad)( TDriverObject *pDriverObject, char *RegistryPath );
// typedef for DriverLoad entry point
// Note: the DriverLoad entry ordinal number should be @1

#endif // TDRIVEROBJECT_DEFINE

class IMPGChannel;
class ILatchIOChannel;

//  Common I/O Interface
class ICIODriver
{
public:
	virtual void CNCAPI setFilterMethod( INT nMethod ) = 0;
	// set the digital filter method

	virtual long CNCAPI ReadAlarmFlags( void ) = 0;
	// to read current alram status

	virtual void CNCAPI RefreshAlarmFlags( void ) = 0;
	// to refresh resetable alarm flag

	virtual void CNCAPI ScanMatrixIO( void ) = 0;
	//  To request I/O driver to scan matrix I/O

	virtual void CNCAPI ScanISignal( void ) = 0;
	//  To request I/O driver to scan input signals.

	virtual void CNCAPI ScanOSignal( void ) = 0;
	//  To request I/O driver to scan output signals.

	virtual IMPGChannel * CNCAPI GetMPGChannel( INT nIBit ) = 0;
	// to get MPG channel

	virtual BOOL CNCAPI LockLatchIOChannel( ILatchIOChannel *&pLatchIOChannel, INT nIBit ) = 0;
	// to lock LatchIOchannel

	virtual BOOL CNCAPI UnlockLatchIOChannel( INT nIBit ) = 0;
	// to unlock LatchIOchannel
};

#endif	// _cio_h_
