// NurbsCurve.h: interface for the NurbsCurve class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_NURBSCURVE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_)
#define AFX_NURBSCURVE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_ORDER					4	// it depends on CONTINUITY of corner
#define ZEPS						(1.0e-10)
#define MAX_PACK_NUMBER				50
#define BIAS_PROPORTION				0.01	// 1%

enum ECheckResult
{
	E_FailTol = 0,		// if err is larger than tolerance
	E_CheckNextPt,		// if err is less than tolerance or the FootPtParamer recorded
	E_NotDetermined,	// if the inner product isn't close to zero enough
};

class CTuple3d;
class CVector3d;
class CBezier;

class CNurbsCurve
{
public:
	CNurbsCurve( void );
	CNurbsCurve( int MaxCapacity );
	virtual ~CNurbsCurve();

	int m_nSize;
	// curve size.

	double m_feedrate;
	// feedrate of curve, IU / usec

	int m_nOrder;
	// the NURBS curve order

	int m_nNumOfControlPt;
	// number of control point

	CVector3d *m_ControlPt;
	// CVector3d[ ] ControlPt;

	double *m_weight;
	// double[ ] weight;

	double *m_knot;
	// double[ ] knot;

	BOOL m_bLastCurve;
	// indicate last curve.

	CNurbsCurve *m_lpNextCurve;
	// point to next curve.

	BOOL m_bReciprocateMotion;
	// flag of reciprocating motion

	void Position( double u, CVector3d *lpPos );
	// get point position

	double Next_u( double u, double ds, double *remainder );
	// get the next position parameter u, return Remainder as surplus distance

	double Find_x_And_u( double y, double* u = NULL );
	// input y-axis value to get the correspond x-axis value and parameter u

	double Curvature( double u );
	// get Curvature

	double Radius( double u );
	// get Radius

	double SearchUofLargeCurvature( double u1, double u2 );
	// get u of max curvature in u1 and u2. if no knot in u1 to u2, return -1.
	// if 1 knot in u1 to u2, return u of knot
	// if more then 2 knot in u1 to u2, return u which is max curvture.

	double LengthOfCurve( void );
	// get length of curve approximate by Gauss-Legendre Integration

	double LengthOfCurve( double u1, double u2 );
	// get length of curve at [u1,u2) approximate by Gauss-Legendre Integration
	// input u1, u2 can be located in different span.

	BOOL SplitCurve( BOOL bIsBack, double CutLength, CNurbsCurve **lpCOut1, CNurbsCurve **lpCOut2, BOOL NormalizeKnot = TRUE );
	// split a NURBS curve to two Nurbs curves by CutLength.
	// if error, return TRUE
	// in this function, it will generate up to three temp curve, and keep two curve after function

	BOOL SplitCurve( double u, CNurbsCurve **lpCOut1, CNurbsCurve **lpCOut2, BOOL bNormalizeKnot = TRUE );
	// split a NURBS curve from u to two Nurbs curves.
	// if error, return TRUE
	// in this function, it will generate up to three temp curve, and keep two curve after function

	double CheckAngle( CNurbsCurve *lpPreCurve, CNurbsCurve *lpNextCurve );
	// return the angle ( in radian ) between two curve.

	BOOL IsG1Conti( CNurbsCurve *lpNextCurve, double *Angle );
	// return FALSE: G0 continuous, TRUE: G1 continuous.

	BOOL CombineCurve( CNurbsCurve **lpC1, CNurbsCurve **lpC2, CNurbsCurve **lpCOut );
	// combine two curves without modify shape and return one.
	// if error, return TRUE
	// in this function, it will generate two temp curve, and keep one curve after function

	static BOOL CopyCurve( CNurbsCurve *lpSrcCurve, CNurbsCurve **lpOutCurve );
	// copy a Nurbs curve to another.
	// if error, return TRUE

	void Release();
	// call nurbs curve pool to release this.

	void Print();
	// print curve data.

	void Print( char *fileName );
	// print curve data.

	void KPrint();
	// print curvature of curve.

	void KPrint( double u1, double u2 );
	// print curvature of curve in [u1,u2].

	BOOL GetCurvatureDerivatives( double u, double &k1, double &k2 );
	// compute first derivative of curvature (k1) and second derivative of curvature (k2), and return is error
	// if error, the k2 is unuseful, and the value of k1 only can be as reference.

	void CurvePtandDerivatives( double u, const int nDerOrder, CVector3d *lpDerC );
	// compute the curve point, first and second derivative value.

	BOOL ElevateCurveDegree( CNurbsCurve **lpCout, const int nElevateOrder );
	// elevate the order of NURBS curve
	// if error, return TRUE
	// in this function, it will generate two temp curve, and keep one curve after function

	BOOL InsertKnot( CNurbsCurve **lpCOut, double u, int &nTimes );
	// insert knot u by nTimes, return a curve.
	// if error, return TRUE
	// in this function, it will generate one temp curve, and keep one curve after function

	// ----------- Check the error between sample point and curve -----------

	BOOL CheckOverError( CTuple3d *lpSamplePoint, int nNumOfSp, double TolSquare, double *FootPtParameter = NULL );
	// Calculate the error square between sample points and this curve
	// FootPtParameter == NULL : return if over error happens( compared to tolerance )
	// FootPtParameter != NULL : return the foot point parameter for rotation axis curve fitting
	// Reference the function get_geometric_axis_over_error() in CNURBS.h.

	static BOOL DoMaxRemoveKnot( CNurbsCurve **lpCurve, CTuple3d *lpSp, int nNumOfSp, double Tolerance );
	// If the error between sample point and this lpCurve less than tolerance
	// remove knot as much as possible.

	void RemoveKnot( double knot, int &nTimes );
	// Remove knot 'nTimes' times
	// the shape of the curve will be changed
	// " needed to check error by other function "

private:

	int FindSpan( double u );
	// find the knot span index of u.

	int FindSpanMult( double u, int &nSpan );
	// find the knot span index of u, return the multiplicity.

	void BasisFuns( const int nSpan, double u, double lpN[] );
	// compute the nonvanish basis functions.

	void DersBasisFuns( const int nSpan, double u, const int nDerOrder, double lpDerN[][MAX_ORDER] );
	// compute the basis functions and its derivatives.

	BOOL ElevateToSameOrder( CNurbsCurve **lpC1, CNurbsCurve **lpC2 );
	// elevate the order (degree+1) up to same order in both curves.
	// if error, return TRUE

	BOOL SplitCurve( double u, BOOL bFormerCurve, CNurbsCurve **lpCOut );
	// Split a NURBS curve from u to one Nurbs curves.
	// if error, return TRUE

	void UpdateUsingPtNum( int nUsingPtNum, int nParam );
	// update the maximum using number of control points.

	double Interpolate_u( double u1, double u2, double ds, double *remainder, double tol );
	// interpolate u in (u1,u2) by linear interpolation.

	double Next_u( double u, double ds, double *remainder, double tol );
	// get the next position parameter u, return Remainder as surplus distance

	double Find_x_And_u( double y, double tol, double *u = NULL );
	// input y-axis value to get the correspond x-axis value and parameter u

	// ----------- the transform between Nurbs and Bezier -----------

	BOOL NurbsToBeziers( int &nNumOfPartition, CBezier **lpBeziers );
	// decompose this Nurbs into the direct sum of lpBeziers.
	// if error, return TRUE

	void WriteNurbsToBezier( CBezier *lpResult );
	// Write a Nurbs curve to Bezier form.

	BOOL ReduceDegree( int nReduceDeg, CBezier **lpBeziers, CNurbsCurve **lpResult );
	// Reduce Nurbs's deg from ( this->m_nOrder - 1 ) to ( m_nOrder - nReduceDeg ).
	// Remark: m_nOrder - nReduceDeg >= 4.
	// support DoMaxDegReduction.
	// if error, return TRUE

	BOOL IsControlPtsTingle( void );
	// whether the control point tingle.

	double LengthOfSpanCurve( double u1, double u2, int N, double *weight, double *Abscissa );
	// get length of within a span curve at [u1,u2) approximate by N-point Gauss-Legendre Integration
	// input u1, u2 must be located in the same span.

	double GetDotWithSample( double u, CTuple3d* point );
	// given u and compute V*P'.

	ECheckResult CheckDistance( double &a, double &b, double c, CTuple3d* point, double TolSquare,
								double *FootPtParameter, double &f, double &df );
	// given c in [a,b] and one sample point
	// check if distance between sample point and curve point less than tolerance.
	// update FootPtParameter and record f, df for next iteration.
	// return E_FALSE, E_CheckNextPt, if err is less than tolerance
};

#endif// !defined(AFX_NURBSCURVE_H__705F16AC_2175_403E_AC70_5E05C8A50E21__INCLUDED_)
