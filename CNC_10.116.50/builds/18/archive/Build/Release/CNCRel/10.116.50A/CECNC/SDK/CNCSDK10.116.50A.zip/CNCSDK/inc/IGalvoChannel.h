#if !defined(_IGALVOCHANNEL_H_INCLUDED_)
#define _IGALVOCHANNEL_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IGalvoChannel
{
public:
	virtual ~IGalvoChannel( void ) {}
	// destructor

	virtual void CNCAPI PutPositionCommand( long *pPulse ) = 0;
	// put position command, unit: count

	virtual long CNCAPI ReadRealPosition( void ) = 0;
	// read absolute counter

	virtual void CNCAPI SetServoOn( BOOL bOn ) = 0;
	// set servo ON/OFF

	virtual void CNCAPI PutFineDDACount( long nFineDDACount ) = 0;
	// put fine DDA count

	virtual void CNCAPI SetGalvoServoOn( BOOL bOn ) = 0;
	// set galvo module servo ON/OFF

	virtual BOOL CNCAPI GetGalvoServoState( void ) = 0;
	// get galvo module servo ON/OFF state

	virtual BOOL CNCAPI GalvoHomeSetting( void ) = 0;
	// clear galvo module absolute count, not clear yet when return FALSE

	virtual int CNCAPI GalvoParamPutValue( int nNo, long nValue ) = 0;
	// put galvo module parameter

	virtual int CNCAPI GalvoParamGetValue( int nNo, long &nValue ) = 0;
	// get galvo module parameter

	virtual void CNCAPI GetNotchFilterData( int nFilterID, void *pFilterData ) = 0;
	// get notch filter data

	virtual void CNCAPI SetNotchFilterData( int nFilterID, void *pFilterData ) = 0;
	// set notch filter data
};

#endif // _IGALVOCHANNEL_H_INCLUDED_
