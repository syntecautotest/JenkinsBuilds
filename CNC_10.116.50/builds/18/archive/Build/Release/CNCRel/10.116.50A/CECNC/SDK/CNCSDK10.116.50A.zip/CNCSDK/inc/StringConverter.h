// StringConverter.h: interface for the CStringConverter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_STRINGCONVERTER_H_)
#define _STRINGCONVERTER_H_

class CStringConverter
{
public:
	static long tstol( const TCHAR* tstring );
	// tstring to long

	static long tstol_hex( const TCHAR* tstring );
	// hex tstring to long

	static long stol( const char *string );
	// string to long

	static long stol_hex( const char *string );
	// hex string to long

	static void toLower( char* string );
	// convert string to lower case

	static void toUpper( char* string );
	// convert string to upper case
};

#endif // !defined(_STRINGCONVERTER_H_)
