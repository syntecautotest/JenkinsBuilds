
#if !defined(OPENCNCDEF_H_)
#define OPENCNCDEF_H_

#include "nstdlib.h"
#include "CommonStruct.h"

#define SIZE_CoordStore					8
#define SIZE_AxisStore					32
#define SIZE_SpindleStore				8
#define SIZE_ServoStore					32
#define SIZE_ServoSubStore				11
#define SIZE_MpgWheelStore				8
#define SIZE_AxisExchanger				4
#define ID_AuxCoord						5

#define NUMOF_DEVELOPERPARAMETER		100
#define NUMOF_THIRDPARTYPARAMETER		500
#define NUMOF_REFERENCESIZE				40
#define SIZE_MSTChannelTable			5
#define NUMOF_GLOBALVAR					400

#define	MAX_AxisID						32
#define MAX_CoordAxisID					NUMOF_AXIS

#define NUMOF_SIMUAXIS			6
#define NUMOF_SPINDLE			6		// the number of spindle
#define NUMOF_AxisGroup			4		// this is max axis group number of mode group 
#define NUMOF_StrokeLimit		3
#define NUMOF_StrokeType		3

#define MAX_NumOfLineCompensateNode	5
#define MAX_NumOfLineTable			5

#define FILTER_ORDER_TappingLearning		5

#define NUMOF_SerialDrvIO		2

// bound constant
#define MAX_MotReqPktArgs		3

// rapid traverse F0 override
#define RTF0OVERRIDE			9999

// data structure for reference point table
#ifndef TREFERENCEPOINT_STRUCT_
#define TREFERENCEPOINT_STRUCT_

typedef struct {
	double	Axis[NUMOF_AXIS];		// unit: mm or inch
} TReferencePoint;

#endif // TREFERENCEPOINT_STRUCT_

struct TWorkPlaneInfo
{
	int		XAxis;
	// arc displacement vector horzontal axis index

	int		YAxis;
	// arc displacement vector vertical axis index

	int		ZAxis;
	// arc displacement vector normal axis index

	int		IAxis;
	// arc center vector horzontal axis index

	int		JAxis;
	// arc cenetr vector vertical axis index

	int		KAxis;
	// arc center vector normal axis index

};

#ifndef EOCVARIANTTYPE_ENUM_
#define EOCVARIANTTYPE_ENUM_

enum EOcVariantType {
	OCVT_VACANT,
	OCVT_LONG,
	OCVT_DOUBLE,
	OCVT_STRING
};

#endif // EOCVARIANTTYPE_ENUM_

#ifndef TOCVARIANT_STRUCT_
#define TOCVARIANT_STRUCT_

typedef struct tagTOcVariant {
	short		m_type;
	union {
		long	m_long;
		double	m_double;
	};
} TOcVariant;

#endif // TOCVARIANT_STRUCT_

#ifndef TSENSORTYPE_ENUM_
#define TSENSORTYPE_ENUM_
enum EEncoderType {
	SENSORTYPE_IncEncoder,
	SENSORTYPE_Ruler,
	SENSORTYPE_Null,
	SENSORTYPE_AbsoluteEncoder
};
#endif // TSENSORTYPE_ENUM_

#ifndef TSERVOCOMMANDT_TYPEDEF_
#define TSERVOCOMMANDT_TYPEDEF_

typedef enum EServoCommandType {
	SCT_Position,
	SCT_Velocity,
} ESCType;

typedef struct tagServoCommand {
	long	nChannelID;
	long	nSubChannelID;
	ESCType	Type;
	union {
		double	PCommand;
		double	VCommand;
	};
} TServoCommand;

#endif // TSERVOCOMMANDT_TYPEDEF_

#define BASEADDR_NonvolatileEncCounter		(10500L)
#define BASEADDR_NewNonvolatileEncCounter	(10600L)
#define BASEADDR_OverflowLapCounter			(10660L)

// debug mode switch
#define DBG_MODE_TappingLearning	0
#define DBG_MODE_FastTappingLearning	0

#endif // OPENCNCDEF_H_

#ifndef TCSCHANGETYPE_ENUM_
#define TCSCHANGETYPE_ENUM_
enum ECSChangeEventID{

	CSEVT_Default,

	CSEVT_WorkpieceOffsetChangedByMacroVariable,
	// change by program: macro
	// workpiece zero offset data

	CSEVT_WorkpieceOffsetChangedByHMI,
	// change by human machine interface
	// workpiece zero offset data

	CSEVT_ExternWorkpieceOffsetChangedByMacroVariable,
	// change by program: macro....
	// extern workpiece

	CSEVT_ExternWorkpieceOffsetChangedByHMI,
	// change by human machine interface
	// extern workpiece

	CSEVT_SyncHaltPtToHCSByPLC,
	// notify synchronize halt point offset to hand coordinate system by PLC
};
#endif // TCSCHANGETYPE_ENUM_

#ifndef TTAPPING_EERRORNUM_
#define TTAPPING_EERRORNUM_
enum ETappingError {
	ETE_NoError,
	ETE_TappingError,
	ETE_TappingLearningError,
	ETE_OverStrokeLimit,
	ETE_PolySolverError
};
#endif
