// ValidityProtect.h: interface for the Validity Protect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VALIDITYPROTECT_H__C953ACE1_04F0_4115_9444_E3460F4EAC56__INCLUDED_)
#define AFX_VALIDITYPROTECT_H__C953ACE1_04F0_4115_9444_E3460F4EAC56__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VALIDITY_CountDownDays		7

class CPasswordBitsFunc;
class CDESObj;

class CValidityProtect
{
public:
	CValidityProtect();
	// constructs a CValidityProtect class

	virtual ~CValidityProtect();
	// destructs this object

	void recordSystemTime(void);
	// record current time

	int getStatus(void);
	// query current status, in normal or in protect
	// use for if MMI lock the screen

	virtual void getPassSeed(char *UseSeed, int StrSize);   
	// 4chars or Mac Encode

	unsigned long getStartTime(void);  
	// system can use date start date relative to year 1900

	unsigned long getTimeSet(void);  
	// system use time set, in hour

	long getTimeRemain(void);  
	// system can use time remain, in hour

	void putInnerKey(char *InnerKey);  
	// put inner key, use to change password encrypt key

	void generate_8Char_RandomNo(char *CheckNo);
	// generate 8 char for pass generated seed

	BOOL macAddrMatch(long *MacData);	
	// compare Mac Store and real mac address

	// use time deadline type
	enum EDeadTimeStatus {
		DT_NoTimeLimit = 0,
		DT_ModifyTime = 2,
		DT_TimeOut = 3,
		DT_CountDown = 4,
		DT_InTimeLimit = 100
	};

protected:	
	void getMacAddress( UCHAR *buffer );
	// put value into fram

	unsigned long relativeHoursTo1900(void);
	// calculate relative time => hours

	void recordStartDate(void);
	// bit 0 ~ 15: yday, 16 ~ 20: day, 21 ~ 24: month, 25 ~ 31: year
	// translate date to long, and write to assign Registry No

	void getSystemMacAddr(void);
	// read Mac address and translate to two long

	BOOL isCurrentTimeBeforeStartTime(void);
	// check if current before record start time
  
	int IsDeadLine(void);
	// check current system status

	int CalculateYDays(int Years, int Months, int Days);
	// calculate how many days from 1/1, use for CE 

protected:
	// use to Encode/Decode password 
	unsigned char m_InKey[8];

	int m_UseTimeStatus;
	// current Use Time Status
	// 0: system initial, need protected
	// 1: compactable with old system, so not use, not define 
	// 2: system in use time period, no protected
	// 3: protected enable , need protected
	// 4: in count down status

	unsigned long *m_DeadLine;
	// record Deadline time 

	unsigned long *m_CurrentTime;
	// record current time 

	unsigned long *m_StartTime;
	// record start time 

	unsigned long *m_TimeModify;
	// record if time modify 

	unsigned long *m_PassSeed;
	// record password seed 

	unsigned long *m_MacData;
	// record Mac address 

	unsigned long *m_MacInvalidStart;
	// record Mac not match time start

	unsigned long *m_MacInvalidSet;
	// record Mac not match deadline time 

	unsigned char m_Random_key[10];
	// use 4 digit seed repeat to 8 digit

	unsigned long m_MacMainBoard[2];
	// record system mac address in 2 long type

	long m_TimRemain;
	// system can use time 

	BOOL m_InvalidUpgrade;
	// if downgrade ver, and clear usetime

	CDESObj *m_pDesObj;
	// DES helper object

	CPasswordBitsFunc *m_pBitsFunc;
	// Text password helper object
};


#endif // !defined(AFX_VALIDITYPROTECT_H__C953ACE1_04F0_4115_9444_E3460F4EAC56__INCLUDED_)

