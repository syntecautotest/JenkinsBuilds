#if !defined(_IOBJFCNEVAL_H____INCLUDED_)
#define _IOBJFCNEVAL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CommonStruct.h"

// For gradient calculation
#define INC_STEP 1e-4

class IObjFcnEvaluator
{
public:
	virtual ~IObjFcnEvaluator( void ) {};
	// destructor

	virtual void SetConstDef( TMotOptConst *pConst ) = 0;
	// set constant for unit conversion

	virtual double GetFcnValue( TMotOptParam *pPrm ) = 0;
	// calculate function value according to current parameters

protected:
	int m_nNumOfParam;
	// number of parameters

};

#endif // !defined(_IOBJFCNEVAL_H____INCLUDED_)
