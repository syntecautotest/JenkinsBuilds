// TrajectoryDef.h: interface for the CTrajectoryDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRAJECTORYDEF_H__0EB25243_16B0_11D3_B6E7_000000000000__INCLUDED_)
#define AFX_TRAJECTORYDEF_H__0EB25243_16B0_11D3_B6E7_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTrajectoryDef  
{
public:
	static const double EPSILON_Displacement;
	// epsilon displacement in BLU

	static const double MAX_MoveTime;
	// maximum move time, in micro-second
};

#endif // !defined(AFX_TRAJECTORYDEF_H__0EB25243_16B0_11D3_B6E7_000000000000__INCLUDED_)
