#if !defined(_ILATCHIOCHANNEL_H_INCLUDED_)
#define _ILATCHIOCHANNEL_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_LatchIOChannel		5

#define UNDEFINE_IBIT	-1

class ILatchIOChannel
{
public:
	virtual BOOL CNCAPI isPositiveEdge( void ) = 0;
	// query I-bit positive edge status

	virtual BOOL CNCAPI isNegativeEdge( void ) = 0;
	// query I-bit negative edge status

	virtual double CNCAPI getPosEdgeTimeRatio( void ) = 0;
	// get I-bit positive edge time ratio, unit: percentage between two interrupt

	virtual double CNCAPI getNegEdgeTimeRatio( void ) = 0;
	// get I-bit negative edge time ratio, unit: percentage between two interrupt

	virtual LONG CNCAPI getPosEdgeAbsCounter( void ) = 0;
	// get I-bit positive edge absolute counter

	virtual LONG CNCAPI getNegEdgeAbsCounter( void ) = 0;
	// get I-bit negative edge absolute counter

	virtual BOOL CNCAPI isSupportAbsCounter( void ) = 0;
	// query whether it is support absolute counter
};

#endif // !defined(_ILATCHIOCHANNEL_H_INCLUDED_)
