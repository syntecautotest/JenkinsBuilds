// ISriManager.h: interface of the ISriManager class.
//
//////////////////////////////////////////////////////////////////////

#include "commonstruct.h"

#if !defined(_ISRIMANAGER_H____INCLUDED_)
#define _ISRIMANAGER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SUBEV_UpdateFirmwareProgress		1
#define SUBEV_UpdateFirmwareFinish			2
#define SUBEV_UpdateFirmwareError			3
#define SUBEV_QueryModuleInfoFinish			4

class ISriManager
{
public:
	virtual ~ISriManager( void ) {}
	// destructor

	virtual BOOL ReadCommConfig( int nPort, BOOL &bEnabled, LONG &ProtocolType, LONG &Baudrate, LONG &CtrlMode, LONG &ScanTime, LONG &Timeout ) = 0;
	// read communication config

	virtual BOOL WriteCommConfig( int nPort, BOOL bEnabled, LONG ProtocolType, LONG Baudrate, LONG CtrlMode, LONG ScanTime, LONG Timeout ) = 0;
	// write communication config

	virtual BOOL ReadStationInfo( int nPort, int nStation, TStationInfo &OldInfo, TStationInfo &NewInfo ) = 0;
	// read station information

	virtual BOOL WriteStationInfo( int nPort, int nStation, TStationInfo StationInfo ) = 0;
	// read station information

	virtual BOOL SaveStationInfo( int &nRepeatedRbit ) = 0;
	// save station information

	virtual BOOL ReadStationState( int nPort, int nStationID, TStationState &StationState ) = 0;
	// read station state

	virtual BOOL ReadCommDbState( int nPort, BOOL &bRunning, LONG &RealScanTime ) = 0;
	// read comm port debug state

	virtual BOOL ReadStationDbState( int nPort, int nStationID, TStationDbState &StationDbState ) = 0;
	// read station debug state

	virtual void QueryModuleInfo( void ) = 0;
	// query module information

	virtual void UpdateFirmware( int nPort, int nStationID, BOOL bSelectSlot[], TCHAR FileName[] ) = 0;
	// update firmware

	virtual void UpdateFirmwareProgress( int &nPercent, int &nState ) = 0;
	// query the state during update firmware process

	virtual void add_OnCncEvent( IOnCncEvent *lpListener ) = 0;
	// to add cnc event listener

	virtual void remove_OnCncEvent( IOnCncEvent *lpListener ) = 0;
	// to remove cnc event listener

	virtual void SetSRICommNum( int nNum ) = 0;
	// to set SRI supported communication number
};
#endif //(_ISRIMANAGER_H____INCLUDED_)