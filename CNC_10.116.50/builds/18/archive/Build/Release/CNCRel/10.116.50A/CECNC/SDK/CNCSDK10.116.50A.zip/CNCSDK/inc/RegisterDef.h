#if !defined(_RegisterDef_INCLUDE_)
#define _RegisterDef_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// SYNTEC user-defined register
// NOTE : first and second region can be used as bit value
#define Reg_First_Min						50
#define Reg_First_Max						80
#define Reg_Second_Min						256
#define Reg_Second_Max						511
#define Reg_Third_Min						1033
#define Reg_Third_Max						2049
#define Reg_Fourth_Min						2091
#define Reg_Fourth_Max						2099
#define Reg_Fifth_Min						3101
#define Reg_Fifth_Max						4095
#define Reg_Sixth_Min						6000
#define Reg_Sixth_Max						7999
#define Reg_Seventh_Min						20000
#define Reg_Seventh_Max						65535

#endif // _RegisterDef_INCLUDE_