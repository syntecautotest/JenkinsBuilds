#if !defined(_CORNERERROR_H____INCLUDED_)
#define _CORNERERROR_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCornerError : public IObjFcnEvaluator
{
public:
	CCornerError( int NumParam );
	// constructor

	virtual ~CCornerError( void );
	// destructor

	void SetConstDef( TMotOptConst *pConst );
	// set constant for unit conversion

	double GetFcnValue( TMotOptParam *pPrm );
	// calculate function value according to given parameters

	void SetServoModel( void );
	// set model of servo motor and re-evaluate error value

private:
	TMotOptConst m_Const;
	// constants for calculation
};

#endif // !defined(_CORNERERROR_H____INCLUDED_)
