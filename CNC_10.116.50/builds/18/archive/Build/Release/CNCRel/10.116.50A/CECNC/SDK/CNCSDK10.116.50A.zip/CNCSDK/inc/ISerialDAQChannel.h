#if !defined(AFX_ISERIALDAQCHANNEL_H__794FACE3_1EB0_4f75_941E_61469F02BB6B__INCLUDED_)
#define AFX_ISERIALDAQCHANNEL_H__794FACE3_1EB0_4f75_941E_61469F02BB6B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISerialDAQChannel
{
public:
	virtual BOOL CNCAPI IsSupportDAQChannel( void ) = 0;
	// whether DAQ channel is supported

	virtual LONG CNCAPI GetSampleFrequency( void ) = 0;
	// get sampling frequency, unit: Hz

	virtual void CNCAPI GetSamplePeriod( LONG &nMinPeriod, LONG &nActivePeriod ) = 0;
	// get sampling period, unit: 0.01 us

	virtual void CNCAPI SetSampleDivider( LONG nDivider ) = 0;
	// set sampling divider

	virtual void CNCAPI PutDAQChSetting( int nDAQCh, BOOL bEnable, int nCh, int nSubCh, EDAQ_SELECT_TYPE nSelectType, LONG nMapIndex, EDAQ_Data_Type nDataType ) = 0;
	// put DAQ channel setting

	virtual void CNCAPI GetDAQChSetting( int nDAQCh, BOOL &bEnable, LONG &nMapIndex, EDAQ_Data_Type &nDataType ) = 0;
	// get DAQ channel setting

	virtual void CNCAPI EnableDAQChannel( int nDAQCh, BOOL bEnable ) = 0;
	// enable DAQ channel to stand by

	virtual BOOL CNCAPI EnableSampleData( BOOL bEnable ) = 0;
	// enable sample data

	virtual void CNCAPI EnableAuxiliarySignal( int nSubCh, BOOL bEnable, EAUX_SIGNAL_TYPE nType ) = 0;
	// enable auxiliary signal

	virtual LONG CNCAPI GetNumDAQChannel( void ) = 0;
	// get number of scope data acquisition channel
};

#endif // !defined(AFX_ISERIALDAQCHANNEL_H__794FACE3_1EB0_4f75_941E_61469F02BB6B__INCLUDED_)
