#if !defined(AFX_LASERCTRLDEF_H__INCLUDED_)
#define AFX_LASERCTRLDEF_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// laser version definition
#define NONPLAYMODE_SIGNATURE			( 0x29000001 )
#define PLAYMODE_SIGNATURE				( 0x50000001 )
#define PLAYMODE_DOCORRECTION			( 0x50000002 )
#define PLAYMODE_VARYING_ENG_NODE		( 0x50000003 )
#define PLAYMODE_NCFILE_CMD_ID			( 0x60000001 )

#define LASER_VERSION					( PLAYMODE_NCFILE_CMD_ID )

#define NCFILE_SIGNATURE_LOWER_B		( 0x60000000 )
#define NCFILE_SIGNATURE_UPPER_B		( 0x70000000 )

// alarm for each axis (include geom-axis and laser-axis)
#define ALMID_LASER_StrokeLimit			( 1 )
#define ALMID_LASER_LossAbsPosition		( 2 )
#define ALMID_LASER_ChannelIDErr		( 3 )
#define ALMID_LASER_OpenFileFailure		( 5 )

// alarm for laser control
#define ALMID_LASER_SyncError			( 21 )
#define ALMID_LASER_OutOfRange			( 22 )
#define ALMID_LASER_DCT_WrongFormat		( 24 )
#define ALMID_LASER_NC_WrongContent		( 26 )

#define LASER_Debug						( 0 )
#define LASER_VirtCoordID				( 1 )
#define NUM_GEO_AXIS					( 3 )
#define mm_to_BLU						( 1000.0 )
#define BLU_to_mm						( 0.001 )
#define MAX_EnergyScale					( 255 )
#define MAX_EnergyCount					( 256 )
#define MAX_FineDDACount				( 256 )
#define MIN_FineDDACount				( 1 )
#define MAX_GALVO_CMD					( 32767 )
#define MIN_GALVO_CMD					( -32768 )

#define ALM_IDX_Main					( 0 )
#define ALM_IDX_GEOM_AXIS				( 1 )
#define ALM_IDX_LASER_AXIS				( 4 )
#define ALM_IDX_CONVEYOR				( 5 )
#define MAX_ALM_COUNT					( 7 )

// define for default motion parameter
#define LASER_DefVelocity				( 3.3e-3 )		// IU / us, feedrate = 200000 mm/min
#define LASER_DefAcc					( 3.3e-7 )		// IU / us ^ 2, acc to feedrate time = 10 ms
#define LASER_DefJerk					( 9.8e-13 )		// IU / us ^ 3, jerk to 1G time = 10 ms
#define LASER_DefTA						( 10000 )		// us
#define LASER_DefTS						( 10000 )		// us
#define LASER_DefChordErrorTol			( 0.1 )			// mm
#define LASER_DefArcRefRadius			( 5.0 )			// mm

#define LASER_FILENAME_LEN_LONG			( 32 )
#define LASER_FILENAME_LEN_CHAR			( LASER_FILENAME_LEN_LONG * sizeof( long ) )

// for distorsion table
#define MAX_ROWCOL						( 65 )
#define MAX_LAYERCOUNT					( 5 )
#define DIM_2D							( 2 )
#define DIM_3D							( 3 )
#define MAX_POS_2D						( 4 )		// start (Xs,Ys) end (Xe,Ye)
#define MAX_ZANGLE						( 2 )		// Z angle of Z axis of galvo module
#define MAX_ANGLE_2D					( MAX_ROWCOL * MAX_ROWCOL * DIM_2D )		// MAX_ROWCOL * MAX_ROWCOL * DIM_2D

// distortion table
typedef struct {
	long nDim;
	long nCount[ DIM_3D ];
	long nReserved[ 3 ];
	long nScale[ MAX_LAYERCOUNT * 2 ];
	long nOffset[ MAX_LAYERCOUNT * 2 ];
	long nPosArray[ MAX_POS_2D ];
	long nZPos[ MAX_LAYERCOUNT ];
	long nAngleArray[ MAX_ANGLE_2D ];
	long nZAngle[ MAX_ZANGLE ];
} TDistortionTable;

typedef struct {
	long nLgthAdj_Value_X[ 16 ];
	long nLgthAdj_Value_Y[ 16 ];
	long nScaleX[ MAX_LAYERCOUNT ];
	long nScaleY[ MAX_LAYERCOUNT ];
	long nOffsetX[ MAX_LAYERCOUNT ];
	long nOffsetY[ MAX_LAYERCOUNT ];
	long nZPos[ MAX_LAYERCOUNT ];
	long nBarrelFactor[ DIM_2D * 2 ];
	long nZAngle[ MAX_ZANGLE ];
	long nFocalLength;
	long nPosRange;
	long nMode;
	long nGridCnt;
	long nLgthAdjCnt;
	long nZCount;
} TDCTCommonParam;

typedef struct {
	long nGeomParam[ DIM_2D * 2 ];
	long nRotateInfo[ 3 ];
} TDCTGeomAdjParam;

// distortion table param
typedef struct {
	TDCTCommonParam ComParam;
	TDCTGeomAdjParam GeomAdjParam;	
	long nAngleArray[ MAX_ANGLE_2D ];
} TDCTParam;

// eneygy file header
typedef struct {
	long nSignature;
	unsigned long nNumOfRecord;
	char reserved[24];
} TEnergyHeader;

typedef struct {
	long nIntData[ NUM_GEO_AXIS ]; // position: x, y, z, unit: um
	long nIntCnt; // total count in this node
	long nEngCnt; // energy count in this node
} TIntEngNode;

#define SIZEOF_TIntEngNode				( 20 )
#define MAX_LASER_NODE_ARRAY_LENGTH		( 4096 )
#define SIZE_BufferForPos				( MAX_LASER_NODE_ARRAY_LENGTH * 10 )
#define MAX_LASER_CMD_SIZE				( 256 )

#define LASER_XY2_CMD_PERIOD			( 10 ) // unit: us

#endif // !defined(AFX_LASERCTRLDEF_H__INCLUDED_)
