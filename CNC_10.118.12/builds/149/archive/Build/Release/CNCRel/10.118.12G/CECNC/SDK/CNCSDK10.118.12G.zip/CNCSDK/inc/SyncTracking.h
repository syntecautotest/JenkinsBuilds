#if !defined(_SYNCTRACKING_H____INCLUDED_)
#define _SYNCTRACKING_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SyncTraking_Debug_Mode		0

class CInterpolator;
class CTrajectorySyncTracking;

class CSyncTracking
{
public:
	CSyncTracking( void );
	// constructor

	~CSyncTracking( void );
	// destructor

public:
	double GetDisplacement( double elapse );
	// get displacement

	BOOL IssueSyncTrackData( TBlockData data );
	// issue rapid travel node

	void Reset( void );
	// reset

	void Abort( void );
	// abort

private:
	void WriteToInterpolator( TPVTSheet &sheet, CInterpolator *pInterpolator );
	// write to interpolator

#if SyncTraking_Debug_Mode
	void testPlanBlock_SyncTracking( void );
	// test the function: planBlock_SyncTracking
#endif

public:
	void putMaxAxisFeedrate( const double AxFmax );
	// put maximum axis feedrate in IU / us

	void putMaxAxisAcc( const double AxAmax );
	// put maximum axis acceleration in IU / us ^ 2

	void putMaxAxisJerk( const double AxJmax );
	// put maximum axis jerk in IU / us ^ 3

private:
	double m_AxFmax;
	// maximum slave axis feedrate in ratio

	double m_AxAmax;
	// maximum slave axis acceleration in ratio

	double m_AxJmax;
	// maximum slave axis jerk in ratio

	CInterpolator *m_pInterpolator;
	// Interpolator

	CTrajectorySyncTracking *m_pTrajSyncTracking;
	// trajectory normal

	CRTMutex m_cs;
};
#endif // !defined(_SYNCTRACKING_H____INCLUDED_)
