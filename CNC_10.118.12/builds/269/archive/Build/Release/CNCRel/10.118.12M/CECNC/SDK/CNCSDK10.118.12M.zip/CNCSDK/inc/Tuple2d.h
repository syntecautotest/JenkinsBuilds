// Tuple2d.h: interface for the CTuple2d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TUPLE2D_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_)
#define AFX_TUPLE2D_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class UTILAPI CTuple2d  
{
public:
	CTuple2d();
	// Constructs and initializes a Tuple2d to (0,0).

	CTuple2d( double x, double y );
	// Constructs and initializes a Tuple2d from the specified
	// xy coordinates.

	virtual ~CTuple2d();
	// destructor

	void add( CTuple2d &t );
	// Sets the value of this tuple to the vector sum of itself
	// and tuple t.

	void add( CTuple2d &t1, CTuple2d &t2 );
	// Sets the value of this tuple to the vector sum of tuples
	// t1 and t2.

	void sub( CTuple2d &t );
	// Sets the value of this tuple to the vector difference of
	// itself and tuple t (this = this - t).

	void sub( CTuple2d &t1, CTuple2d &t2 );
	// Sets the value of this tuple to the vector difference of
	// tuple t1 and t2 (this = t1 - t2).

	void negate( void );
	// Negates the value of this vector in place.

	void negate( CTuple2d &t );
	// Sets the value of this tuple to the negation of tuple t.

	void scale( double s );
	// Sets the value of this tuple to the scalar multiplication
	// of itself.

	void scale( double s, CTuple2d &t );
	// Sets the value of this tuple to the scalar multiplication
	// of tuple t.

	void scaleAdd( double s, CTuple2d &t );
	// Sets the value of this tuple to the scalar multiplication
	// of itself and then adds tuple t (this = s*this + t).

	void scaleAdd( double s, CTuple2d &t1, CTuple2d &t2 );
	// Sets the value of this tuple to the scalar multiplication of
	// tuple t1 and then adds tuple t2 (this = s*t1 + t2).

	void set( CTuple2d &t );
	// Sets the value of this tuple to the specified tuple t.

	void set( double x, double y );
	// Sets the value of this tuple to the specified xy coordinates.

	// public data member
	double m_x;
	double m_y;
};

#endif // !defined(AFX_TUPLE2D_H__94FC73EC_8DCA_478F_9540_D7B41C7DBDD0__INCLUDED_)
