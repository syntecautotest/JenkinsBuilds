// LinkedListPool.h: interface for the CGeomAxis class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINKEDLISTPOOL_H__INCLUDED_)
#define AFX_LINKEDLISTPOOL_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct TLinkedListNode {
	void *pData;
	TLinkedListNode *pNext;
};

class CLinkedListPool
{
public:
	CLinkedListPool( int nSize, int nCount );
	// contructor, nSize: bytes of data structure; nCount: number of data

	~CLinkedListPool( void );
	// destructor

public:
	void init( void );
	// initialize

	TLinkedListNode *insertFirst( void *pData );
	// insert data to first node (head)

	TLinkedListNode *insertLast( void *pData );
	// insert data to last node (tail)

	TLinkedListNode *removeFirst( void );
	// remove first node (head) and return it

	TLinkedListNode *removeLast( void );
	// remove last node (tail) and return it

	BOOL remove( TLinkedListNode *pNode );
	// remove a node

	TLinkedListNode *insert( TLinkedListNode *pNode, void *pData );
	// insert a node data after the node and return it

	TLinkedListNode *peek( INT nIndex );
	// peek according to nIndex
	// nIndex = 0 : Current Node
	// nIndex > 0 : Next nIndex Node

	BOOL isEmpty( void );
	// query whether it is empty

	BOOL isFull( void );
	// query whether it is full

	INT getDataCount( void );
	// get date node count

	int getFreeCount( void );
	// get free node count

private:
	TLinkedListNode *m_pNode;
	// linked list

	void **m_pData;
	// data

	int m_nMaxCount;
	// max data count

	int m_nFreeCount;
	// free count

	int m_nSize;
	// size

	TLinkedListNode *m_pFree;
	TLinkedListNode *m_pHead;
	TLinkedListNode *m_pTail;
	// linked list node
};
#endif // !defined(AFX_GEOMAXIS_H__INCLUDED_)
