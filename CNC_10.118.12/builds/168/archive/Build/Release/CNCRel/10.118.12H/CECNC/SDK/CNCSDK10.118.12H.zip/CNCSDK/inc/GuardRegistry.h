// GuardRegistry.h: interface for the CGuardRegistry class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GUARDREGISTRY_H__0FFFAEF9_17D4_42ce_9A19_92CFAAAA2533__INCLUDED_)
#define AFX_GUARDREGISTRY_H__0FFFAEF9_17D4_42ce_9A19_92CFAAAA2533__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGuardStore;

class CGuardRegistry
{
public:
	enum EGuardLevel {
		GL_SingleCopy,
		GL_Lastknown,
		GL_Mirror,
		GL_MirrorLastknown
	};
	// constants for guard level

	enum EDataIntegrity {
		DI_NONE = 0,
		DI_NEW,
		DI_LASTKNOWN,
		DI_UPTODATE
	};
	// Data intergrity constants

	enum EMaxBounds {
		LEN_StorageName = 256
	};
	// bound constant

public:
	CGuardRegistry( int GuardLevel = GL_Lastknown );
	// constructor

	virtual ~CGuardRegistry();
	// destructor

	void setGuardLevel( int GuardLevel );
	// set guard level

	BOOL open( CHAR *root, CHAR *path, CHAR *function, CHAR *name, UINT NumOfRecord, INT fMirror );
	// open persistent storage
	// return TRUE when successful, return FALSE when failure

	void putValue( long no, long value );
	// put value into registry

	long getValue( long no );
	// get value from registry

	void putString( long no, char *str, int nSize );
	// put string into registry

	void getString( long no, char *str, int nSize );
	// get string from registry

	BOOL commit( void );
	// commit data into persistent storage

	int ImportFrom( char *lpLocation );
	// import data into registry from specified location
	// return TRUE when successful, return FALSE when failure.

	int ExportTo( char *lpLocation );
	// export data from registry to specified location
	// return TRUE when successful, return FALSE when failure.

	int getVersion(void);
	// get registry format version

	int getDataIntegrity( void );
	// get data integrity of current loaded data

	unsigned long getWriteCount( void );
	// get commit counter( write count )

	void getModifiedTime( SYSTEMTIME *t );
	// get modification time

	long getCommitFailContinuous( void );
	// get max fail continuous count of each connection

	long getCommitAccFailCounter( void );
	// get sum of  fail count of each connection

private:
	CGuardStore *m_pGuardStore;
	// helper object

	int m_GuardLevel;
	// the guard level

	int m_DataIntegrity;
	// the data integrity

	char m_lpStorage[ LEN_StorageName ];
	// opened storage name

	void makeBackupFilename( char *dest, char *root, char *function, char *name, char *ext );
	// change backup filename

	void makeLocationPath( char *path_buffer, char *lpLocation );
	// make path name for location path
};

#endif // !defined(AFX_GUARDREGISTRY_H__0FFFAEF9_17D4_42ce_9A19_92CFAAAA2533__INCLUDED_)
