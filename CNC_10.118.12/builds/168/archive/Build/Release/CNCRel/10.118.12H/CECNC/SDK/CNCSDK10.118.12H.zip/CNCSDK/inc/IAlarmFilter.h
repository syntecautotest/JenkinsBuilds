// IAlarmFilter.h: interface for the IAlarmFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IALARMFILTER_H__3CD02104_A957_4236_A609_2F45E1D3A53E__INCLUDED_)
#define AFX_IALARMFILTER_H__3CD02104_A957_4236_A609_2F45E1D3A53E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class IAlarmFilter  
{
public:
	virtual ~IAlarmFilter( void ) {}
	// destructor

	virtual void CNCAPI registryAlarm( int ClassID, int ObjectID, int AlarmID, char *pHintText ) = 0;
	// register alarm

	virtual void CNCAPI unregisterAlarm( int ClassID, int ObjectID, int AlarmID ) = 0;
	// unregister alarm
};

#endif // !defined(AFX_IALARMFILTER_H__3CD02104_A957_4236_A609_2F45E1D3A53E__INCLUDED_)
