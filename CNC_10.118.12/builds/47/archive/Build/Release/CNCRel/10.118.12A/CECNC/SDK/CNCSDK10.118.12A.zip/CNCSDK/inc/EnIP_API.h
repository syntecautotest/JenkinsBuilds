// The EtherNet/IP API Declaration
#pragma once

#if defined( _ENIPAPI_DLLEXPORT ) // Build DLL
	#define ENIPAPI __declspec( dllexport )
#else // Use DLL
	#define ENIPAPI __declspec( dllimport )
#endif // _ENIPAPI_DLLEXPORT


typedef unsigned long long	ENIP_HANDLE;

#define ENIP_ERROR_HANDLE ( ( ENIP_HANDLE )0 )


enum EEnIPRecvState {
	EERS_SUCCESS,			// Recv Success
	EERS_WAITDATA,			// Wait Response Data
	EERS_TIMEOUT,			// Recv Time Out

	//== User Level Error
	EERS_OPERATE_ERROR,		// Operation Error

	//== Communication Level Error
	EERS_ENCAPMSG_ERROR,	// Encapsulation Message Error

	//== System Levle Error
	EERS_INTERNET_ERROR,	// Internet Error
};


#pragma pack( push, 1 ) // 1-byte Alignment

struct TEnIPSockAddr {
	SHORT sin_family;
	USHORT sin_port;
	DWORD sin_addr;
	BYTE sin_zero[ 8 ];
};

struct TEnIPRevision {
	BYTE nMajor;
	BYTE nMinor;
};

struct TEnIPDevInfo {
	WORD nProtocolVersion;
	TEnIPSockAddr SockAddr;
	WORD nVendorID;
	WORD nDeviceType;
	WORD nProductCode;
	TEnIPRevision Revision;
	WORD nStatus;
	DWORD nSerialNumber;
	CHAR szProductName[ 33 ];
	BYTE nState;
};

struct TEnIPRspInfo {
	BYTE nService;					// Response service code is let the highest bit of request service code as 1 (same as plus 0x80)
	BYTE nPaddingByte;				// Reserved
	BYTE nGeneralSatus;				// Response Satus
	BYTE nAdditionStatusSize;		// Additional Status Size (unit: WORD)
	const BYTE *pAdditionStatus;	// Addition Status
	INT nRspDataLength;				// Response Data Length (unit: BYTE)
	const BYTE *pRspData;			// Response Data
};

#pragma pack( pop )


extern "C" {

// List of device info from EnIP broadcast
struct ENIPAPI TEnIPDevInfoList {
	UINT nCount;				// Count of device
	TEnIPDevInfo *pDevInfo;		// Device info array
	TEnIPDevInfoList();			// Constructor
	~TEnIPDevInfoList();		// Destructor
};


// Send the UDP broadcast message to get potential EnIP device from specific LAN port number.
// Note1: If success will record the device info into list, othrewise not.
// Note2: If nMaxRspDelay (unit: milliseconds) is value of 0 ms, then a default value of 2000 ms shall be used
//        If it is value of 1-500 ms, then a value of 500 ms shall be used
BOOL EnIP_Broadcast( /*In*/ UINT nLAN, /*Out*/ TEnIPDevInfoList &DevInfoList, /*In*/ USHORT nMaxRspDelay = 0 );

// To open the connection for specific EnIP device with TCP/IP
// Set device IPv4 address (Big Endian), and communication timeout value (unit: microsecond (us))
BOOL EnIP_Connection( /*In*/ ULONG nIPAddr, /*In*/ ULONG nTimeOut );

// Get device timeout value, unit: microsecond (us)
// Note: the station is device IPv4 address (Big Endian)
ULONG EnIP_GetDeviceTimeOut( /*In*/ ULONG nStation );

// Send EnIP Explicit Messaging Request Command
// If success return control handle, otherwise return ENIP_ERROR_HANDLE
// Note: the station is device IPv4 address (Big Endian)
ENIP_HANDLE EnIP_SendExpMsgReq( /*In*/ ULONG nStation, /*In*/ BYTE nService, /*In*/ WORD nClass, /*In*/ DWORD nInstance, /*In*/ WORD nAttribute, /*In*/ const void *pReqData = NULL, /*In*/ WORD nReqDataLength = 0 );

// Recv EnIP Explicit Messaging Response Data
// Copy the response data into buffer and record information in RspInfo
EEnIPRecvState EnIP_RecvExpMsgRsp( /*In*/ ENIP_HANDLE hHandle, /*Out*/ void *pRspBuf, /*In*/ INT nMaxBufSize, /*Out*/ TEnIPRspInfo &RspInfo );

}
