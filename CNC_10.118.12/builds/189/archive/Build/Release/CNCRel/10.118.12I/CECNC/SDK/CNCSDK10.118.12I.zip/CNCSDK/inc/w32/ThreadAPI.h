//
//	ThreadAPI.H
//
//	Thread API Exported Interface
//

#if !defined(_THREADAPI_INCLUDED_)
#define _THREADAPI_INCLUDED_

#include "nstdlib.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MMI_Processor	1
#define Krnl_Processor	1

extern HANDLE CNCAPI CreateThreadWithAffinity(
	LPSECURITY_ATTRIBUTES lpsa,
	DWORD cbStack,
	LPTHREAD_START_ROUTINE lpStartAddr,
	LPVOID lpvThreadParam,
	DWORD fdwCreate,
	LPDWORD lpIDThread,
	DWORD dwProcessor = MMI_Processor
	);
// This function use system CreateThread with set Affinity API.
// If not set dwProcessor, use first CPU.

extern DWORD GetTotalProcessors( void );
// If CE7, call winapi to get total processor.
// If Win32 or CE6, return 1.

extern BOOL CNCAPI CloseThread(
	HANDLE hThread   // handle to thread to close
);
// The CloseThread function closes an open thread handle.
// If the function succeeds, the return value is nonzero.
// If the function fails, the return value is zero.

extern void GetAllThreadInfo(
	LPDWORD	lpStackSize,		// array to store thread stack size, in bytes
	LPDWORD	lpStackFree			// array to store thread stack free, in bytes
);
// query all thread information

extern void CNCAPI GetThreadInfo(
	LPDWORD	lpStackSize,		// storage to store thread stack size, in bytes
	LPDWORD	lpStackFree			// storage to store thread stack free, in bytes
);
// query my thread information

extern void CNCAPI NcSetThreadPriority( HANDLE hThread, int nPriority );
// set thread priority
#ifdef __cplusplus
}
#endif 

#endif // _THREADAPI_INCLUDED_
