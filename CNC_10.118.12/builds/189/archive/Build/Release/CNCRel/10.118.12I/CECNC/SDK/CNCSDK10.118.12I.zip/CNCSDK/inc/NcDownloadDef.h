// NcDownloadDef.h: definition for the NcDownload
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NCDOWNLOADDEF_H__INCLUDED_)
#define AFX_NCDOWNLOADDEF_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SIZE_CheckBlocksGramaBuff		1024 * 8

#endif // !defined(AFX_NCDOWNLOADDEF_H__INCLUDED_)
