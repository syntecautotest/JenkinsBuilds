#if !defined(_CFLROBOTMOVEL_H____INCLUDED_)
#define _CFLROBOTMOVEL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFLRobotMoveL : public IRobotFeedLimit
{
public:
	CFLRobotMoveL( void );
	// constructor

	~CFLRobotMoveL( void );
	// destructor

public:
	void putMotionNode( TLANode *pNode );
	// put motion node to feedlimit module

	void onMotionParamChanged( const TMotParamTable &MotParamTable );
	// on motion parameters changed

	void calcLength( TLANode *pNode );
	// calculate block length.

	BOOL processMaxOverride( TLANode *pNode, LONG nArg[ 2 ] );
	// process maximum override

protected:
	void calcMotionFeature( TLANode *pNode );
	// calculate block motion feature.

	void estimateElapseTime( TLANode *pNode );
	// estimate elapse time of pNode

private:
	void clampFeedrateByFLFR( TLANode *pNode );
	// clamp feedrate by maximum FL (m_Fmax), FR (m_FRmax), input FL, and input FR

	void clampAccByMaxAcc( TLANode *pNode );
	// clamp block acceleration by maximum linear and rotation

	void clampJerkByMaxJerk( TLANode *pNode );
	// clamp block jerk by maximum linear and rotational jerk

// functions for MOVC
private:
	void clampArcCorFeedrateByLR406( TLANode *pNode, TLANode *pLNode );
	// clamp end-effector corner feedrate by linear and rotational 406

	void clampArcRotationalCorFeedrate( TLANode *pNode, TLANode *pLNode, double &eCornerFR );
	// clamp end-effector corner feedrate

	double calcArcEquivalentVc( TLANode *pNode, double LVc, double RVc );
	// calculate equivalent Vc by LVc and RVc

	void clampArcV0VcFclampByLinear408( TLANode *pNode, TLANode *pLNode );
	// clamp V0 Vc and Fclamp by input feedrate

private:
	double m_MaxOverride;
	// max override

	CLAQueue *m_pLRQueue;
	// linear/rotational corner feedrate queue

	double m_Fmax;
	// maximum feedrate

	double m_Amax;
	// maximum acceleration in IU / us ^ 2

	double m_Jmax;
	// maximum jerk in IU / us ^ 3

	double m_FRmax;
	// maximum compound end-effector rotation feedrate, in IU / us, default 180 deg/s

	double m_ARmax;
	// maximum compound end-effector rotation acceleration, in IU / us^2, default 2500 deg/s^2

	double m_JRmax;
	// maximum compound end-effector rotation jerk, in IU / us^3, default 245000 deg/s^3

	double m_DFRmax;
	// maximum compound end-effector rotation velocity difference between two MOVL commands, default 30 deg/s
	// for example, max allowed speed is 15 deg/s in full reversed rotation direction

	double m_ArcRadiusRef;
	// arc radius reference, in IU

	double m_ArcFeedrateRef;
	// arc feedrate reference, in IU / us

	double m_MaxCentripetalForce;
	// maximum centripetal force
};
#endif // !defined(_CFLROBOTMOVEL_H____INCLUDED_)
