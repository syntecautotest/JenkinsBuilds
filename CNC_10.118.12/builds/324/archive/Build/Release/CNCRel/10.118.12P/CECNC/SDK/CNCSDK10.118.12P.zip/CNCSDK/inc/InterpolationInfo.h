#if !defined(_INTERPOLATIONINFO_INCLUDE_)
#define _INTERPOLATIONINFO_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef FUNCINFO_TYPE_
#define FUNCINFO_TYPE_

enum EFuncInfoType {
	EFT_BeforeDisplacement = 0,
	EFT_AfterDisplacement,
	NUMOF_FUNCINFOTYPE,
};

#endif // FUNCINFO_TYPE_

#ifndef TFUNCINFO_STRUCT_
#define TFUNCINFO_STRUCT_

// maximum number of FuncInfo with each interpolationTick
#define MAX_FUNCINFO_EACHINT	( 6 )
// maximum number of arg with each FunctionInfo 
#define MAX_ARG_EACHFUNCINFO	( 2 )

struct TFuncInfo {
	union {
		DOUBLE eArg[ MAX_ARG_EACHFUNCINFO ];
		LONG nArg[ MAX_ARG_EACHFUNCINFO ];
	};
	LONG nFuncID;
	LONG nArgNum;
	LONG nFuncType;
};

struct TMultiFuncInfo {
	TFuncInfo FuncInfo;
	LONG nAxisUsed;
};

struct TAxisIntInstruction {
	TFuncInfo FuncInfo[ MAX_FUNCINFO_EACHINT ];
	LONG nFuncInfoNum;
};

struct TIntInstruction {
	TMultiFuncInfo MultiFuncInfo[ MAX_FUNCINFO_EACHINT ];
	LONG nFuncInfoNum;
};

#endif // TFUNCINFO_STRUCT_

#ifndef FUNCINFO_ARG_
#define FUNCINFO_ARG_

enum EBacklashONOFF {
	EBL_OFF = 0,
	EBL_ON,
};

#endif // FUNCINFO_ARG_

#endif // _INTERPOLATIONINFO_INCLUDE_
