#if !defined(_PlatformAPI_INCLUDE_)
#define _PlatformAPI_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef DWORD (* PFN_ISR)( LPVOID pBuf );

#ifdef __cplusplus
extern "C" {
#endif

// API initialization/de-initialization
HRESULT WINAPI PlatformAPIInit( void );
void WINAPI PlatformAPIUninit( void );
HRESULT WINAPI PlatformAPIShutdown( void );
HRESULT WINAPI PlatformAPI( DWORD dwCode, PBYTE pBufferIn, DWORD dwSizeIn, PBYTE pBufferOut, DWORD dwSizeOut );

// PlatformAPI interface
HRESULT WINAPI PlatformVersion( /*out*/ ULONG *lpnVersion );
HRESULT WINAPI PlatformApiVersion( /*out*/ ULONG *lpnApiVersion );
HRESULT WINAPI GetBaseBoardID( /*out*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthRead );
HRESULT WINAPI GetExtentionBoardID( /*out*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthRead );
HRESULT WINAPI SetExtentionBoardID( /*in*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthWrite );
HRESULT WINAPI GetHW_ID( /*out*/ ULONG *lpnHW_ID );
HRESULT WINAPI DeviceBaseAddr( /*in*/ LONG nDeviceID, /*out*/ ULONG *lpDeviceBaseAddr );
HRESULT WINAPI GetBLVersion( /*out*/ ULONG *lpnBLVersion );
HRESULT WINAPI RawMemReadByte( /*in*/ BYTE *lpAddr, /*out*/ BYTE *lpnValue );
HRESULT WINAPI RawMemWriteByte( /*in*/ BYTE *lpAddr, /*in*/ BYTE nValue );
HRESULT WINAPI RawMemReadWord( /*in*/ WORD *lpAddr, /*out*/ WORD *lpnValue );
HRESULT WINAPI RawMemWriteWord( /*in*/ WORD *lpAddr, /*in*/ WORD nValue );
HRESULT WINAPI RawMemRead( /*in*/ DWORD *lpAddr, /*out*/ DWORD *lpnValue );
HRESULT WINAPI RawMemWrite( /*in*/ DWORD *lpAddr, /*in*/ DWORD nValue );
HRESULT WINAPI Reboot( void );
HRESULT WINAPI BackLightOn( void );
HRESULT WINAPI BackLightOff( void );
HRESULT WINAPI LEDSetStatus( /*in*/ LONG nID, /*in*/ LONG nMode);
HRESULT WINAPI GetCpuTemperture( /*out*/ LONG *lpnCpuTemperture );
HRESULT WINAPI FPGADownload( /*in*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength );
HRESULT WINAPI FramReadByte( /*in*/ ULONG nAddr, /*out*/ char* lpnVal );
HRESULT WINAPI FramWriteByte( /*in*/ ULONG nAddr, /*in*/ char nVal );
HRESULT WINAPI FramReadByteArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ char *lpBuffer );
HRESULT WINAPI FramWriteByteArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ char *lpBuffer );
HRESULT WINAPI FramReadLong( /*in*/ ULONG nAddr, /*out*/ ULONG* lpnVal );
HRESULT WINAPI FramWriteLong( /*in*/ ULONG nAddr, /*in*/ ULONG nVal );
HRESULT WINAPI FramReadLongArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ ULONG *lpBuffer );
HRESULT WINAPI FramWriteLongArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ ULONG *lpBuffer );
HRESULT WINAPI FramLock( void );
HRESULT WINAPI FramUnlock( void );
HRESULT WINAPI FramLockStatus( BOOL *lpbLockStatus );
HRESULT WINAPI FramSize( /*out*/ ULONG *lpnSize );
HRESULT WINAPI GetCpuClock( DWORD* lpnCpuClock );
HRESULT WINAPI EEpromReadByteArray( /*in*/ BYTE nDevice, /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ BYTE *lpBuffer );
HRESULT WINAPI EEpromWriteByteArray( /*in*/ BYTE nDevice, /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ BYTE *lpBuffer );
HRESULT WINAPI LatchCNC2State( /*out*/ BYTE *lpnCNC2State );

HRESULT WINAPI GetDeviceNumber(/*out*/ BYTE *pnDeviceNum );
HRESULT WINAPI GetDeviceFeature(/*in*/ BYTE nDeviceIndex, /*out*/ BYTE *pnDeviceType );
HRESULT WINAPI ReadDevicePacket(/*in*/ BYTE nDeviceIndex, /*out*/ LPVOID pBufferOut);
HRESULT WINAPI WriteDevicePacket(/*in*/ BYTE nDeviceIndex, /*in*/ LPVOID pBufferIn);

HRESULT WINAPI ISRCallBack( /*in*/ PFN_ISR pfnExtISR, /*in*/ LPVOID dwContext );
// registration ISR CallBack function.

#ifdef __cplusplus
}
#endif 

#endif // !defined(_PlatformAPI_INCLUDE_)
