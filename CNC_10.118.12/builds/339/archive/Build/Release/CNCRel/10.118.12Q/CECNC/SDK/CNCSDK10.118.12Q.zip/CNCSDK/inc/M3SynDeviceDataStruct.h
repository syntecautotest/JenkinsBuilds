#if !defined(_M3SYNTECDEVICESTRUCT_H__INCLUDED_)
#define _M3SYNTECDEVICESTRUCT_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define FILE_PATH_SIZE				(256)
#define FILE_NAME_SIZE				(32)
#define MODEL_SIZE					(32)
#define SN_SIZE						(32)
#define MAX_MODULE_NUM				(5)
#define MAX_UNIT_NUM				(4)
#define DEVICE_HEADER_SIZE			(12)
#define MAX_CONTEXT_LEVEL			(3)
#define LOADER_QUEUE_LENGTH			(100)		// queue length of binary file loader
#define M3_SYNTEC_SAMPLE_FREQ		(2000)		// bode plot sample frequency: 2000(Hz)
#define M3_SYNTEC_CHIRP_TIME		(10)		// chirp signal during time: 10(0.1sec)
#define M3_SYNTEC_CHIRP_MAGNITUDE	(300)		// chirp signal magnitude: 300(0.01%)
#define M3_SYNTEC_MAX_NOTCH_FILTER	(5)			// max count of supported notch filter

// Syntec Module position
#define SYN_MDPOS_FRONT_STAGE		(0x0000)
#define SYN_MDPOS_EXP_SLOT1			(0x00A1)	// expansion slot1
#define SYN_MDPOS_EXP_SLOT2			(0x00A2)	// expansion slot2

// Syntec Module ID
#define SYN_MD_BACK_STAGE			(0x0000)	// syntec back stage
#define SYN_MD_FRONT_STAGE			(0x0001)	// syntec front stage
#define SYN_MD_IO_EXP_CARD			(0x0002)	// IO expansion card
#define SYN_MD_MAIN_DIN_BOARD		(0x0003)	// main DIN board
#define SYN_MD_STEP_CTRL_CARD		(0x0004)	// Step control expansion card
#define SYN_MD_32IO_EXP_CARD		(0x0005)	// 32I/32O expansion card

// Syntec Unit ID
#define SYN_UNIT_CPU1				(0x00)		// CPU1
#define SYN_UNIT_CPU2				(0x01)		// CPU2
#define SYN_UNIT_FLASH				(0x20)		// flash of FPGA

enum EContextLevel {
	CL_DEVICE = 0,
	CL_MODULE,
	CL_UNIT
};

// data struct of syntec device code
struct TSynDeviceCode {
	BYTE ApplyCode;
	BYTE reserved1;
	WORD DeviceType:4;
	WORD reserved2:12;
};

// data struct of syntec device info header
struct TSynDevInfoHeader {
	WORD nVersion;			// version of device info header
	WORD nHeaderSize;		// header size of device info
	WORD nDataStartOffset;	// start offset of device data
	WORD nMaxDataNum;		// max number of data
	WORD nMaxMDNum;			// max number of module
	WORD nMDNum;			// actual number of module
	WORD nMDMaxDataNum;		// max number of data in each module
	WORD nMDDataNum;		// actual number of data in each module
	WORD nMaxUnitNum;		// max number of unit in each module
	WORD nUnitMaxDataNum;	// max number of data in each unit
	WORD nUnitDataNum;		// actual number of data in each unit
	WORD nBootLoaderVer;	// bootloader version
};

// syntec unit information
struct TSynUnitInfo {
	WORD nUnitID;						// unit ID
	WORD nFirmwareVer;					// firmware version
	char szFileName[ FILE_NAME_SIZE ];	// file name for update
};

// syntec module information
struct TSynModuleInfo {
	WORD nPosition;					// slot position of modlue
	WORD nID;						// module ID
	WORD nHWVer;					// hardware version
	WORD nUnitNum;					// num. of unit on module
	char szModel[ MODEL_SIZE ];		// model name of module
	char szSerialNum[ SN_SIZE ];	// serial num. of module
};

// syntec module all information, include module & all units
struct TSynModuleInfoAll {
	TSynModuleInfo ModuleInfo;					// syntec module information
	TSynUnitInfo UnitInfo[ MAX_UNIT_NUM ];		// syntec units information
};

struct TSynDeviceAll {
	TSynDevInfoHeader DevHeader;					// device info header
	TSynModuleInfoAll ModuleAll[ MAX_MODULE_NUM ];	// all module info.
};

// syntec file information for burn in
struct TSynFileBurnIn {
	int nModuleNo;
	int nUnitNo;
	LONG nVersion;
	char szFilePath[ FILE_PATH_SIZE ];
};

struct TSynContext {
	int nIndex;				// index of current device
	int nOffset;			// memory of offset
	int nLastOffset;		// memory offset of last device
	DWORD nStartAddr;		// memory start address
	DWORD nLastStartAddr;	// memory last start address
	int nDevNum;			// number of current device
	int nSubDevNum;			// number of sub-device
	int nDataCount;			// data count of device
	void *pDataBuffer;		// data buffer pointer
};

struct TSynDeviceVersion {
	BYTE ModifyVersion;
	BYTE SubVersion:4;
	BYTE MajorVersion:4;
	WORD reserved;
};

struct TSyntecFeatureVersionInfo {
	DWORD bSupportDynamicPosing:1;
	DWORD bSupportLatching:1;
	DWORD bSupportCruise:1;
	DWORD bSupportUnitSetting:1;
	DWORD bSupportPullUp:1;
	DWORD bParamSupportTable:1;
	DWORD bSupportVFF:1;
	DWORD reserved2:1;					// for gear ratio
	DWORD bSupportOrientationSwitch:1;
	DWORD bSupportClearMultiTurn:1;
	DWORD bSupportPosingPwrOffReturn:1;
	DWORD reserved3:1;					// for high/low speed coil switch
	DWORD bSupportDrivePwrOffReturn:1;
	DWORD reserved4:19;
};

struct TSyntecBugFixVersionInfo {
	DWORD bSupportNewRestoreLevel:1;
	DWORD reserved:31;
};

#endif // !defined(_M3SYNTECDEVICESTRUCT_H__INCLUDED_)
