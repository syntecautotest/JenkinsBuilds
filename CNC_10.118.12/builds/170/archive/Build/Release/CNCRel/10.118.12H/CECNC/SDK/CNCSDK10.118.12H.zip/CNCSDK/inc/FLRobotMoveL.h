#if !defined(_CFLROBOTMOVEL_H____INCLUDED_)
#define _CFLROBOTMOVEL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFLRobotMoveL : public IRobotFeedLimit
{
public:
	CFLRobotMoveL( void );
	// constructor

	~CFLRobotMoveL( void );
	// destructor

public:
	void putMotionNode( TRobotMRP *pRobotMRP );
	// put motion node to feedlimit module

	void onMotionParamChanged( const TMotParamTable &MotParamTable );
	// on motion parameters changed

	void calcLength( TRobotMRP *pRobotMRP );
	// calculate block length.

	BOOL processMaxOverride( TRobotMRP *pRobotMRP, LONG nArg[ 2 ] );
	// process maximum override

public:
	void setChannelCount( INT nChannelCount );
	// set number of axis channel, including robot and external axis

private:
	void putMaxAxisFeedrate( const double AxFmax[] );
	// put maximum axis feedrate in IU / us

	void putMaxAxisAcceleration( const double AxAmax[] );
	// put maximum axis acceleration in IU / us ^ 2

	void putMaxAxisJerk( const double AxJmax[] );
	// put maximum axis jerk

protected:
	void calcMotionFeature( TRobotMRP *pRobotMRP );
	// calculate block motion feature.

	void estimateElapseTime( TRobotMRP *pRobotMRP );
	// estimate elapse time of pNode

private:
	void clampFeedrateByFLFRFEJ( TRobotMRP *pRobotMRP );
	// clamp feedrate by maximum FL (m_Fmax), FR (m_FRmax), FEJ ( m_AxFmax ) input FL, FR and FEJ

	void clampAccByMaxAcc( TRobotMRP *pRobotMRP );
	// clamp block acceleration by maximum linear and rotation

	void clampJerkByMaxJerk( TRobotMRP *pRobotMRP );
	// clamp block jerk by maximum linear and rotational jerk

// functions for MOVC
private:
	void clampArcCorFeedrateByLR406( TRobotMRP *pRobotMRP, TRobotMRP *pLastRobotMRP );
	// clamp end-effector corner feedrate by linear and rotational 406

	void clampArcRotationalCorFeedrate( TRobotMRP *pRobotMRP, TRobotMRP *pLastRobotMRP, double &eCornerFR );
	// clamp end-effector corner feedrate

	double calcArcEquivalentVc( TRobotMRP *pRobotMRP, double LVc, double RVc );
	// calculate equivalent Vc by LVc and RVc

	void clampArcV0VcFclampByLinear408( TRobotMRP *pRobotMRP, TRobotMRP *pLastRobotMRP );
	// clamp V0 Vc and Fclamp by input feedrate

private:
	DOUBLE calcEqFeedrateByFEJ( TRobotMRP *pRobotMRP );
	// calculate target feedrate according to FEJ for external axes

	DOUBLE calcEqMaxAxisAcc( TRobotMRP *pRobotMRP );
	// calculate max axis acceleration

	DOUBLE calcEqMaxAxisJerk( TRobotMRP *pRobotMRP );
	// calculate max axis jerk

private:
	INT m_nChannelCount;
	// channel count, including robot and external axis

	double m_MaxOverride;
	// max override

	CRobotMRPQueue *m_pLRQueue;
	// linear/rotational corner feedrate queue

	double m_Fmax;
	// maximum feedrate

	double m_Amax;
	// maximum acceleration in IU / us ^ 2

	double m_Jmax;
	// maximum jerk in IU / us ^ 3

	double m_FRmax;
	// maximum compound end-effector rotation feedrate, in IU / us, default 180 deg/s

	double m_ARmax;
	// maximum compound end-effector rotation acceleration, in IU / us^2, default 2500 deg/s^2

	double m_JRmax;
	// maximum compound end-effector rotation jerk, in IU / us^3, default 245000 deg/s^3

	double m_DFRmax;
	// maximum compound end-effector rotation velocity difference between two MOVL commands, default 30 deg/s
	// for example, max allowed speed is 15 deg/s in full reversed rotation direction

	double m_AxFmax[ NUMOF_AXIS ];
	double m_AxAmax[ NUMOF_AXIS ];
	double m_AxJmax[ NUMOF_AXIS ];
	// Feedrate, Acceleration, Jerk for each axis

	double m_ArcRadiusRef;
	// arc radius reference, in IU

	double m_ArcFeedrateRef;
	// arc feedrate reference, in IU / us

	double m_MaxCentripetalForce;
	// maximum centripetal force
};
#endif // !defined(_CFLROBOTMOVEL_H____INCLUDED_)
