#if !defined(_BPTLIMITER_H____INCLUDED_)
#define _BPTLIMITER_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBPTLimiter : public IListener
{
public:
	CBPTLimiter( int nLenLAQue, int nBPTLimitHigh, int nBPTLimitLow, int nEventCoordID );
	// constructor, tell BPT Limiter the length of LAQue to decide the number of BPT Burst motion blocks
	// BPT Limiter provides two BPT level for switching (Normal and HPCC)

	~CBPTLimiter( void );
	// destructor

public:
	void AdvanceOneBlockTime( long nTime, BOOL fStraightLineNurbs );
	// advance block time (us)

	BOOL GetSuggestedFeedrate( double &FCommand, double Length );
	// get suggedted feedrate (considering BPT burst)
	// return value shows if FCommand is clamped or not

	void PutOverride( double Override );
	// notify current Override

	void SetBPTPerformanceHigh( void );
	// set BPT Limit when switching normal mode

	void SetBPTPerformanceLow( void );
	// set BPT Limit when switching HPCC mode

	void Reset( void );
	// reset

	void Trigger( TEvtInfo *pEvtArg, va_list var );
	// trigger event

private:
	BOOL m_bDisabled;
	// Disable BPT Limiter

	double m_nBPTHighUs;
	// BPT high gear in us for normal G01

	double m_nBPTLowUs;
	// BPT low gear in us for NURBS

	int m_nNumOfBPTBurstNodes;
	// number of BPT Burst Nodes

	int m_nBPTGuageUpperBound;
	// upper bound of BPT Gauge

	double m_BlockPerUs;
	// BPT limitation in us: Block per micro second

	double m_BPTGauge;
	// the BPT gauge shows the BPT buffer status

	double m_OverrideTimeScale;
	// current override Time Scale

	double m_InvOverrideTimeScale;
	// for speed up calculation

	int m_nEventCoordID;
	// my event ID

	BOOL m_bInhibit;
	// BPT limiter inhibit
};
#endif // !defined(_BPTLIMITER_H____INCLUDED_)
