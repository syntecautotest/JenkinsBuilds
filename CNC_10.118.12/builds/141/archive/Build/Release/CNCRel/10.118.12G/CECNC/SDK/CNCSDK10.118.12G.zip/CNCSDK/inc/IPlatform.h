// IPlatform.h: interface for the IPlatform interface.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IPLATFORM_H__INCLUDED_)
#define AFX_IPLATFORM_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define S_NOSUPPORT				((HRESULT)0xFFFFFFFFL)
#define S_OK					((HRESULT)0x00000000L)
#define S_FALSE					((HRESULT)0x00000001L)

#define IODEVICE_BUFF_SIZE			( 64 )

// flatform device input structure
struct IODevice_Read {
	ULONG ReadErrorCode;
	BYTE pBuffer[ IODEVICE_BUFF_SIZE ];
};
 
// flatform device output structure
struct IODevice_Write {
	ULONG WriteErrorCode;
	BYTE pBuffer[ IODEVICE_BUFF_SIZE ];
};

enum EGPMCSetting {
	EGPMCS_General,
	EGPMCS_AmRTEX,
};

enum ECPUBoardType {
	CPUBOARD_NotDef = 0,
	CPUBOARD_PCA6773,
	CPUBOARD_PCA6781,
	CPUBOARD_IPCLX800,
	CPUBOARD_STLX800,
	CPUBOARD_STLX900,
	CPUBOARD_IPCLX600,
	CPUBOARD_IPCLX900,
	CPUBOARD_IPCN450AD,
	CPUBOARD_IPCN450AE,
	CPUBOARD_STVX800,
	CPUBOARD_S3C6410 = 500,
	CPUBOARD_AM35x,
	CPUBOARD_AM335x,
	CPUBOARD_IMX6,
};

enum EExtensionBoardType {
	EXTBOARD_NotDef = 0,
	EXTBOARD_x8610A10B2987,		// X86:	10A/10B + UDN2987,		HW_ID:0x00
	EXTBOARD_x8620DHybrid,		// X86:	20D Hybrid + UDN2987,	HW_ID:0x01
	EXTBOARD_x86RTEX,			// x86:	RTEX					HW_ID:0x05

	EXTBOARD_x8610A10B_Comp,	// ARM + ISA bus for 10A/10B	HW_ID:0xF0
	EXTBOARD_x8620D_Comp,		// ARM + ISA bus for 20 series	HW_ID:0xF1
	EXTBOARD_x86RTEX_Comp,		// ARM + ISA bus for RTEX		HW_ID:0xF5

	EXTBOARD_Arm3Av1 = 500,		// ARM:	3A/6A					HW_ID:0x00
	EXTBOARD_Arm3Av2,			// ARM:	3A/6A					HW_ID:0x10
	EXTBOARD_Arm3Bv1,			// ARM:	3B/6B/11A				HW_ID:0x01
	EXTBOARD_Arm3Bv2,			// ARM:	3B/6B/11A				HW_ID:0x11
	EXTBOARD_Arm30GM,			// ARM:	30GM					HW_ID:0x02
	EXTBOARD_ArmHHB,			// ARM:	Hand Holder Box			HW_ID:0x03
	EXTBOARD_Arm_M2_080,		// ARM:	21A						HW_ID:0x04
	EXTBOARD_Arm11B,			// ARM:	11B						HW_ID:0x05
	EXTBOARD_Arm_M2_098_M3_IP,	// ARM:	22A						HW_ID:0x0B
	EXTBOARD_eHMC_Step,			// ARM: EMB5 LX25 step motor	HW_ID:0x08
	EXTBOARD_Arm_4in1Driver,	// ARM:	4 in 1 Driver			HW_ID:0x09
	EXTBOARD_Arm_FC,			// ARM:	Hign end FC general		HW_ID:0x12
	EXTBOARD_Arm_FCv2,			// ARM:	Hign end FC v2 general	HW_ID:0x22
	EXTBOARD_Arm_FC_Serial,		// ARM:	Hign end FC serial		HW_ID:0x15
	EXTBOARD_Arm_FCv2_Serial,	// ARM:	Hign end FC v2 Serial	HW_ID:0x25
	EXTBOARD_Arm_HHB_Serial,	// ARM: HHB serial				HW_ID:0x16
	EXTBOARD_Arm_ScanLaser_4in1,// ARM: Scan laser 4 in 1		HW_ID:0x0A
	EXTBOARD_STARM,				// ARM:	STARM					HW_ID:0xFF

	// add new ext. board here.
	EXTBOARD_COUNT
};

enum EPlatformDeviceType {
	EPDT_RFHHB_24Key = 1,
};

class IPlatform
{
public:
	virtual ~IPlatform( void ) {}
	// destructor

	virtual int GetMotherboardType( void ) = 0;
	// return motherboard type.

	virtual int GetExtensionboardType( void ) = 0;
	// return extension board type.

	virtual void GetMacAddress( UCHAR *buffer ) = 0;
	// return mac address of CPU board

	virtual ULONG *DeviceBaseAddr( int nDeviceID ) = 0;
	// return device base address.

	virtual BOOL isSupportDIOOverLoad( void ) = 0;
	// check is support digital IO overload.

	virtual BOOL isSupportSRI( void ) = 0;
	// check whether it is support SRI

	virtual BOOL isSupportFram( void ) = 0;
	// check whether it is support Fram

	virtual BOOL RegISRCallBack( LPVOID pfnExtISR, LPVOID dwContext ) = 0;
	// registration ISR CallBack function.

	virtual int GetFPGASupportFuncNum( int nFunc ) = 0;
	// get FPGA support function number

	virtual void UpdateMacAddr(void) = 0;
	// update Mac address

	// PlatformAPI Driver interface
	virtual HRESULT PlatformVersion( /*out*/ ULONG *lpnVersion ) = 0;
	virtual HRESULT PlatformApiVersion( /*out*/ ULONG *lpnApiVersion ) = 0;
	virtual HRESULT GetMotherboardName( /*out*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthRead ) = 0;
	virtual HRESULT GetExtentionboardName( /*out*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthRead ) = 0;
	virtual HRESULT SetExtentionboardName( /*in*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength, /*out*/ ULONG *lpnLengthWrite ) = 0;
	virtual HRESULT BackLightOn( void ) = 0;
	virtual HRESULT BackLightOff( void ) = 0;
	virtual HRESULT LEDSetStatus( /*in*/ LONG nID, /*in*/ LONG nType) = 0;
	virtual HRESULT GetCpuClock( /*out*/ ULONG *lpnCpuClock ) = 0;
	virtual HRESULT GetCpuTemperture( /*out*/ LONG *lpnCpuTemperture ) = 0;
	virtual HRESULT GetSysTemperture( /*out*/ LONG *lpnSysTemperture ) = 0;
	virtual HRESULT FPGADownload( /*in*/ TCHAR *lpBuffer, /*in*/ ULONG nBufferLength ) = 0;
	virtual HRESULT FramReadByte( /*in*/ ULONG nAddr, /*out*/ char* lpnVal ) = 0;
	virtual HRESULT FramWriteByte( /*in*/ ULONG nAddr, /*in*/ char nVal ) = 0;
	virtual HRESULT FramReadByteArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ char *lpBuffer ) = 0;
	virtual HRESULT FramWriteByteArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ char *lpBuffer ) = 0;
	virtual HRESULT FramReadLong( /*in*/ ULONG nAddr, /*out*/ ULONG* lpnVal ) = 0;
	virtual HRESULT FramWriteLong( /*in*/ ULONG nAddr, /*in*/ ULONG nVal ) = 0;
	virtual HRESULT FramReadLongArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ ULONG *lpBuffer ) = 0;
	virtual HRESULT FramWriteLongArray( /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ ULONG *lpBuffer ) = 0;
	virtual HRESULT FramLock( void ) = 0;
	virtual HRESULT FramUnlock( void ) = 0;
	virtual HRESULT FramLockStatus( /*out*/ BOOL *lpbLockStatus ) = 0;
	virtual HRESULT FramSize( /*out*/ ULONG *lpnSize ) = 0;
	virtual HRESULT EEpromReadByteArray( /*in*/ BYTE nDevice, /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*out*/ BYTE *lpBuffer ) = 0;
	virtual HRESULT EEpromWriteByteArray( /*in*/ BYTE nDevice, /*in*/ ULONG nAddr, /*in*/ ULONG nSize, /*in*/ BYTE *lpBuffer ) = 0;
	virtual HRESULT GetDeviceNumber( /*out*/ BYTE *pnDeviceNum ) = 0;
	virtual HRESULT GetDeviceFeature( /*in*/ BYTE nDeviceIndex, /*out*/ BYTE *pnDeviceType ) = 0;
	virtual HRESULT ReadDevicePacket( /*in*/ BYTE nDeviceIndex, /*out*/ LPVOID pBufferOut ) = 0;
	virtual HRESULT WriteDevicePacket( /*in*/ BYTE nDeviceIndex, /*in*/ LPVOID pBufferIn ) = 0;
};
#endif // !defined(AFX_IPLATFORM_H__INCLUDED_)
