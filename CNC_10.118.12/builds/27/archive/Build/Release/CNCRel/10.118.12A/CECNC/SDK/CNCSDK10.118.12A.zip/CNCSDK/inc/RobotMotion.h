#if !defined(_ROBOTMOTION_H____INCLUDED_)
#define _ROBOTMOTION_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRobotMotion
{
public:
	CRobotMotion( CTrajectoryNormal *pTrajNormal );
	// constructor

	~CRobotMotion( void );
	// destructor

public:
	void estimateElapseTime( TLANode *pNode );
	// estimate elapse time of pNode

	void calcBlockPVTInfo( TRobotMRP *pRobotMRP );
	// do planblock and calculate PVT information

	LONG getSolveRootErrCode( void );
	// get error code of solving polynomial root

	DOUBLE calcSCurveVc( TRobotMRP *pRobotMRP );
	// by pass to trajectroy noraml

	void writeOverlapStartTime( TRobotMRP *pCurRobotMRP, TRobotMRP *pNextRobotMRP );
	// write overlap start time according to PL PQ PR
	// Use threads: trajectory plan

private:
	DOUBLE calcReasonableOvlLength( TRobotMRP *pRobotMRP, DOUBLE Dist );
	// calculate resonable block overlap length due to MOVC using arc length to interpolate

protected:
	CTrajectoryNormal *m_pTrajNormal;
	// trajectory normal
};
#endif // !defined(_ROBOTMOTION_H____INCLUDED_)
