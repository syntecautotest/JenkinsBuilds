#if !defined(_FLCUTCSLOPEFORSPRING_H____INCLUDED_)
#define _FLCUTCSLOPEFORSPRING_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFLCutCSlopeForSpring : public CFLCutCSlope
{
public:
	CFLCutCSlopeForSpring( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool, CBPTLimiter *pBPTLimiter );
	// constructor

	virtual ~CFLCutCSlopeForSpring( void );
	// destructor

protected:
	void CalcCornerFeature( TLANode *pNode, double &eLastVc );
	// to calculate inter-block feature

	void CalculateCornerDeviation( TLANode *pNode, TLANode *pLNode, double eDeviation[] );
	// calculate corner deviation and its length

	void CalcBlockMotionFeature( TLANode *pNode, CArcFeature &af );
	// calculate block motion feature

private:
	void ProcessMaxOverride( TLANode *pNode, double &Weight );
	// process maximmum override and calculate max axis movement Weight

	void ClampBlockFeedrateByProgramFeedrate( TLANode *pNode, double MaxLength );
	// clamp block feedrate by maximum programming feedrate

	void ClampCornerFeedrateByBlockFeedrate( TLANode *pNode, TLANode *pLNode );
	// clamp corner feedrate by block feedrate

	void decideMaxVelocity( TLANode *pNode, double &Vmax1, double &Vmax2 );
	// decide maximum velocity
};

#endif // !defined(_FLCUTCSLOPEFORSPRING_H____INCLUDED_)
