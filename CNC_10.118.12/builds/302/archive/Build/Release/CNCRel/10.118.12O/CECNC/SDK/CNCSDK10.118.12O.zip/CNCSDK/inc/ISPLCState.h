#if !defined(_ISPLCSTATE_H_INCLUDED_)
#define _ISPLCSTATE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ISPLCState :
	public ISvoDevComState
{
public:
	virtual ~ISPLCState( void ) {}
	// destructor
};

#endif // _ISPLCSTATE_H_INCLUDED_
