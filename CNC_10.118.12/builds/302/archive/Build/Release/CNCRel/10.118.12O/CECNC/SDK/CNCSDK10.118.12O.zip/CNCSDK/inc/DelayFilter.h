// DelayFilter.h: interface for the CDelayFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DELAYFILTER_H__7349C10B_BFBD_4e60_BEDA_87315FBECB2B__INCLUDED_)
#define AFX_DELAYFILTER_H__7349C10B_BFBD_4e60_BEDA_87315FBECB2B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDelayFilter
{
public:

	CDelayFilter( long nTimeBase, long nMaxTimeInterval );
	// constructor

	CDelayFilter( int nCapacity );
	// constructor with parameter capacity

	virtual ~CDelayFilter();
	// destructor

	void set_TimeConstant( double TA );
	// set time constant

	INT getLength( void );
	// get length of MovingQueue

	virtual void empty( void );
	// empty object

	BOOL isEmpty( void );
	// query whether there are no command queue inside?

	double get_QueuedCommand( void );
	// to get remain data

	virtual void shiftCommand( double &command );
	// to shift new command

	virtual void shiftCommand( double InCommand, double &OutCommand );
	// to shift new command

protected:

	long m_nTimeBase;
	// time unit of post-acceleration buffer 

	double m_TA;
	// time constant

	double *m_MovingQueue;
	// buffer for calculate moving average

	int m_nLength;
	// moving average length

	int m_nTail;
	// index to next empty slot of queue

	double m_QueuedCommand;
	// the remain data amount.

	int m_nCapacity;
	// the capacity

	CRTMutex m_cs;
	// mutex for object state consistent

	int m_ZeroInputCount;
	// count input zero times
};

#endif // !defined(AFX_DELAYFILTER_H__7349C10B_BFBD_4e60_BEDA_87315FBECB2B__INCLUDED_)
