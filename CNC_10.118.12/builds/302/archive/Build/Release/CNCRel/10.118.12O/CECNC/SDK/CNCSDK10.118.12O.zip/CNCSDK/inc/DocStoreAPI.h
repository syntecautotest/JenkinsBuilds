#if !defined(_DOCSTOREAPI_INCLUDED_)
#define _DOCSTOREAPI_INCLUDED_

#include "nstdlib.h"

#ifdef __cplusplus
class ILineStore;

extern "C" DWORD CNCAPI DsOpenCustomDoc( char *docname, ILineStore *pStore );
// opem custom document with specified LineStore interface
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern void CNCAPI DsInit( void );
// init line document store ibrary module

extern DWORD CNCAPI DsOpen( char *docname );
// open specified line document store, return non-sero cookie when
// successful, else return 0., when document name is NULL.
// docname	"hv:pathname" for huge disk file viewer.
//			"lm:name" for spare named mapping file
//			"name" for named in-memory document, this document can
//				share between application, to release this document
//				the DsClose calls should same as DsOpen calls
//			(null) for no named in-memory document

extern void CNCAPI DsClose( DWORD dwCookie );
// close specified line document store

extern BOOL CNCAPI DsSaveFile( DWORD dwCookie );
// save edit data into file

extern int CNCAPI DsReadLine( DWORD dwCookie, long lineno, char *buffer, int count );
// return the data size copied, when count is 0,
// then return the actual size of specified line

extern long CNCAPI DsGetLineCount( DWORD dwCookie );
// return the total line count

extern void CNCAPI DsClearAll( DWORD dwCookie );
// clear all content

extern BOOL CNCAPI DsInsertAfter( DWORD dwCookie, long lineno, void *data, int size );
// insert data after specified line number.
// return TRUE, when successful, others, return FALSE.

extern BOOL CNCAPI DsInsertBefore( DWORD dwCookie, long lineno, void *data, int size );
// insert data before specified line number.
// return TRUE, when successful, others, return FALSE.

extern BOOL CNCAPI DsAppend( DWORD dwCookie, void *data, int size );
// append specified data at the tail of whole data.

extern BOOL CNCAPI DsDelete( DWORD dwCookie, long lineno );
// delete specified line, this function will all behind line move
// forward one line

extern BOOL CNCAPI DsPut( DWORD dwCookie, long lineno, void *data, int size );
// put specified data into specified line

extern BOOL CNCAPI DsErase( DWORD dwCookie, long lineno );
// erase specified line data, this function just rease specified
// line data, and no move behind line forward.

extern void CNCAPI DsSuspend( void );
// suspend document store, this will close all opened file

extern void CNCAPI DsResume( void );
// suspend document store, this will reopen required file

#ifdef __cplusplus
}
#endif 

#endif // _DOCSTOREAPI_INCLUDED_