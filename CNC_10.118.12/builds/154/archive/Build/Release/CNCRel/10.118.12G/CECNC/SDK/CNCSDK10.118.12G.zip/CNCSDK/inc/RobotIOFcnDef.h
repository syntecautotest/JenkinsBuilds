#if !defined(_ROBOTIOFCNDEF_H____INCLUDED_)
#define _ROBOTIOFCNDEF_H____INCLUDED_

#include "stdafx.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define RBIT_MULTIPLIER	( 100 )		// ex: R50.1 == 5001
#define MAX_BITNUM		( 16 )		// ex: R50.0 ~ R50.15

#define SIGNAL_ON		( 1 )			// condition ON definition
#define SIGNAL_OFF		( 0 )			// condition OFF definition

#define I_BIT_ON		( 0xFF )
#define I_BIT_OFF		( 0x00 )
#define O_BIT_ON		( 0xFF )
#define O_BIT_OFF		( 0x00 )
#define C_BIT_ON		( 0xFF )
#define C_BIT_OFF		( 0x00 )
#define A_BIT_ON		( 0xFF )
#define A_BIT_OFF		( 0x00 )
#define R_BIT_ON		( 0x01 )
#define R_BIT_OFF		( 0x00 )

#endif // !defined(_ROBOTMOTIONDEF_H____INCLUDED_)
