#if !defined(_FCCUTSMOOTHSCURVE_H____INCLUDED_)
#define _FCCUTSMOOTHSCURVE_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFCCutSmoothSCurve : public CFCCutCSlope
{
	struct TGroupInfo {
		int nHeadIndex;
		int nTailIndex;
		double V0;
		double Vc;
		double A0;
		double Ac;
		double Vmax;
		double LenSum;
	};

public:
	CFCCutSmoothSCurve( long nSize, CLAFilter *pLAFilter, CLANodePool *pLAPool );
	// constructor

	~CFCCutSmoothSCurve( void );
	// destructor

	void putLANode( TLANode *pNode, double eParam1 );
	// put look ahead node to feed control module

	void MotionPlanTick( void );
	// motion plan tick

private:
	void ForwardElimination( int nStartIndex, double tmpVc );
	// do forward singular block elimination

	BOOL NormalFlushRawQueueNodes( int &nCount );
	// normally flush raw queue nodes

	int rSearchMatureBlock( double &tmpVc );
	// to search the first mature block in reverse order

	void BackwardElimination( int nPos, double tmpVc );
	// backward singular block elimination

	BOOL PseudoBackwardElimination( int nStartIndex, double &eLasttmpVc, BOOL bStopInMature, int &nMatureIndex );
	// pseudo backward singular block elimination, return TRUE if the block of nStartIndex is clamped down

	void FlushImmatureNodes( int nFlushCount );
	// flush immature node of specified number of count from raw queue.
	// count	the number of node count to be release

	int ForwardModifyTop( int nPos );
	// forward modify top from node 0 to node nPos

	BOOL ModifyTop( int nHeadIndex, int nEndIndex, int &nMatureIndex );
	// plan one s-curve between one or more node

	BOOL FindBoundary( int nStartIndex, int nEndIndex, TGroupInfo *GroupInfo );
	// find group boundary and correspond infomation, and return if find actual end index

	void CalDetailInfo( TGroupInfo *GroupInfo, TPVTSheet *sheet );
	// calculate all node's boundary according to pvt sheet

	BOOL CalReasonSCurveVel( double &Vc, double &Ac, double V0, double A0, double P, double Vmax, double IniVel, double LenSum );
	// calculate max Vc and correspond Ac
	// if not be clamped by CalMaxVel, it need to check the max scurve velocity by iniVel and LenSum

	BOOL BackCalReasonSCurveVel( double &V0, double &A0, double Vc, double Ac, double P, double Vmax, double IniVel, double LenSum );
	// backward calculate reasonable scurve velocity

private:
	CTrajectoryNormal *m_pTrajNormal;
	// trajectory normal

	CPolynomialRootSolver m_PRS;
	// polynomial root solver

	double m_Coeff[5];
	// polynomial coefficients with m_Coeff[i] for i-th degree coefficient

	double m_eForwardIniV;
	// record forward initial time in putLANode for next putLANode

	double m_eForwardLen;
	// record forward length in putLANode for next putLANode
};

#endif // !defined(_FCCUTCSLOPEFORSCURVE_H____INCLUDED_)
