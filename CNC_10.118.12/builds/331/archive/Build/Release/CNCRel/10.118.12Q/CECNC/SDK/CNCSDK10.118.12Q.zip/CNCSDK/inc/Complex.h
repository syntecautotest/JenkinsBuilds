// We define complex numbers and complex computation operators "+", "*", "=", "Re", and "Im"
// "Re" is to get the real part and "Im" is to get the imaginary part of a complex number

#if !defined(_COMPLEX_INCLUDE_)
#define _COMPLEX_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CComplex
{
public:
	// initilize at origin
	CComplex();	
	CComplex(double real);
	CComplex(double real, double imaginary);	

	// assigning operator for complex numbers
	CComplex operator=(const CComplex & other);

	// plus operator for complex numbers
	CComplex operator+(const CComplex &) const;

	// multiplication operator for complex numbers
	CComplex operator*(const CComplex &) const;

public:
	double Re();
	// get the real part of a complex number

	double Im();
	// get the imagimary part of a complex number

	double Norm();
	// to calculate complex number norm

	double NormSquare();
	// calculate norm square

	CComplex Exp( double Exp );
	// calculate this^Exp

	CComplex Neg();
	// return -this

	CComplex Conjugation();
	// return conjugation of this

	BOOL isReal();
	// if this is a real number, then return TRUE

private:
	double m_RealPart;
	// set the real part of a complex number

	double m_ImaginaryPart;
	// set the imaginary part of a complex number
};

#endif // !defined(_COMPLEX_INCLUDE_)