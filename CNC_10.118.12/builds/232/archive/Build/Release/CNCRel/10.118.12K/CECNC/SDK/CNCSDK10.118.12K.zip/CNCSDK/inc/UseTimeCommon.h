// UseTimeComm.h: Comm header
//
//////////////////////////////////////////////////////////////////////

#if !defined(_USETIMECOMMON_INCLUDE_)
#define _USETIMECOMMON_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define USETIME_DataArraySize		20

#define IDX_UTDead			0
#define IDX_UTCurrent		1
#define IDX_UTStart			2
#define IDX_TimeModifed		3
#define IDX_UTSeed			4
#define IDX_CompanyID		5
#define IDX_MacData			7
#define IDX_InvalidStart	9
#define IDX_InvalidDead		10
#define IDX_ModifiedCount	11
#define IDX_FactoryID		12
#define IDX_FactoryKey		13
#define IDX_UinqueKey		14
#define IDX_PassVerInfo		18

#define	NoTimeLimit( nDead )	( ( ( nDead == 0 ) || ( nDead == 0xFFFFFFFF ) )  ? TRUE : FALSE )

// use time password status
enum EPASS_Status {
	PASS_Error = 0,
	PASS_UseTimeRight = 1,
};

// use time password status
enum EUT_Version {
	UT_Version0 = 0,
	UT_Version1 = 0,
	UT_Version2 = 1,
	UT_Version3 = 2,
	UT_Version4 = 3
};

// use time deadline type
enum EDeadTimeStatus {
	DT_NoTimeLimit = 0,
	DT_ModifyTime = 2,
	DT_TimeOut = 3,
	DT_CountDown = 4,
	DT_InTimeLimit = 100
};

#endif // _USETIMECOMMON_INCLUDE_
