#include "CommonStruct.h"
#include "SerialPLCAxisDef.h"
#include "RotDef.h"
#include "NcDownloadDef.h"
#include "LaserCtrlDef.h"
#include "ServoTuningDef.h"

// InterfaceType : 6 Bit
// Function : 10 Bit
#define OCK_CODE( InterfaceType, Function ) ( ( InterfaceType << 10 ) | Function )

// interface type
#define CNC_API					1
#define SERVO_DATA_API			2
#define DQ_API					3
#define XMLDB_API				4
#define SIMU_API				5
#define DNC_API					6
#define OPLOG_API				7
#define EVENT_TRIGGER_API		8
#define SerialPLCAxis_API		9
#define SRI_API					10
#define ROBOT_API				11
#define Rot_API					12
#define SvoDevice_API			13
#define LASER_API				14
#define TUNING_API				15
#define DEVICE_UPDATE_API		16
#define SWP_API					17
#define ADJUST_API				18
#define SerialParam_API			19
#define BODE_API				20
#define Grinder_API				21
#define SerialScope_API			22
#define IOMapping_API			23
#define PARAM_API				24
#define FrictionAdjust_API		25
#define SerialDevice_API		26
#define GENERAL_PARAM_API		27

//------------------------------------------------------------
// CNC interface code
//#define OCK_CncParamGetCapacity			OCK_CODE(CNC_API, 1)
//#define OCK_CncParamDump					OCK_CODE(CNC_API, 2)
//#define OCK_CncParamPutValue				OCK_CODE(CNC_API, 3)
//#define OCK_CncParamGetValue				OCK_CODE(CNC_API, 4)
#define OCK_NcStateDump						OCK_CODE(CNC_API, 5)
#define OCK_NcDebugDump						OCK_CODE(CNC_API, 6)
#define OCK_NcStateGetValue					OCK_CODE(CNC_API, 7)
#define OCK_NcStateGetCapacity				OCK_CODE(CNC_API, 8)
#define OCK_NcDebugGetCapacity				OCK_CODE(CNC_API, 9)
#define OCK_PlcDumpIBits					OCK_CODE(CNC_API, 10)
#define OCK_PlcDumpOBits					OCK_CODE(CNC_API, 11)
#define OCK_PlcDumpCBits					OCK_CODE(CNC_API, 12)
#define OCK_PlcDumpSBits					OCK_CODE(CNC_API, 13)
#define OCK_PlcDumpABits					OCK_CODE(CNC_API, 14)
#define OCK_PlcDumpRRegister				OCK_CODE(CNC_API, 15)
#define OCK_PlcDumpTimer					OCK_CODE(CNC_API, 16)
#define OCK_PlcDumpCounter					OCK_CODE(CNC_API, 17)
#define OCK_PlcGetIBit						OCK_CODE(CNC_API, 18)
#define OCK_PlcDevicePutIBit				OCK_CODE(CNC_API, 19)
#define OCK_PlcGetOBit						OCK_CODE(CNC_API, 20)
#define OCK_PlcGetCBit						OCK_CODE(CNC_API, 21)
#define OCK_PlcPutCBit						OCK_CODE(CNC_API, 22)
#define OCK_PlcGetSBit						OCK_CODE(CNC_API, 23)
#define OCK_PlcPutSBit						OCK_CODE(CNC_API, 24)
#define OCK_PlcGetABit						OCK_CODE(CNC_API, 25)
#define OCK_PlcGetRRegister					OCK_CODE(CNC_API, 26)
#define OCK_PlcPutRRegister					OCK_CODE(CNC_API, 27)
#define OCK_PlcGetTimer						OCK_CODE(CNC_API, 28)
#define OCK_PlcGetCounter					OCK_CODE(CNC_API, 29)
#define OCK_PlcGetCapacity					OCK_CODE(CNC_API, 30)
#define OCK_NcPutBreakPoint					OCK_CODE(CNC_API, 31)
#define OCK_NcGlobalDump					OCK_CODE(CNC_API, 32)
#define OCK_NcGlobalGetValue				OCK_CODE(CNC_API, 33)
#define OCK_NcGlobalPutValue				OCK_CODE(CNC_API, 34)
#define OCK_NcGlobalGetCapacity				OCK_CODE(CNC_API, 35)
#define OCK_NcDumpPendingAlarm				OCK_CODE(CNC_API, 40)
#define OCK_NcDumpAlarmHistory				OCK_CODE(CNC_API, 41)
#define OCK_NcCoordVarDump					OCK_CODE(CNC_API, 44)
#define OCK_NcExecuteBlocks					OCK_CODE(CNC_API, 45)
#define OCK_NcPutPrecisionParameter			OCK_CODE(CNC_API, 46)
#define OCK_NcGetPrecisionParameter			OCK_CODE(CNC_API, 47)
#define OCK_NcPutWorkpieceZero				OCK_CODE(CNC_API, 48)
#define OCK_NcPutExternWorkpieceZero		OCK_CODE(CNC_API, 49)
#define OCK_NcGetWorkpieceZero				OCK_CODE(CNC_API, 50)
#define OCK_NcGetExternWorkpieceZero		OCK_CODE(CNC_API, 51)
#define OCK_NcGetWorkpieceTableSize			OCK_CODE(CNC_API, 52)
#define OCK_NcCoordVarGetValue				OCK_CODE(CNC_API, 53)
#define OCK_NcCoordVarPutValue				OCK_CODE(CNC_API, 54)
#define OCK_CncRegistryPutValue				OCK_CODE(CNC_API, 55)
#define OCK_CncRegistryGetValue				OCK_CODE(CNC_API, 56)
#define OCK_CncSaveString					OCK_CODE(CNC_API, 61)
#define OCK_CncLoadString					OCK_CODE(CNC_API, 62)
#define OCK_NcGetToolCompensation			OCK_CODE(CNC_API, 63)
#define OCK_NcPutToolCompensation			OCK_CODE(CNC_API, 64)
#define OCK_ParseMacro						OCK_CODE(CNC_API, 65)
#define OCK_NcPutRelativePosition			OCK_CODE(CNC_API, 66)
#define OCK_NcReset							OCK_CODE(CNC_API, 68)
//#define OCK_ParamImport					OCK_CODE(CNC_API, 70)
//#define OCK_ParamExport					OCK_CODE(CNC_API, 71)
#define OCK_RegistryImport					OCK_CODE(CNC_API, 72)
#define OCK_RegistryExport					OCK_CODE(CNC_API, 73)
#define OCK_NcGetPendingAlarmSize			OCK_CODE(CNC_API, 74)
#define OCK_NcClearHint						OCK_CODE(CNC_API, 75)
#define OCK_NcClearHistory					OCK_CODE(CNC_API, 76)
#define OCK_NcSetCryptologyKey				OCK_CODE(CNC_API, 77)
#define OCK_NcGetVersionInfo				OCK_CODE(CNC_API, 79)
#define OCK_UT_getStatus					OCK_CODE(CNC_API, 80)
#define OCK_UT_getPassSeed					OCK_CODE(CNC_API, 81)
#define OCK_UT_getTimeStart					OCK_CODE(CNC_API, 82)
#define OCK_UT_getTimeSet					OCK_CODE(CNC_API, 83)
#define OCK_UT_getTimeRemain				OCK_CODE(CNC_API, 84)
#define OCK_UT_putUserID					OCK_CODE(CNC_API, 85)
#define OCK_UT_putPassKey					OCK_CODE(CNC_API, 86)
#define OCK_UT_putInnerKey					OCK_CODE(CNC_API, 87)
#define OCK_HW_GetPlatformName				OCK_CODE(CNC_API, 88)
#define OCK_HW_GetCPUTemperature			OCK_CODE(CNC_API, 89)
#define OCK_HW_GetSystemTemperature			OCK_CODE(CNC_API, 90)
#define OCK_HW_OnPanelBacklight				OCK_CODE(CNC_API, 91)
#define OCK_HW_OffPanelBacklight			OCK_CODE(CNC_API, 92)
#define OCK_SWOP_getPassSeed				OCK_CODE(CNC_API, 95)
#define OCK_SWOP_getModel					OCK_CODE(CNC_API, 96)
#define OCK_SWOP_getSerialNo				OCK_CODE(CNC_API, 97)
#define OCK_SWOP_putPassKey					OCK_CODE(CNC_API, 98)
#define OCK_SWOP_isOptionEnabled			OCK_CODE(CNC_API, 99)
#define OCK_UT_getFactoryID					OCK_CODE(CNC_API, 100)
#define OCK_UT_putFactoryID					OCK_CODE(CNC_API, 101)
#define OCK_SWOP_isFunctionEnabled			OCK_CODE(CNC_API, 102)
#define OCK_SWOP_getEnabledAxes				OCK_CODE(CNC_API, 103)
#define OCK_SWOP_getMachine					OCK_CODE(CNC_API, 104)
#define OCK_RegistryGetVersion				OCK_CODE(CNC_API, 105)
#define OCK_NcRestorePrecisionParamDefault	OCK_CODE(CNC_API, 113)
#define OCK_NcSetCheckRegister				OCK_CODE(CNC_API, 114)
#define OCK_NcCheckRegisterMaxCount			OCK_CODE(CNC_API, 115)
#define OCK_NcSetMachinePosition			OCK_CODE(CNC_API, 117)
#define OCK_GetDesKey						OCK_CODE(CNC_API, 118)
//#define OCK_CoordParamGetCapacity			OCK_CODE(CNC_API, 119)
//#define OCK_CoordParamDump				OCK_CODE(CNC_API, 120)
//#define OCK_CoordParamPutValue			OCK_CODE(CNC_API, 121)
//#define OCK_CoordParamGetValue			OCK_CODE(CNC_API, 122)
//#define OCK_CoordParamImport				OCK_CODE(CNC_API, 123)
//#define OCK_CoordParamExport				OCK_CODE(CNC_API, 124)
#define OCK_IsCoordExist					OCK_CODE(CNC_API, 125)
#define OCK_NcGetModeGroupCoordNum			OCK_CODE(CNC_API, 126)
#define OCK_NcGetOSInfo						OCK_CODE(CNC_API, 127)
#define OCK_NcGetDirs						OCK_CODE(CNC_API, 128)
#define OCK_NcGetDirFiles					OCK_CODE(CNC_API, 129)
#define OCK_NcGetDirFilesInfo				OCK_CODE(CNC_API, 130)
#define OCK_NcGetFreeSpace					OCK_CODE(CNC_API, 131)
#define OCK_NcGetAxisLoad					OCK_CODE(CNC_API, 132)
#define OCK_NcPutMainProgram				OCK_CODE(CNC_API, 138)
#define OCK_NcGetMainProgramName			OCK_CODE(CNC_API, 139)
#define OCK_NcGetProgramName				OCK_CODE(CNC_API, 140)
#define OCK_GetMMIUniqueKey					OCK_CODE(CNC_API, 141)
#define OCK_ReleaseCurrent					OCK_CODE(CNC_API, 142)
#define OCK_PlcDevicePutIBits				OCK_CODE(CNC_API, 143)
#define OCK_NcIsBlockGrammarError			OCK_CODE(CNC_API, 144)
#define OCK_PlcDevicePutOBits				OCK_CODE(CNC_API, 145)
#define OCK_PlcSetForceIOEnable				OCK_CODE(CNC_API, 146)
#define OCK_PlcForceIBit					OCK_CODE(CNC_API, 147)
#define OCK_PlcForceOBit					OCK_CODE(CNC_API, 148)
#define OCK_PlcForceIBitArray				OCK_CODE(CNC_API, 149)
#define OCK_PlcForceOBitArray				OCK_CODE(CNC_API, 150)
#define OCK_PlcReleaseHoldIBit				OCK_CODE(CNC_API, 151)
#define OCK_PlcReleaseHoldOBit				OCK_CODE(CNC_API, 152)
#define OCK_PlcHoldBitReset					OCK_CODE(CNC_API, 153)
#define OCK_NcGetECamProfiles				OCK_CODE(CNC_API, 156)
#define OCK_PlcGetHoldIBit					OCK_CODE(CNC_API, 157)
#define OCK_PlcGetHoldOBit					OCK_CODE(CNC_API, 158)
#define OCK_NcGetSRISupportFuncNum			OCK_CODE(CNC_API, 160)
#define OCK_NcGetDACSupportFuncNum			OCK_CODE(CNC_API, 161)
#define OCK_NcGetENCSupportFuncNum			OCK_CODE(CNC_API, 162)
#define OCK_NcGetDDASupportFuncNum			OCK_CODE(CNC_API, 163)
#define OCK_NcGetHARDKEYSupportFuncNum		OCK_CODE(CNC_API, 164)
#define OCK_NcGetLIOSupportFuncNum			OCK_CODE(CNC_API, 165)
#define OCK_NcGetRIOSupportFuncNum			OCK_CODE(CNC_API, 166)
#define OCK_NcGetIOENCSupportFuncNum		OCK_CODE(CNC_API, 167)
#define OCK_NcChangeMetricImperialUnit		OCK_CODE(CNC_API, 168)
#define OCK_NcCompToolLengthMeasure			OCK_CODE(CNC_API, 176)
#define OCK_NcGetSysMainProgramName			OCK_CODE(CNC_API, 177)
#define OCK_NcGetExecuteBlockLineNo			OCK_CODE(CNC_API, 178)
#define OCK_NcGetSyncSpdPosData				OCK_CODE(CNC_API, 179)
#define OCK_NcSetSyncSpdPosData				OCK_CODE(CNC_API, 180)
#define OCK_NcGetSystemDateTime				OCK_CODE(CNC_API, 181)
#define OCK_NcSetSystemDateTime				OCK_CODE(CNC_API, 182)
#define OCK_GetDiskFreeSpace				OCK_CODE(CNC_API, 183)
#define OCK_GetRapidTravelOverride			OCK_CODE(CNC_API, 184)
#define OCK_GetFeedrateOverride				OCK_CODE(CNC_API, 185)
#define OCK_GetSpindleOverride				OCK_CODE(CNC_API, 186)
#define OCK_NcPutRemoteMPGCounter			OCK_CODE(CNC_API, 187)
#define OCK_CoordStateGetValue				OCK_CODE(CNC_API, 188)
#define OCK_NcSetMCodeGroupTable			OCK_CODE(CNC_API, 189)
#define OCK_NcGetMCodeGroupTable			OCK_CODE(CNC_API, 190)
#define OCK_NcClearAccCycleTime				OCK_CODE(CNC_API, 191)
#define OCK_SWOP_getNumOfOption				OCK_CODE(CNC_API, 192)
#define OCK_NcGetEnvKeyName					OCK_CODE(CNC_API, 193)
#define OCK_NcGetEnabledToolNumber			OCK_CODE(CNC_API, 194)
#define OCK_NcPutPartCountNumber			OCK_CODE(CNC_API, 195)
#define OCK_NcPutRequiredPartCountNumber	OCK_CODE(CNC_API, 196)
#define OCK_NcPutTotalPartCountNumber		OCK_CODE(CNC_API, 197)
#define OCK_NcGetPartCountNumber			OCK_CODE(CNC_API, 198)
#define OCK_NcGetRequiredPartCountNumber	OCK_CODE(CNC_API, 199)
#define OCK_NcGetTotalPartCountNumber		OCK_CODE(CNC_API, 200)
#define OCK_GetLoaderAxesNumber				OCK_CODE(CNC_API, 201)
//#define OCK_NcGetCoordParamDef				OCK_CODE(CNC_API, 202)
#define OCK_NcRecordModeStart				OCK_CODE(CNC_API, 203)
#define OCK_NcIsRecordModeEnabled			OCK_CODE(CNC_API, 204)
#define OCK_NcDumpAlarmHistoryDuration		OCK_CODE(CNC_API, 205)
#define OCK_NcPutMakerConfigInfo			OCK_CODE(CNC_API, 206)
#define OCK_NcGetMakerConfigInfo			OCK_CODE(CNC_API, 207)
#define OCK_NcPutWorkRecordFlag				OCK_CODE(CNC_API, 208)
#define OCK_NcGetWorkRecordFlag				OCK_CODE(CNC_API, 209)
#define OCK_SWOP_getOptionTryLeftTime		OCK_CODE(CNC_API, 210)
#define OCK_UpdatePLC						OCK_CODE(CNC_API, 211)
#define OCK_AxisStateGetValue				OCK_CODE(CNC_API, 212)
#define OCK_SWOP_getWorkPieceNumber			OCK_CODE(CNC_API, 213)
#define OCK_SWOP_getEnabledSpds				OCK_CODE(CNC_API, 214)
#define OCK_NcIsCoordSystemFrameWritable	OCK_CODE(CNC_API, 215)
#define OCK_SvoDevStateGetValue				OCK_CODE(CNC_API, 216)
#define OCK_NcReadyToGo						OCK_CODE(CNC_API, 217)

//------------------------------------------------------------
// Servo Data API interface code
#define OCK_ServoReadData					OCK_CODE(SERVO_DATA_API, 1)
#define OCK_ServoWriteData					OCK_CODE(SERVO_DATA_API, 2)
#define OCK_SSV_GetDeviceInfo				OCK_CODE(SERVO_DATA_API, 3)
#define OCK_SerialServoIsConnect			OCK_CODE(SERVO_DATA_API, 4)
#define OCK_GetProtocolType					OCK_CODE(SERVO_DATA_API, 5)

//------------------------------------------------------------
// data acquisition API interface code
#define OCK_DQ_Init							OCK_CODE(DQ_API, 1)
#define OCK_DQ_IsBusy						OCK_CODE(DQ_API, 2)
#define OCK_DQ_GetProgressPercentage		OCK_CODE(DQ_API, 3)
#define OCK_DQ_GetTimeBase					OCK_CODE(DQ_API, 4)
#define OCK_DQ_Start						OCK_CODE(DQ_API, 5)
#define OCK_DQ_Abort						OCK_CODE(DQ_API, 6)
#define OCK_DQ_GetData						OCK_CODE(DQ_API, 7)
#define OCK_DQ_GetDataDouble				OCK_CODE(DQ_API, 8)

//------------------------------------------------------------
// XMLDB interface code
#define OCK_XMLDB_SetDatabaseLocation		OCK_CODE(XMLDB_API, 1)
#define OCK_XMLDB_SetSchemaLocation			OCK_CODE(XMLDB_API, 2)
#define OCK_XMLDB_SaveCycleData				OCK_CODE(XMLDB_API, 3)
#define OCK_XMLDB_LoadCycleData				OCK_CODE(XMLDB_API, 4)
#define OCK_XMLDB_NewCycleData				OCK_CODE(XMLDB_API, 5)
#define OCK_XMLDB_DeleteTable				OCK_CODE(XMLDB_API, 6)
#define OCK_XMLDB_GetTableList				OCK_CODE(XMLDB_API, 7)
#define OCK_XMLDB_GetXLDevice				OCK_CODE(XMLDB_API, 8)
#define OCK_XMLDB_PutXLDevice				OCK_CODE(XMLDB_API, 9)
#define OCK_XMLDB_GetCycleData				OCK_CODE(XMLDB_API, 10)
#define OCK_XMLDB_PutCycleData				OCK_CODE(XMLDB_API, 11)
#define OCK_XMLDB_AddDatabaseLocation		OCK_CODE(XMLDB_API, 12)
#define OCK_XMLDB_AddSchemaLocation			OCK_CODE(XMLDB_API, 13)
#define OCK_XMLDB_GetDataBaseLocation		OCK_CODE(XMLDB_API, 14)
#define OCK_XMLDB_DeleteDataBaseLocation	OCK_CODE(XMLDB_API, 15)

//------------------------------------------------------------
// CNC simulation interface code
#define OCK_SMCreate						OCK_CODE(SIMU_API, 1)
#define OCK_SMClose							OCK_CODE(SIMU_API, 2)
#define OCK_SMPlay							OCK_CODE(SIMU_API, 3)
#define OCK_SMStop							OCK_CODE(SIMU_API, 4)
#define OCK_SMGetBlockData					OCK_CODE(SIMU_API, 5)
#define OCK_SMGetAxisDimContexts			OCK_CODE(SIMU_API, 6)
#define OCK_SMGetAlarmLocation				OCK_CODE(SIMU_API, 7)
#define OCK_SMSetSearchPath					OCK_CODE(SIMU_API, 8)
#define OCK_SMGetSearchPath					OCK_CODE(SIMU_API, 9)
#define OCK_SMIsEOF							OCK_CODE(SIMU_API, 10)
#define OCK_SMIsAlarm						OCK_CODE(SIMU_API, 11)
#define OCK_SMPutMDIBlocks					OCK_CODE(SIMU_API, 12)
#define OCK_SMGlobalGetValue				OCK_CODE(SIMU_API, 13)
#define OCK_SMGetAlarmList					OCK_CODE(SIMU_API, 14)
#define OCK_SMSetStartLineNo				OCK_CODE(SIMU_API, 15)
#define OCK_SMUpdateKey						OCK_CODE(SIMU_API, 16)
#define OCK_SMUpdateLife					OCK_CODE(SIMU_API, 17)
//------------------------------------------------------------
// DNC control interface code
#define OCK_DNC_GetBufferSize				OCK_CODE(DNC_API, 1)
#define OCK_DNC_PutBlocks					OCK_CODE(DNC_API, 2)
#define OCK_DNC_IsStreamEmpty				OCK_CODE(DNC_API, 3)
#define OCK_DNC_Reset						OCK_CODE(DNC_API, 4)
#define OCK_DNC_IsStreamReady				OCK_CODE(DNC_API, 5)
#define OCK_DNC_MaxCmdSizeInChar			OCK_CODE(DNC_API, 6)

//------------------------------------------------------------
// Operation logger interface code
#define OCK_OPLogPost						OCK_CODE(OPLOG_API, 1)
#define OCK_OPLogFlush						OCK_CODE(OPLOG_API, 2)
#define OCK_OPLogDump						OCK_CODE(OPLOG_API, 3)

//------------------------------------------------------------
// Event Trigger Manager interface code
// becuase there is some removed API use No.1~ No.9, so we use No.11~ for protect these API
#define OCK_Listener_RegisterEvent		OCK_CODE(EVENT_TRIGGER_API, 11)
#define OCK_Listener_UnregisterEvent	OCK_CODE(EVENT_TRIGGER_API, 12)
#define OCK_Listener_Init				OCK_CODE(EVENT_TRIGGER_API, 13)
#define OCK_Listener_Deinit				OCK_CODE(EVENT_TRIGGER_API, 14)
#define OCK_Listener_DumpData			OCK_CODE(EVENT_TRIGGER_API, 15)
#define OCK_Listener_Alive				OCK_CODE(EVENT_TRIGGER_API, 16)
#define OCK_Listener_DumpRawData		OCK_CODE(EVENT_TRIGGER_API, 17)
#define OCK_Listener_Init_v2			OCK_CODE(EVENT_TRIGGER_API, 18)

//------------------------------------------------------------
// Serial PLC Axis Interface code
//#define OCK_SPLCA_ParamGetCapacity			OCK_CODE(SerialPLCAxis_API, 1)
//#define OCK_SPLCA_ParamDump					OCK_CODE(SerialPLCAxis_API, 2)
//#define OCK_SPLCA_ParamPutValue				OCK_CODE(SerialPLCAxis_API, 3)
//#define OCK_SPLCA_ParamGetValue				OCK_CODE(SerialPLCAxis_API, 4)
//#define OCK_SPLCA_ParamImport					OCK_CODE(SerialPLCAxis_API, 5)
//#define OCK_SPLCA_ParamExport					OCK_CODE(SerialPLCAxis_API, 6)
#define OCK_SPLCA_GetMonitorData				OCK_CODE(SerialPLCAxis_API, 7)
#define OCK_SPLCA_GetNumOfMaxAxis				OCK_CODE(SerialPLCAxis_API, 8)
//#define OCK_SPLCA_GetTypeOfChArray			OCK_CODE(SerialPLCAxis_API, 9)
//#define OCK_SPLCA_TuningIsSupport				OCK_CODE(SerialPLCAxis_API, 19)
//#define OCK_SPLCA_TuningSet1stLimit			OCK_CODE(SerialPLCAxis_API, 20)
//#define OCK_SPLCA_TuningSet2ndLimit			OCK_CODE(SerialPLCAxis_API, 21)
//#define OCK_SPLCA_TuningLimitCheck			OCK_CODE(SerialPLCAxis_API, 22)
//#define OCK_SPLCA_TuningGetDefault			OCK_CODE(SerialPLCAxis_API, 23)
//#define OCK_SPLCA_TuningSetData				OCK_CODE(SerialPLCAxis_API, 24)
//#define OCK_SPLCA_TuningStartCheck			OCK_CODE(SerialPLCAxis_API, 25)
//#define OCK_SPLCA_TuningStart					OCK_CODE(SerialPLCAxis_API, 26)
//#define OCK_SPLCA_TuningStop					OCK_CODE(SerialPLCAxis_API, 27)
//#define OCK_SPLCA_TuningGetStatus				OCK_CODE(SerialPLCAxis_API, 28)
//#define OCK_SPLCA_TuningSetWatchMode			OCK_CODE(SerialPLCAxis_API, 29)

//------------------------------------------------------------
// SRI Interface code
#define OCK_SRI_ReadCommConfig					OCK_CODE(SRI_API, 1)
#define OCK_SRI_WriteCommConfig					OCK_CODE(SRI_API, 2)
#define OCK_SRI_ReadStationInfo					OCK_CODE(SRI_API, 3)
#define OCK_SRI_WriteStationInfo				OCK_CODE(SRI_API, 4)
#define OCK_SRI_SaveStationInfo					OCK_CODE(SRI_API, 5)
#define OCK_SRI_ReadStationState				OCK_CODE(SRI_API, 6)
#define OCK_SRI_UpdateFirmware					OCK_CODE(SRI_API, 7)
#define OCK_SRI_UpdateFirmwareProgress			OCK_CODE(SRI_API, 8)
#define OCK_SRI_ReadCommDbState					OCK_CODE(SRI_API, 9)
#define OCK_SRI_ReadStationDbState				OCK_CODE(SRI_API, 10)
#define OCK_SRI_QueryModuleInfo					OCK_CODE(SRI_API, 11)

//------------------------------------------------------------
// Robot Interface code
// Robot system (1~20)
#define OCK_ROBOT_CalKinematicTransform			OCK_CODE(ROBOT_API, 1)
#define OCK_ROBOT_CheckRefPtExtAxStrokeLimit	OCK_CODE(ROBOT_API, 2)
// because this API will be delete after the weaving function move into kernel
// choose number 20 in order to not effect adding other new API
#define OCK_ROBOT_CalWeavingCrdAndDist			OCK_CODE(ROBOT_API, 20)
// four point tool coordinate calibration (21~25)
#define OCK_ROBOT_ToolCrdCalibSetMethod			OCK_CODE(ROBOT_API, 21)
#define OCK_ROBOT_ToolCrdCalibTeach				OCK_CODE(ROBOT_API, 22)
#define OCK_ROBOT_ToolCrdCalibDoCalibration		OCK_CODE(ROBOT_API, 23)
#define OCK_ROBOT_ToolCrdCalibSaveToolData		OCK_CODE(ROBOT_API, 24)
// protection zone (26~30)
#define OCK_ROBOT_ProtectZoneSet				OCK_CODE(ROBOT_API, 26)
#define OCK_ROBOT_ProtectZoneCheckState			OCK_CODE(ROBOT_API, 27)
// three point user coordinate calibration (31~35)
#define OCK_ROBOT_UserCrdCalib3PtTeach			OCK_CODE(ROBOT_API, 31)
#define OCK_ROBOT_UserCrdCalib3PtCalAndSave		OCK_CODE(ROBOT_API, 32)
// about user coordinate (36~40)
#define OCK_ROBOT_UserCrdGetData				OCK_CODE(ROBOT_API, 36)
#define OCK_ROBOT_UserCrdSetData				OCK_CODE(ROBOT_API, 37)
#define OCK_ROBOT_UserCrdClearAll				OCK_CODE(ROBOT_API, 38)
#define OCK_ROBOT_UserCrdSetActiveID			OCK_CODE(ROBOT_API, 39)
// about tool coordinate (41~45)
#define OCK_ROBOT_ToolCrdGetData				OCK_CODE(ROBOT_API, 41)
#define OCK_ROBOT_ToolCrdSetData				OCK_CODE(ROBOT_API, 42)
#define OCK_ROBOT_ToolCrdClearAll				OCK_CODE(ROBOT_API, 43)
#define OCK_ROBOT_ToolCrdSetActiveID			OCK_CODE(ROBOT_API, 44)

//------------------------------------------------------------
// Rot Interface code
//#define OCK_Rot_ParamGetCapacity				OCK_CODE(Rot_API, 1)
//#define OCK_Rot_ParamDump						OCK_CODE(Rot_API, 2)
//#define OCK_Rot_ParamPutValue					OCK_CODE(Rot_API, 3)
//#define OCK_Rot_ParamGetValue					OCK_CODE(Rot_API, 4)
//#define OCK_Rot_ParamImport					OCK_CODE(Rot_API, 5)
//#define OCK_Rot_ParamExport					OCK_CODE(Rot_API, 6)
#define OCK_Rot_GetMonitorData					OCK_CODE(Rot_API, 7)
#define OCK_Rot_GetNumOfMaxAxis					OCK_CODE(Rot_API, 8)
//#define OCK_Rot_GetTypeOfChArray				OCK_CODE(Rot_API, 9)
//#define OCK_Rot_TuningIsSupport				OCK_CODE(Rot_API, 19)
//#define OCK_Rot_TuningGetDefault				OCK_CODE(Rot_API, 20)
//#define OCK_Rot_TuningSetData					OCK_CODE(Rot_API, 21)
//#define OCK_Rot_TuningStart					OCK_CODE(Rot_API, 22)
//#define OCK_Rot_TuningStop					OCK_CODE(Rot_API, 23)
//#define OCK_Rot_TuningGetStatus				OCK_CODE(Rot_API, 24)
//#define OCK_Rot_TuningSetWatchMode			OCK_CODE(Rot_API, 25)

//------------------------------------------------------------
// Servo Device Interface code
#define OCK_SvoDev_GetNum					OCK_CODE( SvoDevice_API, 1 )
#define OCK_SvoDev_GetID					OCK_CODE( SvoDevice_API, 2 )
//#define OCK_SvoDev_GetTypeOfCh			OCK_CODE( SvoDevice_API, 6 )

//------------------------------------------------------------
// Laser Control Interface code
#define OCK_LASER_SetHomePosition				OCK_CODE(LASER_API, 2)
#define OCK_LASER_queryLaserFreeBufferSize		OCK_CODE(LASER_API, 19)
#define OCK_LASER_putPrintData					OCK_CODE(LASER_API, 20)

// param interface code
//#define OCK_LASER_GAxisParamPutValue			OCK_CODE(LASER_API, 21)
//#define OCK_LASER_GAxisParamGetValue			OCK_CODE(LASER_API, 22)
//#define OCK_LASER_GAxisParamGetCapacity		OCK_CODE(LASER_API, 23)
//#define OCK_LASER_GAxisParamDump				OCK_CODE(LASER_API, 24)
//#define OCK_LASER_GAxisParamImport			OCK_CODE(LASER_API, 25)
//#define OCK_LASER_GAxisParamExport			OCK_CODE(LASER_API, 26)
//#define OCK_LASER_ParamPutValue				OCK_CODE(LASER_API, 27)
//#define OCK_LASER_ParamGetValue				OCK_CODE(LASER_API, 28)
//#define OCK_LASER_ParamGetCapacity			OCK_CODE(LASER_API, 29)
//#define OCK_LASER_ParamDump					OCK_CODE(LASER_API, 30)
//#define OCK_LASER_ParamImport					OCK_CODE(LASER_API, 31)
//#define OCK_LASER_ParamExport					OCK_CODE(LASER_API, 32)

//#define OCK_LASER_CBMParamPutValue			OCK_CODE(LASER_API, 33)
//#define OCK_LASER_CBMParamGetValue			OCK_CODE(LASER_API, 34)
//#define OCK_LASER_CBMParamGetCapacity			OCK_CODE(LASER_API, 35)
//#define OCK_LASER_CBMParamDump				OCK_CODE(LASER_API, 36)
//#define OCK_LASER_CBMParamImport				OCK_CODE(LASER_API, 37)
//#define OCK_LASER_CBMParamExport				OCK_CODE(LASER_API, 38)

// laser resonance suppression interface code
// these API comment are kept for the previous version of MMI
// #define OCK_LASER_IsSupportAntiResonance		OCK_CODE(LASER_API, 51)
// #define OCK_LASER_GetNotchFilterData			OCK_CODE(LASER_API, 52)
// #define OCK_LASER_SetNotchFilterData			OCK_CODE(LASER_API, 53)
// #define OCK_LASER_GetNotchFilterDisplay		OCK_CODE(LASER_API, 54)
// #define OCK_LASER_StartSystemIdentify		OCK_CODE(LASER_API, 55)
// #define OCK_LASER_GetIdentifyResult			OCK_CODE(LASER_API, 56)
// #define OCK_LASER_GetFftDataLength			OCK_CODE(LASER_API, 57)
// #define OCK_LASER_GetFrequencyData			OCK_CODE(LASER_API, 58)
// #define OCK_LASER_GetGainData				OCK_CODE(LASER_API, 59)
// #define OCK_LASER_ClearAnalyzeData			OCK_CODE(LASER_API, 60)
// #define OCK_LASER_GetResonancePoint			OCK_CODE(LASER_API, 61)
#define OCK_LASER_GetServoOnState				OCK_CODE(LASER_API, 62)
#define OCK_LASER_ChangeServoOnState			OCK_CODE(LASER_API, 63)
#define OCK_LASER_GalvoHomeSetting				OCK_CODE(LASER_API, 64)
#define OCK_LASER_GalvoParamGetValue			OCK_CODE(LASER_API, 65)
#define OCK_LASER_GalvoParamPutValue			OCK_CODE(LASER_API, 66)

// laser distortion table correction parameter interface
#define OCK_LASER_SetTableMode					OCK_CODE(LASER_API, 81)
#define OCK_LASER_GetTableMode					OCK_CODE(LASER_API, 82)
#define OCK_LASER_SetFocalLength				OCK_CODE(LASER_API, 83)
#define OCK_LASER_GetFocalLength				OCK_CODE(LASER_API, 84)
#define OCK_LASER_SetDesiredCentralLength		OCK_CODE(LASER_API, 85)
#define OCK_LASER_GetDesiredCentralLength		OCK_CODE(LASER_API, 86)
#define OCK_LASER_SetGridCount					OCK_CODE(LASER_API, 87)
#define OCK_LASER_GetGridCount					OCK_CODE(LASER_API, 88)
#define OCK_LASER_SetActualCentralLength		OCK_CODE(LASER_API, 89)
#define OCK_LASER_GetActualCentralCount			OCK_CODE(LASER_API, 90)
#define OCK_LASER_GetActualCentralLength		OCK_CODE(LASER_API, 91)
#define OCK_LASER_SetBarrelFactor				OCK_CODE(LASER_API, 92)
#define OCK_LASER_GetBarrelFactor				OCK_CODE(LASER_API, 93)
#define OCK_LASER_SetRotationInfo				OCK_CODE(LASER_API, 94)
#define OCK_LASER_GetRotationInfo				OCK_CODE(LASER_API, 95)
#define OCK_LASER_SetGeomAdjustParam			OCK_CODE(LASER_API, 96)
#define OCK_LASER_GetGeomAdjustParam			OCK_CODE(LASER_API, 97)
#define OCK_LASER_AdjustSpecifiedPoint			OCK_CODE(LASER_API, 98)
#define OCK_LASER_SetZAxisInfo					OCK_CODE(LASER_API, 99)
#define OCK_LASER_GetZAxisCount					OCK_CODE(LASER_API, 100)
#define OCK_LASER_GetZAxisInfo					OCK_CODE(LASER_API, 101)
#define OCK_LASER_SetScaleAndOffset				OCK_CODE(LASER_API, 102)
#define OCK_LASER_GetScaleAndOffset				OCK_CODE(LASER_API, 103)
#define OCK_LASER_PutDCTParam					OCK_CODE(LASER_API, 104)
#define OCK_LASER_GetDCTParamCount				OCK_CODE(LASER_API, 105)
#define OCK_LASER_GetDCTParam					OCK_CODE(LASER_API, 106)
#define OCK_LASER_SaveDCTData					OCK_CODE(LASER_API, 107)
#define OCK_LASER_ClearDCTData					OCK_CODE(LASER_API, 108)
#define OCK_LASER_SetDCTUserStrokeLimit			OCK_CODE(LASER_API, 109)
#define OCK_LASER_GetDCTUserStrokeLimit			OCK_CODE(LASER_API, 110)
#define OCK_LASER_SetRLDCTAdjScaleAndOffset		OCK_CODE(LASER_API, 111)
#define OCK_LASER_GetRLDCTAdjScaleAndOffset		OCK_CODE(LASER_API, 112)
#define OCK_LASER_SetDCTType					OCK_CODE(LASER_API, 113)
#define OCK_LASER_GetDCTType					OCK_CODE(LASER_API, 114)
#define OCK_LASER_CopyDCTFromLsrToRL			OCK_CODE(LASER_API, 115)

// Conveyor Belt Scanning Interface		
#define OCK_LASER_GetObjectQueueRemNum			OCK_CODE(LASER_API, 120)
#define OCK_LASER_SetObjectOffsetAndAngle		OCK_CODE(LASER_API, 121)
#define OCK_LASER_GetObjectLostNum				OCK_CODE(LASER_API, 122)
#define OCK_LASER_ResetObjectLostNum			OCK_CODE(LASER_API, 123)

//------------------------------------------------------------
// Servo Tuning Interface code
//#define OCK_AxisTuningIsSupport				OCK_CODE(TUNING_API, 1)
//#define OCK_AxisTuning1stLimit				OCK_CODE(TUNING_API, 2)
//#define OCK_AxisTuning2ndLimit				OCK_CODE(TUNING_API, 3)
//#define OCK_AxisTuningLimitCheck				OCK_CODE(TUNING_API, 4)
//#define OCK_AxisTuningGetDefault				OCK_CODE(TUNING_API, 5)
//#define OCK_AxisTuningSetData					OCK_CODE(TUNING_API, 6)
//#define OCK_AxisTuningStartCheck				OCK_CODE(TUNING_API, 7)
//#define OCK_AxisTuningStart					OCK_CODE(TUNING_API, 8)
//#define OCK_AxisTuningStop					OCK_CODE(TUNING_API, 9)
//#define OCK_AxisTuningGetStatus				OCK_CODE(TUNING_API, 10)
//#define OCK_SpdTuningIsSupport				OCK_CODE(TUNING_API, 11)
//#define OCK_SpdTuningGetDefault				OCK_CODE(TUNING_API, 12)
//#define OCK_SpdTuningSetData					OCK_CODE(TUNING_API, 13)
//#define OCK_SpdTuningStart					OCK_CODE(TUNING_API, 14)
//#define OCK_SpdTuningStop						OCK_CODE(TUNING_API, 15)
//#define OCK_SpdTuningGetStatus				OCK_CODE(TUNING_API, 16)
#define OCK_SpdAdvTuningGetDefault				OCK_CODE(TUNING_API, 17)
#define OCK_SpdAdvTuningSetData					OCK_CODE(TUNING_API, 18)
#define OCK_SpdAdvTuningGainCalculation			OCK_CODE(TUNING_API, 19)
#define OCK_SpdAdvTuningSwitchOn				OCK_CODE(TUNING_API, 20)
#define OCK_SpdAdvTuningTurnOn					OCK_CODE(TUNING_API, 21)
#define OCK_SpdAdvTuningTurnOff					OCK_CODE(TUNING_API, 22)
//#define OCK_AxisTuningSetWatchMode			OCK_CODE(TUNING_API, 23)
//#define OCK_SpdTuningSetWatchMode				OCK_CODE(TUNING_API, 24)
#define OCK_TuningIsSupport						OCK_CODE(TUNING_API, 25)
#define OCK_Tuning1stLimit						OCK_CODE(TUNING_API, 26)
#define OCK_Tuning2ndLimit						OCK_CODE(TUNING_API, 27)
#define OCK_TuningLimitCheck					OCK_CODE(TUNING_API, 28)
#define OCK_TuningGetDefault					OCK_CODE(TUNING_API, 29)
#define OCK_TuningSetData						OCK_CODE(TUNING_API, 30)
#define OCK_TuningStartCheck					OCK_CODE(TUNING_API, 31)
#define OCK_TuningStart							OCK_CODE(TUNING_API, 32)
#define OCK_TuningStop							OCK_CODE(TUNING_API, 33)
#define OCK_TuningGetStatus						OCK_CODE(TUNING_API, 34)
#define OCK_TuningSetWatchMode					OCK_CODE(TUNING_API, 35)

//------------------------------------------------------------
// Device Update Interface code
#define OCK_IsDeviceInfoReady					OCK_CODE(DEVICE_UPDATE_API, 1)
#define OCK_GetCountOfSynDevice					OCK_CODE(DEVICE_UPDATE_API, 2)
#define OCK_GetSynDeviceStationID				OCK_CODE(DEVICE_UPDATE_API, 3)
#define OCK_GetSynDeviceInfo					OCK_CODE(DEVICE_UPDATE_API, 4)
#define OCK_GetSynModuleInfo					OCK_CODE(DEVICE_UPDATE_API, 5)
#define OCK_GetSynUnitInfo						OCK_CODE(DEVICE_UPDATE_API, 6)
#define OCK_OpenBootMode						OCK_CODE(DEVICE_UPDATE_API, 7)
#define OCK_CloseBootMode						OCK_CODE(DEVICE_UPDATE_API, 8)
#define OCK_FileBurnIn							OCK_CODE(DEVICE_UPDATE_API, 9)
#define OCK_BurnInMonitor						OCK_CODE(DEVICE_UPDATE_API, 10)

//------------------------------------------------------------
// Software Panel Interface code
#define OCK_SWP_CycleStart						OCK_CODE(SWP_API, 1)
#define OCK_SWP_Feedhold						OCK_CODE(SWP_API, 2)
#define OCK_SWP_JOG								OCK_CODE(SWP_API, 3)
#define OCK_SWP_MPGSimulation					OCK_CODE(SWP_API, 4)
#define OCK_SWP_SetMachinePosition				OCK_CODE(SWP_API, 5)
#define OCK_SWP_SetManualControl				OCK_CODE(SWP_API, 6)
#define OCK_SWP_Reset							OCK_CODE(SWP_API, 7)
#define OCK_SWP_SingleBlock						OCK_CODE(SWP_API, 8)
#define OCK_SWP_ModeSelection					OCK_CODE(SWP_API, 9)
#define OCK_SWP_IncrementFeed					OCK_CODE(SWP_API, 10)
#define OCK_SWP_SetSpindleOverride				OCK_CODE(SWP_API, 11)
#define OCK_SWP_SetFeedrateOverride				OCK_CODE(SWP_API, 12)
#define OCK_SWP_SetJOGOverride					OCK_CODE(SWP_API, 13)
#define OCK_SWP_SetRapidTravelOverride			OCK_CODE(SWP_API, 14)

//------------------------------------------------------------
// Adjust Interface code
#define OCK_Adjust_SetSpdPosingHomeOffset		OCK_CODE(ADJUST_API, 1)
#define OCK_Adjust_GetSpdPosingHomeOffset		OCK_CODE(ADJUST_API, 2)
#define OCK_Adjust_SaveSpdPosingHomeOffset		OCK_CODE(ADJUST_API, 3)
#define OCK_Adjust_GetSpdEncFeedbackPos			OCK_CODE(ADJUST_API, 4)

//------------------------------------------------------------
// serial param api
#define OCK_SerialParam_GetCapacity					OCK_CODE(SerialParam_API, 1)
#define OCK_SerialParam_Dump						OCK_CODE(SerialParam_API, 2)
#define OCK_SerialParam_PutValue					OCK_CODE(SerialParam_API, 3)
#define OCK_SerialParam_GetValue					OCK_CODE(SerialParam_API, 4)
#define OCK_SerialParam_ReloadValue					OCK_CODE(SerialParam_API, 5)
#define OCK_SerialParam_GetStatus					OCK_CODE(SerialParam_API, 6)
#define OCK_SerialParam_IsReady						OCK_CODE(SerialParam_API, 7)
#define OCK_SerialParam_Init						OCK_CODE(SerialParam_API, 8)
#define OCK_SerialParam_GetInitStatus				OCK_CODE(SerialParam_API, 9)
#define OCK_SerialParam_MemorySave					OCK_CODE(SerialParam_API, 10)
#define OCK_SerialParam_SaveResult					OCK_CODE(SerialParam_API, 11)
#define OCK_SerialParam_SupportParamInit			OCK_CODE(SerialParam_API, 12)
//reserved
#define OCK_SerialParam_RestoreStart				OCK_CODE(SerialParam_API, 14)
#define OCK_SerialParam_RestoreEnd					OCK_CODE(SerialParam_API, 15)
#define OCK_StateVar_ServiceReg						OCK_CODE(SerialParam_API, 16)
#define OCK_StateVar_ServiceUnReg					OCK_CODE(SerialParam_API, 17)
#define OCK_StateVar_GetCapacity					OCK_CODE(SerialParam_API, 18)
#define OCK_StateVar_Dump							OCK_CODE(SerialParam_API, 19)
#define OCK_StateVar_GetValue						OCK_CODE(SerialParam_API, 20)
#define OCK_SerialParam_NeedMemorySave				OCK_CODE(SerialParam_API, 21)
#define OCK_SerialParam_IsSupport					OCK_CODE(SerialParam_API, 22)

//------------------------------------------------------------
// Bode Plot Interface code
#define OCK_BODE_IsSupportAntiResonance			OCK_CODE(BODE_API, 1)
#define OCK_BODE_GetNotchFilterData				OCK_CODE(BODE_API, 2)
#define OCK_BODE_SetNotchFilterData				OCK_CODE(BODE_API, 3)
#define OCK_BODE_GetNotchFilterDisplay			OCK_CODE(BODE_API, 4)
#define OCK_BODE_StartSystemIdentify			OCK_CODE(BODE_API, 5)
#define OCK_BODE_GetIdentifyResult				OCK_CODE(BODE_API, 6)
#define OCK_BODE_GetFftDataLength				OCK_CODE(BODE_API, 7)
#define OCK_BODE_GetFrequencyData				OCK_CODE(BODE_API, 8)
#define OCK_BODE_GetGainData					OCK_CODE(BODE_API, 9)
#define OCK_BODE_GetPhaseData					OCK_CODE(BODE_API, 10)
#define OCK_BODE_StopSystemIdentify				OCK_CODE(BODE_API, 11)
#define OCK_BODE_GetResonancePoint				OCK_CODE(BODE_API, 12)

//------------------------------------------------------------
// serial scope api
#define OCK_SC_IsSupportDAQ				OCK_CODE(SerialScope_API, 1)
#define OCK_SC_GetSampleFrequency		OCK_CODE(SerialScope_API, 2)
#define OCK_SC_GetSampleTime			OCK_CODE(SerialScope_API, 3)
#define OCK_SC_SetSampleDivider			OCK_CODE(SerialScope_API, 4)
#define OCK_SC_PutDAQChSetting			OCK_CODE(SerialScope_API, 5)
#define OCK_SC_GetDAQChSetting			OCK_CODE(SerialScope_API, 6)
#define OCK_SC_EnableDAQChannel			OCK_CODE(SerialScope_API, 7)
#define OCK_SC_EnableSampleData			OCK_CODE(SerialScope_API, 8)
#define OCK_SC_EnableAuxiliarySignal	OCK_CODE(SerialScope_API, 9)
#define OCK_SC_GetNumDAQChannel			OCK_CODE(SerialScope_API, 10)
#define OCK_SC_AdjustVelChirpSignal		OCK_CODE(SerialScope_API, 11)

//------------------------------------------------------------
// Grinder Interface code
#define OCK_Grinder_DoTuneAngle					OCK_CODE(Grinder_API, 1)
#define OCK_Grinder_CheckGrinderState			OCK_CODE(Grinder_API, 2)

//------------------------------------------------------------
// IO mapping api
#define OCK_IOMap_GetHint				OCK_CODE( IOMapping_API, 1 )
#define OCK_IOMap_GetTableInfo			OCK_CODE( IOMapping_API, 2 )
#define OCK_IOMap_LoadTable				OCK_CODE( IOMapping_API, 3 )
#define OCK_IOMap_RestoreDefaultTable	OCK_CODE( IOMapping_API, 4 )
#define OCK_IOMap_SaveTable				OCK_CODE( IOMapping_API, 5 )
#define OCK_IOMap_IsSRIEnabled			OCK_CODE( IOMapping_API, 6 )
#define OCK_IOMap_IsRestorable			OCK_CODE( IOMapping_API, 7 )

//------------------------------------------------------------
// param api
#define OCK_Param_GetGroupNumOfType			OCK_CODE(PARAM_API, 1)
#define OCK_Param_GetCapacity				OCK_CODE(PARAM_API, 2)
#define OCK_Param_Dump						OCK_CODE(PARAM_API, 3)
#define OCK_Param_PutValue					OCK_CODE(PARAM_API, 4)
#define OCK_Param_GetValue					OCK_CODE(PARAM_API, 5)
#define OCK_Param_Import					OCK_CODE(PARAM_API, 6)
#define OCK_Param_Export					OCK_CODE(PARAM_API, 7)

//------------------------------------------------------------
// Friction Adjust Interface code
#define OCK_FrictionAdjust_GetCtrlParam				OCK_CODE(FrictionAdjust_API, 1)
#define OCK_FrictionAdjust_SetCtrlParam				OCK_CODE(FrictionAdjust_API, 2)
#define OCK_FrictionAdjust_SetArcCuttingInfo		OCK_CODE(FrictionAdjust_API, 3)
#define OCK_FrictionAdjust_CheckDataStatus			OCK_CODE(FrictionAdjust_API, 4)
#define OCK_FrictionAdjust_GetDisplayData			OCK_CODE(FrictionAdjust_API, 5)
#define OCK_FrictionAdjust_GetRawData				OCK_CODE(FrictionAdjust_API, 6)
#define OCK_FrictionAdjust_GetRawDataIndex			OCK_CODE(FrictionAdjust_API, 7)
#define OCK_FrictionAdjust_Clear					OCK_CODE(FrictionAdjust_API, 8)
#define OCK_FrictionAdjust_SetFricCompMethod		OCK_CODE(FrictionAdjust_API, 9)

// Serial Device Api
#define OCK_SD_GetActiveEncoder						OCK_CODE(SerialDevice_API, 1)
#define OCK_SD_ClearMultiTurnAbsEnc					OCK_CODE(SerialDevice_API, 2)
#define OCK_SD_GetDeviceInfo						OCK_CODE(SerialDevice_API, 3)

//------------------------------------------------------------
// General param api
#define OCK_GENERAL_PARAM_GetCapacity				OCK_CODE(GENERAL_PARAM_API, 1)
#define OCK_GENERAL_PARAM_DescriptionTitleDump		OCK_CODE(GENERAL_PARAM_API, 2)
#define OCK_GENERAL_PARAM_CtrlTitleDump				OCK_CODE(GENERAL_PARAM_API, 3)
#define OCK_GENERAL_PARAM_InfoDump					OCK_CODE(GENERAL_PARAM_API, 4)
#define OCK_GENERAL_PARAM_GetValue					OCK_CODE(GENERAL_PARAM_API, 5)
#define OCK_GENERAL_PARAM_PutValue					OCK_CODE(GENERAL_PARAM_API, 6)
#define OCK_GENERAL_PARAM_SearchIndexByDeviceID		OCK_CODE(GENERAL_PARAM_API, 7)

//------------------------------------------------------------
// Strcut Define
#define SIZE_STR					256
#define SIZE_STRING					1024
#define SIZE_PassSeed				20
#define SIZE_PlatForm				80
#define SIZE_ParseBuffer			20480
#define SIZE_CycleDataBuffer		8192
#define SIZE_MDIBLOCKS				1024
#define SIZE_ExeBlocks				256
#define SIZE_XMLDB_TableList		130172
#define SIZE_XMLDB_XLDevice			16384
#define SIZE_XMLDB_PutCycleData		128
#define SIZE_DESKey					10
#define SIZE_DNCBlocks				1024 * 8
#define SIZE_SSV_DEVICEINFO			33
#define SIZE_CoordParamDef			20
#define SIZE_CoordName				32
#define NUM_RobotPosOri				6
#define NUM_RobotPos				3
#define NUM_ExtAxJoints				( 6 )
#define NUM_RobotProtectZoneState	10

//------------------------------------------------------------
// CNC interface code

// OCK_NcStateDump
struct In_OCK_NcStateDumpParams
{
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_NcStateDumpParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	LONG		*lpBuffer;
};

// OCK_NcDebugDump
struct In_OCK_NcDebugDumpParams
{
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_NcDebugDumpParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	LONG		*lpBuffer;
};

// OCK_NcStateGetValue
struct In_OCK_NcStateGetValueParams
{
	LONG		nNo;
};

struct Out_OCK_NcStateGetValueParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_NcStateGetCapacity
struct In_OCK_NcStateGetCapacityParams
{
};

struct Out_OCK_NcStateGetCapacityParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_NcDebugGetCapacity
struct In_OCK_NcDebugGetCapacityParams
{
};

struct Out_OCK_NcDebugGetCapacityParams
{
	HRESULT		hr;
	LONG		nValue;
};

// PlcDumpBits
struct In_OCK_LgcDumpBitsParams
{
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_LgcDumpBitsParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	BYTE		*lpBuffer;
};

// OCK_PlcDumpRRegister
struct In_OCK_LgcDumpRRegisterParams
{
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_LgcDumpRRegisterParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	LONG		*lpBuffer;
};

// OCK_PlcDumpTimer
struct In_OCK_LgcDumpTimerParams
{
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_LgcDumpTimerParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	TLogicTimer		*lpBuffer;
};

// OCK_PlcDumpCounter
struct In_OCK_LgcDumpCounterParams
{
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_LgcDumpCounterParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	TLogicCounter	*lpBuffer;
};

// OCK_PlcGetIBit
struct In_OCK_LgcGetIBitParams
{
	LONG		nNo;
};

struct Out_OCK_LgcGetIBitParams
{
	HRESULT		hr;
	BYTE		Value;
};

// OCK_PlcDevicePutBits
struct In_OCK_PlcDevicePutBitsParams
{
	LONG		nFirst;
	LONG		nLengthToPut;
	BYTE		*lpBuffer;
};

struct Out_OCK_PlcDevicePutBitsParams
{
	HRESULT		hr;
};

// OCK_PlcDevicePutIBit
struct In_OCK_PlcDevicePutIBitParams
{
	LONG		nNo;
	BYTE		newVal;
};

struct Out_OCK_PlcDevicePutIBitParams
{
	HRESULT		hr;
};

// OCK_PlcGetOBit
struct In_OCK_LgcGetOBitParams
{
	LONG		nNo;
};

struct Out_OCK_LgcGetOBitParams
{
	HRESULT		hr;
	BYTE		Value;
};

// OCK_PlcGetCBit
struct In_OCK_LgcGetCBitParams
{
	LONG		nNo;
};

struct Out_OCK_LgcGetCBitParams
{
	HRESULT		hr;
	BYTE		Value;
};

// OCK_PlcPutCBit
struct In_OCK_LgcPutCBitParams
{
	LONG		nNo;
	BYTE		newVal;
};

struct Out_OCK_LgcPutCBitParams
{
	HRESULT		hr;
};

// OCK_PlcGetSBit
struct In_OCK_LgcGetSBitParams
{
	LONG		nNo;
};

struct Out_OCK_LgcGetSBitParams
{
	HRESULT		hr;
	BYTE		Value;
};

// OCK_PlcPutSBit
struct In_OCK_LgcPutSBitParams
{
	LONG		nNo;
	BYTE		newVal;
};

struct Out_OCK_LgcPutSBitParams
{
	HRESULT		hr;
};

// OCK_PlcGetABit
struct In_OCK_LgcGetABitParams
{
	LONG		nNo;
};

struct Out_OCK_LgcGetABitParams
{
	HRESULT		hr;
	BYTE		Value;
};

// OCK_PlcGetRRegister
struct In_OCK_LgcGetRRegisterParams
{
	LONG		nNo;
};

struct Out_OCK_LgcGetRRegisterParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_PlcPutRRegister
struct In_OCK_LgcPutRRegisterParams
{
	LONG		nNo;
	DWORD		newVal;
};

struct Out_OCK_LgcPutRRegisterParams
{
	HRESULT		hr;
};

// OCK_PlcGetTimer
struct In_OCK_LgcGetTimerParams
{
	LONG		nNo;
};

struct Out_OCK_LgcGetTimerParams
{
	HRESULT		hr;
	TLogicTimer	Value;
};

// OCK_PlcGetCounter
struct In_OCK_LgcGetCounterParams
{
	LONG		nNo;
};

struct Out_OCK_LgcGetCounterParams
{
	HRESULT		hr;
	TLogicCounter	Value;
};

// OCK_PlcGetCapacity
struct In_OCK_LgcGetCapacityParams
{
};

struct Out_OCK_LgcGetCapacityParams
{
	HRESULT		hr;
	TPlcCapacity	Value;
};

// OCK_PlcSetForceIOEnable
struct In_OCK_PlcSetForceIOEnableParams
{
	BOOL		bEnabled;
};

struct Out_OCK_PlcSetForceIOEnableParams
{
	HRESULT		hr;
};

// OCK_PlcForceIBit
struct In_OCK_PlcForceIBitParams
{
	LONG		nNo;
	BYTE		newVal;
	BOOL		bHold;
};

struct Out_OCK_PlcForceIBitParams
{
	HRESULT		hr;
};

// OCK_PlcForceOBit
struct In_OCK_PlcForceOBitParams
{
	LONG		nNo;
	BYTE		newVal;
	BOOL		bHold;
};

struct Out_OCK_PlcForceOBitParams
{
	HRESULT		hr;
};

// OCK_PlcForceBitArray
struct In_OCK_PlcForceBitArrayParams
{
	BOOL		bHold;
	LONG		nFirst;
	LONG		nLengthToPut;
	BYTE		*lpBuffer;
};

struct Out_OCK_PlcForceBitArrayParams
{
	HRESULT		hr;
};

// OCK_PlcReleaseHoldIBit
struct In_OCK_PlcReleaseHoldIBitParams
{
	LONG		nNo;
};

struct Out_OCK_PlcReleaseHoldIBitParams
{
	HRESULT		hr;
};

// OCK_PlcReleaseHoldOBit
struct In_OCK_PlcReleaseHoldOBitParams
{
	LONG		nNo;
};

struct Out_OCK_PlcReleaseHoldOBitParams
{
	HRESULT		hr;
};

// OCK_PlcHoldBitReset
struct In_OCK_PlcHoldBitResetParams
{
};

struct Out_OCK_PlcHoldBitResetParams
{
	HRESULT		hr;
};

// OCK_PlcGetHoldIBit
struct In_OCK_PlcGetHoldIBitParams
{
	int			nLengthToRead;
};

struct Out_OCK_PlcGetHoldIBitParams
{
	HRESULT		hr;
	int			nLengthRead;
	int			*lpData;
};

// OCK_PlcGetHoldOBit
struct In_OCK_PlcGetHoldOBitParams
{
	int			nLengthToRead;
};

struct Out_OCK_PlcGetHoldOBitParams
{
	HRESULT		hr;
	int			nLengthRead;
	int			*lpData;
};

// OCK_UpdatePLC
struct In_OCK_UpdatePLC
{
};

struct Out_OCK_UpdatePLC
{
	HRESULT		hr;
	long		nResult;
};

// OCK_NcPutBreakPoint
struct In_OCK_NcPutBreakPoint
{
	int			nCoordID;
	int			nBreakSeqNo;
	int			nBreakLineNo;
};

struct Out_OCK_NcPutBreakPoint
{
	HRESULT		hr;
};

	// OCK_NcGlobalDump
struct In_OCK_NcGlobalDumpParams
{
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_NcGlobalDumpParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	TOcVariant	*lpBuffer;
};

// OCK_NcGlobalGetValue
struct In_OCK_NcGlobalGetValueParams
{
	LONG		nNo;
};

struct Out_OCK_NcGlobalGetValueParams
{
	HRESULT		hr;
	TOcVariant	*lpVal;
};

// OCK_NcGlobalPutValue
struct In_OCK_NcGlobalPutValueParams
{
	LONG		nNo;
	TOcVariant	*newVal;
};

struct Out_OCK_NcGlobalPutValueParams
{
	HRESULT		hr;
};

// OCK_NcGlobalGetCapacity
struct In_OCK_NcGlobalGetCapacityParams
{
};

struct Out_OCK_NcGlobalGetCapacityParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_NcDumpPendingAlarm
struct In_OCK_NcDumpPendingAlarmParams
{
	LONG		nLengthToRead;
};

struct Out_OCK_NcDumpPendingAlarmParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	TOcAlarmInfo	*lpBuffer;
};

// OCK_NcDumpAlarmHistory
struct In_OCK_NcDumpAlarmHistoryParams
{
	LONG		nLengthToRead;
};

struct Out_OCK_NcDumpAlarmHistoryParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	TOcAlarmInfo	*lpBuffer;
};

// OCK_NcCoordVarDump
struct In_OCK_NcCoordVarDumpParams
{
	LONG		CoordID;
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_NcCoordVarDumpParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	TOcVariant	*lpBuffer;
};

// OCK_NcExecuteBlocks
struct In_OCK_NcExecuteBlocksParams
{
	TCHAR		lpszBlocks[SIZE_ExeBlocks];
};

struct Out_OCK_NcExecuteBlocksParams
{
	HRESULT		hr;
};

// OCK_NcPutWorkpieceZero
struct In_OCK_NcPutWorkpieceZeroParams
{
	LONG		nNo;
	TWorkpieceFrame	*lpWF;
};

struct Out_OCK_NcPutWorkpieceZeroParams
{
	HRESULT		hr;
};

// OCK_NcPutExternWorkpieceZero
struct In_OCK_NcPutExternWorkpieceZeroParams
{
	TWorkpieceFrame	*lpWF;
};

struct Out_OCK_NcPutExternWorkpieceZeroParams
{
	HRESULT		hr;
};

// OCK_NcIsCoordSystemFrameWritable
struct In_OCK_NcIsCoordSystemFrameWritable
{
	ECSFrameType	nCSFrameType;
	INT				nWPFrameNo;
};

struct Out_OCK_NcIsCoordSystemFrameWritable
{
	HRESULT		hr;
};

// OCK_NcGetWorkpieceZero
struct In_OCK_NcGetWorkpieceZeroParams
{
	LONG		nFirst;
	LONG		nLengthToRead;
};

struct Out_OCK_NcGetWorkpieceZeroParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	TWorkpieceFrame	*lpBuffer;
};

// OCK_NcGetExternWorkpieceZero
struct In_OCK_NcGetExternWorkpieceZeroParams
{
};

struct Out_OCK_NcGetExternWorkpieceZeroParams
{
	HRESULT		hr;
	TWorkpieceFrame	*lpWF;
};

// OCK_NcGetWorkpieceTableSize
struct In_OCK_NcGetWorkpieceTableSizeParams
{
};

struct Out_OCK_NcGetWorkpieceTableSizeParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_NcCoordVarGetValue
struct In_OCK_NcCoordVarGetValueParams
{
	LONG		CoordID;
	LONG		nNo;
};

struct Out_OCK_NcCoordVarGetValueParams
{
	HRESULT		hr;
	TOcVariant	*lpVal;
};

// OCK_NcCoordVarPutValue
struct In_OCK_NcCoordVarPutValueParams
{
	LONG		CoordID;
	LONG		nNo;
	TOcVariant	*lpNewVal;
};

struct Out_OCK_NcCoordVarPutValueParams
{
	HRESULT		hr;
};

// OCK_CncRegistryPutValue
struct In_OCK_RegistryPutValueParams
{
	LONG		nNo;
	LONG		newVal;
};

struct Out_OCK_RegistryPutValueParams
{
	HRESULT		hr;
};

// OCK_CncRegistryGetValue
struct In_OCK_RegistryGetValueParams
{
	LONG		nNo;
};

struct Out_OCK_RegistryGetValueParams
{
	HRESULT		hr;
	LONG		nValue;
};

struct Out_OCK_IsCRCCorrectParams
{
	HRESULT		hr;
	long		*pbIsCorrect;
};

// OCK_CncSaveString
struct In_OCK_NcSaveStringParams
{
	LONG		nMode;
	LONG		nNo;
	TCHAR		lpszVal[SIZE_STRING];
};

struct Out_OCK_NcSaveStringParams
{
	HRESULT		hr;
};

// OCK_CncLoadString
struct In_OCK_NcLoadStringParams
{
	LONG		nMode;
	LONG		nNo;
	LONG		nLength;
};

struct Out_OCK_NcLoadStringParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_STRING];
};

// OCK_NcGetToolCompensation
struct In_OCK_NcGetToolCompensationParams
{
	LONG		nNo;
};

struct Out_OCK_NcGetToolCompensationParams
{
	HRESULT		hr;
	TToolOffset	*lpBuffer;
};

// OCK_NcPutToolCompensation
struct In_OCK_NcPutToolCompensationParams
{
	LONG		nNo;
	TToolOffset	*lpVal;
};

struct Out_OCK_NcPutToolCompensationParams
{
	HRESULT		hr;
};

// OCK_ParseMacro
struct In_OCK_ParseMacroParams
{
	LONG		nLength;
	LONG		NShift;
	TCHAR		lpszVal[SIZE_ParseBuffer];
};

struct Out_OCK_ParseMacroParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_ParseBuffer];
};

// OCK_NcPutRelativePosition
struct In_OCK_NcPutRelativePositionParams
{
	DWORD		mask;
	LONG		nLength;
	LONG		lpVal[NUMOF_AXIS];
};

struct Out_OCK_NcPutRelativePositionParams
{
	HRESULT		hr;
};

// OCK_NcReset
struct In_OCK_NcResetParams
{
};

struct Out_OCK_NcResetParams
{
	HRESULT		hr;
};

// OCK_RegistryImport
struct In_OCK_RegistryImportParams
{
	TCHAR		lpszFilename[SIZE_STR];
};

struct Out_OCK_RegistryImportParams
{
	HRESULT		hr;
};

// OCK_RegistryExport
struct In_OCK_RegistryExportParams
{
	TCHAR		lpszFilename[SIZE_STR];
};

struct Out_OCK_RegistryExportParams
{
	HRESULT		hr;
};

// OCK_NcGetPendingAlarmSize
struct In_OCK_NcGetPendingAlarmSizeParams
{
};

struct Out_OCK_NcGetPendingAlarmSizeParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_NcClearHint
struct In_OCK_NcClearHintParams
{
};

struct Out_OCK_NcClearHintParams
{
	HRESULT		hr;
};

// OCK_NcClearHistory
struct In_OCK_NcClearHistoryParams
{
};

struct Out_OCK_NcClearHistoryParams
{
	HRESULT		hr;
};

// OCK_NcSetCryptologyKey
struct In_OCK_NcSetCryptologyKeyParams
{
	TCHAR		lpszKeyValue[SIZE_STR];
};

struct Out_OCK_NcSetCryptologyKeyParams
{
	HRESULT		hr;
};

// OCK_NcPutPrecisionParameter
struct In_OCK_NcPutPrecisionParameter
{
	LONG		nNo;
	TPrecisionRecord	lpPR;
};

struct Out_OCK_NcPutPrecisionParameter
{
	HRESULT		hr;
};

// OCK_NcGetPrecisionParameter
struct In_OCK_NcGetPrecisionParameter
{
	LONG		nNo;
};

struct Out_OCK_NcGetPrecisionParameter
{
	HRESULT				hr;
	TPrecisionRecord	lpPR;
};

// OCK_NcGetVersionInfo
struct In_OCK_NcGetVersionInfo
{
	LONG		nLengthToRead;
};

struct Out_OCK_NcGetVersionInfo
{
	HRESULT		hr;
	LONG		nLengthRead;
	TVersionInfo		*lpBuffer;
};

// OCK_UT_getStatus
struct In_OCK_UT_getStatusParams
{
};

struct Out_OCK_UT_getStatusParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_UT_getPassSeed
struct In_OCK_UT_getPassSeedParams
{
	LONG		nLength;
};

struct Out_OCK_UT_getPassSeedParams
{
	HRESULT		hr;
	TCHAR		lpPassSeed[SIZE_PassSeed];
};

// OCK_UT_getTimeStart
struct In_OCK_UT_getTimeStartParams
{
};

struct Out_OCK_UT_getTimeStartParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_UT_getTimeSet
struct In_OCK_UT_getTimeSetParams
{
};

struct Out_OCK_UT_getTimeSetParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_UT_getTimeRemain
struct In_OCK_UT_getTimeRemainParams
{
};

struct Out_OCK_UT_getTimeRemainParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_UT_putUserID
struct In_OCK_UT_putUserIDParams
{
	TCHAR		lpUserID[SIZE_STR];
};

struct Out_OCK_UT_putUserIDParams
{
	HRESULT		hr;
};

// OCK_UT_putPassKey
struct In_OCK_UT_putPassKeyParams
{
	TCHAR		lpPassKey[SIZE_STR];
};

struct Out_OCK_UT_putPassKeyParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_UT_putInnerKey
struct In_OCK_UT_putInnerKeyParams
{
	TCHAR		lpInnerKey[SIZE_STR];
};

struct Out_OCK_UT_putInnerKeyParams
{
	HRESULT		hr;
};

// OCK_UT_getFactoryID
struct In_OCK_UT_getFactoryIDParams
{
	LONG		nLength;
};

struct Out_OCK_UT_getFactoryIDParams
{
	HRESULT		hr;
	TCHAR		lpFactoryID[SIZE_PassSeed];
};

// OCK_UT_putFactoryID
struct In_OCK_UT_putFactoryIDParams
{
	TCHAR		lpFactoryID[SIZE_STR];
};

struct Out_OCK_UT_putFactoryIDParams
{
	HRESULT		hr;
};

// OCK_HW_GetPlatformName
struct In_OCK_HW_GetPlatformNameParams
{
	LONG		nLength;
};

struct Out_OCK_HW_GetPlatformNameParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_PlatForm];
};

// OCK_HW_GetCPUTemperature
struct In_OCK_HW_GetCPUTemperatureParams
{
};

struct Out_OCK_HW_GetCPUTemperatureParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_HW_GetSystemTemperature
struct In_OCK_HW_GetSystemTemperatureParams
{
};

struct Out_OCK_HW_GetSystemTemperatureParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_HW_OnPanelBacklight
struct In_OCK_HW_OnPanelBacklightParams
{
};

struct Out_OCK_HW_OnPanelBacklightParams
{
	HRESULT		hr;
};

// OCK_HW_OffPanelBacklight
struct In_OCK_HW_OffPanelBacklightParams
{
};

struct Out_OCK_HW_OffPanelBacklightParams
{
	HRESULT		hr;
};

// OCK_SWOP_getPassSeed
struct In_OCK_SWOP_getPassSeedParams
{
	LONG		nLength;
};

struct Out_OCK_SWOP_getPassSeedParams
{
	HRESULT		hr;
	TCHAR		lpPassSeed[SIZE_PassSeed];
};

// OCK_SWOP_getModel
struct In_OCK_SWOP_getModelParams
{
	LONG		nLength;
};

struct Out_OCK_SWOP_getModelParams
{
	HRESULT		hr;
	TCHAR		lpModel[SIZE_PassSeed];
};

// OCK_SWOP_getSerialNo
struct In_OCK_SWOP_getSerialNoParams
{
	LONG		nLength;
};

struct Out_OCK_SWOP_getSerialNoParams
{
	HRESULT		hr;
	TCHAR		lpSerialNo[SIZE_PassSeed];
};

// OCK_SWOP_putPassKey
struct In_OCK_SWOP_putPassKeyParams
{
	TCHAR		lpPassKey[SIZE_STR];
};

struct Out_OCK_SWOP_putPassKeyParams
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_SWOP_isOptionEnabled
struct In_OCK_SWOP_isOptionEnabledParams
{
	LONG		nOptionID;
};

struct Out_OCK_SWOP_isOptionEnabledParams
{
	HRESULT		hr;
	LONG		bIsEnabled;
};

// OCK_SWOP_isFunctionEnabled
struct In_OCK_SWOP_isFunctionEnabledParams
{
	LONG		nFunctionID;
};

struct Out_OCK_SWOP_isFunctionEnabledParams
{
	HRESULT		hr;
	LONG		bIsEnabled;
};

// OCK_SWOP_getEnabledAxes
struct In_OCK_SWOP_getEnabledAxesParams
{
};

struct Out_OCK_SWOP_getEnabledAxesParams
{
	HRESULT		hr;
	LONG		EnabledAxes;
};

// OCK_SWOP_getMachine
struct In_OCK_SWOP_getMachineParams
{
	LONG		nLength;
};

struct Out_OCK_SWOP_getMachineParams
{
	HRESULT		hr;
	TCHAR		lpMachine[SIZE_PassSeed];
};

// OCK_SWOP_getNumOfOption
struct In_OCK_SWOP_getNumOfOption
{
};

struct Out_OCK_SWOP_getNumOfOption
{
	HRESULT		hr;
	LONG		nNumOfOption;
};

// OCK_SWOP_getOptionTryLeftTime
struct In_OCK_SWOP_getOptionTryLeftTimeParams
{
	LONG		nOptionID;
};

struct Out_OCK_SWOP_getOptionTryLeftTimeParams
{
	HRESULT		hr;
	LONG		nLeftTime;
};

// OCK_SWOP_getWorkPieceNumber
struct Out_OCK_SWOP_getWorkPieceNumber
{
	HRESULT		hr;
	LONG		nNumber;
};

// OCK_SWOP_getEnabledSpds
struct Out_OCK_SWOP_getEnabledSpds
{
	HRESULT		hr;
	LONG		EnabledSpds;
};

// OCK_NcGetEnvKeyName
struct In_OCK_NcGetEnvKeyName
{
};

struct Out_OCK_NcGetEnvKeyName
{
	HRESULT		hr;
	char		KeyName[SIZE_STR];
};

// OCK_NcGetEnabledToolNumber
struct In_OCK_NcGetEnabledToolNumber
{
};

struct Out_OCK_NcGetEnabledToolNumber
{
	HRESULT		hr;
	LONG		nNumOfTool;
};

// OCK_NcPutPartCountNumber
struct In_OCK_NcPutPartCountNumber
{
	LONG		nCount;
};

struct Out_OCK_NcPutPartCountNumber
{
	HRESULT		hr;
};

// OCK_NcPutRequiredPartCountNumber
struct In_OCK_NcPutRequiredPartCountNumber
{
	LONG		nCount;
};

struct Out_OCK_NcPutRequiredPartCountNumber
{
	HRESULT		hr;
};

// OCK_NcPutTotalPartCountNumber
struct In_OCK_NcPutTotalPartCountNumber
{
	LONG		nCount;
};

struct Out_OCK_NcPutTotalPartCountNumber
{
	HRESULT		hr;
};

// OCK_NcGetPartCountNumber
struct In_OCK_NcGetPartCountNumber
{
};

struct Out_OCK_NcGetPartCountNumber
{
	HRESULT		hr;
	LONG		nCount;
};

// OCK_NcGetRequiredPartCountNumber
struct In_OCK_NcGetRequiredPartCountNumber
{
};

struct Out_OCK_NcGetRequiredPartCountNumber
{
	HRESULT		hr;
	LONG		nCount;
};

// OCK_NcGetTotalPartCountNumber
struct In_OCK_NcGetTotalPartCountNumber
{
};

struct Out_OCK_NcGetTotalPartCountNumber
{
	HRESULT		hr;
	LONG		nCount;
};

// OCK_GetLoaderAxesNumber
struct In_OCK_GetLoaderAxesNumber
{
};

struct Out_OCK_GetLoaderAxesNumber
{
	HRESULT		hr;
	LONG		nAxes;
};

// OCK_NcDumpAlarmHistoryDuration
struct In_OCK_NcDumpAlarmHistoryDuration
{
	LONG				nLengthToRead;
};

struct Out_OCK_NcDumpAlarmHistoryDuration
{
	HRESULT				hr;
	LONG				nLengthRead;
	THistoryALMInfo		*lpBuffer;
};

// OCK_RegistryGetVersion
struct In_OCK_RegistryGetVersionParams
{
};

struct Out_OCK_RegistryGetVersionParams
{
	HRESULT		hr;
	INT			nValue;
};

// OCK_NcSetMachinePosition
struct In_OCK_NcSetMachinePositionParams
{
	INT			nAxisID;
	LONG		nPosition;
};

struct Out_OCK_NcSetMachinePositionParams
{
	HRESULT		hr;
};

// OCK_NcRestorePrecisionParamDefault
struct In_OCK_NcRestorePrecisionParamDefault
{
};

struct Out_OCK_NcRestorePrecisionParamDefault
{
	HRESULT		hr;
};

// OCK_NcSetCheckRegister
struct In_OCK_NcSetCheckRegister
{
	int			nLength;
	int			*pMap;
};

struct Out_OCK_NcSetCheckRegister
{
	HRESULT		hr;
};

// OCK_NcCheckRegisterMaxCount
struct In_OCK_NcCheckRegisterMaxCount
{
};

struct Out_OCK_NcCheckRegisterMaxCount
{
	HRESULT		hr;
	int			nMaxCount;
};


// OCK_GetDesKey
struct In_OCK_GetDesKey
{
	long		nCount;
};

struct Out_OCK_GetDesKey
{
	HRESULT		hr;
	TCHAR		lpKey[SIZE_DESKey];
};

// OCK_IsCoordExist
struct In_OCK_IsCoordExist {
	int			nID;
};

struct Out_OCK_IsCoordExist {
	HRESULT		hr;
	BOOL		bExist;
};

// OCK_NcGetModeGroupCoordNum
struct In_OCK_NcGetModeGroupCoordNum
{
	int			nID;
};

struct Out_OCK_NcGetModeGroupCoordNum
{
	HRESULT		hr;
	int			nNumber;
};

// OCK_NcGetOSInfo
struct In_OCK_NcGetOSInfo
{
	LONG		nNameLength;
};

struct Out_OCK_NcGetOSInfo
{
	HRESULT		hr;
	DWORD		dwMajorVersion;
	DWORD		dwMinorVersion;
	TCHAR		lpName[SIZE_STRING];
};

// OCK_NcGetDirs
struct In_OCK_NcGetDirs
{
	LONG		nLength;
	TCHAR		lpszName[SIZE_STRING];
};

struct Out_OCK_NcGetDirs
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_STRING];
};

// OCK_NcGetDirFiles
struct In_OCK_NcGetDirFiles
{
	LONG		nLength;
	TCHAR		lpDir[SIZE_STRING];
};

struct Out_OCK_NcGetDirFiles
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_STRING];
};

// OCK_NcGetDirFilesInfo
struct In_OCK_NcGetDirFilesInfo
{
	LONG		nLength;
	TCHAR		lpDir[SIZE_STRING];
};

struct Out_OCK_NcGetDirFilesInfo
{
	HRESULT		hr;
	LONG		nLength;
	TOcMyFileInfo *lpBuffer;
};

// OCK_NcGetFreeSpace
struct In_OCK_NcGetFreeSpace
{
};

struct Out_OCK_NcGetFreeSpace
{
	HRESULT		hr;
	__int64		FreeBytesAvailable;
};

// OCK_GetDiskFreeSpace
struct In_OCK_GetDiskFreeSpace
{
	LONG		nLength;
	TCHAR		lpDiskPath[SIZE_STRING];
};

struct Out_OCK_GetDiskFreeSpace
{
	HRESULT		hr;
	__int64		FreeBytesAvailable;
};

// OCK_GetRapidTravelOverride
struct In_OCK_GetRapidTravelOverride
{
};

struct Out_OCK_GetRapidTravelOverride
{
	HRESULT		hr;
	int			Override;
};

// OCK_GetFeedrateOverride
struct In_OCK_GetFeedrateOverride
{
};

struct Out_OCK_GetFeedrateOverride
{
	HRESULT		hr;
	int			Override;
};

// OCK_GetSpindleOverride
struct In_OCK_GetSpindleOverride
{
	LONG		nSpdID;
};

struct Out_OCK_GetSpindleOverride
{
	HRESULT		hr;
	int			Override;
};

// OCK_CoordStateGetValue
struct In_OCK_CoordStateGetValue
{
	LONG		nCoordID;
	LONG		nNo;
};

struct Out_OCK_CoordStateGetValue
{
	HRESULT		hr;
	TOcVariant	*pValue;
};

// OCK_AxisStateGetValue
struct In_OCK_AxisStateGetValue
{
	LONG		nAxisID;
	LONG		nNo;
};

struct Out_OCK_AxisStateGetValue
{
	HRESULT		hr;
	TOcVariant	*pValue;
};

// OCK_SvoDevStateGetValue
struct In_OCK_SvoDevStateGetValue
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	LONG		nNo;
};

struct Out_OCK_SvoDevStateGetValue
{
	HRESULT		hr;
	TOcVariant	*pValue;
};

// OCK_NcReadyToGo
struct In_OCK_NcReadyToGo
{
};

struct Out_OCK_NcReadyToGo
{
	HRESULT		hr;
	BOOL		bReady;
};

// OCK_NcSetMCodeGroupTable
struct In_OCK_NcSetMCodeGroupTable
{
	TMCodeGroupTable MCodeGroupTable;
};

struct Out_OCK_NcSetMCodeGroupTable
{
	HRESULT		hr;
};

// OCK_NcGetMCodeGroupTable
struct In_OCK_NcGetMCodeGroupTable
{
};

struct Out_OCK_NcGetMCodeGroupTable
{
	HRESULT		hr;
	TMCodeGroupTable MCodeGroupTable;
};

// OCK_NcClearAccCycleTime
struct In_OCK_NcClearAccCycleTime
{
};

struct Out_OCK_NcClearAccCycleTime
{
	HRESULT		hr;
};

// OCK_NcRecordModeStart
struct In_OCK_NcRecordModeStart
{
};

struct Out_OCK_NcRecordModeStart
{
	HRESULT		hr;
};

// OCK_NcIsRecordModeEnabled
struct In_OCK_NcIsRecordModeEnabled
{
};

struct Out_OCK_NcIsRecordModeEnabled
{
	HRESULT		hr;
	BOOL		bEnabled;
};

// OCK_NcPutMakerConfigInfo
struct In_OCK_NcPutMakerConfigInfo
{
	TMakerConfigInfo	tMakerConfigInfo;
};

struct Out_OCK_NcPutMakerConfigInfo
{
	HRESULT		hr;
};

// OCK_NcGetMakerConfigInfo
struct In_OCK_NcGetMakerConfigInfo
{
};

struct Out_OCK_NcGetMakerConfigInfo
{
	HRESULT				hr;
	TMakerConfigInfo	tMakerConfigInfo;
};

// OCK_NcPutWorkRecordFlag
struct In_OCK_NcPutWorkRecordFlag
{
	BOOL	bRecordFlag;
};

struct Out_OCK_NcPutWorkRecordFlag
{
	HRESULT		hr;
};

// OCK_NcGetWorkRecordFlag
struct In_OCK_NcGetWorkRecordFlag
{
};

struct Out_OCK_NcGetWorkRecordFlag
{
	HRESULT		hr;
	BOOL		bRecordFlag;
};

// OCK_NcGetAxisLoad
struct In_OCK_NcGetAxisLoad
{
	LONG		nAxisID;
};

struct Out_OCK_NcGetAxisLoad
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_NcPutMainProgram
struct In_OCK_NcPutMainProgram
{
	int			nCoordID;
	LONG		nStartSeqNo;
	LONG		nStartLineNo;
	TCHAR		progname[SIZE_STR];
};

struct Out_OCK_NcPutMainProgram
{
	HRESULT		hr;
};

// OCK_NcGetMainProgramName
struct In_OCK_NcGetMainProgramName
{
	int			nCoordID;
};

struct Out_OCK_NcGetMainProgramName
{
	HRESULT		hr;
	TCHAR		progname[SIZE_STR];
};

// OCK_NcGetProgramName
struct In_OCK_NcGetProgramName
{
	int			nCoordID;
};

struct Out_OCK_NcGetProgramName
{
	HRESULT		hr;
	TCHAR		progname[SIZE_STR];
};

// OCK_NcChangeMetricImperialUnit
struct In_OCK_NcChangeMetricImperialUnit
{
	LONG		nMetricImperialUnit;
};

struct Out_OCK_NcChangeMetricImperialUnit
{
	HRESULT		hr;
};

// OCK_NcGetSysMainProgramName
struct In_OCK_NcGetSysMainProgramName
{
	int			nCoordID;
};

struct Out_OCK_NcGetSysMainProgramName
{
	HRESULT		hr;
	TCHAR		progname[SIZE_STR];
};

// OCK_NcGetExecuteBlockLineNo
struct In_OCK_NcGetExecuteBlockLineNo
{
	int			nCoordID;
};

struct Out_OCK_NcGetExecuteBlockLineNo
{
	HRESULT		hr;
	int			nLineNo;
};

// OCK_NcGetSyncSpdPosData
struct In_OCK_NcGetSyncSpdPosData {
	int			nGroupID;
	int			nReserved;
};

struct Out_OCK_NcGetSyncSpdPosData {
	HRESULT		hr;
	int			nReserved;
	double		StdAngleOffset;
	double		CurAngleDiff;
};

// OCK_NcSetSyncPosData
struct In_OCK_NcSetSyncSpdPosData {
	int			nGroupID;
	int			nReserved;
};

struct Out_OCK_NcSetSyncSpdPosData {
	HRESULT		hr;
	int			nReserved;
};

// OCK_NcPutRemoteMPGCounter
struct In_OCK_NcPutRemoteMPGCounter {
	LONG		nCounter;
};

struct Out_OCK_NcPutRemoteMPGCounter {
	HRESULT		hr;
};

// OCK_GetMMIUniqueKeyParams
struct In_OCK_GetMMIUniqueKeyParams
{
	DWORD		CurKey;
};

struct Out_OCK_GetMMIUniqueKeyParams
{
	HRESULT		hr;
	DWORD		MMIKey;
};

// OCK_ReleaseCurrentParams
struct In_OCK_ReleaseCurrentParams
{
	DWORD		CurKey;
};

struct Out_OCK_ReleaseCurrentParams
{
	HRESULT		hr;
};

// OCK_NcIsBlockGrammarError
struct In_OCK_NcIsBlockGrammarErrorParams
{
	TCHAR		lpszStr[SIZE_CheckBlocksGramaBuff];
	LONG		nHeaderType;
};

struct Out_OCK_NcIsBlockGrammarErrorParams
{
	HRESULT		hr;
	BOOL		isBlockGrammarError;
};

// OCK_NcGetECamProfiles
struct In_OCK_NcGetECamProfilesParams
{
	int nAxisName;
	int nInLength;
	int nOutLength;
	int nReserved;
	double MasterFeedrate;
	double *InData;
};

struct Out_OCK_NcGetECamProfilesParams
{
	HRESULT		hr;
	int nOutLength;
	int nErrCode;
	int nErrFeature;
	double *OutData;
};

// OCK_NcGetFPGASupportFuncNum
struct In_OCK_NcGetFPGASupportFuncNumParams
{
};

struct Out_OCK_NcGetFPGASupportFuncNumParams
{
	HRESULT		hr;
	int			nNumOf_Support;
};

// OCK_SvoDev_GetNum
struct In_OCK_SvoDev_GetNum
{
	LONG		nType;
};

struct Out_OCK_SvoDev_GetNum
{
	HRESULT		hr;
	LONG		nNum;
};

// OCK_SvoDev_GetID
struct In_OCK_SvoDev_GetID
{
	LONG		nType;
};

struct Out_OCK_SvoDev_GetID
{
	HRESULT		hr;
	LONG		*pIDArray;
};

// OCK_LASER_SetHomePosition
struct In_OCK_LASER_SetHomePosition
{
	int			nAxisID;
};

struct Out_OCK_LASER_SetHomePosition
{
	HRESULT		hr;
};

// OCK_LASER_queryLaserFreeBufferSize
struct In_OCK_LASER_queryLaserFreeBufferSize
{
};

struct Out_OCK_LASER_queryLaserFreeBufferSize
{
	long		nFreeSize;
	HRESULT		hr;
};

// OCK_LASER_putPrintData
struct In_OCK_LASER_putPrintData
{
	BYTE		*pData;
};

struct Out_OCK_LASER_putPrintData
{
	HRESULT		hr;
};

//------------------------------------------------------------
// Laser Resonance Suppression interface code

// OCK_LASER_GetServoOnState
struct In_OCK_LASER_GetServoOnState
{
};
struct Out_OCK_LASER_GetServoOnState
{
	HRESULT		hr;
	BOOL		bServoOn;
};

// OCK_LASER_ChangeServoOnState
struct In_OCK_LASER_ChangeServoOnState
{
	BOOL		bServoOn;
};
struct Out_OCK_LASER_ChangeServoOnState
{
	HRESULT		hr;
};

// OCK_LASER_GalvoHomeSetting
struct In_OCK_LASER_GalvoHomeSetting
{
};
struct Out_OCK_LASER_GalvoHomeSetting
{
	HRESULT		hr;
};

// OCK_LASER_GalvoParamGetValue
struct In_OCK_LASER_GalvoParamGetValue
{
	LONG		nAxisID;
	LONG		nNo;
};
struct Out_OCK_LASER_GalvoParamGetValue
{
	HRESULT		hr;
	LONG		nValue;
	int			nStatus;
};

// OCK_LASER_GalvoParamPutValue
struct In_OCK_LASER_GalvoParamPutValue
{
	LONG		nAxisID;
	LONG		nNo;
	LONG		nValue;
};
struct Out_OCK_LASER_GalvoParamPutValue
{
	HRESULT		hr;
	int			nStatus;
};

// laser distortion table correction parameter interface-----

// OCK_LASER_SetTableMode
struct In_OCK_LASER_SetTableMode
{
	long		nMode;
};
struct Out_OCK_LASER_SetTableMode
{
	HRESULT		hr;
};

// OCK_LASER_GetTableMode
struct In_OCK_LASER_GetTableMode
{
};
struct Out_OCK_LASER_GetTableMode
{
	HRESULT		hr;
	long		nMode;
};

// OCK_LASER_SetFocalLength
struct In_OCK_LASER_SetFocalLength
{
	long		nFocalLength; // unit: BLU
};
struct Out_OCK_LASER_SetFocalLength
{
	HRESULT		hr;
};

// OCK_LASER_GetFocalLength
struct In_OCK_LASER_GetFocalLength
{
};
struct Out_OCK_LASER_GetFocalLength
{
	HRESULT		hr;
	long		nFocalLength; // unit: BLU
};

// OCK_LASER_SetDesiredCentralLength
struct In_OCK_LASER_SetDesiredCentralLength
{
	long		nDesiredCentralLength; // unit: BLU
};
struct Out_OCK_LASER_SetDesiredCentralLength
{
	HRESULT		hr;
};

// OCK_LASER_GetDesiredCentralLength
struct In_OCK_LASER_GetDesiredCentralLength
{
};
struct Out_OCK_LASER_GetDesiredCentralLength
{
	HRESULT		hr;
	long		nLength; // unit: BLU
};

// OCK_LASER_SetGridCount
struct In_OCK_LASER_SetGridCount
{
	long			nGridCount;
};
struct Out_OCK_LASER_SetGridCount
{
	HRESULT		hr;
};

// OCK_LASER_GetGridCount
struct In_OCK_LASER_GetGridCount
{
};
struct Out_OCK_LASER_GetGridCount
{
	HRESULT		hr;
	long		nGridCount;
};

// OCK_LASER_SetActualCentralLength
struct In_OCK_LASER_SetActualCentralLength
{
	long		nCount;
	long		*pActualLength; // unit: BLU, length = nCount * 2 * sizeof( long )
};
struct Out_OCK_LASER_SetActualCentralLength
{
	HRESULT		hr;
};

// OCK_LASER_GetActualCentralCount
struct In_OCK_LASER_GetActualCentralCount
{
};
struct Out_OCK_LASER_GetActualCentralCount
{
	HRESULT hr;
	long nCount;
};

// OCK_LASER_GetActualCentralLength
struct In_OCK_LASER_GetActualCentralLength
{
};
struct Out_OCK_LASER_GetActualCentralLength
{
	HRESULT		hr;
	long		*pLength; // unit: BLU, length = nCount * 2 * sizeof( long )
};

// OCK_LASER_SetBarrelFactor
struct In_OCK_LASER_SetBarrelFactor
{
	double		BarrelFactorX_Ng; // negative direction
	double		BarrelFactorX_Ps; // positive direction
	double		BarrelFactorY_Ng; // negative direction
	double		BarrelFactorY_Ps; // positive direction
};
struct Out_OCK_LASER_SetBarrelFactor
{
	HRESULT		hr;
};

// OCK_LASER_GetBarrelFactor
struct In_OCK_LASER_GetBarrelFactor
{
};
struct Out_OCK_LASER_GetBarrelFactor
{
	HRESULT		hr;
	double		BarrelFactorX_Ng; // negative direction
	double		BarrelFactorX_Ps; // positive direction
	double		BarrelFactorY_Ng; // negative direction
	double		BarrelFactorY_Ps; // positive direction
};

// OCK_LASER_SetRotationInfo
struct In_OCK_LASER_SetRotationInfo
{
	long		nAngle;   // unit: 1e-6 degree
	long		nCenterX; // unit: BLU
	long		nCenterY; // unit: BLU
};
struct Out_OCK_LASER_SetRotationInfo
{
	HRESULT		hr;
};

// OCK_LASER_GetRotationInfo
struct In_OCK_LASER_GetRotationInfo
{
};
struct Out_OCK_LASER_GetRotationInfo
{
	HRESULT		hr;
	long		nAngle;	  // unit: 1e-6 degree
	long		nCenterX; // unit: BLU
	long		nCenterY; // unit: BLU
};

// OCK_LASER_SetGeomAdjustParam
struct In_OCK_LASER_SetGeomAdjustParam
{
	long		nSelect;   // 0:Parallelogram, 1: Trapezoid
	long		nFactorX; // unit: BLU
	long		nFactorY; // unit: BLU
};
struct Out_OCK_LASER_SetGeomAdjustParam
{
	HRESULT		hr;
};

// OCK_LASER_GetGeomAdjustParam
struct In_OCK_LASER_GetGeomAdjustParam
{
	long		nSelect;	// 0:Parallelogram, 1: Trapezoid
};
struct Out_OCK_LASER_GetGeomAdjustParam
{
	HRESULT		hr;
	long		nFactorX; // unit: BLU
	long		nFactorY; // unit: BLU
};

// OCK_LASER_AdjustSpecifiedPoint
struct In_OCK_LASER_AdjustSpecifiedPoint
{
	long		nXCount;
	long		nYCount;
	long		nMaxSize;
	long		PosCmd[2];    // unit: BLU
	long		ActualPos[2]; // unit: BLU
};
struct Out_OCK_LASER_AdjustSpecifiedPoint
{
	HRESULT		hr;
};

// OCK_LASER_SetZAxisInfo
struct In_OCK_LASER_SetZAxisInfo
{
	long		nZCount;
	long		nZAngleMin; // unit: BLU
	long		nZAngleMax; // unit: BLU
	long		*pZPos; // unit: BLU, length = nZCount * sizeof( long )
};
struct Out_OCK_LASER_SetZAxisInfo
{
	HRESULT		hr;
};

// OCK_LASER_GetZAxisCount
struct In_OCK_LASER_GetZAxisCount
{
};
struct Out_OCK_LASER_GetZAxisCount
{
	HRESULT hr;
	long nZCount;
};

// OCK_LASER_GetZAxisInfo
struct In_OCK_LASER_GetZAxisInfo
{
};
struct Out_OCK_LASER_GetZAxisInfo
{
	HRESULT		hr;
	long		nZAngleMin; // unit: BLU
	long		nZAngleMax; // unit: BLU
	long		*pZPos; // unit: BLU, length = nZCount * sizeof( long )
};

// OCK_LASER_SetScaleAndOffset
struct In_OCK_LASER_SetScaleAndOffset
{
	long		nLayerCount;
	long		*pSetting; // length = nLayerCount * 4 * sizeof( long )
};
struct Out_OCK_LASER_SetScaleAndOffset
{
	HRESULT		hr;
};

// OCK_LASER_GetScaleAndOffset
struct In_OCK_LASER_GetScaleAndOffset
{
};
struct Out_OCK_LASER_GetScaleAndOffset
{
	HRESULT		hr;
	long		*pSetting; // length = nLayerCount * 4 * sizeof( long )
};

// OCK_LASER_PutDCTParam
struct In_OCK_LASER_PutDCTParam
{
	long nSize;
	BYTE *pData;
};
struct Out_OCK_LASER_PutDCTParam
{
	HRESULT hr;
};

// OCK_LASER_GetDCTParamCount
struct In_OCK_LASER_GetDCTParamCount
{
};
struct Out_OCK_LASER_GetDCTParamCount
{
	HRESULT hr;
	long nSize;
};

// OCK_LASER_GetDCTParam
struct In_OCK_LASER_GetDCTParam
{
};
struct Out_OCK_LASER_GetDCTParam
{
	HRESULT hr;
	BYTE *pData;
};

// OCK_LASER_SaveDCTData
struct In_OCK_LASER_SaveDCTData
{
	long nDestination;
};
struct Out_OCK_LASER_SaveDCTData
{
	HRESULT hr;
};

// OCK_LASER_ClearDCTData
struct In_OCK_LASER_ClearDCTData
{
	long nDestination;
};

struct Out_OCK_LASER_ClearDCTData
{
	HRESULT hr;
};

// OCK_LASER_SetDCTUserStrokeLimit
struct In_OCK_LASER_SetDCTUserStrokeLimit
{
	LONG nDir;
	LONG nMin;
	LONG nMax;
};

struct Out_OCK_LASER_SetDCTUserStrokeLimit
{
	HRESULT hr;
};

// OCK_LASER_GetDCTUserStrokeLimit
struct In_OCK_LASER_GetDCTUserStrokeLimit
{
	LONG nDir;
};

struct Out_OCK_LASER_GetDCTUserStrokeLimit
{
	HRESULT hr;
	LONG nMin;
	LONG nMax;
};

// OCK_LASER_SetRLDCTAdjScaleAndOffset
struct In_OCK_LASER_SetRLDCTAdjScaleAndOffset
{
	LONG nScaleX; // unit�G0.001
	LONG nScaleY; // unit�G0.001
	LONG nOffsetX; // unit�G1 BLU (um)
	LONG nOffsetY; // unit�G1 BLU (um)
};

struct Out_OCK_LASER_SetRLDCTAdjScaleAndOffset
{
	HRESULT hr;
};

// OCK_LASER_GetRLDCTAdjScaleAndOffset
struct In_OCK_LASER_GetRLDCTAdjScaleAndOffset
{
};

struct Out_OCK_LASER_GetRLDCTAdjScaleAndOffset
{
	HRESULT hr;
	LONG nScaleX; // unit�G0.001
	LONG nScaleY; // unit�G0.001
	LONG nOffsetX; // unit�G1 BLU (um)
	LONG nOffsetY; // unit�G1 BLU (um)
};

// OCK_LASER_SetDCTType
struct In_OCK_LASER_SetDCTType
{
	LONG nType;		// 0�GLaser DCT; 1:Red Light DCT
};

struct Out_OCK_LASER_SetDCTType
{
	HRESULT hr;
};

// OCK_LASER_GetDCTType
struct In_OCK_LASER_GetDCTType
{
};

struct Out_OCK_LASER_GetDCTType
{
	HRESULT hr;
	LONG nType;		// 0�GLaser DCT; 1:Red Light DCT
};

// OCK_LASER_CopyDCTFromLsrToRL
struct In_OCK_LASER_CopyDCTFromLsrToRL
{
};

struct Out_OCK_LASER_CopyDCTFromLsrToRL
{
	HRESULT hr;
};

// OCK_LASER_GetObjectQueueRemNum
struct In_OCK_LASER_GetObjectQueueRemNum
{
};

struct Out_OCK_LASER_GetObjectQueueRemNum
{
	HRESULT hr;
	LONG nRemNum;
};


// OCK_LASER_SetObjectOffsetAndAngle
struct In_OCK_LASER_SetObjectOffsetAndAngle
{
	BOOL bDetectRes;
	LONG nObjNum;
	TObjOffsetAng2D *ObjData;
};

struct Out_OCK_LASER_SetObjectOffsetAndAngle
{
	HRESULT hr;
};

// OCK_LASER_GetObjectLostNum
struct In_OCK_LASER_GetObjectLostNum
{
};

struct Out_OCK_LASER_GetObjectLostNum
{
	HRESULT hr;
	LONG nObjectLostNum;
};

// OCK_LASER_ResetObjectLostNum
struct In_OCK_LASER_ResetObjectLostNum
{
};

struct Out_OCK_LASER_ResetObjectLostNum
{
	HRESULT hr;
};


//------------------------------------------------------------
// Servo Data API interface code

// OCK_SSV_GetDeviceInfo
struct In_OCK_SSV_GetDeviceInfoParams
{
	LONG		nAxisId;
	LONG		nFunctionCode;
};

struct Out_OCK_SSV_GetDeviceInfoParams
{
	HRESULT		hr;
	TCHAR		szDeviceInfo[SIZE_SSV_DEVICEINFO];
};

// OCK_SerialServoIsConnect
struct In_OCK_SerialServoIsConnect
{
};

struct Out_OCK_SerialServoIsConnect
{
	HRESULT		hr;
	BOOL		bConnect;
};

// OCK_GetProtocolType
struct In_OCK_GetProtocolType
{
};

struct Out_OCK_GetProtocolType
{
	HRESULT		hr;
	LONG		nProtocolType;
};

//------------------------------------------------------------
// data acquisition API interface code

// OCK_DQ_Init
struct In_OCK_DQ_InitParams
{
	long		nNumOfChannel;
	long		nDataLength;
	long		nSampleInterval;
	long		nBufferLength;
	long		*pnFuncID;
	long		*pnArgument;
};

struct Out_OCK_DQ_InitParams
{
	HRESULT		hr;
};

// OCK_DQ_IsBusy
struct In_OCK_DQ_IsBusyParams
{
};

struct Out_OCK_DQ_IsBusyParams
{
	HRESULT		hr;
	long		bIsBusy;
};

// OCK_DQ_GetProgressPercentage
struct In_OCK_DQ_GetProgressPercentageParams
{
};

struct Out_OCK_DQ_GetProgressPercentageParams
{
	HRESULT		hr;
	long		nPercentage;
};

// OCK_DQ_GetTimeBase
struct In_OCK_DQ_GetTimeBaseParams
{
};

struct Out_OCK_DQ_GetTimeBaseParams
{
	HRESULT		hr;
	long		nTimebase;
};

// OCK_DQ_Start
struct In_OCK_DQ_StartParams
{
};

struct Out_OCK_DQ_StartParams
{
	HRESULT		hr;
};

// OCK_DQ_Abort
struct In_OCK_DQ_AbortParams
{
};

struct Out_OCK_DQ_AbortParams
{
	HRESULT		hr;
};

// OCK_DQ_GetData
struct In_OCK_DQ_GetDataParams
{
	LONG		nLengthToRead;
};

struct Out_OCK_DQ_GetDataParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	long		*lpBuffer;
};

// OCK_DQ_GetDataDouble
struct In_OCK_DQ_GetDataDoubleParams
{
	LONG		nLengthToRead;
};

struct Out_OCK_DQ_GetDataDoubleParams
{
	HRESULT		hr;
	LONG		nLengthRead;
	double		*lpBuffer;
};

//------------------------------------------------------------
// XMLDB interface code

// OCK_XMLDB_SetDatabaseLocation
struct In_OCK_XMLDB_SetDatabaseLocationParams
{
	TCHAR		lpszLocation[SIZE_STR];
};

struct Out_OCK_XMLDB_SetDatabaseLocationParams
{
	HRESULT		hr;
};

// OCK_XMLDB_AddDatabaseLocation
struct In_OCK_XMLDB_AddDatabaseLocationParams
{
	TCHAR		lpszLocation[SIZE_STR];
};

struct Out_OCK_XMLDB_AddDatabaseLocationParams
{
	HRESULT		hr;
	DWORD		nKey;
};

// OCK_XMLDB_SetSchemaLocation
struct In_OCK_XMLDB_SetSchemaLocationParams
{
	TCHAR		lpszLocation[SIZE_STR];
};

struct Out_OCK_XMLDB_SetSchemaLocationParams
{
	HRESULT		hr;
};

// OCK_XMLDB_AddSchemaLocation
struct In_OCK_XMLDB_AddSchemaLocationParams
{
	TCHAR		lpszLocation[SIZE_STR];
};

struct Out_OCK_XMLDB_AddSchemaLocationParams
{
	HRESULT		hr;
};

// OCK_XMLDB_SaveCycleData
struct In_OCK_XMLDB_SaveCycleDataParams
{
	DWORD		nKey;
	TCHAR		lpszTableName[SIZE_STR];
	TCHAR		lpszCycleName[SIZE_STR];
};

struct Out_OCK_XMLDB_SaveCycleDataParams
{
	HRESULT		hr;
};

// OCK_XMLDB_LoadCycleData
struct In_OCK_XMLDB_LoadCycleDataParams
{
	DWORD		nLength;
	DWORD		nKey;
	TCHAR		lpszTableName[SIZE_STR];
};

struct Out_OCK_XMLDB_LoadCycleDataParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_STR];
};

// OCK_XMLDB_NewCycleData
struct In_OCK_XMLDB_NewCycleDataParams
{
	DWORD		nKey;
	TCHAR		lpszCycleName[SIZE_STR];
};

struct Out_OCK_XMLDB_NewCycleDataParams
{
	HRESULT		hr;
};

// OCK_XMLDB_DeleteTable
struct In_OCK_XMLDB_DeleteTableParams
{
	DWORD		nKey;
	TCHAR		lpszTableName[SIZE_STR];
};

struct Out_OCK_XMLDB_DeleteTableParams
{
	HRESULT		hr;
};

// OCK_XMLDB_GetTableList
struct In_OCK_XMLDB_GetTableListParams
{
	DWORD		nLength;
	DWORD		nKey;
	TCHAR		lpszTableDir[SIZE_STR];
};

struct Out_OCK_XMLDB_GetTableListParams
{
	HRESULT		hr;
	DWORD		nLength;
	TCHAR		lpBuffer[SIZE_XMLDB_TableList];
};

// OCK_XMLDB_GetXLDevice
struct In_OCK_XMLDB_GetXLDeviceParams
{
	long		nNo;
	LONG		nLength;
	DWORD		nKey;
};

struct Out_OCK_XMLDB_GetXLDeviceParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_XMLDB_XLDevice];
};

// OCK_XMLDB_PutXLDevice
struct In_OCK_XMLDB_PutXLDeviceParams
{
	long		nNo;
	DWORD		nKey;
	TCHAR		lpszNewValue[SIZE_XMLDB_XLDevice];
};

struct Out_OCK_XMLDB_PutXLDeviceParams
{
	HRESULT		hr;
};

// OCK_XMLDB_GetCycleData
struct In_OCK_XMLDB_GetCycleDataParams
{
	DWORD		nLength;
	DWORD		nKey;
	TCHAR		lpszCycleName[SIZE_STR];
};

struct Out_OCK_XMLDB_GetCycleDataParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_CycleDataBuffer];
};

// OCK_XMLDB_PutCycleData
struct In_OCK_XMLDB_PutCycleDataParams
{
	DWORD		nLength;
	DWORD		nKey;
	TCHAR		lpszCycleXml[SIZE_CycleDataBuffer];
};

struct Out_OCK_XMLDB_PutCycleDataParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_XMLDB_PutCycleData];
};

// OCK_XMLDB_GetDataBaseLocation
struct In_OCK_XMLDB_GetDataBaseLocationParams
{
	DWORD		nKey;
};

struct Out_OCK_XMLDB_GetDataBaseLocationParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[MAX_PATH];
};

// OCK_XMLDB_DeleteDatabaseLocation
struct In_OCK_XMLDB_DeleteDataBaseLocationParams
{
	DWORD		nKey;
};

struct Out_OCK_XMLDB_DeleteDataBaseLocationParams
{
	HRESULT		hr;
};
//-------------------------------------------------------------
// CNC simulation interface

// OCK_SMCreate
struct In_OCK_SMCreateParams
{
	DWORD		HMIKey;
};

struct Out_OCK_SMCreateParams
{
	HRESULT		hr;
	DWORD		dwHandle;
};

// OCK_SMClose
struct In_OCK_SMCloseParams
{
	DWORD		dwHandle;
	DWORD		HMIKey;
};

struct Out_OCK_SMCloseParams
{
	HRESULT		hr;
};

// OCK_SMUpdateKey
struct In_OCK_SMUpdateKeyParams
{
	DWORD		dwHandle;
	DWORD		HMIKey;
};

struct Out_OCK_SMUpdateKeyParams
{
	HRESULT		hr;
	DWORD		dwHandle;
};

// OCK_SMPlay
struct In_OCK_SMPlayParams
{
	DWORD		dwHandle;
	LONG		CoordID;
	DWORD		HMIKey;
	TCHAR		lpszProgName[SIZE_STR];
};

struct Out_OCK_SMPlayParams
{
	HRESULT		hr;
};

// OCK_SMStop
struct In_OCK_SMStopParams
{
	DWORD		dwHandle;
	DWORD		HMIKey;
};

struct Out_OCK_SMStopParams
{
	HRESULT		hr;
};

// OCK_SMGetBlockData
struct In_OCK_SMGetBlockDataParams
{
	DWORD		dwHandle;
	DWORD		nLengthToRead;
	DWORD		HMIKey;
};

struct Out_OCK_SMGetBlockDataParams
{
	HRESULT		hr;
	DWORD		nLengthRead;
	BOOL		bSucceeded;
	TNcBlockData *lpBuffer;
};

// OCK_SMGetAxisDimContexts
struct In_OCK_SMGetAxisDimContextsParams
{
	DWORD		dwHandle;
	DWORD		nLengthToRead;
	DWORD		HMIKey;
};

struct Out_OCK_SMGetAxisDimContextsParams
{
	HRESULT		hr;
	DWORD		nLengthRead;
	TAxisDimContext *lpBuffer;
};

// OCK_SMGetAlarmLocation
struct In_OCK_SMGetAlarmLocationParams
{
	DWORD		dwHandle;
	LONG		nLength;
	DWORD		HMIKey;
};

struct Out_OCK_SMGetAlarmLocationParams
{
	HRESULT		hr;
	LONG		nLineNo;
	LONG		nSequenceNo;
	TCHAR		lpszProgName[SIZE_STR];
};

// OCK_SMSetSearchPath
struct In_OCK_SMSetSearchPathParams
{
	DWORD		dwHandle;
	DWORD		HMIKey;
	TCHAR		lpszPath[SIZE_STR];
};

struct Out_OCK_SMSetSearchPathParams
{
	HRESULT		hr;
};

// OCK_SMGetSearchPath
struct In_OCK_SMGetSearchPathParams
{
	DWORD		dwHandle;
	DWORD		nLength;
	DWORD		HMIKey;
};

struct Out_OCK_SMGetSearchPathParams
{
	HRESULT		hr;
	TCHAR		lpBuffer[SIZE_STR];
};

// OCK_SMIsEOF
struct In_OCK_SMIsEOFParams
{
	DWORD		dwHandle;
	DWORD		HMIKey;
};

struct Out_OCK_SMIsEOFParams
{
	HRESULT		hr;
	BOOL		bEOF;
};

// OCK_SMIsAlarm
struct In_OCK_SMIsAlarmParams
{
	DWORD		dwHandle;
	DWORD		HMIKey;
};

struct Out_OCK_SMIsAlarmParams
{
	HRESULT		hr;
	BOOL		bAlarm;
};

// OCK_SMPutMDIBlocks
struct In_OCK_SMPutMDIBlocksParams
{
	DWORD		dwHandle;
	DWORD		HMIKey;
	TCHAR		lpszBlocks[SIZE_STR];
};

struct Out_OCK_SMPutMDIBlocksParams
{
	HRESULT		hr;
};

// OCK_SMGlobalGetValue
struct In_OCK_SMGlobalGetValueParams
{
	DWORD		dwHandle;
	LONG		nNo;
	DWORD		HMIKey;
};

struct Out_OCK_SMGlobalGetValueParams
{
	HRESULT		hr;
	TOcVariant	Value;
};

// OCK_SMGetAlarmList
struct In_OCK_SMGetAlarmListParams
{
	DWORD		dwHandle;
	DWORD		nLengthToRead;
	DWORD		HMIKey;
};

struct Out_OCK_SMGetAlarmListParams
{
	HRESULT		hr;
	DWORD		nLengthRead;
	TOcAlarmInfo *lpBuffer;
};

// OCK_SMSetStartLineNo
struct In_OCK_SMSetStartLineNoParams
{
	DWORD		dwHandle;
	LONG		nLineNumber;
	DWORD		HMIKey;
};

struct Out_OCK_SMSetStartLineNoParams
{
	HRESULT		hr;
};

struct In_OCK_SMUpdateLifeParams
{
	DWORD		HMIKey;
};

struct Out_OCK_SMUpdateLifeParams
{
	HRESULT		hr;
};

// OCK_DNC_GetBufferSize
struct Out_OCK_DNC_GetBufferSizeParams
{
	HRESULT		hr;
	long		nDNCBufferSize;
};

// OCK_DNC_PutBlocks
struct In_OCK_DNC_PutBlocksParams
{
	TCHAR		lpszSTR[SIZE_DNCBlocks];
};

struct Out_OCK_DNC_PutBlocksParams
{
	HRESULT		hr;
};

// OCK_DNC_IsStreamEmpty
struct In_OCK_DNC_IsStreamEmptyParams
{
};

struct Out_OCK_DNC_IsStreamEmptyParams
{
	HRESULT		hr;
	BOOL		isStreamEmpty;
};

// OCK_DNC_Reset
struct In_OCK_DNC_ResetParams
{
};

struct Out_OCK_DNC_ResetParams
{
	HRESULT		hr;
};

// OCK_DNC_IsStreamReady
struct In_OCK_DNC_IsStreamReadyParams
{
};

struct Out_OCK_DNC_IsStreamReadyParams
{
	HRESULT		hr;
	BOOL		isReady;
};

// OCK_DNC_MaxCmdSizeInChar
struct In_OCK_DNC_MaxCmdSizeInCharParams
{
};

struct Out_OCK_DNC_MaxCmdSizeInCharParams
{
	HRESULT		hr;
	DWORD		nSize;
};

// OCK_OPLogPost
struct In_OCK_OPLogPostParams
{
	UINT32		nLogData;
};

struct Out_OCK_OPLogPostParams
{
	HRESULT		hr;
};

// OCK_OPLogFlush
struct In_OCK_OPLogFlush
{
};

struct Out_OCK_OPLogFlush
{
	HRESULT		hr;
};

// OCK_OPLogDump
struct In_OCK_OPLogDump
{
	UINT32		hDumpHandle;
	UINT32		nLogDataCount;
	BYTE		bStart;
};

struct Out_OCK_OPLogDump
{
	HRESULT		hr;
	UINT32		hDumpHandle;
	UINT32		nLogDataCount;
	int			nRestCount;
	UINT32		*lpLogData;
};

// RegisterListenerEvent / UnregisterListenerEvent
struct In_OCK_ListenerEvent
{
	INT			nUserID;
	// event ID
	USHORT			nEvtID;
	USHORT			nEvtArg;
	// start rule
	USHORT			nStartID;
	USHORT			nStartArg;
	// end rule
	USHORT			nEndID;
	USHORT			nEndArg;
	// catch data
	DWORD			nCatchType;
	USHORT			nCatchArg;
};

// RegisterListenerEvent / UnregisterListenerEvent / DeinitListener / ListenerAlive
struct Out_OCK_Result
{
	LONG			hr;
};

// InitListener
struct In_OCK_InitDumpBufferListener
{
	LONG		nBufferSize;
};

// InitListener set buffer size and PackLength
struct In_OCK_InitDumpBufferPackListener
{
	LONG		nBufferSize;
	LONG		nPackLength;
	BOOL		bSuspend;
};

struct Out_OCK_InitDumpBufferListener
{
	HRESULT		hr;
	int		nUserID;
};

// DumpListenerData
struct In_OCK_DumpListenerData
{
	int		nUserID;
	int		nBufferSize;
};

// DumpListenerData
struct Out_OCK_DumpListenerData
{
	HRESULT		hr;
	int			nReadSize;
	UINT32		nErrCode;
	BYTE*		byte;
};

struct In_OCK_UserID
{
	int		nUserID;
};

// OCK_Listener_DumpRawData
struct In_OCK_Listener_DumpRawData
{
	int			nUserID;
	int			nBufferSize;
};

struct Out_OCK_Listener_DumpRawData
{
	HRESULT		hr;
	int			nReadSize;
	BYTE		*pData;
};

//------------------------------------------------------------
// Serial PLC Axis Interface code

// OCK_SPLCA_GetMonitorData
struct In_OCK_SPLCA_GetMonitorData
{
	int			nID;
};

struct Out_OCK_SPLCA_GetMonitorData
{
	HRESULT		hr;
	LONG		nMode;
	BOOL		bRunning;
	BOOL		bFeedhold;
	BOOL		bAlarm;
	BOOL		bReady;
	BOOL		bReached;
	BOOL		bAbsMode;
	BOOL		bServoOn;
	LONG		TargetPosition;			// in um, 0.001 deg
	LONG		TargetVelocity;			// in mm / min, deg / min
	LONG		CurPosition;			// in um, 0.001 deg
	LONG		CurVelocity;			// in mm / min, deg / min
	BOOL		bMPGCtrl;
};

// OCK_SPLCA_GetNumOfMaxAxis
struct In_OCK_SPLCA_GetNumOfMaxAxis
{
};

struct Out_OCK_SPLCA_GetNumOfMaxAxis
{
	HRESULT		hr;
	LONG		nSize;
};

//------------------------------------------------------------
// SRI Interface code

// OCK_SRI_ReadCommConfig
struct In_OCK_SRI_ReadCommConfig
{
	INT			nCommPort;
};

struct Out_OCK_SRI_ReadCommConfig
{
	HRESULT		hr;
	BOOL		bEnabled;
	LONG		ProtocolType;
	LONG		Baudrate;
	LONG		ControlMode;
	LONG		ScanTime;
	LONG		Timeout;
};

// OCK_SRI_WriteCommConfig
struct In_OCK_SRI_WriteCommConfig
{
	INT			nCommPort;
	BOOL		bEnabled;
	LONG		ProtocolType;
	LONG		Baudrate;
	LONG		ControlMode;
	LONG		ScanTime;
	LONG		Timeout;
};

struct Out_OCK_SRI_WriteCommConfig
{
	HRESULT		hr;
};

// OCK_SRI_ReadStationInfo
struct In_OCK_SRI_ReadStationInfo
{
	INT				nCommPort;
	INT				nStationID;
};

struct Out_OCK_SRI_ReadStationInfo
{
	HRESULT			hr;
	TStationInfo	OldStationInfo;
	TStationInfo	NewStationInfo;
};

// OCK_SRI_WriteStationInfo
struct In_OCK_SRI_WriteStationInfo
{
	INT				nCommPort;
	INT				nStationID;
	TStationInfo	StationInfo;
};

struct Out_OCK_SRI_WriteStationInfo
{
	HRESULT			hr;
};

// OCK_SRI_ReadStationState
struct In_OCK_SRI_ReadStationState
{
	INT				nCommPort;
	INT				nStationID;
};

struct Out_OCK_SRI_ReadStationState
{
	HRESULT			hr;
	TStationState	StationState;
};

// OCK_SRI_SaveStationInfo
struct In_OCK_SRI_SaveStationInfo
{
};

struct Out_OCK_SRI_SaveStationInfo
{
	HRESULT			hr;
	INT				nRepeatedRbit;
};

// OCK_SRI_UpdateFirmware
struct In_OCK_SRI_UpdateFirmware
{
	INT			nCommPort;
	INT			nStationID;
	BOOL		bSelectSlot[ MAX_MODULEPERSTATION ];
	TCHAR		lpszFilename[ SIZE_STR ];
};

struct Out_OCK_SRI_UpdateFirmware
{
	HRESULT		hr;
};

// OCK_SRI_UpdateFirmwareProgress
struct In_OCK_SRI_UpdateFirmwareProgress
{
};

struct Out_OCK_SRI_UpdateFirmwareProgress
{
	HRESULT		hr;
	INT			nPercent;
	INT			nState;
};

// OCK_SRI_ReadCommDbState
struct In_OCK_SRI_ReadCommDbState
{
	INT				nCommPort;
};

struct Out_OCK_SRI_ReadCommDbState
{
	HRESULT			hr;
	BOOL			bRunning;
	LONG			RealScanTime;
};

// OCK_SRI_ReadStationDbState
struct In_OCK_SRI_ReadStationDbState
{
	INT				nCommPort;
	INT				nStationID;
};

struct Out_OCK_SRI_ReadStationDbState
{
	HRESULT			hr;
	TStationDbState	StationDbState;
};

// OCK_SRI_QueryModuleInfo
struct In_OCK_SRI_QueryModuleInfo
{
};

struct Out_OCK_SRI_QueryModuleInfo
{
	HRESULT			hr;
};

// OCK_Param_GetGroupNumOfType
struct In_OCK_Param_GetGroupNumOfType
{
	INT			nType;
};

struct Out_OCK_Param_GetGroupNumOfType
{
	HRESULT		hr;
	INT			nNum;
};

// OCK_Param_GetCapacity
struct In_OCK_Param_GetCapacity
{
	INT			nType;
	INT			nID;
};

struct Out_OCK_Param_GetCapacity
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_Param_Dump
struct In_OCK_Param_Dump
{
	INT			nType;
	INT			nID;
	LONG		nLength;
};

struct Out_OCK_Param_Dump
{
	HRESULT		hr;
	TParamSpec	*lpBuffer;
};

// OCK_Param_PutValue
struct In_OCK_Param_PutValue
{
	INT			nType;
	INT			nID;
	LONG		nNo;
	LONG		newVal;
};

struct Out_OCK_Param_PutValue
{
	HRESULT		hr;
};

// OCK_Param_GetValue
struct In_OCK_Param_GetValue
{
	INT			nType;
	INT			nID;
	LONG		nNo;
};

struct Out_OCK_Param_GetValue
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_Param_Import
struct In_OCK_Param_Import
{
	INT			nType;
	INT			nID;
	TCHAR		lpszFilename[SIZE_STR];
};

struct Out_OCK_Param_Import
{
	HRESULT		hr;
};

// OCK_Param_Export
struct In_OCK_Param_Export
{
	INT			nType;
	INT			nID;
	TCHAR		lpszFilename[SIZE_STR];
};

struct Out_OCK_Param_Export
{
	HRESULT		hr;
};

//------------------------------------------------------------
// Robot interface code

// OCK_ROBOT_CalKinematicTransform
struct In_OCK_ROBOT_CalKinematicTransform
{
	BOOL		bIKMode;
	INT			nCoordID;
	INT			nUserCoordID;
	INT			nToolCoordID;
	INT			nLength;
	INT			nReserved;
	DOUBLE		Input[ NUM_RobotPosOri ];		// IU
};

struct Out_OCK_ROBOT_CalKinematicTransform
{
	HRESULT		hr;
	INT			nLength;
	DOUBLE		Output[ NUM_RobotPosOri ];		// IU
};

// OCK_ROBOT_CheckRefPtExtAxStrokeLimit
struct In_OCK_ROBOT_CheckRefPtExtAxStrokeLimit
{
	INT			nCoordID;
	INT			nLength;
	DOUBLE		Input[ NUM_ExtAxJoints ];		// IU
};

struct Out_OCK_ROBOT_CheckRefPtExtAxStrokeLimit
{
	HRESULT		hr;
	INT			nAlarmID;
};

// OCK_ROBOT_CalWeavingCrdAndDist
struct In_OCK_ROBOT_CalWeavingCrdAndDist
{
	INT			nCoordID;
	INT			nReserved;
	DOUBLE		StartPoint[ NUM_RobotPosOri ];	// IU
	DOUBLE		EndPoint[ NUM_RobotPosOri ];	// IU
};

struct Out_OCK_ROBOT_CalWeavingCrdAndDist
{
	HRESULT		hr;
	INT			nReserved;
	DOUBLE		Distance;	// IU
	DOUBLE		WeavingCoord[ NUM_RobotPosOri ];// IU
};

// OCK_ROBOT_ToolCrdCalibSetMethod
struct In_OCK_ROBOT_ToolCrdCalibSetMethod
{
	INT			nCoordID;
	INT			nCaliMethod;
};

struct Out_OCK_ROBOT_ToolCrdCalibSetMethod
{
	HRESULT		hr;
};

// OCK_ROBOT_ToolCrdCalibTeach
struct In_OCK_ROBOT_ToolCrdCalibTeach
{
	INT			nPoint;
	INT			nCoordID;
};

struct Out_OCK_ROBOT_ToolCrdCalibTeach
{
	HRESULT		hr;
};

// OCK_ROBOT_ToolCrdCalibDoCalibration
struct In_OCK_ROBOT_ToolCrdCalibDoCalibration
{
	INT			nCoordID;
};

struct Out_OCK_ROBOT_ToolCrdCalibDoCalibration
{
	HRESULT		hr;
	INT			nReserved;
	DOUBLE		ToolData[ NUM_RobotPosOri ];
	DOUBLE		EEfPos[ NUM_RobotPos ];
	DOUBLE		EEfPosMaxError[ NUM_RobotPos ];
	DOUBLE		EEfPosMeanError;
};

// OCK_ROBOT_ToolCrdCalibSaveToolData
struct In_OCK_ROBOT_ToolCrdCalibSaveToolData
{
	INT			nCoordID;
	INT			nNo;
	TCHAR		Name[ SIZE_CoordName ];
};

struct Out_OCK_ROBOT_ToolCrdCalibSaveToolData
{
	HRESULT		hr;
};

// OCK_ROBOT_ProtectZoneSet
struct In_OCK_ROBOT_ProtectZoneSet
{
	INT			nCoordID;
	INT			nID;
};

struct Out_OCK_ROBOT_ProtectZoneSet
{
	HRESULT		hr;
};

// OCK_ROBOT_ProtectZoneCheckState
struct In_OCK_ROBOT_ProtectZoneCheckState
{
	INT			nCoordID;
	INT			nLength;
	BOOL		State[ NUM_RobotProtectZoneState ];
};

struct Out_OCK_ROBOT_ProtectZoneCheckState
{
	HRESULT		hr;
};

// OCK_ROBOT_UserCrdCalib3PtTeach
struct In_OCK_ROBOT_UserCrdCalib3PtTeach
{
	INT			nCoordID;
	INT			nStep;
};

struct Out_OCK_ROBOT_UserCrdCalib3PtTeach
{
	HRESULT		hr;
};

// OCK_ROBOT_UserCrdCalib3PtCalAndSave
struct In_OCK_ROBOT_UserCrdCalib3PtCalAndSave
{
	INT			nCoordID;
	INT			nNo;
	TCHAR		Name[ SIZE_CoordName ];
};

struct Out_OCK_ROBOT_UserCrdCalib3PtCalAndSave
{
	HRESULT		hr;
};

// OCK_ROBOT_UserCrdGetData
struct In_OCK_ROBOT_UserCrdGetData
{
	INT			nCoordID;
	INT			nNo;
};

struct Out_OCK_ROBOT_UserCrdGetData
{
	HRESULT		hr;
	TCHAR		Name[ SIZE_CoordName ];
	INT			nReserved;
	DOUBLE		XYZABC[ NUM_RobotPosOri ];	// IU
};

// OCK_ROBOT_UserCrdSetData
struct In_OCK_ROBOT_UserCrdSetData
{
	INT			nCoordID;
	INT			nNo;
	TCHAR		Name[ SIZE_CoordName ];
	DOUBLE		XYZABC[ NUM_RobotPosOri ]; // IU
};

struct Out_OCK_ROBOT_UserCrdSetData
{
	HRESULT		hr;
};

// OCK_ROBOT_UserCrdClearAll
struct In_OCK_ROBOT_UserCrdClearAll
{
	INT			nCoordID;
};

struct Out_OCK_ROBOT_UserCrdClearAll
{
	HRESULT		hr;
};

// OCK_ROBOT_UserCrdSetActiveID
struct In_OCK_ROBOT_UserCrdSetActiveID
{
	INT			nCoordID;
	INT			nUserCoordID;
};

struct Out_OCK_ROBOT_UserCrdSetActiveID
{
	HRESULT		hr;
};

// OCK_ROBOT_ToolCrdGetData
struct In_OCK_ROBOT_ToolCrdGetData
{
	INT			nCoordID;
	INT			nNo;
};

struct Out_OCK_ROBOT_ToolCrdGetData
{
	HRESULT		hr;
	TCHAR		Name[ SIZE_CoordName ];
	INT			nReserved;
	DOUBLE		XYZABC[ NUM_RobotPosOri ]; // IU
};

// OCK_ROBOT_ToolCrdSetData
struct In_OCK_ROBOT_ToolCrdSetData
{
	INT			nCoordID;
	INT			nNo;
	TCHAR		Name[ SIZE_CoordName ];
	DOUBLE		XYZABC[ NUM_RobotPosOri ]; // IU
};

struct Out_OCK_ROBOT_ToolCrdSetData
{
	HRESULT		hr;
};

// OCK_ROBOT_ToolCrdClearAll
struct In_OCK_ROBOT_ToolCrdClearAll
{
	INT			nCoordID;
};

struct Out_OCK_ROBOT_ToolCrdClearAll
{
	HRESULT		hr;
};

// OCK_ROBOT_ToolCrdSetActiveID
struct In_OCK_ROBOT_ToolCrdSetActiveID
{
	INT			nCoordID;
	INT			nToolID;
};

struct Out_OCK_ROBOT_ToolCrdSetActiveID
{
	HRESULT		hr;
};

//------------------------------------------------------------
// Rot Interface code

// OCK_Rot_GetMonitorData
struct In_OCK_Rot_GetMonitorData
{
	int nID;
};

struct Out_OCK_Rot_GetMonitorData
{
	HRESULT		hr;
	LONG		nMode;
	BOOL		bRunning;
	BOOL		bFeedhold;
	BOOL		bAlarm;
	BOOL		bReady;
	BOOL		bServoOn;
	BOOL		bInPosition;
	BOOL		bHomeLatched;
	LONG		TarToolNo;
	LONG		CurToolNo;
	LONG		CurTorqueLimit;		// in permillage
	LONG		TorqueLoad;			// in 0.1% rated torque
	LONG		FbkPos;				// in 0.001 deg
	LONG		FbkVel;				// in RPM
	BOOL		bManualContMove;
	BOOL		bMPGCtrl;
};

// OCK_Rot_GetNumOfMaxAxis
struct In_OCK_Rot_GetNumOfMaxAxis
{
};

struct Out_OCK_Rot_GetNumOfMaxAxis
{
	HRESULT		hr;
	LONG		nSize;
};

//------------------------------------------------------------
// Auto Tuning Interface code

// OCK_SpdAdvTuningGetDefault
struct In_OCK_SpdAdvTuningGetDefault
{
	LONG		nSpdID;
	int			nDataIndex;
};
struct Out_OCK_SpdAdvTuningGetDefault
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_SpdAdvTuningSetData
struct In_OCK_SpdAdvTuningSetData
{
	LONG		nSpdID;
	int			nDataIndex;
	LONG		nValue;
};
struct Out_OCK_SpdAdvTuningSetData
{
	HRESULT		hr;
};

// OCK_SpdAdvTuningGainCalculation
struct In_OCK_SpdAdvTuningGainCalculation
{
	LONG		nBandWidth;
};
struct Out_OCK_SpdAdvTuningGainCalculation
{
	HRESULT		hr;
	LONG		nPositionGain;
	LONG		nSpeedGain;
	LONG		nSpeedIntegralTime;
	LONG		nSpeedFilterTime;
	LONG		nTorqueFilterTime;
};

// OCK_SpdAdvTuningSwitchOn
struct In_OCK_SpdAdvTuningSwitchOn
{
	LONG		nSpdID;
};
struct Out_OCK_SpdAdvTuningSwitchOn
{
	HRESULT		hr;
};

// OCK_SpdAdvTuningTurnOn
struct In_OCK_SpdAdvTuningTurnOn
{
	LONG		nSpdID;
};
struct Out_OCK_SpdAdvTuningTurnOn
{
	HRESULT		hr;
	BOOL		bSwitchOn;
};

// OCK_SpdAdvTuningTurnOff
struct In_OCK_SpdAdvTuningTurnOff
{
	LONG		nSpdID;
};
struct Out_OCK_SpdAdvTuningTurnOff
{
	HRESULT		hr;
};

// OCK_TuningIsSupport
struct In_OCK_TuningIsSupport
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_TuningIsSupport
{
	HRESULT		hr;
	BOOL		isEnable;
	BOOL		isSupportLimit;
};

// OCK_Tuning1stLimit
struct In_OCK_Tuning1stLimit
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_Tuning1stLimit
{
	HRESULT		hr;
};

// OCK_Tuning2ndLimit
struct In_OCK_Tuning2ndLimit
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_Tuning2ndLimit
{
	HRESULT		hr;
};

// OCK_TuningLimitCheck
struct In_OCK_TuningLimitCheck
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_TuningLimitCheck
{
	HRESULT		hr;
	INT			nLimitCheck;
	DOUBLE		MinRange;
	DOUBLE		MaxRange;
};

// OCK_TuningGetDefault
struct In_OCK_TuningGetDefault
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_TuningGetDefault
{
	HRESULT		hr;
	INT			nTuningMode;
	INT			nMachineType;
};

// OCK_TuningSetData
struct In_OCK_TuningSetData
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	INT			nTuningMode;
	INT			nMachineType;
};

struct Out_OCK_TuningSetData
{
	HRESULT		hr;
};

// OCK_TuningStartCheck
struct In_OCK_TuningStartCheck
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_TuningStartCheck
{
	HRESULT		hr;
	BOOL		bTuningStart;
};

// OCK_TuningStart
struct In_OCK_TuningStart
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_TuningStart
{
	HRESULT		hr;
};

// OCK_TuningStop
struct In_OCK_TuningStop
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_TuningStop
{
	HRESULT		hr;
};

// OCK_TuningGetStatus
struct In_OCK_TuningGetStatus
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_TuningGetStatus
{
	HRESULT		hr;
	BOOL		isFinished;
	INT			nResult;
};

// OCK_TuningSetWatchMode
struct In_OCK_TuningSetWatchMode
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	BOOL		bWatchMode;
};

struct Out_OCK_TuningSetWatchMode
{
	HRESULT		hr;
};

//------------------------------------------------------------
// Software Panel Interface code

// OCK_SWP_CycleStart
struct In_OCK_SWP_CycleStart
{
};
struct Out_OCK_SWP_CycleStart
{
	HRESULT		hr;
};

// OCK_SWP_Feedhold
struct In_OCK_SWP_Feedhold
{
};
struct Out_OCK_SWP_Feedhold
{
	HRESULT		hr;
};

// OCK_SWP_JOG
struct In_OCK_SWP_JOG
{
	BOOL		bOn;
	LONG		nAxisID;
	BOOL		nDirection;
};
struct Out_OCK_SWP_JOG
{
	HRESULT		hr;
};

// OCK_SWP_MPGSimulation
struct In_OCK_SWP_MPGSimulation
{
	BOOL		bOn;
};
struct Out_OCK_SWP_MPGSimulation
{
	HRESULT		hr;
};

// OCK_SWP_SetMachinePosition
struct In_OCK_SWP_SetMachinePosition
{
	LONG		nAxisID;
};
struct Out_OCK_SWP_SetMachinePosition
{
	HRESULT		hr;
};

// OCK_SWP_SetManualControl
struct In_OCK_SWP_SetManualControl
{
	BOOL		bOn;
	LONG		nAxisID;
};
struct Out_OCK_SWP_SetManualControl
{
	HRESULT		hr;
};

// OCK_SWP_Reset
struct In_OCK_SWP_Reset
{
};
struct Out_OCK_SWP_Reset
{
	HRESULT		hr;
};

// OCK_SWP_SingleBlock
struct In_OCK_SWP_SingleBlock
{
	BOOL		bOn;
};
struct Out_OCK_SWP_SingleBlock
{
	HRESULT		hr;
};

// OCK_SWP_ModeSelection
struct In_OCK_SWP_ModeSelection
{
	LONG		nMode;
};
struct Out_OCK_SWP_ModeSelection
{
	HRESULT		hr;
};

// OCK_SWP_IncrementFeed
struct In_OCK_SWP_IncrementFeed
{
	LONG		nValue;
};
struct Out_OCK_SWP_IncrementFeed
{
	HRESULT		hr;
};

// OCK_SWP_SetSpindleOverride
struct In_OCK_SWP_SetSpindleOverride
{
	LONG		nValue;
};
struct Out_OCK_SWP_SetSpindleOverride
{
	HRESULT		hr;
};

// OCK_SWP_SetFeedrateOverride
struct In_OCK_SWP_SetFeedrateOverride
{
	LONG		nValue;
};
struct Out_OCK_SWP_SetFeedrateOverride
{
	HRESULT		hr;
};

// OCK_SWP_SetJOGOverride
struct In_OCK_SWP_SetJOGOverride
{
	LONG		nValue;
};
struct Out_OCK_SWP_SetJOGOverride
{
	HRESULT		hr;
};

// OCK_SWP_SetRapidTravelOverride
struct In_OCK_SWP_SetRapidTravelOverride
{
	LONG		nValue;
};
struct Out_OCK_SWP_SetRapidTravelOverride
{
	HRESULT		hr;
};

// OCK_NcGetSystemDateTime
struct In_OCK_NcGetSystemDateTime
{
};

struct Out_OCK_NcGetSystemDateTime
{
	HRESULT		hr;
	LONG		wYear;
	LONG		wMonth;
	LONG		wDay;
	LONG		wHour;
	LONG		wMinute;
	LONG		wSecond;
};

// OCK_NcSetSystemDateTime
struct In_OCK_NcSetSystemDateTime
{
	LONG		wYear;
	LONG		wMonth;
	LONG		wDay;
	LONG		wHour;
	LONG		wMinute;
	LONG		wSecond;
};

struct Out_OCK_NcSetSystemDateTime
{
	HRESULT		hr;
	BOOL		bSucceeded;
};

//------------------------------------------------------------
// Device Update Interface code

// OCK_IsDeviceInfoReady
struct In_OCK_IsDeviceInfoReady
{
};

struct Out_OCK_IsDeviceInfoReady
{
	HRESULT		hr;
	BOOL		bReady;
};

// OCK_GetCountOfSynDevice
struct In_OCK_GetCountOfSynDevice
{
};

struct Out_OCK_GetCountOfSynDevice
{
	HRESULT		hr;
	int			nCount;
};

// OCK_GetSynDeviceStationID
struct In_OCK_GetSynDeviceStationID
{
	int			nNo;
};

struct Out_OCK_GetSynDeviceStationID
{
	HRESULT		hr;
	int			nStationID;
};

// OCK_GetSynDeviceInfo
struct In_OCK_GetSynDeviceInfo
{
	int			nStationID;
};

struct Out_OCK_GetSynDeviceInfo
{
	HRESULT		hr;
	int			nType;
	TSyntecDevInfo	TInfo;
};

// OCK_GetSynModuleInfo
struct In_OCK_GetSynModuleInfo
{
	int			nStationID;
	int			nModuleNo;
};

struct Out_OCK_GetSynModuleInfo
{
	HRESULT		hr;
	TSyntecModuleInfo	TInfo;
};

// OCK_GetSynUnitInfo
struct In_OCK_GetSynUnitInfo
{
	int			nStationID;
	int			nModuleNo;
	int			nUnitNo;
};

struct Out_OCK_GetSynUnitInfo
{
	HRESULT		hr;
	TSyntecUnitInfo		TInfo;
};

// OCK_OpenBootMode
struct In_OCK_OpenBootMode
{
	int			nStationID;
};

struct Out_OCK_OpenBootMode
{
	HRESULT		hr;
	BOOL		bReady;
	BOOL		bAlarmFlag;
};

// OCK_CloseBootMode
struct In_OCK_CloseBootMode
{
	int			nStationID;
};

struct Out_OCK_CloseBootMode
{
	HRESULT		hr;
	BOOL		bReady;
	BOOL		bAlarmFlag;
};

// OCK_FileBurnIn
struct In_OCK_FileBurnIn
{
	int			nStationID;
	int			nFileCounts;
	TFileBurnIn	*pInfo;
};

struct Out_OCK_FileBurnIn
{
	HRESULT		hr;
	BOOL		bAlarmFlag;
};

// OCK_BurnInMonitor
struct In_OCK_BurnInMonitor
{
	int			nStationID;
};

struct Out_OCK_BurnInMonitor
{
	HRESULT		hr;
	BOOL		bFinished;
	long		nProgress;
	BOOL		bAlarmFlag;
};

// OCK_Adjust_SetSpdPosingHomeOffset
struct In_OCK_Adjust_SetSpdPosingHomeOffset
{
	int			nSpdID;
	LONG		nPosition;
};

struct Out_OCK_Adjust_SetSpdPosingHomeOffset
{
	HRESULT		hr;
};

// OCK_Adjust_GetSpdPosingHomeOffset
struct In_OCK_Adjust_GetSpdPosingHomeOffset
{
	int			nSpdID;
};

struct Out_OCK_Adjust_GetSpdPosingHomeOffset
{
	HRESULT		hr;
	LONG		nPosition;
};

// OCK_Adjust_SaveSpdPosingHomeOffset
struct In_OCK_Adjust_SaveSpdPosingHomeOffset
{
	int			nSpdID;
};

struct Out_OCK_Adjust_SaveSpdPosingHomeOffset
{
	HRESULT		hr;
};

// OCK_Adjust_GetSpdEncFeedbackPos
struct In_OCK_Adjust_GetSpdEncFeedbackPos
{
	int			nSpdID;
};

struct Out_OCK_Adjust_GetSpdEncFeedbackPos
{
	HRESULT		hr;
	LONG		nPosition;
};


// OCK_SerialParam_GetCapacity
struct In_OCK_SerialParam_GetCapacity
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SerialParam_GetCapacity
{
	HRESULT		hr;
	LONG		nValue;
};

// OCK_SerialParam_Dump
struct In_OCK_SerialParam_Dump
{
	LONG		nType;
	LONG		nID;
	LONG		nLength;
};

struct Out_OCK_SerialParam_Dump
{
	HRESULT		hr;
	int			nStatus;
	BOOL		bParamNoHex;
	TSerialParamSpec		*lpBuffer;
};

// OCK_SerialParam_PutValue
struct In_OCK_SerialParam_PutValue
{
	LONG		nType;
	LONG		nID;
	LONG		nNo;
	LONG		nValue;
	BOOL		bRestore;
};

struct Out_OCK_SerialParam_PutValue
{
	HRESULT		hr;
	int			nStatus;
};

// OCK_SerialParam_GetValue
struct In_OCK_SerialParam_GetValue
{
	LONG		nType;
	LONG		nID;
	LONG		nNo;
};

struct Out_OCK_SerialParam_GetValue
{
	HRESULT		hr;
	LONG		nValue;
	int			nStatus;
};

// OCK_SerialParam_ReloadValue
struct In_OCK_SerialParam_ReloadValue
{
	LONG		nType;
	LONG		nID;
	LONG		nNo;
};

struct Out_OCK_SerialParam_ReloadValue
{
	HRESULT		hr;
	int			nStatus;
};

// OCK_SerialParam_GetStatus
struct In_OCK_SerialParam_GetStatus
{
	LONG		nType;
	LONG		nID;
	LONG		nNo;
};

struct Out_OCK_SerialParam_GetStatus
{
	HRESULT		hr;
	int			nStatus;
};

// OCK_SerialParam_IsReady
struct In_OCK_SerialParam_IsReady
{
	LONG		nType;
};

struct Out_OCK_SerialParam_IsReady
{
	HRESULT		hr;
	BOOL		bReady;
};

// OCK_SerialParam_Init
struct In_OCK_SerialParam_Init
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SerialParam_Init
{
	HRESULT		hr;
};

// OCK_SerialParam_GetInitStatus
struct In_OCK_SerialParam_GetInitStatus
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SerialParam_GetInitStatus
{
	HRESULT		hr;
	int			nStatus;
};

// OCK_SerialParam_MemorySave
struct In_OCK_SerialParam_MemorySave
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SerialParam_MemorySave
{
	HRESULT		hr;
	BOOL		isSupport;
};

// OCK_SerialParam_SaveResult
struct In_OCK_SerialParam_SaveResult
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SerialParam_SaveResult
{
	HRESULT		hr;
	int			Result;
};

// OCK_SerialParam_SupportParamInit
struct In_OCK_SerialParam_SupportParamInit
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SerialParam_SupportParamInit
{
	HRESULT		hr;
	BOOL		isSupport;
};

// OCK_SerialParam_RestoreStart
struct Out_OCK_SerialParam_RestoreStart
{
	HRESULT		hr;
};

// OCK_SerialParam_RestoreEnd
struct Out_OCK_SerialParam_RestoreEnd
{
	HRESULT		hr;
};

// OCK_StateVar_ServiceReg
struct In_OCK_StateVar_ServiceReg {
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_StateVar_ServiceReg {
	HRESULT		hr;
	BOOL		bSuccess;
	LONG		nHandle;
};

// OCK_StateVar_ServiceUnReg
struct In_OCK_StateVar_ServiceUnReg {
	LONG		nHandle;
};

struct Out_OCK_StateVar_ServiceUnReg {
	HRESULT		hr;
	BOOL		bSuccess;
};

// OCK_StateVar_GetCapacity
struct In_OCK_StateVar_GetCapacity {
	LONG		nHandle;
};

struct Out_OCK_StateVar_GetCapacity {
	HRESULT		hr;
	LONG		nValue;
};

// OCK_StateVar_Dump
struct In_OCK_StateVar_Dump {
	LONG		nHandle;
	LONG		nLength;
};

struct Out_OCK_StateVar_Dump {
	HRESULT			hr;
	INT				nStatus;
	BOOL			bParamNoHex;
	TStateVarSpec	*lpBuffer;
};

// OCK_StateVar_GetValue
struct In_OCK_StateVar_GetValue {
	LONG		nHandle;
	LONG		nLength;
};

struct Out_OCK_StateVar_GetValue {
	HRESULT		hr;
	INT			nStatus;
	LONG		*pValue;
};

// OCK_SerialParam_NeedMemorySave
struct In_OCK_SerialParam_NeedMemorySave
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SerialParam_NeedMemorySave
{
	HRESULT		hr;
	BOOL		bNeedMemorySave;
};

// OCK_SD_GetActiveEncoder
struct In_OCK_SD_GetActiveEncoder
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_SD_GetActiveEncoder
{
	HRESULT		hr;
	BOOL		isAbsolute;
};

// OCK_SD_ClearMultiTurnAbsEnc
struct In_OCK_SD_ClearMultiTurnAbsEnc
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};

struct Out_OCK_SD_ClearMultiTurnAbsEnc
{
	HRESULT		hr;
	LONG		nResult;
};

// OCK_SD_GetDeviceInfo
struct In_OCK_SD_GetDeviceInfo
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	LONG		nDeviceInfo;
};
 
struct Out_OCK_SD_GetDeviceInfo
{
	HRESULT		hr;
	TCHAR		szDeviceInfo[ SIZE_SSV_DEVICEINFO ];
};

// OCK_SerialParam_IsSupport
struct In_OCK_SerialParam_IsSupport
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SerialParam_IsSupport
{
	HRESULT		hr;
	BOOL		isSupport;
};

// OCK_BODE_IsSupportAntiResonance
struct In_OCK_BODE_IsSupportAntiResonance
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};
struct Out_OCK_BODE_IsSupportAntiResonance
{
	HRESULT		hr;
	int			nSupportStatus;
};

// OCK_BODE_GetNotchFilterData
struct In_OCK_BODE_GetNotchFilterData
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	LONG		nFilterID;
};
struct Out_OCK_BODE_GetNotchFilterData
{
	HRESULT		hr;
	TNotchFilterData	FilterData;
};

// OCK_BODE_SetNotchFilterData
struct In_OCK_BODE_SetNotchFilterData
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	LONG		nFilterID;
	TNotchFilterData	FilterData;
};
struct Out_OCK_BODE_SetNotchFilterData
{
	HRESULT		hr;
};

// OCK_BODE_GetNotchFilterDisplay
struct In_OCK_BODE_GetNotchFilterDisplay
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	LONG		nFilterID;
};
struct Out_OCK_BODE_GetNotchFilterDisplay
{
	HRESULT		hr;
	TDisplayBoundary	BoundData;
};

// OCK_BODE_StartSystemIdentify
struct In_OCK_BODE_StartSystemIdentify
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};
struct Out_OCK_BODE_StartSystemIdentify
{
	HRESULT		hr;
};

// OCK_BODE_GetIdentifyResult
struct In_OCK_BODE_GetIdentifyResult
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};
struct Out_OCK_BODE_GetIdentifyResult
{
	HRESULT		hr;
	BOOL		bFinish;
	BOOL		bSuccess;
};

// OCK_BODE_GetFftDataLength
struct In_OCK_BODE_GetFftDataLength
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};
struct Out_OCK_BODE_GetFftDataLength
{
	HRESULT		hr;
	LONG		nTotalLength;
};

// OCK_BODE_GetFrequencyData
struct In_OCK_BODE_GetFrequencyData
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	LONG		nDataIndex;
	LONG		nDataLength;
};
struct Out_OCK_BODE_GetFrequencyData
{
	HRESULT		hr;
	LONG		*pFrequency;
};

// OCK_BODE_GetGainData
struct In_OCK_BODE_GetGainData
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	LONG		nDataIndex;
	LONG		nDataLength;
};
struct Out_OCK_BODE_GetGainData
{
	HRESULT		hr;
	LONG		*pGain;
};

// OCK_BODE_GetPhaseData
struct In_OCK_BODE_GetPhaseData
{
	LONG		nDeviceType;
	LONG		nDeviceID;
	LONG		nDataIndex;
	LONG		nDataLength;
};
struct Out_OCK_BODE_GetPhaseData
{
	HRESULT		hr;
	LONG		*pPhase;
};

// OCK_BODE_StopSystemIdentify
struct In_OCK_BODE_StopSystemIdentify
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};
struct Out_OCK_BODE_StopSystemIdentify
{
	HRESULT		hr;
};

// OCK_BODE_GetResonancePoint
struct In_OCK_BODE_GetResonancePoint
{
	LONG		nDeviceType;
	LONG		nDeviceID;
};
struct Out_OCK_BODE_GetResonancePoint
{
	HRESULT		hr;
	LONG		nResonanceFreq;
	LONG		nResonancePeak;
};

// OCK_SC_IsSupportDAQ
struct In_OCK_SC_IsSupportDAQ
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SC_IsSupportDAQ
{
	HRESULT		hr;
	BOOL		isSupport;
};

// OCK_SC_GetSampleFrequency
struct In_OCK_SC_GetSampleFrequency
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SC_GetSampleFrequency
{
	HRESULT		hr;
	LONG		nSampleFreq;
};

// OCK_SC_GetSampleTime
struct In_OCK_SC_GetSampleTime
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SC_GetSampleTime
{
	HRESULT		hr;
	LONG		nMinPeriod;
	LONG		nActivePeriod;
};

// OCK_SC_SetSampleDivider
struct In_OCK_SC_SetSampleDivider
{
	LONG		nType;
	LONG		nID;
	LONG		nDivider;
};

struct Out_OCK_SC_SetSampleDivider
{
	HRESULT		hr;
};

// OCK_SC_PutDAQChSetting
struct In_OCK_SC_PutDAQChSetting
{
	LONG		nType;
	LONG		nID;
	int			nDAQCh;
	BOOL		bEnable;
	LONG		nSelectType;
	LONG		nMapIndex;
	LONG		nDataType;
};

struct Out_OCK_SC_PutDAQChSetting
{
	HRESULT		hr;
};

// OCK_SC_GetDAQChSetting
struct In_OCK_SC_GetDAQChSetting
{
	LONG		nType;
	LONG		nID;
	int			nDAQCh;
};

struct Out_OCK_SC_GetDAQChSetting
{
	HRESULT		hr;
	BOOL		bEnable;
	LONG		nMapIndex;
	LONG		nDataType;
};

// OCK_SC_EnableDAQChannel
struct In_OCK_SC_EnableDAQChannel
{
	LONG		nType;
	LONG		nID;
	int			nDAQCh;
	BOOL		bEnable;
};

struct Out_OCK_SC_EnableDAQChannel
{
	HRESULT		hr;
};

// OCK_SC_EnableSampleData
struct In_OCK_SC_EnableSampleData
{
	LONG		nType;
	LONG		nID;
	BOOL		bEnable;
};

struct Out_OCK_SC_EnableSampleData
{
	HRESULT		hr;
};

// OCK_SC_EnableAuxiliarySignal
struct In_OCK_SC_EnableAuxiliarySignal
{
	LONG		nType;
	LONG		nID;
	BOOL		bEnable;
	int			nAuxType;
};

struct Out_OCK_SC_EnableAuxiliarySignal
{
	HRESULT		hr;
};

// OCK_SC_GetNumDAQChannel
struct In_OCK_SC_GetNumDAQChannel
{
	LONG		nType;
	LONG		nID;
};

struct Out_OCK_SC_GetNumDAQChannel
{
	HRESULT		hr;
	LONG		nNumDAQCh;
};

// OCK_SC_AdjustVelChirpSignal
struct In_OCK_SC_AdjustVelChirpSignal
{
	LONG		nType;
	LONG		nID;
	LONG		nStartFreq;
	LONG		nEndFreq;
	LONG		nDuringTime;
	LONG		nMagnitude;
};

struct Out_OCK_SC_AdjustVelChirpSignal
{
	HRESULT		hr;
};

// OCK_Grinder_DoTuneAngle
struct In_OCK_Grinder_DoTuneAngle
{
	int			nTunningState;
	LONG		nSpdID;
	LONG		nType;
	LONG		nID;
	LONG		SpdSpeed;
};

struct Out_OCK_Grinder_DoTuneAngle
{
	HRESULT		hr;
};

// OCK_Grinder_CheckGrinderState
struct In_OCK_Grinder_CheckGrinderState
{
	// Do nothing
};

struct Out_OCK_Grinder_CheckGrinderState
{
	HRESULT		hr;
	int			nResult;
	LONG		SpdSpeed;
	double		Magnitude;
	double		Theta;
	double		AlphaAngle;
	double		BetaAngle;
	double		GamaAngle;
};

// OCK_IOMap_GetHint
struct Out_OCK_IOMap_GetHint
{
	HRESULT		hr;
	LONG		nHintID;
};

// OCK_IOMap_GetTableInfo
struct In_OCK_IOMap_GetTableInfo
{
	LONG		nTableType;
};

struct Out_OCK_IOMap_GetTableInfo
{
	HRESULT		hr;
	LONG		nLength_I;
	LONG		nLength_O;
	BOOL		bFileGood;
};

// OCK_IOMap_LoadTable
struct In_OCK_IOMap_LoadTable
{
	LONG		nTableType;
	LONG		nLength_I;
	LONG		nLength_O;
};

struct Out_OCK_IOMap_LoadTable
{
	HRESULT		hr;
	TMapTable	*pTable_I; // do not use this pointer, not what it means
	TMapTable	*pTable_O; // do not use this pointer, not what it means
};

// OCK_IOMap_RestoreDefaultTable
struct In_OCK_IOMap_RestoreDefaultTable
{
	LONG		nTableType;
};

struct Out_OCK_IOMap_RestoreDefaultTable
{
	HRESULT		hr;
	LONG		nMsgID;
};

// OCK_IOMap_SaveTable
struct In_OCK_IOMap_SaveTable
{
	LONG				nTableType;
	LONG				nLength_I;
	LONG				nLength_O;
	TReadWriteTable		*pTable_I; // do not use this pointer, not what it means
	TReadWriteTable		*pTable_O; // do not use this pointer, not what it means
};

struct Out_OCK_IOMap_SaveTable
{
	HRESULT		hr;
	LONG		nMsgID;
	CHAR		Error[ SIZE_ERRORBIT ];
};

// OCK_IOMap_IsSRIEnabled
struct Out_OCK_IOMap_IsSRIEnabled
{
	HRESULT		hr;
	BOOL		bEnable;
};

// OCK_IOMap_IsRestorable
struct Out_OCK_IOMap_IsRestorable
{
	HRESULT		hr;
	BOOL		bRestorable;
};

// OCK_FrictionAdjust_GetCtrlParam
struct In_OCK_FrictionAdjust_GetCtrlParam
{
	LONG			nAxisID;
};

struct Out_OCK_FrictionAdjust_GetCtrlParam
{
	HRESULT			hr;
	TMotorParam		CtrlParam;
};

// OCK_FrictionAdjust_SetCtrlParam
struct In_OCK_FrictionAdjust_SetCtrlParam
{
	LONG			nAxisID;
	TMotorParam		CtrlParam;
};

struct Out_OCK_FrictionAdjust_SetCtrlParam
{
	HRESULT			hr;
};

// OCK_FrictionAdjust_SetArcCuttingInfo
struct In_OCK_FrictionAdjust_SetArcCuttingInfo
{
	LONG			nFirstAxisID;
	LONG			nSecondAxisID;
	DOUBLE			Radius;
	DOUBLE			FeedRate;
};

struct Out_OCK_FrictionAdjust_SetArcCuttingInfo
{
	HRESULT			hr;
};

// OCK_FrictionAdjust_CheckDataStatus
struct In_OCK_FrictionAdjust_CheckDataStatus
{
	// do nothing
};

struct Out_OCK_FrictionAdjust_CheckDataStatus
{
	HRESULT		hr;
	INT			nStatus;
};

// OCK_FrictionAdjust_GetDisplayData
struct In_OCK_FrictionAdjust_GetDisplayData
{
	LONG		nDataLength;
	LONG		nAxisIndex;
	LONG		nDataType;
};

struct Out_OCK_FrictionAdjust_GetDisplayData
{
	HRESULT		hr;
	LONG		nReturnDataLength;
	DOUBLE		*pData;
};

// OCK_FrictionAdjust_GetRawData
struct In_OCK_FrictionAdjust_GetRawData
{
	LONG		nDataLength;
	LONG		nAxisIndex;
	LONG		nDataType;
};

struct Out_OCK_FrictionAdjust_GetRawData
{
	HRESULT		hr;
	LONG		nReturnDataLength;
	DOUBLE		*pData;
};

// OCK_FrictionAdjust_GetFbkDataIndex
struct In_OCK_FrictionAdjust_GetRawDataIndex
{
	// do nothing
};

struct Out_OCK_FrictionAdjust_GetRawDataIndex
{
	HRESULT		hr;
	LONG		nStartIndex;
	LONG		nEndIndex;
};

// OCK_FrictionAdjust_Clear
struct In_OCK_FrictionAdjust_Clear
{
	// do nothing
};

struct Out_OCK_FrictionAdjust_Clear
{
	HRESULT		hr;
};


// OCK_FrictionAdjust_SetCompChangedCmd
struct In_OCK_FrictionAdjust_SetFricCompMethod
{
	INT			nCompMethod;
};

struct Out_OCK_FrictionAdjust_SetFricCompMethod
{
	HRESULT		hr;
};

// OCK_GENERAL_PARAM_GetCapacity
struct In_OCK_GENERAL_PARAM_GetCapacity
{
	INT						nParamType;
};

struct Out_OCK_GENERAL_PARAM_GetCapacity
{
	HRESULT					hr;
	INT						nParamDescripDimension;
	INT						nParamCtrlDimension;
	INT						nNumOfParam;
};

// OCK_GENERAL_PARAM_DescriptionTitleDump
struct In_OCK_GENERAL_PARAM_DescriptionTitleDump
{
	INT						nParamType;
};

struct Out_OCK_GENERAL_PARAM_DescriptionTitleDump
{
	HRESULT					hr;
	TOcKey					*pParamDescriptionKey;
};

// OCK_GENERAL_PARAM_CtrlTitleDump
struct In_OCK_GENERAL_PARAM_CtrlTitleDump
{
	INT						nParamType;
};

struct Out_OCK_GENERAL_PARAM_CtrlTitleDump
{
	HRESULT					hr;
	TOcKey					*pParamCtrlTitleKey;
};

// OCK_GENERAL_PARAM_InfoDump
struct In_OCK_GENERAL_PARAM_InfoDump
{
	INT						nParamType;
	INT						nStartIndex;
	INT						nLength;
};

struct Out_OCK_GENERAL_PARAM_InfoDump
{
	HRESULT					hr;
	TParamInfo				*pParamInfo;
};

// OCK_GENERAL_PARAM_GetValue
struct In_OCK_GENERAL_PARAM_GetValue
{
	INT						nParamType;
	INT						nParamCtrlIndex;
	INT						nParamIndex;
};

struct Out_OCK_GENERAL_PARAM_GetValue
{
	HRESULT					hr;
	TOcVariant				Value;
};

// OCK_GENERAL_PARAM_PutValue
struct In_OCK_GENERAL_PARAM_PutValue
{
	INT						nParamType;
	INT						nParamCtrlIndex;
	INT						nParamIndex;
	TOcVariant				Value;
};

struct Out_OCK_GENERAL_PARAM_PutValue
{
	HRESULT					hr;
};

// OCK_GENERAL_PARAM_SearchIndexByDeviceID
struct In_OCK_GENERAL_PARAM_SearchIndexByDeviceID
{
	INT						nParamType;
	INT						nDeviceType;
	INT						nDeviceID;
};

struct Out_OCK_GENERAL_PARAM_SearchIndexByDeviceID
{
	HRESULT					hr;
	INT						nParamCtrlIndex;
};
