// AxisNameDef.h:
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AXISNAMEDEF_H__INCLUDED_)
#define AFX_AXISNAMEDEF_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum EAxisName {
	EAN_NotDefine = -1,
	EAN_X = 0,
	EAN_Y = 1,
	EAN_Z = 2,
	EAN_GeomNum = 3,
	EAN_A = 3,
	EAN_B = 4,
	EAN_C = 5,
	EAN_U = 6,
	EAN_V = 7,
	EAN_W = 8,
	EAN_Num = 9,
};

#endif // !defined(AFX_AXISNAMEDEF_H__INCLUDED_)
