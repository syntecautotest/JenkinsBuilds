// TrajectoryOscillator.h: interface for the CTrajectoryOscillator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_TRAJECTORYOSCILLATOR_H____INCLUDED_)
#define _TRAJECTORYOSCILLATOR_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define NUMOF_SECTIONS							( 4 )

class CTrajectoryOscillator : public IListener
{
public:
	enum EOscillationError {
		EOE_NoError = 0,
		EOE_StopTimeBreakLimit = 1,
		EOE_FailToCompleteOneCycle = 2,
		EOE_InappropriateTrajParam = 3,
	};

private:
	enum EOscillatorShapeType {
		EOST_NotDefined = -1,
		EOST_Z,
		EOST_Trapezoid,

		EOST_Num,
	};

public:
	CTrajectoryOscillator( INT nEventCoordID );
	// constructor

	~CTrajectoryOscillator( void );
	// destructor

	void Trigger( TEvtInfo *pEvtArg, va_list var );
	// trigger event

private:
	void RegisterEvent( void );
	// register event

	void UnregisterEvent( void );
	// unegister event

public:
	void configZShapeOscillator( DOUBLE Amp, DOUBLE Freq, DOUBLE StopTime1, DOUBLE StopTime2, BOOL bSmooth );
	// set Oscillator basic param, amplitude and frequency, Z-Shape
	// unit: [ mm, Hz, us, us ]
	// threads: motionplan tick

	void configTrapezoidOscillator( DOUBLE Amp, DOUBLE Freq, DOUBLE StopTime1, DOUBLE StopTime2, DOUBLE StopTime3, DOUBLE StopTime4, BOOL bSmooth );
	// set Oscillator basic param, amplitude and frequency, Trapezoid-Shape
	// unit: [ mm, Hz, us, us, us, us ]
	// threads: motionplan tick

	INT generateOscillatorPattern( DOUBLE WaveDuration );
	// generate Oscillator pattern
	// threads: interpolation tick

	DOUBLE getModifiedFrequency( void );
	// return modified frequency

	DOUBLE getModifiedTimePeriod( void );
	// return modified time period

	void getDisplacement( DOUBLE TimeElapse, DOUBLE *Segment );
	// get Oscillator magnitude
	// threads: interpolation tick

private:
	typedef INT( CTrajectoryOscillator::*PlanTrajectoryFunc )( DOUBLE TotalStopTime, TPVTSheet Sheet[] );
	// define plan trajectory funtion format

	typedef void( CTrajectoryOscillator::*ComeposeTrajFunc )( void );
	// define comepose traj. funtion format

	INT modifyFrequency( DOUBLE WaveDuration, DOUBLE TotalStopTime, DOUBLE Frequency );
	// modify frequency and time period
	// threads: interpolation tick

	INT planTrajectory_Z( DOUBLE TotalStopTime, TPVTSheet Sheet[] );
	// do Z-shape plan block

	INT planTrajectory_Trapezoid( DOUBLE TotalStopTime, TPVTSheet Sheet[] );
	// do Trapezoid-shape plan block

	void executeOscTrajComposition_Z( void );
	// compse Oscillator by patterns and write into interpolator
	// threads: interpolation tick

	void executeOscTrajComposition_Trapezoid( void );
	// compse Oscillator by patterns and write into interpolator
	// threads: interpolation tick

	void writeSectionToInterpolator( INT nDirection, TPVTSheet &Sheet, DOUBLE DelayTime );
	// write PVT and delayTime of the section to interpolator
	// threads: interpolation tick

private:
	CInterpolator *m_pInterpolator;
	// pointer of interpolator

	CTrajectorySyncTracking *m_pTrajSyncTracking;
	// pointer of SyncTracking

	CTrajectoryNormal *m_pTrajNormal;
	// pointer of TrajectoryNormal

	PlanTrajectoryFunc m_PlanTraj[ CTrajectoryOscillator::EOST_Num ];
	// plan traj. function table

	ComeposeTrajFunc m_ComeposeTraj[ CTrajectoryOscillator::EOST_Num ];
	// compose traj. function table

	TPVTSheet m_Sheet[ NUMOF_SECTIONS ];
	// PVTSheet for Oscillator pattern sections
	// for example:
	// 1. Z: first section is used for start and end, second section is used for middle; use index to express: 011110
	// 2. Trapezoid: each section are the same; use index to express: 000000
	// 3. Triangle: thress sections are different, use index to express: 012012

	INT m_nEventCoordID;
	// event coordinate ID

	INT m_nShapeType;
	// Oscillator shape type

	BOOL m_bSmooth;
	// is trajectory smooth

	DOUBLE m_Amplitude;
	// Oscillator amplitude
	// unit: mm

	DOUBLE m_Frequency;
	// command Oscillator frequency
	// unit: Hz

	DOUBLE m_ModifiedFreq;
	// real Oscillator frequency
	// unit: Hz

	DOUBLE m_MaxFreq;
	// max Oscillator frequency
	// unit: Hz

	DOUBLE m_SectionStopTime[ NUMOF_SECTIONS ];
	// section stiop time
	// unit: micro second

	DOUBLE m_T;
	// the time to complete one full cycle, or one Oscillator, is called the time period
	// unit: micro second

	DOUBLE m_RemainCycleCnt;
	// remain cycle count

	INT m_nDirection;
	// PVT pattern direction

	DOUBLE m_Vmax;
	DOUBLE m_Amax;
	DOUBLE m_Jmax;
	// parameter of Oscillator motion

	DOUBLE m_MotParamOverrideScale;
	// motion parameter override scale
};

#endif // !defined(_TRAJECTORYOSCILLATOR_H____INCLUDED_)
