// UTPassword.h: interface for the CUTPassword class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UTPASSWORD_H__B1AB5FE9_FC4E_4500_B3ED_61FAC062DEC4__INCLUDED_)
#define AFX_UTPASSWORD_H__B1AB5FE9_FC4E_4500_B3ED_61FAC062DEC4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IUseTimeVer;
class CSMBUTPass;

class CUTPassword
{
public:
	CUTPassword( ULONG *nUTData, char *szSerialNo, long nCNCVerNo );
	// constructs a CUTPassword class

	virtual ~CUTPassword( );
	// destructs this object

	INT getUTPassData( ULONG *nPassData );
	// if password ok, then need update and save data

	ULONG getPassSeed( char *szSerialNo, INT nStatus, char *szRetSeed, INT nStrSize );
	// get seed for generate password, include factory ID and random key

	INT putPassKey( char *Password, INT nCurStatus );
	// Password to unlock or Set Use time

	INT getTimeSetValue( void );
	// when password ok, read time set in password

	INT getPasswordVer( void );
	// get Password version number

	void upDateUTStatus( INT nStatus );
	// update current UT status for SMB open channel

public:
	INT SMBRequestUTChannel( char *szTokenSMB, INT nStatus, char *szCncData );
	// for SMB server request establish UT channel

	INT DeviceReadUTChannelState( char *szDeviceID );
	// for SMB server alive check UT channel state, 0: cloase, 1: wait, 2: open

	INT getUTChannelState( void );
	// for only read UT channel state use

	INT SMBOpenUTChannel( void );
	// for MMI use to open UT channel, then SMB server can send password into CNC 

	INT SMBputUTPassword( char *szUTPass, char *szRetPassword  );
	// for SMB server use to send password into CNC

private:
	ULONG *m_nUTData;
	// use time data array

	INT m_nPassVer;
	// current password use version

	BOOL m_bIsV1Clear;
	// if use V1 to clear factory key

	char m_szSerialNo[ 20 ];
	// record serial no for V4 use

	long m_nCncVersion;
	// record current Version No.

	IUseTimeVer *m_pPassHandler;
	// password decode handler

	IUseTimeVer *m_pPassV1;
	// password V1 decode handler, for clear factory key

	void getPassVerData( void *pSetInfo );
	// get Password version factory key information

	ULONG setPasswordVer( ULONG nPassStatus, ULONG nPassVer );
	// set Password version number

	INT getPasswordType( INT nPassVer, INT nStatus );
	// password status, no limit, in time limit, hardware not match.. 
	// 0�Gno limit
	// 1�Gin time protected
	// 2�Ghardware not match (change cpu board)
	// 3�Ghardware not match
	// 4�Gtime modify
	// 5�Ginvalid upgrade version(net version password be solved at pre version)

	void getSerialNoCheckSum( char *szSerial, char *szSeed, char *szCheckSum );
	// calculate Check sum string from Serial No and password Seed

	void upDatePassData( INT nCurStatus  );
	// if password ok, then update data from password content

	ULONG UTDataGet( INT nIndex );
	// read value from UTData

	void UTDataPut( INT nIndex, ULONG nValue );
	// update value into UTData

private:
// SMB UseTime Service private
	CSMBUTPass *m_pSMBUTPass;
	// SMB password service  handler

};

#endif // !defined(AFX_UTPASSWORD_H__B1AB5FE9_FC4E_4500_B3ED_61FAC062DEC4__INCLUDED_)

