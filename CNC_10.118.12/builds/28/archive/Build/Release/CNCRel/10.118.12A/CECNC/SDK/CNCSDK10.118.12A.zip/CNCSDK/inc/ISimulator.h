// ISimulator.h: interface for the ISimulator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISIMULATOR_H__C21A5085_F848_4188_A0DE_AFE63DFFB249__INCLUDED_)
#define AFX_ISIMULATOR_H__C21A5085_F848_4188_A0DE_AFE63DFFB249__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OpenCNCDef.h"
#include "AxisDimension.h"
#include "IAlarmStore.h"

#ifndef NCBLOCKDATA_STRUCT_
#define NCBLOCKDATA_STRUCT_

typedef struct tagTNcBlockData {
		long	BlockID;				// unique block ID
		long	ClassID;				// class identifier
		long	Opcode;					// opcode
		union {
			struct {
				short cArgs;							// number of argument
				TOcVariant vArgs[MAX_MotReqPktArgs];	// argument array
			};
			struct {
				double	Destination[NUMOF_SIMUAXIS];	// X/Y/Z/A/B/C/U/V/W
				double	Center[3];						// I/J/K
				long	nNumberOfRevolution;			// number of revolution
			};
		};
		char	ProgramName[LENOFPROGRAMNAME];		// program name
		long	LineNo;								// line number
		long	SequenceNo;							// sequence number
} TNcBlockData;

#endif // NCBLOCKDATA_STRUCT_

class ISimulator  
{
public:

	virtual ~ISimulator() {}
	// virtual destructor is required for correctly deleteing members of son classes

	virtual void GetAlarmList( /*[out]*/ TOcAlarmInfo *pAlarmList, /*[in]*/ long nSizeToRead, /*[out]*/ long *lpSizeRead) = 0;
	// to get all alarm list

	virtual void parseBlocks( long CoordID, char *pBlocks, char *buffer, DWORD count, long NShift ) = 0;
	// parse blocks

	virtual void putMDIBlocks( char *pBlocks ) = 0;
	// put MDI blocks

	virtual void open( long CoordID, char *ProgName ) = 0;
	// open to allocate resource for simulation
	// please call this method before call Go/Step/Abort command

	virtual void topen( long CoordID, TCHAR *ProgName ) = 0;
	// open to allocate resource for simulation
	// please call this method before call Go/Step/Abort command

	virtual void setStartLineNo( long nLineNumber ) = 0;
	// set start line number
	// NOTE: this function should be called before open

	virtual BOOL GetBlockData(
		TNcBlockData *lpBuffer,
		DWORD nNumberOfBlocksToRead,
		LPDWORD lpNumberOfBlocksRead
	) = 0;
	// get NC block data

	virtual BOOL isAlarm( void ) = 0;
	// check whether simulator is in alarm state?

	virtual BOOL isEOF( void ) = 0;
	// check whether simulator is end of stream

	virtual void close( void ) = 0;
	// close to release locked resources
	// please call this method when no use

	virtual void getAxisDimContexts( TAxisDimContext pContext[] ) = 0;
	// get array of axis dimension context, this function should be called
	// after simulator has been open

	virtual void getAlarmLocation( char *ProgramName, long *LineNo, long *SequenceNo ) = 0;
	// get current block information

	virtual void setSearchPath( char *pPath ) = 0;
	// assign search path for simulation

	virtual void getSearchPath( char *pBuffer ) = 0;
	// get search path for simulation

	virtual BOOL CNCAPI GetGlobalVariable( int no, TOcVariant *value ) = 0;
	// get global variable value of parser associated channel
	// return TRUE when variable exist, else return FALSE
};

#endif // !defined(AFX_ISIMULATOR_H__C21A5085_F848_4188_A0DE_AFE63DFFB249__INCLUDED_)
