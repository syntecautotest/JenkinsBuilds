// HomeSearchCore.h: interface for the CHomeSearchCore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOMESEARCHCORE_H__46081753_61DE_4F45_B02A_508F6E2755F2__INCLUDED_)
#define AFX_HOMESEARCHCORE_H__46081753_61DE_4F45_B02A_508F6E2755F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IHomeSearchInfo;

class CHomeSearchCore  
{
public:
	// home home searching type
	enum enumHomeType {
		HMTP_FirstIndex,		// first index position
		HMTP_BeforeDogIndex,	// the last index position before dog
		HMTP_OnDogFirstIndex,	// the first index position on dog
		HMTP_OnDogLastIndex,	// the last index position on dog
		HMTP_AfterDogIndex,		// the first index position after dog
		HMTP_HomeDog,			// just home dog himself
		HMTP_OnLeaveDog			// on leave home dog
	};

public:
	CHomeSearchCore();
	virtual ~CHomeSearchCore();

	void AssociateIHomeSearchInfo( IHomeSearchInfo *pHomeSearchInfo );
	// associate IHomeSearchInfo object

	void InterpolationTick( void );
	// interpolation time tick.
	// Use threads: motion plan

	void AbortHomeSearch( void );
	// abort home search process
	// Use threads: <= interpolation

	void SelectHomeType( int HomeType );
	// select home position type of home search function
	// Use threads: <= interpolation

	void StartHomeSearch( void );
	// start home search process
	// Use threads: <= interpolation

	double ReadHomePosition( void );
	// read	home position, in BLU
	// this function must be used when home idle and
	// home found
	// Use threads: <= interpolation

	BOOL isSearchHomeDog( void );
	// query whether it is searching home dog

	int IsHomeIdle( void );
	// query whether the home search task is finished ?
	// for index-based home search algorithm, this function
	// must detect no index alarm and enter idle state
	// automatically, if not, then will cause mechanical
	// damage, because machine will no stop to finding home. 
	// Use threads: <= interpolation

	int IsHomeFound( void );
	// query whether the home position has been found ?
	// this function must be used when home idle.
	// Use threads: <= interpolation

protected:
	IHomeSearchInfo *m_pHomeSearchInfo;
	// pointer to associated IHomeSearchInfo object

private:
	enum EHomeState {
		EHS_Idle = 0,
		EHS_CompleteHome,
		EHS_NowOnHomeDog,
		EHS_JustHomeDog,
		EHS_SearchIndex,
	};

private:

	int m_HomeType;
	// home type

	int m_HomeState;
	// homing state

	double m_HomePosition;
	// latched home position, in BLU

	int	m_fHomeFound;
	// whether home has been found

	int m_fTempHomeLatched;
	// whether temp home has been latched

	double m_TempHomePosition;
	// temp home position, in BLU

	void RunRawHoming( void );
	// run raw homing

	virtual BOOL IsOnHomeDog( void ) = 0;
	// query whether current is above home dog
	// Use threads: <= interpolation
};

#endif // !defined(AFX_HOMESEARCHCORE_H__46081753_61DE_4F45_B02A_508F6E2755F2__INCLUDED_)
