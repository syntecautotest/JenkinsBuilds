// CurvatureCalculator.h: interface of the CCurvatureCalculator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_CURVATURECALCULATOR_H____INCLUDED_)
#define _CURVATURECALCULATOR_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_NUMBER_KICK_NODES				96		// must large than 3
#define UNREACHABLE_RADIUS					1.0E60

struct TLANode;
class CFeedLimit;
class CLAQueue;
class CPoint3d;
class CTuple3d;
class CLANodePool;
class CKickNode;
class CCurvatureCalculatorNode;

class CCurvatureCalculator
{
public:
	CCurvatureCalculator( int nQueueSize, CFeedLimit *pFL, CLANodePool *pLAPool );
	// constructor

	~CCurvatureCalculator(void);
	// destructor

	void SetChordErrorTolerance( double tolerance );
	// set chord error tolerance in IU

	void SetKickTolerance( double tolerance );
	// set kick tolerance in IU

	void putArcCondition( double MaxCentripetalForce );
	// put arc condition in IU / us

	void Abort(void);
	// release queued nodes in m_CCQueue

	void CalculateCurvature( TLANode *pNode );
	// Calculate curvature of ready nodes of m_CCQueue when the block pNode is put in.
	// Move them from m_CCQueue to m_pReceiverLAPipe->m_RawQue and calculate corner feature.

	void flushCCQueue( void );
	// to flush all nodes in curvature calculator queue
	// need to confirm that all G01/G02/G03 blocks in CCQueue have been put into m_pKickNodeBuf before use this function

	BOOL IsEmpty( void );
	// query whether m_CCQueue is empty

	TLANode *rpeek( int index );
	// reversely peek a node in CCQueue

	int getCountOfCCQue( void );
	// get number of C.C.Queue

	void NotifyNoCorner( BOOL bflag );
	// notify if corner existed

private:
	int m_nNumOfCCNodes;
	// number of curvature calculator nodes

	CCurvatureCalculatorNode m_FirstCCNode;
	// first curvature calculator node

	CCurvatureCalculatorNode m_SecondCCNode;
	// second curvature calculator node

	double m_FirstLength;
	// Length of first curvature calculator node

	double m_SecondLength;
	// Length of second curvature calculator node

	double m_InnerProduct;
	// the inner product of m_FirstCCNode and m_SecondCCNode

	double m_CosineTheta;
	// cosine theta between m_FirstCCNode and m_SecondCCNode

	double m_SineTheta;
	// sine theta between m_FirstCCNode and m_SecondCCNode

	double m_FittingRadius;
	// fitting radius

	double m_CachedFittingRadius;
	// cached fitting radius

	double m_MaxChordError;
	// maximum chord error

	double m_CornerFactor;
	// corner factor

	double m_CachedCornerFactor;
	// cached corner factor

	double m_ChordErrorTolerance;
	// chord error tolerance

	CLAQueue m_CCQueue;
	// curvature calculator queue

	CFeedLimit *m_pFL;
	// look ahead cutting object

	CLANodePool *m_pLAPool;
	// free look ahead node pool

	CKickNode *m_pKickNodeBuf;
	// the point buffer

	double m_Kick_Tolerance, m_Kick_ToleranceSquare;
	// the kick tolerance and the Square

	int m_nMaxNumOfKickNodes;
	// max number of kick nodes in buffer queue

	int m_nNumOfKickNodes;
	// number of kick nodes in buffer queue

	BOOL m_bInAbort;
	// flag in abort

	double m_MaxCentripetalForce;
	// record the max centripetal force from CFeedLimit

	double m_CCNodeFclamp;
	// record the max Fclamp in a CCnode

	BOOL m_bNoCorner;
	// if no need to consider corner case

private:
	void InitVariable( void );
	// initialize variables

	BOOL ProcessSpiralNode( TLANode *pNode );
	// process spiral node

	void KickingProcess( TLANode *pNode );
	// calculate kicking error and set curvature vector

	void PutIntoKickBuffer( TLANode *pNode );
	// put node into kick buffer
	// return the number of buffered kick nodes

	void InitializeKickNodeBuffer( double tuple[] );
	// initialize kick node buffer with tuple

	void SetCurvatureVector( CKickNode &node, int nNumOfContainedNodes );
	// set curvature vector

	BOOL CheckKickingError(void);
	// check kicking error
	// return TRUE if some error is significant

	BOOL IsErrorSignificant( CKickNode &KickNode1, CKickNode &KickNode2 );
	// Calculate the error, which is the distance from KickNode1 to
	// the line passing through the origin and KickNode2.
	// Return whether the error is significant.

	void CalcChordErrAndReleaseFirstCCNode( void );
	// Calculate chord error and release first CC node.

	void CalculateChordError(void);
	// calculate chord error

	void CalculateCornerFactor( void );
	// calculate current corner factor

	void ReCalculateFittingRadius( void );
	// re-calculate fitting radius

	void ReleaseFirstCCNode( void );
	// Release first CC node.

	void SetRadius( const double radius, int nNumOfNodes );
	// set fitting radius to nodes in m_FirstCCNode in front of m_CCQueue

	void SetRadius_OneNode( const double radius, BOOL bIsCompleteArc );
	// set fitting radius to one node in front of m_CCQueue

	void calcCCEnterLeaveVector( int nNumOfNodes );
	// calculate curvature calculator enter unit vector, leave unit vector

	void GetFirstNonFuncCallNode( int &nStartIndex, TLANode *&pNode );
	// get first non-function-call node from nStartIndex in CCQueue
};

#endif // !defined(_CURVATURECALCULATOR_H____INCLUDED_)
