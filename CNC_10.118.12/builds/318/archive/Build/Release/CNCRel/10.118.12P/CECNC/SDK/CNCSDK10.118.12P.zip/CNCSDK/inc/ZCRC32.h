// ZCRC32.h: interface for the CZCRC32 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZCRC32_H__EB49A3E3_066D_11D3_83FC_0000E86B4150__INCLUDED_)
#define AFX_ZCRC32_H__EB49A3E3_066D_11D3_83FC_0000E86B4150__INCLUDED_

#include "nstdlib.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CZCRC32
{
public:
	CZCRC32();
	virtual ~CZCRC32();

	void reset( void );
	// Resets CRC-32 to initial value.

	unsigned long getValue( void );
	// Returns CRC-32 value.

	void update( int b );
	// Updates CRC-32 with specified byte.

	void update( const BYTE b[], unsigned off, unsigned len );
	// Updates CRC-32 with specified array of bytes.

	void update( const BYTE b[], unsigned len );
	// Updates CRC-32 with specified array of bytes.

private:
	void CalcCRC32( BYTE b );
	// Updates CRC-32 with specified byte.

	unsigned long m_CRC;
	// the current accumulated CRC32 checksum

	static unsigned long m_CRCTable[256];
	// CRC helper table
};

#endif // !defined(AFX_ZCRC32_H__EB49A3E3_066D_11D3_83FC_0000E86B4150__INCLUDED_)
