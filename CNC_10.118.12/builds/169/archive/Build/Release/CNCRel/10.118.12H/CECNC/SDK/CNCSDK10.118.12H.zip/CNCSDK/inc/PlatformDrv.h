// PlatformDrv.h: Public Macro Define.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLATFORMDRV_H__17EF6CBD_6A58_4FCF_A3BD_5ED1412AFB58__INCLUDED_)
#define AFX_PLATFORMDRV_H__17EF6CBD_6A58_4FCF_A3BD_5ED1412AFB58__INCLUDED_

// the LED twinkle interval in ms.
#define SPD_LED_STOP				-1
#define SPD_LED_SLOW				500
#define SPD_LED_FAST				200

#if defined(PLATFORM_DRIVER)

// STARM2 dummy ID
#define HW_STARM2		( 0xFF )
#define HW_X8610A10B	( 0xF0 )
#define HW_X8620DHYBRID	( 0xF1 )
#define HW_X86RTEX		( 0xF5 )
#define HW_SUPPER		( 0xC0 )
#define HW_NEW21MAH		( 0x80 )

// Hardware ID
#define HW_3Av1						0x00
#define HW_3Av2						0x10
#define HW_3Bv1						0x01
#define HW_3Bv2						0x11
#define HW_30GM						0x02
#define HW_HHB						0x03
#define HW_21A_M2_080				0x04
#define HW_11B						0x05
#define HW_M2_098_M3_IP				0x0B
#define HW_eHMC_Step				0x08
#define HW_4in1Driver				0x09 // ARM:	4 in 1 Driver			HW_ID:0x09
#define HW_HighEndFC				0x12
#define HW_FC_M3					0x15
#define HW_HC8C						0xFF
#endif

enum EDevice {
	DEVICE_FRAM = 0,
	DEVICE_CNC2,
	DEVICE_M2,
	DEVICE_FLEXRAY,
	DEVICE_CPLD,
	DEVICE_M3,
	DEVICE_SRI,
	DEVICE_ETHCAT,
	DEVICE_GALVO,
	DEVICE_RTEX,
	DEVICE_CNC1,
};

enum LEDMode {
	LED_OFF = 0,
	LED_SLOW,
	LED_FAST,
	LED_ON
};

// these sequence IDs are depend on circuits
enum LEDID {
	LED_RUN = 1,
	LED_RS485,
	LED_ALARM,
	LED_WATCHDOG,
};

#endif // !defined(AFX_PLATFORMDRV_H__17EF6CBD_6A58_4FCF_A3BD_5ED1412AFB58__INCLUDED_)
