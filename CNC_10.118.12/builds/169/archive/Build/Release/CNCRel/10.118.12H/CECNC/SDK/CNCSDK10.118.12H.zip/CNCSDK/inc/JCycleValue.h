#if !defined(_JCYCLEVALUE_H_INCLUDED_)
#define _JCYCLEVALUE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "JCycleSchema.h"

class CJXmlTextWriter;
class CJXmlTextReader;
class CJCycleSchemaPool;

class CJCycleValue
{
public:
	CJCycleValue(void);
	~CJCycleValue(void);

	HRESULT loadDefault( CJCycleSchema *objCycleSchema );
	// set value from cycle schema

	HRESULT deserialize( CJXmlTextReader *objReader, CJCycleSchemaPool *objPool );
	// init object by specified cycle node in CycleSchemaPool

	HRESULT deserialize( CJXmlTextReader *objReader, CJCycleSchemaPool **objPool, UINT nPoolCount );
	// init object by specified cycle node in Multi-CycleSchemaPool

	void serialize( CJXmlTextWriter *objWriter );
	// to desearalize object content into XML writer
	
	enum EMaxBound {
		SIZE_ColorRGB = 16
	};

	struct TFieldValue {

		enum EMaxBound {
			SIZE_SimpleValue = 16,
		};

		enum EFieldValueType {
			FVT_SimpleValue,
			FVT_SimpleValueArray,
			FVT_XMLData,
			FVT_VLString
		};

		int	m_nValueType;
		TCHAR m_szSimpleValue[SIZE_SimpleValue];
		TCHAR *m_lpszCLOB;
		LONG m_nCLOBLength;
		CJCycleSchema::TFieldSchema *m_lpFieldSchema;

		void set_CLOBLength( LONG nLength );
		void cleanup( void );
		void init( CJCycleSchema::TFieldSchema *lpFieldSchema );
		void deserialize( CJXmlTextReader *objReader );
		void serialize( CJXmlTextWriter *objWriter );

		BOOL isCLOB( void );
		BOOL isArray( void );

		void standardize( LPTSTR lpszValue );

		TCHAR *get_Value( void );
		TCHAR *get_Value( LONG nIndex );

		void put_Value( LPCTSTR lpszNewValue );
		void put_Value( LONG nIndex, LPCTSTR lpszNewValue );
	};

	LONG m_nFieldCount;
	// number of field count

	TCHAR *get_FieldName( LONG nIndex );
	TFieldValue *get_FieldValue( LONG nIndex );
	TFieldValue *get_FieldValue( LPCTSTR lpszFieldName );
	CJCycleSchema::TFieldSchema *get_FieldSchema( LONG nIndex );
	TCHAR *get_CycleName( void );
	TCHAR *get_LineBackColor( void );
	void set_LineBackColor( LPCTSTR lpszNewColor );

private:

	// field value buffer
	TFieldValue *m_FieldValue;
	LONG m_nValueBufferSize;
	// field value data buffer
	
	// lineheader backcolor buffer
	TCHAR m_szBackColor[SIZE_ColorRGB];

	CJCycleSchema *m_objCycleSchema;
	// the associate cycle schema object
};

#endif // !defined(_JCYCLEVALUE_H_INCLUDED_)
