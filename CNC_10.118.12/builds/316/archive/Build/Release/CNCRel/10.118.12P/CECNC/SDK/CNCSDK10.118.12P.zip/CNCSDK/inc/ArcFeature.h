#if !defined(_ARCFEATURE_H____INCLUDED_)
#define _ARCFEATURE_H____INCLUDED_

class CArcFeature
{
public:
	CArcFeature( void );
	~CArcFeature( void );

	static void calcPerpendicularVector( double InVal[], double normal[], double OutVal[] );
	// to calculate vector which perpendicular to specified normal vector

	void set( CVector3d &vDisp, CVector3d &vCenter, CVector3d &vRefNormal, LONG nNumOfRev );
	// to set 3-D arc data

	void set( int code, double displacement[], double center[], double vRefNormal[], long nNumOfRev );
	// to set 3-D arc data

	BOOL isValidArc( void );
	// check whether it is valid arc

	DOUBLE getLength( void );
	// get length of arc

	DOUBLE getAngleSpan( void );
	// get span angle

	DOUBLE getWPQuantity( void );
	// get the workplane quantity amount

	double getZQuantity( void );
	// get the helical-Z axis quantity amount.this value may be negative,
	// when Z-axis displacement is different with its normal vector.

	double getStartRadius( void );
	// get start radius amount   

	double getEndRadius( void );
	// get end radius amount   

	void getTransform( /*[out]*/double Tx[] );
	// to get transform matrix

	void getEnterDirection( /*[out]*/DOUBLE direction[] );
	// to get enter unit vector at start point

	void getLeaveDirection( /*[out]*/DOUBLE direction[] );
	// to get leave unit vector at end point

	void getDispVector( DOUBLE Disp[] );
	// to get displacement vector

	BOOL getArcError( DOUBLE &ArcError );
	// to get arc error

	void queryPoint( /*[in]*/double ratio, /*[out]*/double displacement[] );
	// to query arc point, which has specified distance ratio retative to start point of arc.

	void SplitToHalf( CArcFeature &StartArc, CArcFeature &EndArc );
	// to split arc to two half arcs

private:
	LONG m_nNumOfRev;
	// number of revolutions

	CVector3d m_vDisplacement;
	// vector from start position to end position

	CVector3d m_vCenter;
	// vector from start position to center point

	CVector3d m_vStart;
	// vector from center point to start position

	CVector3d m_vEnd;
	// vector from center point to end position

	CVector3d m_vNormal;
	// normal vector working plane

	BOOL m_bValidArc;
	// flag for valid arc

	double m_RadiusDestortion;
	// radius distortion

	DOUBLE m_AngleSpan;
	// angle span of the arc, unit: rad

	BOOL m_bAngleSpan;
	// flag that whether angle span was calculated, for time saving uses

	double m_WPQuantity;
	BOOL m_bWPQuantity;
	// length of projection on work plane

	double m_Length;
	BOOL m_bLength;
	// arc total length

	CVector3d m_vEnterDirection;
	BOOL m_bEnterDirection;
	// enter direction

	CVector3d m_vLeaveDirection;
	BOOL m_bLeaveDirection;
	// leave direction

	double m_Tx[9];
	BOOL m_bTx;
	// transform matrix

	DOUBLE m_ArcError;
	// distance between the middle point of the arc and the displacement

	BOOL m_bArcErrorCalulated;
	// flag that whether arc error was calculated, for time saving use

private:	// helper function
	void calcTransform( void );
	// to calculate transform matrix

	void doTransfrom( double &x, double &y, double &z );
	// do transform from arc coordinate to world coordinate
};

#endif // !defined(_ARCFEATURE_H____INCLUDED_)
