// LAFilter.h: interface for the CLAFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LAFILTER_H__8365814F_E832_41DE_BAB9_BFD9922E652D__INCLUDED_)
#define AFX_LAFILTER_H__8365814F_E832_41DE_BAB9_BFD9922E652D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLANodePool;

class CLAFilter
{
public:
	CLAFilter( CLAFilter *pLAFilter, CLANodePool *pLAPool ) :
	m_pLAPool( pLAPool )
	// constructor
	{
		m_pCascadeLAFilter = pLAFilter;
	}

	virtual ~CLAFilter( void ) {}
	// destructor

public:
	virtual void putLANode( TLANode *pNode, double eParam1 = 0 ) = 0;
	// put LA Node

	virtual void setExactStop( void ) = 0;
	// set exact stop

	virtual void setEOBMark( const TPacketInfo &PacketInfo ) = 0;
	// set EOB Mark

#ifndef NDEBUG
protected:
	BOOL IsUnitVector( const double v[], const int nCount )
	// is unit vector
	{
		double length = 0.0;
		for( int i = 0; i < nCount; i++ ) {
			length += v[i] * v[i];
		}
		length = CZMath::zSqrt( length );
		return CZMath::zFabs( length - 1 ) < CZMath::EPSILON_double * 1.0e3;
	}
#endif

protected:
	CLAFilter *m_pCascadeLAFilter;
	// reference to next cascaded filter

	CLANodePool *m_pLAPool;
	// assoiate free node pool
};
#endif // !defined(AFX_LAFILTER_H__8365814F_E832_41DE_BAB9_BFD9922E652D__INCLUDED_)
