// HugeLinePage.h: interface for the CHugeFileSharedEditor class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_HUGEFILESHAREDEDITOR_H__C5F29712_B42F_4F31_8693_12787C1F361D__INCLUDED_)
#define AFX_HUGEFILESHAREDEDITOR_H__C5F29712_B42F_4F31_8693_12787C1F361D__INCLUDED_

#include "ILineStore.h"
#include "HugeFileEditor.h"

class CHugeFileSharedEditor : public ILineStore
{
private:
	CHugeFileReader m_HReader;
	CHugeFileEditor *m_HEditor;

public:		// constructor and destructor
	CHugeFileSharedEditor( long nMaxEditTableSize = 1024 );
	virtual ~CHugeFileSharedEditor();
	
public:		// implement ILineStore interface
	int CNCAPI readLine( long lineno, void *buffer, int count );
	// return the character(with terminate char) counts in specified line,
	// when count is 0 and buffer is NULL then return the actual size
	// of specified line

	long CNCAPI getLineCount( void );
	// return the total line count

	void CNCAPI clearAll(void);
	// clear all content

	BOOL CNCAPI insert( long lineno, void *data, int size );
	// this function not support in this class
	// insert data before specified line number.
	// return TRUE, when successful, others, return FALSE.

	BOOL CNCAPI append( void *data, int size );
	// this function not support in this class
	// append specified data at the tail of whole data.

	BOOL CNCAPI deleteLine( long lineno );
	// this function not support in this class
	// delete specified line, this function will all behind line move
	// forward one line

	BOOL CNCAPI put( long lineno, void *data, int size );
	// this function not support in this class
	// put specified data into specified line

	BOOL CNCAPI erase( long lineno );
	// this function not support in this class
	// erase specified line data, this function just rease specified
	// line data, and no move behind line forward.

public:		// connection interface
	BOOL CNCAPI connect( char *filename );
	// connect to specified filename
	// return TRUE when success, FALSE when failure

	void CNCAPI disconnect( void );
	// disconnect with current connected file

	CHugeFileEditor * CNCAPI clone(CHugeFileSharedEditor *cloneSource);

	BOOL CNCAPI savefile( void );
	// to save file data, when dirty

private:	// object state

	long m_nMaxEditTableSize;
	// maximum edit table size

};

#endif // !defined(AFX_HUGEFILESHAREDEDITOR_H__C5F29712_B42F_4F31_8693_12787C1F361D__INCLUDED_)
