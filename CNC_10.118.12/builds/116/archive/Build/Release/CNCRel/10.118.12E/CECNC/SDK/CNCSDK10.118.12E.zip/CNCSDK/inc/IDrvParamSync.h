// IDrvParamSync.h: interface for the IDrvParamSync class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IDRVPARAMSYNC_H__INCLUDED_)
#define AFX_IDRVPARAMSYNC_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IDrvParamSync
{
public:
	virtual ~IDrvParamSync( void ) {}
	// destructor

	virtual void UpdateCtrlParam( void *pCtrlParam ) = 0;
	// update control parameters
};

#endif // !defined(AFX_IDRVPARAMSYNC_H__INCLUDED_)
