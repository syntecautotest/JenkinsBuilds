#if !defined(_SERIALPARAMDF_H__INCLUDED_)
#define _SERIALPARAMDF_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// param access status
enum EParamStatus {
	PSTATUS_Fail = 0,
	PSTATUS_Success,
	PSTATUS_Busy,
	PSTATUS_Exception,
	PSTATUS_NotSupport,
};

enum EParamSaveState {
	PARAMSAVE_IDLE = 0,
	PARAMSAVE_START,
	PARAMSAVE_PROCESS,
};

// Yaskawa identical param define
#define PARAM_FuncSelect2_Yaskawa			(0x002)
#define PARAM_SpeedLoopGain_Yaskawa			(0x100)
#define PARAM_SpeedIntTimeConst_Yaskawa		(0x101)
#define PARAM_PositionLoopGain_Yaskawa		(0x102)
#define PARAM_MomentInertiaRatio_Yaskawa	(0x103)
#define PARAM_2ndSpeedLoopGain_Yaskawa		(0x104)
#define PARAM_2ndSpeedIntTimeConst_Yaskawa	(0x105)
#define PARAM_2ndPositionLoopGain_Yaskawa	(0x106)
#define PARAM_FeedforwardGain_Yaskawa		(0x109)
#define PARAM_FrictionCompGain_Yaskawa		(0x121)
#define PARAM_2ndFrictionCompGain_Yaskawa	(0x122)
#define PARAM_GainChangeoverSwitch_Yaskawa	(0x139)
#define PARAM_ModelCtrlGain_Yaskawa			(0x141)
#define PARAM_ModelCtrlGainComp_Yaskawa		(0x142)
#define PARAM_2ndModelCtrlGain_Yaskawa		(0x148)
#define PARAM_2ndModelCtrlGainComp_Yaskawa	(0x149)
#define PARAM_SoftStartAcceTime_Yaskawa		(0x305)
#define PARAM_SoftStartDeceTime_Yaskawa		(0x306)
#define PARAM_TrqFilterTimeConst_Yaskawa	(0x401)
#define PARAM_2ndTrqFilterTimeConst_Yaskawa	(0x412)
#define PARAM_VelCompleteWidth_Rot_Yaskawa	(0x503)
#define PARAM_PosCompleteWidth_Yaskawa		(0x522)
#define PARAM_CommCtrl_Yaskawa				(0x800)
#define PARAM_FirstAcceConst1_Yaskawa		(0x80A)
#define PARAM_SecondAcceConst1_Yaskawa		(0x80B)
#define PARAM_FirstDeceConst1_Yaskawa		(0x80D)
#define PARAM_SecondDeceConst1_Yaskawa		(0x80E)




#define PARAM_CmdDataAllocation_Yaskawa		(0x81F)
#define PARAM_LinearAccDecConstSel_Yaskawa	(0x833)
#define PARAM_FirstAcceConst2_Yaskawa		(0x834)
#define PARAM_SecondAcceConst2_Yaskawa		(0x836)
#define PARAM_FirstDeceConst2_Yaskawa		(0x83A)
#define PARAM_SecondDeceConst2_Yaskawa		(0x83C)



// M3 Yaskawa param define
#define M3_PARAM_EncoderType_Yaskawa		(0xA02)
#define M3_PARAM_MotorType_Yaskawa			(0xA04)
#define M3_PARAM_ClosedCtrlSelect_Yaskawa	(0xA06)
#define M3_PARAM_RatedSpeed_Yaskawa			(0xA08)
#define M3_PARAM_MaxSpeed_Yaskawa			(0xA0A)
#define M3_PARAM_SpeedMultiplier_Yaskawa	(0xA0C)
#define M3_PARAM_Resolution_Yaskawa			(0xA14)
#define M3_PARAM_RatedTorque_Yaskawa		(0xA0E)
#define M3_PARAM_MaxTorque_Yaskawa			(0xA10)
#define M3_PARAM_TorqueMultiplier_Yaskawa	(0xA12)
#define M3_PARAM_SpeedUnitSelect_Yaskawa	(0xA82)
#define M3_PARAM_SpeedBaseUnit_Yaskawa		(0xA84)
#define M3_PARAM_PositionUnitSelect_Yaskawa	(0xA86)
#define M3_PARAM_PositinBaseUnit_Yaskawa	(0xA88)
#define M3_PARAM_AccUnitSelect_Yaskawa		(0xA8A)
#define M3_PARAM_AccBaseUnit_Yaskawa		(0xA8C)
#define M3_PARAM_TorqueUnitSelect_Yaskawa	(0xA8E)
#define M3_PARAM_TorqueBaseUnit_Yaskawa		(0xA90)

// M2 Syntec param define
#define M2_PARAM_SpeedControlMode_Syntec	(101)
#define M2_PARAM_PositionLoopGain_Syntec	(201)
#define M2_PARAM_SpeedLoopGain_Syntec		(202)
#define M2_PARAM_SpeedIntegralTime_Syntec	(203)
#define M2_PARAM_SpeedFilterTime_Syntec		(204)
#define M2_PARAM_MomentInertiaRatio_Syntec	(205)
#define M2_PARAM_TorqueFilterTime_Syntec	(206)
#define M2_PARAM_MachineType_Syntec			(223)
#define M2_PARAM_MotorModel_Syntec			(303)
#define M2_PARAM_MotorSerialNo_Syntec		(304)
#define M2_PARAM_EncoderType_Syntec			(323)
#define M2_PARAM_EncParamProtect_Syntec		(332)
#define M2_PARAM_EncoderSensorType_Syntec	(333)
#define M2_PARAM_SvoPackModel_Syntec		(507)
#define M2_PARAM_AccelerationTime_Syntec	(610)
#define M2_PARAM_JerkTime_Syntec			(611)
#define M2_PARAM_HomeOffset_Syntec			(620)
#define M2_PARAM_SvoPackSoftVer_Syntec		(1000)
#define M2_PARAM_EncoderSoftVer_Syntec		(1005)
#define M2_PARAM_AuxiliaryFunction_Syntec	(2000)
#define M2_PARAM_JogDirection_Syntec		(2001)
#define M2_PARAM_JogSpeed_Syntec			(2002)
#define M2_PARAM_JogMode_Syntec				(2003)
#define M2_PARAM_TuningLimit_Syntec			(2004)
#define M2_PARAM_TuningMode_Syntec			(2010)
#define M2_PARAM_ParamSave_Syntec			(2030)
#define M2_PARAM_ParamAccess_Syntec			(2031)
#define M2_PARAM_ParamInit_Syntec			(2033)

// M3 Syntec Param.
#define M3_PARAM_ScpChannelId_Syntec			(0x035)
#define M3_PARAM_SpeedLoopGain_Syntec			PARAM_SpeedLoopGain_Yaskawa				// (0x100)
#define M3_PARAM_SpeedIntTimeConst_Syntec		PARAM_SpeedIntTimeConst_Yaskawa			// (0x101)
#define M3_PARAM_PositionLoopGain_Syntec		PARAM_PositionLoopGain_Yaskawa			// (0x102)
#define M3_PARAM_MomentInertiaRatio_Syntec		PARAM_MomentInertiaRatio_Yaskawa		// (0x103)
#define M3_PARAM_DualEnable_Syntec				(0x22A)
#define M3_PARAM_SoftStartAccDecTime_Syntec		PARAM_SoftStartDeceTime_Yaskawa			// (0x306)
#define M3_PARAM_SpeedFilterTimeConst_Syntec	(0x308)
#define M3_PARAM_MachineType_Syntec				(0x335)
#define M3_PARAM_TrqFilterTimeConst_Syntec		PARAM_TrqFilterTimeConst_Yaskawa		// (0x401)
#define M3_PARAM_1stNFilterFreq_Syntec			(0x409)
#define M3_PARAM_2ndNFilterFreq_Syntec			(0x40C)
#define M3_PARAM_3rdNFilterFreq_Syntec			(0x417)
#define M3_PARAM_4thNFilterFreq_Syntec			(0x41A)
#define M3_PARAM_5thNFilterFreq_Syntec			(0x41D)
#define M3_PARAM_NFilterSwitch_Syntec(nID)		(0x461 + nID - 1)
#define M3_PARAM_PosCompleteWidth_Syntec		(0x522)
#define M3_PARAM_MotorType_Syntec				(0x700)
#define M3_PARAM_MotorSerialNum_Syntec			(0x706)
#define M3_PARAM_MotorRatedTorque_Syntec		(0x708)
#define M3_PARAM_MotorInertia_Syntec			(0x720)
#define M3_PARAM_Resolution_Syntec				(0x902)
#define M3_PARAM_EncoderType_Syntec				(0x904)
#define M3_PARAM_EncParamProtect_Syntec			(0x90C)
#define M3_PARAM_2ndResolution_Syntec			(0x922)
#define M3_PARAM_ScpDivider_Syntec				(0xC01)
#define M3_PARAM_ScpSwitch_Syntec				(0xC02)
#define M3_PARAM_ScpWDCleaner_Syntec			(0xC03)
#define M3_PARAM_ScpChEnable_Syntec(nCH)		(0xC10 + nCH)
#define M3_PARAM_ScpCh02DataType_Syntec			(0xC20)
#define M3_PARAM_ScpCh13DataType_Syntec			(0xC22)
#define M3_PARAM_ScpChMapIndex_Syntec(nCH)		(0xC30 + nCH)
#define M3_PARAM_PosCommand_Syntec				(0xD21)
#define M3_PARAM_PosFeedback_Syntec				(0xD22)
#define M3_PARAM_PosError_Syntec				(0xD23)
#define M3_PARAM_MechAngle_Syntec				(0xD24)
#define M3_PARAM_VelCommand_Syntec				(0xD26)
#define M3_PARAM_VelFeedback_Syntec				(0xD27)
#define M3_PARAM_VelError_Syntec				(0xD28)
#define M3_PARAM_DataTransPeriod_Syntec			(0xD43)
#define M3_PARAM_Scp2ndSinWave_Syntec			(0xE2B)
#define M3_PARAM_Scp2ndCosWave_Syntec			(0xE2C)
#define M3_PARAM_Password_Syntec				(0xF00)
#define M3_PARAM_AuxiliaryFunction_Syntec		(0xF10)
#define M3_PARAM_TuningLimit_Syntec				(0xF14)
#define M3_PARAM_TuningMode_Syntec				(0xF20)
#define M3_PARAM_Save_Syntec					(0xF40)
#define M3_PARAM_ParamInit_Syntec				(0xF43)
#define M3_PARAM_ChirpStartFreq_Syntec			(0xF70)
#define M3_PARAM_ChirpEndFreq_Syntec			(0xF71)
#define M3_PARAM_ChirpDuringTime_Syntec			(0xF72)
#define M3_PARAM_ChirpMagnitude_Syntec			(0xF73)
#define M3_PARAM_ChirpSetting_Syntec			(0xF74)
#define M3_PARAM_PwrOffReturnSwitch_Syntec		(0x804)
#define M3_PARAM_PwrOffReturnDisp_Syntec		(0x806)
#define M3_PARAM_SpeedUnitSelect_Syntec			(0x862)
#define M3_PARAM_SpeedBaseUnit_Syntec			(0x864)
#define M3_PARAM_PositionUnitSelect_Syntec		(0x866)
#define M3_PARAM_PositionBaseUnit_Syntec		(0x868)
#define M3_PARAM_AccUnitSelect_Syntec			(0x86A)
#define M3_PARAM_AccBaseUnit_Syntec				(0x86C)
#define M3_PARAM_TorqueUnitSelect_Syntec		(0x86E)
#define M3_PARAM_TorqueBaseUnit_Syntec			(0x870)

// M2 Syntec-V2 param
#define M2_PARAM_SpeedLoopGain_Syntec_V2		M3_PARAM_SpeedLoopGain_Syntec			// (0x100)
#define M2_PARAM_SpeedIntTimeConst_Syntec_V2	M3_PARAM_SpeedIntTimeConst_Syntec		// (0x101)
#define M2_PARAM_PositionLoopGain_Syntec_V2		M3_PARAM_PositionLoopGain_Syntec		// (0x102)
#define M2_PARAM_MomentInertiaRatio_Syntec_V2	M3_PARAM_MomentInertiaRatio_Syntec		// (0x103)
#define M2_PARAM_TrqFilterTimeConst_Syntec_V2	M3_PARAM_TrqFilterTimeConst_Syntec		// (0x401)
#define M2_PARAM_SoftStartAccDecTime_Syntec_V2	M3_PARAM_SoftStartAccDecTime_Syntec		// (0x306)
#define M2_PARAM_SpeedFilterTimeConst_Syntec_V2	M3_PARAM_SpeedFilterTimeConst_Syntec	// (0x308)
#define M2_PARAM_TuningLimit_Syntec_V2			M3_PARAM_TuningLimit_Syntec				// (0xF14)
#define M2_PARAM_MachineType_Syntec_V2			M3_PARAM_MachineType_Syntec				// (0x335)
#define M2_PARAM_TuningMode_Syntec_V2			M3_PARAM_TuningMode_Syntec				// (0xF20)
#define M2_PARAM_AuxiliaryFunction_Syntec_V2	M3_PARAM_AuxiliaryFunction_Syntec		// (0xF10)
#define M2_PARAM_PosCompleteWidth_Syntec_V2		M3_PARAM_PosCompleteWidth_Syntec		// (0x522)
#define M2_PARAM_Password_Syntec_V2				M3_PARAM_Password_Syntec				// (0xF00)
#define M2_PARAM_EncParamProtect_Syntec_V2		M3_PARAM_EncParamProtect_Syntec			// (0x90C)
#define M2_PARAM_ParamInit_Syntec_V2			M3_PARAM_ParamInit_Syntec				// (0xF43)

// CNC2 Galvo Module Param
#define CNC2_PARAM_KpCoefficient_Galvo		(0x000)
#define CNC2_PARAM_KvpCoefficient_Galvo		(0x002)
#define CNC2_PARAM_KviCoefficient_Galvo		(0x004)
#define CNC2_PARAM_LPFilterC1_Galvo			(0x006)
#define CNC2_PARAM_LPFilterC2_Galvo			(0x008)
#define CNC2_PARAM_LPFilterC3_Galvo			(0x00A)
#define CNC2_PARAM_LPFilterEnable_Galvo		(0x00C)
#define CNC2_PARAM_KpAmpFactor_Galvo		(0x010)
#define CNC2_PARAM_KvpAmpFactor_Galvo		(0x012)
#define CNC2_PARAM_KviAmpFactor_Galvo		(0x014)
#define CNC2_PARAM_LPFC1AmpFactor_Galvo		(0x016)
#define CNC2_PARAM_LPFC2AmpFactor_Galvo		(0x018)
#define CNC2_PARAM_LPFC3AmpFactor_Galvo		(0x01A)
#define CNC2_PARAM_NFilterA2_Galvo(nID)		(0x020 + ( nID - 1 ) * 0x20)
#define CNC2_PARAM_NFilterA1_Galvo(nID)		(0x022 + ( nID - 1 ) * 0x20)
#define CNC2_PARAM_NFilterA0_Galvo(nID)		(0x024 + ( nID - 1 ) * 0x20)
#define CNC2_PARAM_NFilterB1_Galvo(nID)		(0x026 + ( nID - 1 ) * 0x20)
#define CNC2_PARAM_NFilterB0_Galvo(nID)		(0x028 + ( nID - 1 ) * 0x20)
#define CNC2_PARAM_NFilterEnable_Galvo(nID)	(0x02A + ( nID - 1 ) * 0x20)
#define CNC2_PARAM_NFilterAmpFct_Galvo(nID)	(0x030 + ( nID - 1 ) * 0x20)
#define CNC2_PARAM_OriginOffset_Galvo		(0x088)
#define CNC2_PARAM_PositionLoopGain_Galvo	(0x100)
#define CNC2_PARAM_VelocityLoopGain_Galvo	(0x102)
#define CNC2_PARAM_VelDampingRatio_Galvo	(0x104)
#define CNC2_PARAM_LPFilterCutFreq_Galvo	(0x106)
#define CNC2_PARAM_LPFilterSwitch_Galvo		(0x108)
#define CNC2_PARAM_LoopFrequency_Galvo		(0x10A)
#define CNC2_PARAM_DACUnitFactor_Galvo		(0x11E)
#define CNC2_PARAM_NFilterFreq_Galvo(nID)	(0x120 + ( nID - 1 ) * 0x10)
#define CNC2_PARAM_NFilterQValue_Galvo(nID)	(0x122 + ( nID - 1 ) * 0x10)
#define CNC2_PARAM_NFilterDepth_Galvo(nID)	(0x124 + ( nID - 1 ) * 0x10)
#define CNC2_PARAM_NFilterSwitch_Galvo(nID)	(0x150 + ( nID - 1 ) * 0x02)
#define CNC2_PARAM_MotorInertia_Galvo		(0x1A0)
#define CNC2_PARAM_MotorInertiaFactor_Galvo	(0x1A2)
#define CNC2_PARAM_MirrorInertiaRatio_Galvo	(0x1A4)
#define CNC2_PARAM_EncResolution_Galvo		(0x1AA)

// M2/M3 Yaskawa Pn002
#define AbsEncoderUsage_Yaskawa			(0x0F00)
#define ExtEncoderUsage_Yaskawa			(0xF000)
#define CmdCtrlOption_Yaskawa			(0x000F)
#define TFF_TLIMAllocation_Yaskawa		(0x00F0)

// M2/M3 Yaskawa sigma5 Pn002.2
#define AEU_AbsEncoder_Sigma5			(0x0000)
#define AEU_IncEncoder_Sigma5			(0x0100)

// M2 Yaskawa Pn002.0
#define Disable_TLIM_TFF				(0)
#define UseTLIM_Yasakwa					(0x0001)
#define UseTFF_Yaskawa					(0x0002)

// M2 Yaskawa Pn81F.1
#define Setting_Unknown					( -1 )
#define Disable_Allocation				( 0 )
#define Enable_Allocation				( 0x0010 )

// M2/M3 Yaskawa sigma7/sigmaM Pn002.2
#define EU_DefEncoder_Sigma7			(0x0000)
#define EU_IncEncoder_Sigma7			(0x0100)
#define EU_SingleAbsEncoder_Sigma7		(0x0200)

// M2/M3 Yaskawa Pn002.3
#define EEU_DisuseExtEncoder_Yaskawa	(0x0000)

// M2/M3 Yaskawa Pn139
#define GainSwitchSelect_Yaskawa		(0x000F)
#define GainSwitchConditionA_Yaskawa	(0x00F0)

// M2/M3 Yaskawa Pn139.0
#define Max_GainSwitch_No				( 2 )
#define GainSwitch_Manual				( 0 )
#define GainSwitch_Automatic			( 2 )

// M2/M3 Yaskawa Pn800
#define WARNING_CHECK_MASK				(0x00F0)
#define IGNORE_WARNING_95X				(0x0020)
#define IGNORE_WARNING_94X_95X			(0x0030)
#define IGNORE_WARNING_95X_96X			(0x0060)
#define IGNORE_WARNING_94X_95X_96X		(0x0070)
#define IGNORE_WARNING_94X_95X_97X		(0x00B0)
#define IGNORE_WARNING_95X_96X_97X		(0x00E0)
#define IGNORE_WARNING_94X_95X_96X_97X	(0x00F0)

// M3 sigma5/sigma7S/sigma7W/ PnA02
#define M3_IncEncoder					(1)
#define M3_AbsEncoder					(0)

// M3 sigma5/sigma7S/sigma7W/ PnA06
#define M3_SemiClosed					(0)
#define M3_FullyClosed					(1)

// M2 sigma5/sigma7/sigmaM RealEncoderType by ADJ command
#define Encoder_NotDefine				(-1)
#define M2_IncEncoder_Yaskawa			(0)
#define M2_AbsEncoder_Yaskawa			(1)

// M2/M3 Syntec Param Save Fn-30
#define IDLE_Syntec						(0)
#define ParamSave_Syntec				(1)

// M2 Syntec Param Access Fn-31, M3 PnF00
#define ParamAccess						(520)

// M2 Syntec Driver Param init Fn-33
#define ParamInit_Syntec_M2				(1234)

// M3/M2_V2 Syntec Driver Param Init PnF43
#define ParamInit_Syntec_M3				(5678)
#define ParamInit_Syntec_M2_V2			ParamInit_Syntec_M3

// M2/M3 Syntec Encoder Type P3-23/Pn904
#define IncEncoder_Syntec			(0)
#define MultiAbsEncoder_Syntec		(1)
#define SingleAbsEncoder_Syntec		(2)

// M2 P3-32, M3 Pn90C
#define  EncParamProtect_Syntec		(1)

// M2 Syntec Speed Control Mode P1-01
#define M2_VectorControl_Syntec			(0)
#define M2_VFMode_Syntec				(1)

// M2 Syntec Auxiliary Function Fn-00
#define M2_Idle_Syntec					(0)
#define M2_JogMode_Syntec				(1)
#define M2_TuningStart_Syntec			(2)

// M2 Syntec Jog Direction Fn-01
#define M2_Fixed_Syntec					(0)
#define M2_Positive_Syntec				(1)
#define M2_Negative_Syntec				(-1)

// M2 Syntec Jog Mode Fn-03
#define M2_SpeedControl_Syntec			(0)
#define M2_PositionControl_Syntec		(1)

// M2 Syntec Tuning Mode Fn-10
#define M2_InertialTuning_Syntec		(1)
#define M2_CombinationTuning_Syntec		(2)

// M3 Syntec Dual Enable Pn22A
#define M3_DisableDual_Syntec		(0)
#define M3_EnableDual_Syntec		(1)

// M3 Syntec Scope Switch PnC02
#define M3_ScopeSwitchOff_Syntec		(0)
#define M3_ScopeUart_Syntec				(1)
#define M3_ScopeMessage_Syntec			(2)

// M3 Syntec Power off return switch
#define M3_DisablePwrOffReturn_Syntec	(0)
#define M3_EnablePwrOffReturn_Syntec	(1)

// M3 Syntec Param. Password PnF00
#define M3_PermissionLevelOne_Syntec	(520)

// M3 Syntec Param. Auxiliary Function PnF10
#define M3_Idle_Syntec					(0)
#define M3_JogMode_Syntec				(1)
#define M3_TuningStart_Syntec			(2)

// M3 Syntec Param. Tuning Type PnF20
#define M3_InertialTuning_Syntec		(1)
#define M3_CombinationTuning_Syntec		(2)

// M3 Syntec Chirp Signal Setting PnF74
#define M3_ChirpSwitchOff_Syntec		(0)
#define M3_LinearChirp_Syntec			(23041)
#define M3_SlightLinearChirp_Syntec		(23049)

// 3rd party param.
#define PARAM_FuncSelect2_3rdParty		(0x002)

#define AbsEncoderUsage_3rdParty		(0x0F00)

#define EU_DefEncoder_3rdParty_M2		(0x0000)
#define EU_IncEncoder_3rdParty_M2		(0x0100)

// Panasonic Common Param( EtherCAT )
#define ECAT_PARAM_EncoderType_Panasonic			( 15 )
#define ECAT_PARAM_PositionLoopGain_Panasonic		( 100 )

// Panasonic Common Param, Pr0.15 ( EtherCAT )
#define ECAT_MULTI_Absencoder_Panasonic				( 0 )
#define ECAT_Insencoder_Panasonic					( 1 )
#define ECAT_Special_1_Absencoder_Panasonic			( 2 )
#define ECAT_SINGLE_Absencoder_Panasonic			( 3 )
#define ECAT_Special_2_Absencoder_Panasonic			( 4 )

// EtherCAT Delta Param
#define ECAT_PARAM_Alarmcode_Delta					( 1 )

// EtherCAT Delta Param, P0-01
#define ECAT_ALARM_Reset							( 0 )

// Panasonic Common Param( RTEX )
#define RTEX_PARAM_EncoderType_Panasonic			( 15 )
#define RTEX_PARAM_PositionLoopGain_Panasonic		( 1000 )

// RTEX Panasonic Param
#define RTEX_PARAM_Resolution_Panasonic				( 8 )
#define RTEX_PARAM_RetreatSetup_Panasonic			( 6085 )
#define RTEX_PARAM_Function_Setup2_Panasonic		( 7023 )
#define RTEX_PARAM_SpeedUnitSetup_Panasonic			( 7025 )
#define RTEX_PARAM_Monitorselect4_Panasonic			( 7032 )
#define RTEX_PARAM_Monitorselect5_Panasonic			( 7033 )
#define RTEX_PARAM_Monitorselect6_Panasonic			( 7034 )
#define RTEX_PARAM_CommandSetting2_Panasonic		( 7036 )
#define RTEX_PARAM_CommandSetting3_Panasonic		( 7037 )
#define RTEX_PARAM_Communication_Period_Panasonic	( 7091 )
#define RTEX_PARAM_Communication_Status_Panasonic	( 7112 )

// RTEX Panasonic Param, Pr7.36/7.37
#define RTEX_PARAM_UNKNOWN							( -1 )
#define RTEX_PARAM_CommandSettingInvalid			( 0 )
#define RTEX_PARAM_CommandSettingVFF				( 1 )
#define RTEX_PARAM_CommandSettingTFF				( 2 )

#define RTEX_PARAM_Main_Poweroff_Detection			( 0x0003 )
#define RTEX_PARAM_Status_Selection					( 0x8000 )

#endif // !defined(_SERIALPARAMDF_H__INCLUDED_)
