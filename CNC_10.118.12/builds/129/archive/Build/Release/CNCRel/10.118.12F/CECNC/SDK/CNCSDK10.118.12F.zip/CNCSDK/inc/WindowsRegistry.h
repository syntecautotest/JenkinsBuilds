#if !defined(_WINDOWREGISTRY_INCLUDED_)
#define _WINDOWREGISTRY_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CWindowsRegistry
{
public:

	static LONG QueryKey( LPCTSTR lpSubKey, LPCTSTR lpValueName, LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData )
	// query key from system registry
	{
		HKEY hKey;
		LONG ur;

		ATLASSERT( lpSubKey != NULL );
		ATLASSERT( lpValueName != NULL );
		ATLASSERT( lpType != NULL );
		ATLASSERT( lpData != NULL );
		ATLASSERT( lpcbData != NULL );

		// open specified key
		ur = RegOpenKeyEx( HKEY_LOCAL_MACHINE,	// use predefined reserved handle values
						lpSubKey,			// subkey path
						0,					// must be zero
						KEY_QUERY_VALUE,		// open for query value
						&hKey				// result opened handle
						);

		// check error
		if( ur != ERROR_SUCCESS ) {
			return ur;
		}

		// get name key value
		ur = RegQueryValueEx( hKey,			// handle to key to query
							lpValueName,	// address of name of value to query
							NULL,			// reserved
							lpType,		// address of buffer for value type
							lpData,		// address of data
							lpcbData		// address of data size
							);

		// close opened key
		RegCloseKey( hKey );

		return ur;
	}

	static LONG SetKey( LPCTSTR lpSubKey, LPCTSTR lpValueName, DWORD Type, LPBYTE lpData, DWORD cbData )
	// set key into system registry
	{
		HKEY hKey;
		LONG ur;

		ATLASSERT( lpSubKey != NULL );
		ATLASSERT( lpValueName != NULL );
		ATLASSERT( lpData != NULL );

		// open specified key
		ur = RegOpenKeyEx( HKEY_LOCAL_MACHINE,	// use predefined reserved handle values
						lpSubKey,			// subkey path
						0,					// must be zero
						KEY_SET_VALUE,		// open for query value
						&hKey				// result opened handle
						);

		// check error
		if( ur != ERROR_SUCCESS ) {
			return ur;
		}

		// get name key value
		ur = RegSetValueEx( hKey,			// handle to key to query
							lpValueName,	// address of name of value to query
							NULL,			// reserved
							Type,			// address of buffer for value type
							lpData,			// address of dats
							cbData			// data size
						);

		// close opened key
		RegCloseKey( hKey );

		return ur;
	}

	static LONG CreateSubKey( LPCTSTR lpSubKey )
	// create sub key in HKEY_LOCAL_MACHINE
	{
		HKEY hKey;
		LONG ur;
		DWORD dwDisposition;

		ur = RegCreateKeyEx( HKEY_LOCAL_MACHINE,	// use predefined reserved handle values
							lpSubKey,				// subkey path
							0,						// reserved
							NULL,					// Pointer to a null-terminated string that specifies the class (object type) of this key
							0,						// Registry key options
							0,						// Ignored; set to 0 to ensure compatibility with future versions of Windows CE.
							NULL,					// Set to NULL. Windows CE automatically assigns the key a default security descriptor.
							&hKey,					// result opened handle
							&dwDisposition			// Pointer to a variable that receives disposition values.
							);

		// check error
		if( ur != ERROR_SUCCESS ) {
			return ur;
		}

		RegCloseKey(hKey);

		return ur;
	}
};

#endif // _WINDOWREGISTRY_INCLUDED_