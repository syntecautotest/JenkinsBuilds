// ParamCracker.h: interface for the CParamCracker class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PARAMCRACKER_H__22A1F8BF_F8AB_4CF2_BD7B_D770682E609A__INCLUDED_)
#define AFX_PARAMCRACKER_H__22A1F8BF_F8AB_4CF2_BD7B_D770682E609A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ParamStore.h"

class CArchiveManager;

class CParamCracker
{
public:
	CParamCracker();
	// constructor

	virtual ~CParamCracker();
	// destructor

public:
	int pxt2pin( CArchiveManager *pArchive, char *pxtfile, char *pinfile );
	// import parameter definition from description file
	// return	the record number been processed

	int loadPin( CParamStore *pStore, CArchiveManager *pArchive, char *pinfile );
	// load parameter definition from file into parameter store
	// return TRUE for successful, FALSE for failure

	int loadPxt( CParamStore *pStore, CArchiveManager *pArchive, char *pxtfile );
	// load parameter definition from file into parameter store
	// return TRUE for successful, FALSE for failure

private:
	struct TParamHeader
	{
		long	Signature;
		long	CRC;
		long	NumOfRecord;
		long	TitleExtra;
		char	Reserved[16];
	};

	struct TParamRecord
	{
		long	No;
		long	Min;
		long	Max;
		long	Default;
		long	TitleOffset;
		long	TitleLength;
	};

	struct TParamNode {
		TParamRecord	Data;
		char			Title[ CParamStore::MAX_TITLELEN ];
		TParamNode		*pNext;
	};

	struct TDBParam {
		long			TableSize;
		long			TitleExtra;
		TParamRecord	*pTable;
		char			*pTitle;
	};

	static const unsigned long DBPARAM_BINSIGNATURE;

private:

	void putSchemaToStore( CParamStore *pStore, TParamRecord *pTable, char *pTitle, long TableSize );
	// put schema into parameter store

	BOOL ImportDefinition( TDBParam *pDB, CArchiveManager *pArchive, char *pxtfile );
	// import parameter definition from file
	// return TRUE for successful, FALSE for failure

	long BuildParameterList(CArchiveManager *pArchive, char *pxtfile, TParamNode *&pList, long &TotalTitleLen );
	// build parameter list from parameter definition file
	// DefFile			definition filename
	// pList			parameter list
	// TotalTitleLen	the total title length
	// return			the size of list, in node

	void FreeParameterList( TParamNode *pList );
	// free parameter list

	static int __cdecl compare_ParamTable( const void *arg1, const void *arg2 );
	// compare function for parameter Table sorting and searching

	static int compare_IndexToNo( const void *arg1, const void *arg2 );
	// compare function for index-to-no Table sorting and searching

	int AddParameterList( TParamNode **&pTail, TParamRecord &Data,
						  char *Title, long &TotalTitleLen
	);
	// add a node into parameter list
	// return TRUE	when successful
	//		  FALSE when failure
};

#endif // !defined(AFX_PARAMCRACKER_H__22A1F8BF_F8AB_4CF2_BD7B_D770682E609A__INCLUDED_)
