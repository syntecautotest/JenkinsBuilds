// AxisAngle4d.h: interface for the CAxisAngle4d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AXISANGLE4D_H__11925A51_B91A_4E29_9C79_8E8876DF717A__INCLUDED_)
#define AFX_AXISANGLE4D_H__11925A51_B91A_4E29_9C79_8E8876DF717A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class UTILAPI CAxisAngle4d  
{
public:
	CAxisAngle4d();
	// constructs and initialize it as (0.0,0.0,1.0) axis
	// with zero degree

	CAxisAngle4d( double x, double y, double z, double angle );
	// constructs and initialize it from specified (x,y,z) axis
	// with rotation angle is the specified angle

	virtual ~CAxisAngle4d();
	// constructor

	void set( double x, double y, double z, double angle );
	// set this axis-angle from specified (x,y,z) axis with
	// the rotation angle is the specified angle

	// public data member
	double m_angle;
	double m_x;
	double m_y;
	double m_z;
};

#endif // !defined(AFX_AXISANGLE4D_H__11925A51_B91A_4E29_9C79_8E8876DF717A__INCLUDED_)
