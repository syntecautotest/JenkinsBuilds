#if !defined(AFX_ISERIALPLCCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)
#define AFX_ISERIALPLCCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "nstdlib.h"

class ISerialPLCCenter {
public:
	virtual ~ISerialPLCCenter( void ) {}
	// destructor

	virtual BOOL CNCAPI isRunning( int nID ) = 0;
	// is running

	virtual BOOL CNCAPI isFeedhold( int nID ) = 0;
	// is feedhold

	virtual BOOL CNCAPI isInAlarm( int nID ) = 0;
	// is alarm

	virtual BOOL CNCAPI isReady( int nID ) = 0;
	// is ready

	virtual BOOL CNCAPI isReached( int nID ) = 0;
	// is in position or velocity reached

	virtual BOOL CNCAPI isAbsMode( int nID ) = 0;
	// is absolute mode

	virtual BOOL CNCAPI isServoOn( int nID ) = 0;
	// is servo on

	virtual BOOL CNCAPI GetServoIOSignal( int nID, int nIOSignal ) = 0;
	// get servo IO signal

	virtual LONG CNCAPI getOpMode( int nID ) = 0;
	// get operation mode

	virtual LONG CNCAPI getTargetPos( int nID ) = 0;
	// get target position in um, 0.001deg

	virtual LONG CNCAPI getTargetVel( int nID ) = 0;
	// get target velocity in mm / min, deg / min

	virtual LONG CNCAPI getCurPos( int nID ) = 0;
	// get current position in um, 0.001deg

	virtual LONG CNCAPI getActualVelocity( int nID ) = 0;
	// get actual velocity in mm / min, deg / min

	virtual BOOL CNCAPI isMPGCtrl( int nID ) = 0;
	// is MPG control
};

#endif // !defined(AFX_ISERIALPLCCENTER_H__B5FB7C53_1803_11D3_8419_0000E86B4150__INCLUDED_)