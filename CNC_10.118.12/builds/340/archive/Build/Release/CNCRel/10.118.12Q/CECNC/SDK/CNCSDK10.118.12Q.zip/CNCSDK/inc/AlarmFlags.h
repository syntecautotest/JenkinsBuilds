// AlarmFlags.h: interface for the CAlarmFlags class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ALARMFLAGS_H__4E52511A_F78A_4255_B499_AA7A7FE95CFF__INCLUDED_)
#define AFX_ALARMFLAGS_H__4E52511A_F78A_4255_B499_AA7A7FE95CFF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IAlarmFilter;

class CAlarmFlags  
{
public:
	CAlarmFlags( int ClassID );
	CAlarmFlags( int ClassID, int capacity );
	virtual ~CAlarmFlags();

	void setClassID( int ClassID );
	// set class ID

	void setObjectID( int ObjectID );
	// set object ID

	void setAlarmFilter( IAlarmFilter *pFilter );
	// set associated alarm filter

	void set( int no, char *hint = NULL );
	// set specified alarm flag, no base is 1

	void set( long flag, long bitmask, int base );
	// direct set alarm flag
	// flag		alrm flag to be set
	// bitmask	bitmask for flags setting, the flag bit to be set when
	//			the cooresponding bit is one in this mask.
	// base		flag index base, start from 0.

	BOOL test( int no );
	// test if specified flag is ON

	BOOL testAll( void );
	// whether there are any alarm

	void reset( int no );
	// reset specified alarm flag, no base is 1

	void resetAll( void );
	// reset all flags

	void housekeeping( void );
	// do house keeping task

	void RegistryUnClearAlarm( int AlarmID );
	// registry un-clear alarm

private:
	enum {
		MAX_CapacityL = 128,
		MAX_CapacityB = 4096,
		MAX_HintText = 49,
		MAX_HintTableSize = 10,
		BITOFFLAG = 32
	};
	// object capacity constant

	int m_capacityB;
	// alarm capacity in bit

	int m_capacityL;
	// capacity in long word

	int m_ClassID;
	// associated class ID;

	int m_ObjectID;
	// associated object ID;

	IAlarmFilter *m_pAlarmFilter;
	// associated event store

	long m_RegisteredFlags[MAX_CapacityL];
	// registered flags 

	long m_flags[MAX_CapacityL];
	// alarm flags

	long m_UnClearFlags[MAX_CapacityL];
	// un-clear alarm flags

	struct THintTable {
		int nNo;								// alarm no.
		char m_hint[MAX_HintText];				// hint text buffer
	};

	THintTable *m_pHintTable;
	// hint table

	int m_nHintIdx;
	// hint table index

private:
	void GetHintText( int nNo, char HintText[] );
	// get hint text
};

#endif // !defined(AFX_ALARMFLAGS_H__4E52511A_F78A_4255_B499_AA7A7FE95CFF__INCLUDED_)
