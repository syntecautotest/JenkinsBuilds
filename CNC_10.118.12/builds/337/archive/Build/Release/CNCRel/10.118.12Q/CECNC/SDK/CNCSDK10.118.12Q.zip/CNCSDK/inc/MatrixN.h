#if !defined(_MATRIXN_H____INCLUDED_)
#define _MATRIXN_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMatrixN
{

public:

enum ECalculationResult {
	CALCULATION_INPUT_ERROR = -1,
	CALCULATION_FAILED = 0,
	CALCULATION_SUCCESS = 1
};

// max matrix dimension is 60 * 60
// if 60 is not large enough, just extend it!
// used to allocate a region of local variable
// this variable only affects stack memory size in Det() function,
// it is very safe to set it to a larger number
// beware of stack overfow problem when you extend it, default thread stack size in W32 is 1MB, on CE is 64KB.
// testing of memory usage on W32 and CE platform is needed!
#define MAX_COL_ROW_SIZE ( 60 )
#define MAX_MATRIX_BUFFER_SIZE ( MAX_COL_ROW_SIZE * MAX_COL_ROW_SIZE )

public:
	CMatrixN( void );
	// constructor

	CMatrixN( const int nRow, const int nCol );
	// constructor with initializing inputs

	virtual ~CMatrixN( void );
	// destructor

// functions ------------------------------------------------------------
protected:
	virtual void ReSize( const int nRow, const int nCol, const double *pData = NULL );
	// used to resize matrix

	virtual void ConstructMatrixBody( const int nRow, const int nCol );
	// use new to allocate memory, it is called

	virtual void DestructMatrixBody( void );
	// only works when the matrix body m_Data is allocated by "new" operation
	// CAUTION! DO NOT USE VITRUAL FUNCTION in constructor and destructor
	// so DestructMatrixBody() is not a virtual function, it is always a member function of CMatrixN

	virtual void DestructPLUBuf( void );
	// if the PLU buffer is no longer used, we can delete them in advance
	// if not released, they will still be released in destructor

	virtual void ConstructPLUBuf( void );
	// construct PLU buffer by "new" operation in CMatrixN, in CQucikMatrixN, they are statically allocated

private:
	void InitVars( void );
	// called only in constructor
	// repeated parts in the two constructors

public: // matrix level
	virtual void InitMat( const int nRow, const int nCol );
	// if CMatrixN( void ) is used, please use 
	// this function to finish initializing this matrix object

	void MatMiuAB( CMatrixN &B, CMatrixN &result);
	// matrix A-B, stored in result 

	void MatAddAB( CMatrixN &B, CMatrixN &result);
	// matrix A+B, stored in result

	void MatMulAB( CMatrixN &B, CMatrixN &result );
	// matrix A*B, stored in result
	// A = A*B or B = A*B are not allowed

	void MatMulAtB( CMatrixN &B, CMatrixN &result );
	// matrix A'*B, stored in result
	// A = A'*B or B = A'*B are not allowed

	void MatMulABt( CMatrixN &B, CMatrixN &result );
	// matrix A*B', stored in result
	// A = A*B' or B = A*B' are not allowed

	void MatMulScalar( double scalar, CMatrixN &result );
	// matrix A * scalar, stored in result

private:
	void MatMulAB( double* A, double* B, double* C, int m, int n, int p );
	// m*n matrix * n*p matrix, returns a m*p matrix
	// quick math function, this function will be collected in another quick math class in the future

	void MatMulAtB( double* A, double* B, double* C, int nARow, int nACol, int nBCol );
	// Transpose(n*m matrix) * n*p matrix, returns a m*p matrix
	// quick math function, this function will be collected in another quick math class in the future

	void MatMulABt( double* A, double* B, double* C, int nARow, int nBRow, int nBCol );
	// m*n matrix * Transpose(p*n) matrix, returns a m*p matrix
	// quick math function, this function will be collected in another quick math class in the future

	int PLU( void );
	// PLU factorization, only supports nonsingular square matrix now
	// return 0 if failed, 1 if succeed, -1 if matrix is not square

public:
	int Inv( CMatrixN &result );
	// square matrix inversion, return 0: failed 1: successed
	// input UpdatePLU = 1, if we want to call PLU factoraction once in the beginning of the function
	// input UpdatePLU = 0, if this matrix is not changed since the last call of PLU()

	INT PseudoInv( DOUBLE lambda, CMatrixN &result );
	// pseudo inverse of A, return 0: failed 1: succeeded
	// (AtA)'At

	double Det( void );
	// calculate the product of diagonal elements of U matrix to get matrix deteriment
	// if PLU matrices are up-to-date (matrix not changed), please set UpdatePLU = FALSE
	// otherwise, input it as TRUE

	double MinAbsDiagPLUbuffer( void );
	// find the minimal element of diagonal elements of m_LUbuffer
	// this is used to detect if any elgenvalue of matrix is too small (singular)
	// note: Alghough prod(diag(m_LUbuffer)) = prod(eig(m_LUbuffer)),
	// the diagonal elements of m_LUbuffer is not equal to its eigenvalues!!

	void SetIdentity( void );
	// set as an Identity matrix: only for square matrix

public: // vector level
	void Cross2V( const double *v2, double *v3 );
	// Overload type 1: double type, they can be CMatrixN.m_Data
	// v1 = the first three elements of A
	// vector cross, v1 cross v2, stored in v3

	void Cross2V( const CMatrixN *v2, CMatrixN *v3 );
	// Overload type 2: use the CMatrixN directly
	// v1 = the first three elements of A
	// vector cross, v1 cross v2, stored in v3

	double Norm( const int start, const int range );
	// calculate norm of the elements in the matrix
	// Norm(0,3) = the norm of the first three elements in the matrix
	// Norm(3,3) = the norn of the vector from the fourth(3) element to the sixth(5) element in the matrix
	// this is used to calculate the position error andn orientational error of robot arm 
	// Err = [ex ey ez ethx ethy ethz]
	// Other Usage: this function can also be used to get the norm of 2D vector

public: // set get functions
	// set functions
	void SetElement( const int Row, const int Col, const double Value );
	// set matrix element

	void SetElement( const int Shift, const double Value );
	// set matrix element in 1-D array directly

	void SetByArray( const double *Array, const int Length );
	// copy an array to matrix

	void SetByMatrix( CMatrixN &Mat );
	// copy an matrix 

	// get functions
	double GetElement( const int Row, const int Col ) const;
	// Get matrix element : overload version 1

	double GetElement( const int Shift ) const;
	// Get matrix element : overload version 2

	int GetSize( void ) const;
	// Get matrix size

	int GetRow( void ) const;
	// Get number of row 

	int GetCol( void ) const;
	// Get number of column 

	double *GetDataPointer( void );
	// Get the pointer of matrix elements, for reading data element
	// when reading data element, PLU buffers do not need to be re-calculated
	// when writing data element, PLU buffers needs to be re-calculated
	// for save matrix manipulation, m_bMatrixDirty is always set to TRUE after calling this function

	double GetTrace( void ) const;
	// return the trace of square matrix

	void CopyTo( CMatrixN &Mat );
	// Copy current matrix value to "Mat";

public: // ROBOT ONLY!!! special functions for homogeneous matrix (homogeneous matrix must be 4-by-4 matrix)
	void SetRotMat( CMatrixN &RotMat );
	// ROBOT ONLY!!
	// set rotation part of homogeneous matrix by a double array [9]

	void GetRotMat( CMatrixN &RotMat ) const;
	// ROBOT ONLY!!
	// copy the rotation part of homogeneous A to a double array [9]
	// homogeneous must be a 4-by-4 matrix

	void SetTransVec( const double TransVec[3] );
	// ROBOT ONLY!!
	// set the translation part of homogeneous matrix

	void GetTransVec( double TransVec[3] ) const;
	// ROBOT ONLY!!
	// get the translation part of homogeneous matrix

	void GetZAxis( double TransVec[3] ) const;
	// ROBOT ONLY!!
	// get xyz components of z-axis of homogeneous matrix

// ----------------------------------------------------------------------

// variables ------------------------------------------------------------
protected: // matrix contents
	double *m_Data;
	// data elements of the matrix

	int m_nSize;
	// matrix size

	int m_nCol;
	// number of column

	int m_nRow;
	// number of row

protected: // buffer status

	BOOL m_bMatrixDirty;
	// if Inv() or Det() is called, check if they are up-to-date

	// saving memory: for matrices that do not need inv() and det() functions
	// gain more efficienty: for matrices that need inv() and det() functions
	// only when PLU() called, PLU buffer will be firstly created.
	// PLU buffer will be destroyed in destructor if created.
	// for matrices not requires to get determinant, inverse,
	// PLU buffer will not be created and destroyed.
	int *m_Pbuffer;
	// Permutation matrix in PLU factorization

	double *m_LUbuffer;
	// L&U matrix in PLU factorization, they are stored in one matrix for saving memory usage

	double *m_InvLUbuffer;
	// inverse of L&U matrix in PLU factorization, they are stored in one matrix for saving memory usage

private:
	double *m_HeapMatrixbuffer;
	double *m_HeapLUbuffer;
	double *m_HeapInvLUbuffer;
	int *m_HeapPbuffer;
	// allocated by "new" operation

// ----------------------------------------------------------------------

};

#endif // !defined(_MATRIXN_H____INCLUDED_)
