#if !defined(_ICUSTOMPLC_H___INCLUDED_)
#define _ICUSTOMPLC_H___INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "nstdlib.h"

class ICustomPLC {
public:
	virtual ~ICustomPLC( void ) {}
	// destructor

	virtual LONG CNCAPI getCustomPLCVersion( void ) = 0;
	// get custom PLC version

	virtual LONG CNCAPI getNormalPLCAvgTime( void ) = 0;
	// get normal plc avg time

	virtual LONG CNCAPI getNormalPLCMaxTime( void ) = 0;
	// get normal plc max time

	virtual LONG CNCAPI getFastPLCAvgTime( void ) = 0;
	// get fast plc avg time

	virtual LONG CNCAPI getFastPLCMaxTime( void ) = 0;
	// get fast plc max time
};

#endif // !defined(_ICUSTOMPLC_H___INCLUDED_)