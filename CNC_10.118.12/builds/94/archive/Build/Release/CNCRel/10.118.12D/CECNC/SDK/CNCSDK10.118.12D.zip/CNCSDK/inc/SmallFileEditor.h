#if !defined(_SMALLFILEEDITOR_INCLUDE_)
#define _SMALLFILEEDITOR_INCLUDE_

class IFileEditor;
class CLinePage;

class CSmallFileEditor : public IFileEditor
{
public:		// constructor and destructor
	CSmallFileEditor( LONG nMaxEditSize );
	virtual ~CSmallFileEditor();

public:		// implement ILineStore interface
	int CNCAPI readLine( long lineno, void *buffer, int count );
	// return the data size copied, when count is 0,
	// then return the actual size of specified line

	long CNCAPI getLineCount( void );
	// return the total line count

	void CNCAPI clearAll(void);
	// clear all content

	BOOL CNCAPI insert( long lineno, void *data, int size );
	// insert data before specified line number.
	// return TRUE, when successful, others, return FALSE.

	BOOL CNCAPI append( void *data, int size );
	// append specified data at the tail of whole data.

	BOOL CNCAPI deleteLine( long lineno );
	// delete specified line, this function will all behind line move
	// forward one line.

	BOOL CNCAPI put( long lineno, void *data, int size );
	// put specified data into specified line

	BOOL CNCAPI erase( long lineno );
	// erase specified line data, this function just rease specified
	// line data, and no move behind line forward.

public:		// implement IFileEditor interface

	BOOL tconnect( TCHAR *lpszFilename );
	// to load specified file

	BOOL savefile( void );
	// to save specified file

	BOOL savefileto( TCHAR *lpszFilename );
	// to save specified file to assign path

public:
	enum EMaxBounds {
		SIZE_InitPageTable		= 64,
		MIN_PageTableInc		= 1024,
		MIN_DataBufferInc		= 16
	};
	// maximum bound constants

private:
	struct TDataRecord {
		int		size;		// data size
		int		bsize;		// data buffer size
		char	lpData[1];	// node data header
	};

	struct TNode {
		TDataRecord	*pDataRecord;		// pointer to data buffer
	};

private:
	void deleteLineStore( void );
	// delete line store

private:

	ILineStore *m_objLineStore;
	CLinePage *m_objLinePage;

	LONG m_nMaxEditSize;
	// the maximum editable size limit

	TCHAR m_szFilename[256];
	// the focument file name

	long m_linecount;
	// current data count in this page

	long m_datacount;
	// real line count, which has data inside.
};

#endif // !defined(_FILEEDITOR_INCLUDE_)