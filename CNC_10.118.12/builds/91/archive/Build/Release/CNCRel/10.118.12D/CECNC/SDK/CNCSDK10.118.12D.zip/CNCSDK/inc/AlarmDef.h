// AlarmDef.h: interface for the CAlarmDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ALARMDEF_H__27790B00_DEF3_4066_A197_A87C740A8A6B__INCLUDED_)
#define AFX_ALARMDEF_H__27790B00_DEF3_4066_A197_A87C740A8A6B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ALMID_NoError			( 0 )

#ifndef _ALARMDEF_INTERFACE_
#define _ALARMDEF_INTERFACE_

class CAlarmDef
{
public:
	// under DOS, because the string table is limited resource, so only ten class id ,0~9,
	// can be assigned and also only 499 code is available for each class. 
	// But under Windows CE. The above limitation is removed.
	enum EAlarmClass {
		ALARMCLASS_PLCALARM = 0,					// 0	PLC alarm
		ALARMCLASS_COORDINATE,						// 1	Coordinate
		ALARMCLASS_MOTOR,							// 2	Axis/Servo
		ALARMCLASS_SPINDLE,							// 3	Spindle
		ALARMCLASS_COMPILER,						// 4	Compiler
		ALARMCLASS_OPERATION,						// 5	Operation
		ALARMCLASS_PLCHINT,							// 6	PLC hint
		ALARMCLASS_RESERVED1,						// 7	reserved1
		ALARMCLASS_MACRO,							// 8	Macro
		ALARMCLASS_MSG,								// 9	Message
		ALARMCLASS_SERVO,							// 10	Servo
		ALARMCLASS_SERIALPLCAXIS,					// 11	SerialPLCAxis
		ALARMCLASS_SRI,								// 12	SRI
		ALARMCLASS_BACKGNDEXECUTER,					// 13	BackgndExecuter
		ALARMCLASS_ROT,								// 14	Rot
		ALARMCLASS_LaserCtrl,						// 15	Laser Control
		ALARMCLASS_STATION,							// 16	Station
		ALARMCLASS_ROBOT_ALARM = 50,				// 50	Robot
		ALARMCLASS_ROBOT_WARNING = 51,				// 51	warning of Robot
		ALARMCLASS_ROBOT_CRITICAL = 52,				// 52	critical of Robot
		ALARMCLASS_DRV_DELTA = 100,					// 100	Servo Alarm of DELTA
		ALARMCLASS_M2_YAS_ALARM = 101,				// 101	Servo Alarm of M2 YASKAWA
		ALARMCLASS_M2_SYNTEC_ALARM = 102,			// 102	Servo Alarm of M2 SYNTEC
		ALARMCLASS_M3_YAS_ALARM = 103,				// 103	Servo Alarm of M3 YASKAWA
		ALARMCLASS_M3_SYNTEC_ALARM = 104,			// 104	Servo Alarm of M3 SYNTEC
		ALARMCLASS_M2_YAS_WARNING = 105,			// 105	Servo warning of M2 YASKAWA
		ALARMCLASS_M3_YAS_WARNING = 106,			// 106	Servo warning of M3 YASKAWA
		ALARMCLASS_M2_SYNTEC_WARNING = 107,			// 107	Servo warning of M2 SYNTEC
		ALARMCLASS_M3_SYNTEC_WARNING = 108,			// 108	Servo warning of M3 SYNTEC
		ALARMCLASS_ECAT_DELTA_ALARM = 201,			// 201	Servo Alarm of DELTA ECAT
		ALARMCLASS_ECAT_DELTA_WARNING = 202,		// 202	Servo warning of DELTA ECAT
		ALARMCLASS_ECAT_PANA_ALARM = 203,			// 203	Servo Alarm of PANASONIC ECAT
		ALARMCLASS_ECAT_PANA_WARNING = 204,			// 204	Servo warning of PANASONIC ECAT
		ALARMCLASS_RTEX_PANA_ALARM = 205,			// 205	Servo Alarm of PANASONIC RTEX
		ALARMCLASS_RTEX_PANA_WARNING = 206,			// 206	Servo warning of PANASONIC RTEX
		ALARMCLASS_ECAT_SVTRONIX_ALARM = 207,		// 207	Servo alaram of Servotronix ECAT
		ALARMCLASS_ECAT_SVTRONIX_WARNING = 208,		// 208	Servo warning of Servotronix ECAT
		ALARMCLASS_ECAT_MITSUBISHI_ALARM = 209,		// 209  Servo alaram of Mitsubishi ECAT
		ALARMCLASS_ECAT_MITSUBISHI_WARNING = 210,	// 210  Servo warning of Mitsubishi ECAT
	};
	// alarm class identifier

	enum EAlarmObjectBase {
		SPLCA_ALM_BASE = 100,
		ROT_ALM_BASE = 200,
	};
	// alarm object ID base
};

#endif // _ALARMDEF_INTERFACE_

#endif // !defined(AFX_ALARMDEF_H__27790B00_DEF3_4066_A197_A87C740A8A6B__INCLUDED_)
