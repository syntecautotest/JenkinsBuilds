// ArchMgr.h: interface for the CArchiveManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(ARCHMGR_H_)
#define ARCHMGR_H_

#include <stdio.h>
#include "ZipArch.h"

class CArchiveManager : public CZipArchive
{
public:
	struct TZFILE {
		CZipArchive::TLocalFileRecord	lfr;
		char							pathname[128];
		int								fOpen;
		FILE							*Zipfp;
		char							*pCursor;
		char							*pData;
		char							*pDataTail;
		unsigned long					Offset;
	};

public:
	enum EMaxBounds {
		MAX_AssociatedZipFileNumber	= 10
	};

	static const unsigned MAX_ZFILESSIZE;

public:
	CArchiveManager();
	// constructor

	virtual ~CArchiveManager();
	// destructor

	void AssociateZipFile( char *filename );
	// associate zip file

	void EndOfConstruction( void );
	// trigger to take action which necessary be initialize,
	// before this object begin to service

	TZFILE *zfopen( char *filename, char *attrib );
	// open file

	unsigned long zfilelength( TZFILE *zfp );
	// query file size

	int fileexist( char *filename );
	// query whether file is exist?

	int isZFILE( void *zfp );
	// check whether it is z file pointer

	int zfgetc( TZFILE *zfp );
	// get character from file

	int zfseek( TZFILE *zfp, long offset, int origin );
	// seek to position

	int zfread( char *buffer, unsigned size, unsigned count, TZFILE *zfp );
	// read data from file

	char *zfgets( char *string, int n, TZFILE *zfp );
	// Each of these functions returns string. NULL is returned to indicate
	// an error or an end-of-file condition. Use feof or ferror to determine
	// whether an error occurred

	void zclose( TZFILE *zfp );
	// close file

private:

	// function ID
	enum {
		ActionID_Counting =1,	// count the number of local file header
		ActionID_BuildINodeTable// build file directory
	};

	void SkipSourceTo( unsigned long count );
	// skip data in source stream
	// count	the number to be skip from current position, in bytes.

	void RewindSourceStream();
	// rewind data in source stream

	unsigned ReadIn( unsigned char *data, unsigned size );
	// read compressed data from source stream
	// return is the number of data been read

	void WriteOut( unsigned char *data, unsigned size );
	// write de-compressed data out to destination stream

	int IsSourceStreamEOF();
	// query whether end-of-file

	void LFRHandler( TLocalFileRecord *pLFR,
					 char *pathname,
					 int &fAccept,
					 int &fStopScan
	);
	// local file record handler

	int m_ActiveActionID;
	// current active action identifer

	FILE *m_ActiveZipfp;
	// current active Zip file pointer

	char *m_pActiveOutCursor;
	// current active output buffer tail pointer

	long m_ActiveOutRemainSize;
	// current remain output data remain size

	TZFILE *m_ZipINodeTable;
	// i-node table for files inside zip archive

	int	m_ZipINodeTableSize;
	// the size of i-node table.

	FILE *m_AssociatedZipfp[ MAX_AssociatedZipFileNumber ];
	// buffer for store associate zip file file pointer

	int m_AssociatedZipFileNumber;
	// the number of associated zip file
};

#endif // !defined(ARCHMGR_H_)
