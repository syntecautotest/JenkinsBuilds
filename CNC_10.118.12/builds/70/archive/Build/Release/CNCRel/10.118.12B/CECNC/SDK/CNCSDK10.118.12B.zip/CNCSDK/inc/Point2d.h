// Point2d.h: interface for the CPoint2d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POINT2D_H__3B06F281_36C9_4678_9350_0EEB6617721B__INCLUDED_)
#define AFX_POINT2D_H__3B06F281_36C9_4678_9350_0EEB6617721B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Tuple2d.h"

class UTILAPI CPoint2d : public CTuple2d  
{
public:
	CPoint2d();
	virtual ~CPoint2d();

};

#endif // !defined(AFX_POINT2D_H__3B06F281_36C9_4678_9350_0EEB6617721B__INCLUDED_)
