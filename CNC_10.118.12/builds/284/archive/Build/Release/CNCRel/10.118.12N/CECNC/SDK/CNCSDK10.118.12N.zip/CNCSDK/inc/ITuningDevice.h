#if !defined(_ITUNINGDEVICE_H_INCLUDED_)
#define _ITUNINGDEVICE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ITuningDevice
{
public:
	virtual ~ITuningDevice( void ) {}
	// destructor

	virtual BOOL TuningIsSupport( BOOL &isSupportLimit ) = 0;
	// check tuning is supported

	virtual void Tuning1stLimit( void ) = 0;
	// set 1st tuning stroke limit

	virtual void Tuning2ndLimit( void ) = 0;
	// set 2nd tuning stroke limit

	virtual INT TuningLimitCheck( DOUBLE &MinRange, DOUBLE &MaxRange ) = 0;
	// check tuning stroke limit

	virtual void TuningGetDefault( INT &nTuningMode, INT &nMachineType ) = 0;
	// get tuning default data

	virtual void TuningSetData( INT nTuningMode, INT nMachineType ) = 0;
	// set tuning data

	virtual BOOL TuningStartCheck( void ) = 0;
	// check tuning start position

	virtual void TuningStart( void ) = 0;
	// start tuning

	virtual void TuningStop( void ) = 0;
	// stop tuning

	virtual void TuningGetStatus( BOOL &isFinished, INT &nResult ) = 0;
	// get tuning status

	virtual void TuningSetWatchMode( BOOL bWatchMode ) = 0;
	// set tuning watch mode
};

#endif // _ITUNINGDEVICE_H_INCLUDED_
