#if !defined(_QUICKMATRIXN_H____INCLUDED_)
#define _QUICKMATRIXN_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MatrixN.h"

class CQuickMatrixN : public CMatrixN
{
// max size of small MatrixN
// note! QUICK_ARRAY_SIZE mist be <= QUICK_ROW_COL_SIZE * QUICK_ROW_COL_SIZE
// the largest Quick matrix in OCKrnl now is 3 * 13, used in RobotDeltaTypeA (Robot Forward Kinematics)
#define QUICK_ARRAY_SIZE	40
#define QUICK_ROW_COL_SIZE	7 // = ceil( sqrt(QUICK_ARRAY_SIZE) )

// note!!
// the total buffer size when QUICK_ARRAY_SIZE = 40 is about 1KB
// CQuickMatrixN is designed for matrix objects used as local variable (to avoid "new" operation)

public:
	CQuickMatrixN( void );
	// constructor

	CQuickMatrixN( const int nRow, const int nCol );
	// constructor with initializing inputs

	~CQuickMatrixN( void );
	// destructor

	void InitMat( const int nRow, const int nCol );
	// if CMatrixN( void ) is used, please use 
	// this function to finish initializing this matrix object

protected:
	void DestructMatrixBody( void );
	// only works when the matrix body m_Data is allocated by "new" operation
	// CAUTION! DO NOT USE VITRUAL FUNCTION in constructor and destructor
	// so DestructMatrixBody() is not a virtual function, it is always a member function of CMatrixN

	void ConstructMatrixBody( const int nRow, const int nCol );
	// use new to allocate memory, it is called

	void DestructPLUBuf( void );
	// PLU buffer is statically allocated in CQuickMatrixN

	void ConstructPLUBuf( void );
	// PLU buffer is statically allocated in CQuickMatrixN

private:
	void InitVars( void );
	// called only in constructor
	// repeated parts in the two constructors

// ----------------------------------------------------------------------

private:
	double m_QuickMatrixbuffer[QUICK_ARRAY_SIZE];
	double m_QuickLUbuffer[QUICK_ARRAY_SIZE];
	double m_QuickInvLUbuffer[QUICK_ARRAY_SIZE];
	int m_QuickPbuffer[QUICK_ROW_COL_SIZE];
	// static allocated buffers
};

#endif // !defined(_QUICKMATRIXN_H____INCLUDED_)
