// HugeFileReader.h: interface for the CHugeFileReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HUGEFILEREADER_H__93013832_DA26_4B4D_BA4C_8278671B2FBE__INCLUDED_)
#define AFX_HUGEFILEREADER_H__93013832_DA26_4B4D_BA4C_8278671B2FBE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define SIZE_Page		(56000)		// 1400 * 40

#include <stdio.h>
#include "ILineStore.h"

class CHugeFileReader : public ILineStore  
{
public:		// constructor and destructor
	CHugeFileReader();
	virtual ~CHugeFileReader();

public:		// implement ILineStore interface
	int CNCAPI readLine( long lineno, void *buffer, int count );
	// return the character(with terminate char) counts in specified line,
	// when count is 0 and buffer is NULL then return the actual size
	// of specified line

	long CNCAPI getLineCount( void );
	// return the total line count

	void CNCAPI clearAll(void);
	// this function not support in this class
	// clear all content

	BOOL CNCAPI insert( long lineno, void *data, int size );
	// this function not support in this class
	// insert data before specified line number.
	// return TRUE, when successful, others, return FALSE.

	BOOL CNCAPI append( void *data, int size );
	// this function not support in this class
	// append specified data at the tail of whole data.

	BOOL CNCAPI deleteLine( long lineno );
	// this function not support in this class
	// delete specified line, this function will all behind line move
	// forward one line

	BOOL CNCAPI put( long lineno, void *data, int size );
	// this function not support in this class
	// put specified data into specified line

	BOOL CNCAPI erase( long lineno );
	// this function not support in this class
	// erase specified line data, this function just rease specified
	// line data, and no move behind line forward.

public:		// connection interface
	BOOL connect( char *filename );
	// connect to specified filename
	// return TRUE when success, FALSE when failure

	BOOL tconnect( TCHAR *filename );
	// connect to specified filename
	// return TRUE when success, FALSE when failure

	void disconnect( void );
	// disconnect with current connected file

	int GetDataPos( int lineno );
	// get data position in file by line number

public:
	enum EMaxBounds {
		MAX_LinePerPage = 1400,				// default is 1400
		AVG_CharPerLine = 40,
		NUMOF_Page = 2
	};
	// maximum bound constants

private:	// object state
	struct TPage {
		long		BeginLineNo;
		long		BeginLinePos;
		long		EndLineNo;
		long		offset[ MAX_LinePerPage+1 ];
		char		buffer[ SIZE_Page + 8 ];		// 1400 * 40
													// here reserved 8 byte is for OcDesFileReader
													// do decryption should be aligned with 8 byte
	};
	// page data structure

	BOOL cachePage( long lineno, TPage *pPage );
	// cache a page which contains the specified line,
	// return TRUE when success, else return FALSE.

	BOOL doReadLine( long lineno, char *buffer, int count, int &readCount );
	// read specified line, return TRUE when hit, otherwise return FALSE

	void clearCache( void );
	// clear cache

	TPage *m_pPageTable[NUMOF_Page];
	// page buffer table

	long m_linecursor;
	long m_filepos;
	// current line number in connected file

	int m_HitPage;
	// recent hit page

	long m_linecount;
	// line count

	BOOL m_bConnected;
	// connection state

	BOOL m_bLineCountReady;
	// line count has ready

	TCHAR m_filename[256];
	// associated filename
};

#endif // !defined(AFX_HUGEFILEREADER_H__93013832_DA26_4B4D_BA4C_8278671B2FBE__INCLUDED_)
