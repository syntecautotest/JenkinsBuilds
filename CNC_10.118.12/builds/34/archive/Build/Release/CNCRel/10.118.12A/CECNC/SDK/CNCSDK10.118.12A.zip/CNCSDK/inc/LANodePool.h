#if !defined(_LANODEPOOL_H____INCLUDED_)
#define _LANODEPOOL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLANodePool
{
public:
	CLANodePool( long nFreePoolLen );
	// constructor

	~CLANodePool();
	// destructor

	TLANode *ConstructMotionNode( TPacketInfo &PacketInfo, long Opcode, int NumOfParam, double Param[] );
	// construct motion node

	TLANode *ConstructFuncCallNode( long FuncID, long lpvarArgs[], int cArgs, EStopType nStopType, const TPacketInfo *pPacketInfo = NULL );
	// construct function call node

	void FreeLANode( TLANode *pNode );
	// free look ahead node

	long GetNumberOfBlocks( void );
	// to get total number of blocks in C.C., raw, and mature queues

	BOOL IsReady( void );
	// query whether is there enough buffer in free queue list
	// return TRUE, when buffer is enough

private:
	TLANode *GetNodeFromFreeQueue( void );
	// get node from free queue

	void AddNodeIntoFreeQueue( TLANode *pNode );
	// add node into free queue

private:
	long m_nFreeListCount;
	// free list count

	long m_nFreePoolLen;
	// free queue total length

	TLANode *m_pFreeNodeList;
	// free node list

	TZPlex* m_pPlexList;
	// pointer to ZPlex blocks list

	CRTMutex m_csFreeList;
	// mutex for protected free list
};
#endif // !defined(_LANODEPOOL_H____INCLUDED_)
