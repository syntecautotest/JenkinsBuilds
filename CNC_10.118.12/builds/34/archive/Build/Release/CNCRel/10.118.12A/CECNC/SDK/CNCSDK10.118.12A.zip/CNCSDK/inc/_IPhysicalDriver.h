// _IPhysicalDriver.h
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX__IPHYSICALDRIVER_H__D300782F_DC36_49c8_9460_3E5DF2A0E6B4__INCLUDED_)
#define AFX__IPHYSICALDRIVER_H__D300782F_DC36_49c8_9460_3E5DF2A0E6B4__INCLUDED_

#include "ISvoDriver.h"
#include "IPhysicalDriver.h"

#endif // AFX__IPHYSICALDRIVER_H__D300782F_DC36_49c8_9460_3E5DF2A0E6B4__INCLUDED_
