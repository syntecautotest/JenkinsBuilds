#if !defined(_PLAYMODEINTERPOLATOR_H__INCLUDED_)
#define _PLAYMODEINTERPOLATOR_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ERR_NONE					0
#define ERR_FILE_OPEN_FAIL			1
#define ERR_FILE_ABNORMAL_CLOSE		2
#define ERR_FILE_NOT_MATCH			3
#define ERR_DISK_SIZE_NOT_ENOUGH	4
// minimum NcFile Disk available free space : 50KB
#define MIN_DISK_SPACE				( 51200 )

class CAsynQueue;

class CPlayModeInterpolator
{
public:
	CPlayModeInterpolator( long nTimebase );
	~CPlayModeInterpolator( void );

	void DoHouseKeeping( void );
	// do house keeping

	void setChannelCount( int nChannelCount );
	// set channel count

	void RecordStart( long nFileNo );
	// record start

	BOOL isRecordReady( void );
	// is record ready

	void Recording( double displacement[] );
	// recording axis movement data

	void RecordEnd( void );
	// record end

	void PlayStart( long nFileNo );
	// play start

	BOOL getDisplacement( double displacement[], long nTimebase );
	// get displacement

	void Reset( void );
	// reset

	int getError( void );
	// get error

	int getCntPlayQueueInsufficient( void );
	// get incufficeint count of play queue

	void getNCPath( char NcPath[] );
	// get NC path, this function is temp for debug

	BOOL isIdle( void );
	// whether PlayMode and RecordMode is in Idle State

	void setInitPos( double Pos[] );
	// set Record and Play Mode initial position.

private:
	enum EPlayState {
		EPS_Idle,
		EPS_Open,
		EPS_SwitchPlay,
		EPS_Playing,
		EPS_Alarm,
	} m_PlayState;

	enum ERecordState {
		ERS_Idle,
		ERS_Open,
		ERS_Recording,
		ERS_Alarm,
	} m_RecordState;

	int m_nErrorID;
	// error id

	struct TFileSign {
		DWORD LAST_WT_TIME_H;
		DWORD LAST_WT_TIME_L;
		DWORD FILE_SIZE_H;
		DWORD FILE_SIZE_L;
	};	// 16 byte

	struct TPlayFileHeader {
		DWORD VER;				// 0x0000 : version
		DWORD TIMEBASE;			// 0x0004 : interpolation timebase
		BYTE CH_CNT;			// 0x0008 : channel count
		BYTE COMPLETE;			// 0x0009 : record complete ?
		BYTE reserved_1[ 6 ];	// 0x000A : reserved
		TFileSign SIGNATURE;	// 0x0010 : signature( last write time & file size )
		double INIT_POS[ NUMOF_AXIS ];	// 0x0020 : initial program position
		DWORD AXIS_MOVED;		// 0x00A0 : record subprogram moving axis
		BYTE reserved_2[ 860 ];	// 0x00A4~0x03FF
	};	// total size: 1K byte

	FILE *m_pRecordFile;
	// record file

	FILE *m_pPlayFile;
	// play file

	char m_SysDir[128];
	// system root directory

	char m_NCPath[120];
	// system NC path

	struct TFileInfo {
		int nFileNo;
		BOOL bValid;
		double InitPos[ NUMOF_AXIS ];
		DWORD Axis_Moved;
	} m_FileInfo;
	// file information

	long m_nPlayCursor;
	// play cursor

	long m_nPlayFileSize;
	// play file size

	long m_nDefaultTimebase;
	// default timebase

	long m_nRecordTimebase;
	// record timebase

	double m_RestTime;
	// rest time

	BOOL m_bCacheHasData;
	double m_CommandCache[ NUMOF_AXIS ];
	// buffer

	BOOL m_bRecordReq;
	// record request

	BOOL m_bRecordEndReq;
	// record end request

	BOOL m_bPlayReq;
	// play request

	BOOL m_bPlayEndReq;
	// play end request

	CAsynQueue *m_pPlayQueue;
	// play queue

	int m_nChannelCount;
	// channel count

	BOOL m_bInitialized;
	// is initialized

	int m_nQueueInsufficientCount;
	// play queue insufficient count

	double m_RecordAndPlayIniPos[ NUMOF_AXIS ];

	char m_FilePath[256];
	// File path of record file

	int m_nChCountSize;
	// Each size of recording data

private:
	BOOL createPlayFile( void );
	// create play file

	BOOL getNcFileSignature( int nFileNo, TFileSign *pSign );
	// get NcFile signature

	BOOL openPlayFile( void );
	// open play file for play mode

	BOOL isHeaderMatch( TFileInfo *pFileInfo, TPlayFileHeader *pHeader );
	// is header match

	void runRecordingMachine( void );
	// run recording state machine

	void runPlayingMachine( void );
	// run playing state machine

	__int64 GetNcFileFreeSpace( void );
	// Get NCFile free space
};

#endif // _PLAYMODEINTERPOLATOR_H__INCLUDED_
