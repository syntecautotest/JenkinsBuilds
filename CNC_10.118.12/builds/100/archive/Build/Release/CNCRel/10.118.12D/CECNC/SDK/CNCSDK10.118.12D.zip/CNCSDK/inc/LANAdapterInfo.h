// TLANAdapter, TLANAdapterList, CLANAdapterInfo Declaration
#pragma once


struct TLANAdapter {

	TLANAdapter *pNext;											// Pointer to next adapter struct
	CHAR szIPAddr[ 16 ];										// IPv4 Address
	CHAR szIPMask[ 16 ];										// Subnet Mask
	CHAR szDescription[ MAX_ADAPTER_DESCRIPTION_LENGTH + 4 ];	// Adapter Description

	// Constructor
	TLANAdapter();

	// Destructor
	~TLANAdapter();
};

struct TLANAdapterList {

	TLANAdapter *pRoot;	// Root of adapter list
	UINT nCount;		// Count of adapter

	// Constructor
	TLANAdapterList();

	// Destructor
	~TLANAdapterList();
	
	// Push back one adapter information
	void PushBack( const CHAR *szIPAddr, const CHAR *szIPMask, const CHAR *szDescription );

	// Return specific adapter information
	TLANAdapter *operator[]( UINT nIndex );
};

class CLANAdapterInfo
{
public:
	// Constructor
	CLANAdapterInfo();

	// Destructor
	~CLANAdapterInfo();

	// Get count of adapter device
	UINT GetCount( void );

	// Get specific adapter information
	// Note1: nIndex is start from 0
	// Note2: If adapter is exist then return struct address, otherwise return NULL.
	TLANAdapter *GetAdapter( UINT nIndex );

private:
	// Using IPHlpApi to get all of adapter detail information, and store in AdapterList.
	void GetAdapterList( void );

private:
	// Store all of adapters information
	TLANAdapterList AdapterList;
};


