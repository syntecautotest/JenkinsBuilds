#if !defined(_COMMONSTRUCT_INCLUDE_)
#define _COMMONSTRUCT_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef COMMON_CONSTANT_
#define COMMON_CONSTANT_

#if defined(DOSX286)
	#define LENOFPROGRAMNAME		16
#else
	#define LENOFPROGRAMNAME		32
#endif

#define PROG_NAME_STRING_NUM		( 80 )

#if defined(DOSX286)
	#if defined(DOSCNC_NUMOF_AXIS)
		#define NUMOF_AXIS		DOSCNC_NUMOF_AXIS	// maximum is 16
	#else
		#error Not define DOSCNC_NUMOF_AXIS before compile
	#endif
#else
	// maximum is 18, should greater than NUMOF_SIMUAXIS
	#define NUMOF_AXIS			( 18 )								// maximum is 18
	#define NULL_PORT_START		( 17 )
	#define NULL_PORT_END		( NULL_PORT_START + MAX_NULL_CH - 1 )
	#define ENC_PORT_START		( 19 )
	#define ENC_PORT_END		( ENC_PORT_START + MAX_ENC_CH - 1 )
	#define MAX_PORT			( 22 )								// maximum axis port number
	#define MAX_NULL_CH			( 2 )								// maximum null port number
	#define MAX_ENC_CH			( 2 )								// maximum encoder port number
	#define NUMOF_LOADERAXIS	( 5 )
#endif

#define NUMOF_SPINDLE			8		// the number of spindle

#define NUMOF_SIMUAXIS			6
#define NUMOF_ROBOT_AXIS		( 6 )
#define NUMOF_RBT_ADD_AXIS		( 6 )
#define LEN_ParamTitleName		128
#define MAX_MotReqPktArgs		3
#define PARAM_NUM_INTERVAL		( 20 )

#endif // COMMON_CONSTANT_

#ifndef TPARAMSPEC_STRUCT_
#define TPARAMSPEC_STRUCT_

// parameter specification
typedef struct {
	long No;
	TCHAR Title[LEN_ParamTitleName];
	long UBound;
	long LBound;
} TParamSpec;

#endif // TPARAMSPEC_STRUCT_

#define LENOFMAKERINFO			32

#ifndef TMAKER_CONFIG_INFO_
#define TMAKER_CONFIG_INFO_

struct TMakerConfigInfo {
	TCHAR Model[ LENOFMAKERINFO ];
	TCHAR MachSN[ LENOFMAKERINFO ];
	TCHAR Date[ LENOFMAKERINFO ];
	TCHAR DevSN[ LENOFMAKERINFO ];
	TCHAR Phone[ LENOFMAKERINFO ];
};

#endif // TMAKER_CONFIG_INFO_

//------------------------------------------------------------
// data structure for logic controller

#ifndef TLOGICTIMER_STRUCT_
#define TLOGICTIMER_STRUCT_

// data structure for PLC timer device state
typedef struct {
		short			State;                  // timer relay state
		short			Type;                   // 1ms/10ms/100ms/1s
		long			Setting;                // setting value, in time base
		long			Elapse;                 // current value in time base
} TLogicTimer;

#endif // TLOGICTIMER_STRUCT_


#ifndef TLOGICCOUNTER_STRUCT_
#define TLOGICCOUNTER_STRUCT_

// data structure for PLC counter device state
typedef struct {
		short			State;                  // counter relay state
		short			Type;                   // Up/Down/Ringup/Ringdown
		long            Setting;                // setting value, in count
		long            Count;                  // current count, in count
} TLogicCounter;

#endif // TLOGICCOUNTER_STRUCT_

#ifndef TLOGICBGNDEXE_STRUCT_
#define TLOGICBGNDEXE_STRUCT_

// data structure for PLC background executer device state
typedef struct {
		BOOL			Request;		// execute command request
		short			Cmd;			// command code
		short			reserved;		// reserved arg for memory alignment
		long			ProgNo;			// program number
		unsigned long	LineNoAddr;		// address of registry to put current line number
		//unsigned long	AlarmFlagAddr;	// address of registry to notify alarm
		// R registry being used as alarm flag is the one to which next the R register showing 
		// current program linenumber according to specification ( AlarmAddr = LineNoAddr + 1 )
} TBgndExeInfo;

#endif // TLOGICBGNDEXE_STRUCT_

#ifndef TLOGICSRICOMM_STRUCT_
#define TLOGICSRICOMM_STRUCT_

// data structure for PLC SRI device state
typedef struct {
		int		SendStartAddr;			// start address of registry for sending command
		int		SendLength;				// command length in terms of bytes
		int		RetStartAddr;			// start address of registry for receiving data
} TSRIPLCInput;

// data structure for PLC SRI device state
typedef struct {
		BOOL			Request;		// execute command request
		TSRIPLCInput	InputData;		// input data section
} TSRICommInfo;

#endif // TLOGICSRICOMM_STRUCT_

#ifndef TPLCCAPACITY_STRUCT_
#define TPLCCAPACITY_STRUCT_

// PLC capacity
typedef struct {
	long IBits;
	long OBits;
	long CBits;
	long SBits;
	long ABits;
	long RRegister;
	long Timer;
	long Counter;
} TPlcCapacity;

#endif // TPLCCAPACITY_STRUCT_


// data structure for workpiece coordinate frame table
#ifndef TWORKPIECEFRAME_STRUCT_
#define TWORKPIECEFRAME_STRUCT_

typedef struct {
	double	Origin[NUMOF_AXIS];		// origin offset, in mm or inch.
	BOOL	bMirror[NUMOF_AXIS];	// axis mirror.
	double	Angle[NUMOF_AXIS];		// rotation angle, in degree.
	long	Exchange;				// axis exchange, 0:XYZ 1:YXZ.
} TWorkpieceFrame;

#endif // TWORKPIECEFRAME_STRUCT_


// data structure for precision table
#ifndef TPRECISIONTABLE_STRUCT_
#define TPRECISIONTABLE_STRUCT_

#define SIZE_HiSpeedHiPrecisionTable	13

// the number of elements of each group and the number of groups of PrecisionParam Setting
#define NUM_PrecisionParam_ELEM			6
#define NUM_PrecParamDefTeam			9

typedef struct {
	long	nPostTA;						// post acceleration time, in ms
	long	nCornerFeedrate;				// corner feedrate, in mm/min
	long	nArcRefFeedrate;				// arc reference feedrate of 5mm radius circle, in mm/min
	long	nCuttingTA;						// the cutting acceleration time, in ms
	long	nBellShapeTA;					// the bell shaped, in ms
	long	nCuttingTOL;					// the path tolerance, in um ( for nurbs curve fitting tolerance / chord error tolerance )
	long	nServoCmpsLevel;				// the servo compensator level
	long	nReserved[13];					// reserved
} TPrecisionRecord;

// for NCExecutive
struct TPrecisionElem {
	BOOL		fHSHPValid;			// the flag whether param setting error
	long		nCuttingTA;			// the cutting acceleration time, in us
	long		nBellShapeTA;		// the bell shaped time, in us
	long		nPostTS;			// in micro-second
	long		nServoCmpsLevel;	// the servo compensator level
	long		nCuttingTOL;		// the path tolerance, in um ( for chord error tolerance )
	double		CornerFeedrate;		// the corner feedrate, in BLU / min
	double		ArcRefRadius;		// the arc reference radius, in BLU
	double		ArcRefFeedrate;		// the arc reference feedrate, in BLU / min
};

#define MAX_NUMOF_GEOAXES			3		// max. number of geometrical axes

#endif // TPRECISIONTABLE_STRUCT_


// data structure for version information
#ifndef TVERSIONINFO_STRUCT_
#define TVERSIONINFO_STRUCT_

#define LENOFMODULENAME					32

typedef struct tagVersionInfo {
	TCHAR	strModuleName[LENOFMODULENAME];
	short	nFileMajorPart;
	short	nFileMinorPart;
	short	nFileBuildPart;
	short	nFilePrivatePart;
} TVersionInfo;

#endif // TVERSIONINFO_STRUCT_


#ifndef TAxisDimContext_STRUCT_
#define TAxisDimContext_STRUCT_

typedef struct tagTAxisDimContext {
	BOOL	bDiameterProgramming;
	// flag to record whether this axis is diameter programming

	long	IncSystemType;
	// incremental system type A/B/C

	long	InputUnit;
	// Input Unit, 0 for metric, 1 for inch

	long	DefAxisType;
	long	AxisType;
	// axis type
	// CAxisCore::AXISTYPE_LINEAR for axis is linear,
	// CAxisCore::AXISTYPE_ROTARY for axis is rotary
} TAxisDimContext;

#endif // TAxisDimContext_STRUCT_

#ifndef ETOOLTABLEACCESSMODE_ENUM_
#define ETOOLTABLEACCESSMODE_ENUM_

enum EToolTableAccess {
	ETTA_Single = 0,
	ETTA_Multi = 1,
};

#endif // ETOOLTABLEACCESSMODE_ENUM_

#ifndef TTOOLOFFSET_STRUCT_
#define TTOOLOFFSET_STRUCT_

// data structure for tool offset table
typedef struct tagToolOffset {
		short	ToolNose;					// tool nose number
		double	RadiusGeometry;				// unit: IU
		double	RadiusWear;					// unit: IU
		double	LengthGeometry[ 12 ];		// unit: IU
		double	LengthWear[ 12 ];			// unit: IU
		double	ToolAngle;					// Lathe Roatation Tool Axis Angle, unit: IU
} TToolOffset;

#endif // TTOOLOFFSET_STRUCT_


#ifndef TREMOCALARMINFO_STRUCT_
#define TREMOCALARMINFO_STRUCT_

typedef	struct {
		WORD		ClassID;
		WORD		ObjectID;
		WORD		AlarmID;
		SYSTEMTIME	Time;
		TCHAR		HintText[80];
} TRemOcAlarmInfo;

#endif // TREMOCALARMINFO_STRUCT_

#ifndef TCATCHDATA_STRUCT_
#define TCATCHDATA_STRUCT_

typedef struct {
	int nCatchValue;
	int nCatchParam;
} TCatchData;

#endif // TCATCHDATA_STRUCT_

#ifndef TCATCHRULE_STRUCT_
#define TCATCHRULE_STRUCT_

typedef struct {
	int nRuleValue;
	int nRuleParam;
} TCatchRule;
// catch rule setting

#endif // TCATCHRULE_STRUCT_

#ifndef TCATCHRULEEX_STRUCT_
#define TCATCHRULEEX_STRUCT_

typedef struct {
	TCatchRule StartRule;
	TCatchRule EndRule;
} TCatchRuleEx;
// catch rule setting

#endif // TCATCHRULEEX_STRUCT_

#ifndef EOCVARIANTTYPE_ENUM_
#define EOCVARIANTTYPE_ENUM_

enum EOcVariantType {
	OCVT_VACANT,
	OCVT_LONG,
	OCVT_DOUBLE,
	OCVT_STRING
};

#endif // EOCVARIANTTYPE_ENUM_

#ifndef TOCVARIANT_STRUCT_
#define TOCVARIANT_STRUCT_

// TOcVariant : 16 byte
typedef struct tagTOcVariant {
	SHORT		m_type;
	SHORT		nReserved1;		// padding
	LONG		nReserved2;		// padding
	union {
		LONG	m_long;
		DOUBLE	m_double;
	};
} TOcVariant;

#endif // TOCVARIANT_STRUCT_

#ifndef TOCALARMINFO_STRUCT_
#define TOCALARMINFO_STRUCT_

typedef struct {
	WORD		ClassID;
	WORD		ObjectID;
	WORD		AlarmID;
	SYSTEMTIME	Time;
	TCHAR		HintText[80];
} TOcAlarmInfo;
// alarm infomation data

#endif // TOCALARMINFO_STRUCT_

#ifndef THISTORYALMINFO_STRUCT_
#define THISTORYALMINFO_STRUCT_

typedef struct {
	WORD		ClassID;
	WORD		ObjectID;
	WORD		AlarmID;
	WORD		reserved;
	DWORD		Duration;
	BOOL		Clear;
	SYSTEMTIME	Time;
} THistoryALMInfo;

#endif // THISTORYALMINFO_STRUCT_

#ifndef NCBLOCKDATA_STRUCT_
#define NCBLOCKDATA_STRUCT_

typedef struct tagTNcBlockData {
		LONG	BlockID;				// unique block ID
		LONG	ClassID;				// class identifier
		LONG	Opcode;					// opcode
		union {
			struct {
				SHORT cArgs;							// number of argument
				TOcVariant vArgs[ MAX_MotReqPktArgs ];	// argument array
			};
			struct {
				DOUBLE	Destination[ NUMOF_SIMUAXIS ];	// X/Y/Z/A/B/C/U/V/W
				DOUBLE	Center[3];						// I/J/K
				LONG	nNumberOfRevolution;			// number of revolution
				INT		nAxisName[ NUMOF_SIMUAXIS ];	// axis address
			};
		};
		CHAR	ProgramName[ LENOFPROGRAMNAME ];	// program name
		LONG	LineNo;								// line number
		LONG	SequenceNo;							// sequence number
} TNcBlockData;

#endif // NCBLOCKDATA_STRUCT_

#ifndef TOCMYFILEINFO_STRUCT_
#define TOCMYFILEINFO_STRUCT_

typedef struct tagTOcMyFileInfo {
	DWORD dwFileAttributes;
	FILETIME ftLastWriteTime;
	DWORD nFileSizeHigh;
	DWORD nFileSizeLow;
	WCHAR  cFileName[ 260 ];
	WCHAR  FileDescription[ 256 ];
} TOcMyFileInfo;

#endif // TOCMYFILEINFO_STRUCT_

#ifndef TSRIMODULE_STRUCT_
#define TSRIMODULE_STRUCT_

#define MAX_COMM				3
#define MAX_STATIONPERCOMM		16
#define MAX_MODULEPERSTATION	16
#define MAX_SRI_DEVICE			( MAX_COMM * MAX_STATIONPERCOMM * MAX_MODULEPERSTATION )
#define MAX_STRING_LENGTH		8

// Sri Sub-Module information
typedef struct {
	BYTE SlotID;
	BYTE ModuleID;
	BYTE HardwareID;
	BYTE DeviceMode;
	DWORD SerialNo;
	TCHAR FirmwareVer[ MAX_STRING_LENGTH + 1 ];
	TCHAR DeviceType[ MAX_STRING_LENGTH + 1 ];
	WORD Val_read;
	WORD Val_write;
	WORD Size_read;
	WORD Size_write;
} TModuleInfo;

// Sri Station information
typedef struct {
	BYTE StationID;
	BYTE DeviceNum;
	BYTE Reserved_1;
	BYTE Reserved_2;
	TModuleInfo ModuleInfo[ MAX_MODULEPERSTATION ];
} TStationInfo;

// Sri Station state
typedef struct {
	BYTE Status[ MAX_MODULEPERSTATION ];
} TStationState;

// Sri Station debug data
typedef struct {
	BYTE RegionIdx;
	BYTE bErrorFlag;
	BYTE bTimeoutFlag;
	BYTE bCRCErrorFlag;
	BYTE bByteErrorFlag;
	BYTE Reserved;
	WORD ErrorCode;
	LONG ErrorCount;
	LONG TimeoutCount;
	LONG CRCErrorCount;
	LONG ByteErrorCount;
} TStationDbState;

#endif // TSRIMODULE_STRUCT_

#ifndef TSERIAL_PARAM_SPEC_STRUCT_
#define TSERIAL_PARAM_SPEC_STRUCT_

#define NUM_OF_SUBPARAM		( 4 )

// sub-param schema
typedef struct {
	WORD nStart;		// 0~31
	WORD nEnd;			// 0~31
	BYTE bPermission;	// boolean
	BYTE Reserved[ 3 ];	// reserved
	LONG nMax;			// 32bit value
	LONG nMin;			// 32bit value
} TSubSerialParamSchema;

// param schema
typedef struct {
	BYTE nSize;			// 0~4
	BYTE nCount;		// 0~4
	BYTE bPermission;	// boolean
	BYTE bCommon;		// boolean
	BYTE bSigned;		// boolean
	BYTE bHex;			// boolean
	BYTE bRestore;		// boolean
	BYTE Reserved;		// reserved
	LONG nMax;			// 32bit value
	LONG nMin;			// 32bit value
	LONG nDefault;		// 32bit value
	TSubSerialParamSchema SubParam[ NUM_OF_SUBPARAM ];
} TSerialParamSchema;

// modify param schema
typedef struct {
	LONG nDigitSelect;			// modify digit select
	LONG nValue;				// modify value
} TModifyParamSchema;

// state variable schema
typedef struct {
	BYTE nSize;			// 0~4
	BYTE bHex;			// boolean
	BYTE bSigned;		// boolean
	BYTE bCommon;		// boolean
} TStateVarSchema;

typedef struct {
	int nNo;
	TSerialParamSchema ParamSchema;
} TSerialParamSpec;

typedef struct {
	int nNo;
	TStateVarSchema VarSchema;
} TStateVarSpec;

enum EParamDisplayDef {
	PDD_NORMAL = 0,
	PDD_COMMON,
	PDD_M3_COMMON_PARAM,
	PDD_NOT_DISPLAY,
};

#endif // TSERIAL_PARAM_SPEC_STRUCT_

#ifndef EDATASTATUS_ENUM_
#define EDATASTATUS_ENUM_
enum EDataStatus
{
	DSTATUS_Empty = 0,
	DSTATUS_Success,
	DSTATUS_WrongSize,
	DSTATUS_FileNotOpen,
	DSTATUS_WrongHeader,
};
// data access status
#endif // EDATASTATUS_ENUM_

#ifndef DEVICE_UPDATE_INFO_STRUCT_
#define DEVICE_UPDATE_INFO_STRUCT_

#define SIZE_FILE_PATH				256
#define SIZE_FILE_NAME				32
#define SIZE_MODEL					32
#define SIZE_SN						32

// data struct of syntec device info header
struct TSyntecDevInfo {
	WORD nVersion;			// version of device info header
	WORD nHeaderSize;		// header size of device info
	WORD nDataStartOffset;	// start offset of device data
	WORD nMaxDataNum;		// max number of data
	WORD nMaxMDNum;			// max number of module
	WORD nMDNum;			// actual number of module
	WORD nMDMaxDataNum;		// max number of data in each module
	WORD nMDDataNum;		// actual number of data in each module
	WORD nMaxUnitNum;		// max number of unit in each module
	WORD nUnitMaxDataNum;	// max number of data in each unit
	WORD nUnitDataNum;		// actual number of data in each unit
	WORD nBootLoaderVer;	// bootloader version
};

// syntec module information
struct TSyntecModuleInfo {
	WORD nPosition;					// slot position of modlue
	WORD nID;						// module ID
	WORD nHWVer;					// hardware version
	WORD nUnitNum;					// num. of unit on module
	TCHAR szModel[ SIZE_MODEL ];	// model name of module
	TCHAR szSerialNum[ SIZE_SN ];	// serial num. of module
};

// syntec unit information
struct TSyntecUnitInfo {
	WORD nUnitID;						// unit ID
	WORD nFirmwareVer;					// firmware version
	TCHAR szFileName[ SIZE_FILE_NAME ];	// file name for update
};

// syntec unit information for file burn in
struct TFileBurnIn
{
	int nModuleNo;
	int nUnitNo;
	union{
		LONG nVersion;

		struct {
			WORD nUnitVer;
			WORD nModuleVer;
		};
	};
	TCHAR szFilePath[ SIZE_FILE_PATH ];
};

#endif // DEVICE_UPDATE_INFO_STRUCT_

#ifndef MCODE_GROUP_STRUCT_
#define MCODE_GROUP_STRUCT_

#define MAX_MCodeGroup		( 10 )
#define MAX_MCodePerGroup	( 5 )
#define UNDEFINE_MCode		( -1 )

typedef struct {
	int nNum;
	int nMCode[ MAX_MCodePerGroup ];
} TMCodeGroup;

typedef struct {
	int nNum;
	TMCodeGroup MCodeGroup[ MAX_MCodeGroup ];
} TMCodeGroupTable;

#endif // MCODE_GROUP_STRUCT_

#ifndef NOTCH_FILTER_STRUCT_
#define NOTCH_FILTER_STRUCT_

// data struct of notch filter
struct TNotchFilterData {
	BOOL bEnable;			// whether enable this filter
	LONG nFrequency;		// target frequency
	LONG nQValue;			// filter Q value
	LONG nDepth;			// filter depth
};

// data struct of display boundary
struct TDisplayBoundary {
	LONG nUpperFreq;		// frequency upper boundary
	LONG nMidFreq;			// mid-point frequency
	LONG nLowerFreq;		// frequency lower boundary
	LONG nMagnitude;		// gain value at mid-point frequency
};

#endif // NOTCH_FILTER_STRUCT_

#ifndef FRICTION_ADJUST_STRUCT_
#define FRICTION_ADJUST_STRUCT_

// data struct of motor serial parameter
struct TMotorParam {
	LONG	nPositionLoopGain;		// (0.1 1/s)
	LONG	nSpeedLoopGain;			// (0.1 Hz)
	LONG	nSpeedIntegralTime;		// (0.01ms)
	LONG	nInertiaRatio;			// (%)
	LONG	nTorqueFilterTime;		// (0.01ms)
};

// data struct of velocity glitch compensation param, include positive and negative direction
struct TVelocityCompParam {
	LONG	nPosRiseTime;		// (1ms)
	LONG	nPosHoldTime;		// (1ms)
	LONG	nPosDecayTime;		// (1ms)
	LONG	nPosDelayTime;		// (1ms)
	LONG	nPosRiseType;
	LONG	nNegRiseTime;		// (1ms)
	LONG	nNegHoldTime;		// (1ms)
	LONG	nNegDecayTime;		// (1ms)
	LONG	nNegDelayTime;		// (1ms)
	LONG	nNegRiseType;
	LONG	nPosPeakHeight;		// (um/sec)
	LONG	nNegPeakHeight;		// (um/sec)
};

#endif // FRICTION_ADJUST_STRUCT_

#ifndef EVENT_LOG_STRUCT_
#define EVENT_LOG_STRUCT_

typedef struct
{
	INT nEvtID;
	INT nEvtArg;
	INT nStartID;
	INT nStartArg;
	INT nEndID;
	INT nEndArg;
} TEvtInfo;

typedef struct
{
	INT nCatchType;
	INT nCatchArg;
} TCatchInfo;

#endif // EVENT_LOG_STRUCT_

#ifndef SYNTEC_SCOPE_STRUCT_
#define SYNTEC_SCOPE_STRUCT_

// data struct of Syntec scope header
struct TSynScopeHeader {
	WORD nDAQCh:5;
	WORD nDataType:1;
	WORD nDataSize:10;
};

// data struct of Syntec scope channel information
struct TSynScopeChInfo {
	TSynScopeHeader ScopeHeader;
	WORD nDataCount;
};

#endif // SYNTEC_SCOPE_STRUCT_

#ifndef PRODUCT_INFO_STRUCT_
#define PRODUCT_INFO_STRUCT_

#define SIZE_ProdcutInfoRawData		20

typedef struct
{
	INT nPrarm3201;
	LONG nProductInfo[ SIZE_ProdcutInfoRawData ];
} TProductRaw;

#endif // PRODUCT_INFO_STRUCT_

#ifndef IOMAPPING_INFO_STRUCT_
#define IOMAPPING_INFO_STRUCT_

#define SIZE_IONAME		( 32 )
#define SIZE_IOPORT		( 16 )
#define SIZE_ERRORBIT	( 16 )

enum EBitType {
	EBT_NotDef = 0,
	EBT_Ibit = 1,
	EBT_Obit = 2,
	EBT_Rbit = 3,
	EBT_Num,
};

enum EScanLevel {
	ESL_IOScan			= 0,	// io scan
	ESL_Interpolation	= 1,	// interpolation
	ESL_Num,
};

enum EIOTableType {
	EIOTT_AllType	= -1,
	EIOTT_Digital	= 1,
	EIOTT_Analog	= 2,
	EIOTT_Num		= 2,		// Digtal and analog
};

enum EListSort {
	ELS_ScanLevel	= 0,
	ELS_IOType		= 1,
	ELS_Num,
};

typedef struct {
	CHAR Name[ SIZE_IONAME ];
	CHAR Port[ SIZE_IOPORT ];
	LONG nLength;
	BOOL bSupportHardware;
} TReadOnlyTable;

typedef struct {
	LONG nStartBit;
	LONG nBitType;
	//LONG nScanType;		// need MMI to modify together
} TReadWriteTable;

typedef struct {
	TReadOnlyTable Table_RO;
	TReadWriteTable Table_RW;
} TMapTable;

#endif // IOMAPPING_INFO_STRUCT_

#ifndef UTILIZATION_TIME_
#define UTILIZATION_TIME_

enum EUtiliztionTimeIndex {
	UTI_POWERON_TIME_TODAY = 0,
	UTI_CUTTING_TIME_TODAY,
	UTI_INALARM_TIME_TODAY,
	UTI_POWERON_TIME_LASTDAY,
	UTI_CUTTING_TIME_LASTDAY,
	UTI_INALARM_TIME_LASTDAY,
	UTI_NUM,
};

#endif

#ifndef COORD_SYSTEM_FRAME_TYPE_
#define COORD_SYSTEM_FRAME_TYPE_

enum ECSFrameType {
	ECSFT_ExternWP,				// Extern Workpiece
	ECSFT_WP,					// Workpiece
};

#endif

#ifndef EAXISCONTROLMODE_ENUM_
#define EAXISCONTROLMODE_ENUM_

enum EAxisControlMode {
	EACM_Position,
	EACM_Velocity,
	EACM_Torque,
	EACM_SpdOrientation,
	EACM_Cruise,
	EACM_PowerOffReturn,
};
// axis control mode
#endif // EAXISCONTROLMODE_ENUM_

#ifndef TCRUISE_SETTINGDATA_
#define TCRUISE_SETTINGDATA_
// cruise data
struct TCRUISE_SettingData {
	LONG nRefValue;			// reference value of crusie control
	LONG nSlope;			// tracing slope
	LONG nCheckWindow;		// position check window( BLU )
	LONG nCapacThreshold;	// threshold of capacitance
	LONG nPosProtect;		// position protect	(BLU)
};
#endif

#ifndef GENERAL_PARAM_STRUCT_
#define GENERAL_PARAM_STRUCT_

enum EKeyType {
	EKT_SearchString = 1,				// search string by key in XML
	EKT_DirectValue = 2,				// directly show value
	EKT_AxisName = 3,					// return axis name
};

// TOcKey : 4 byte
struct TOcKey {
	DWORD				nKey : 24;
	EKeyType			nKeyType : 8;
};

// TParamValueSpec : 48 byte
struct TParamValueSpec
{
	TOcVariant			Min;
	TOcVariant			Max;
	TOcVariant			Default;
};

struct TParamInfo {
	TParamValueSpec		ParamValueSpec;
	TOcKey				*pParamNameKey;
};

#endif // GENERAL_PARAM_STRUCT_

#ifndef POWER_OFF_RETURN_STRUCT_
#define POWER_OFF_RETURN_STRUCT_

struct TPOWEROFFRETURN_SettingData {
	LONG nReturnDisp;
	LONG nVelRef;
	LONG nAccTime;
};

#endif // POWER_OFF_RETURN_STRUCT_

#endif // _COMMONSTRUCT_INCLUDE_
