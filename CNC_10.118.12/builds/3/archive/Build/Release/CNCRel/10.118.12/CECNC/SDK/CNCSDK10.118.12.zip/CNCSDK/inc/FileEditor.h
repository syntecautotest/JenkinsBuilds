#if !defined(_FILEEDITOR_INCLUDE_)
#define _FILEEDITOR_INCLUDE_

class ILineStore;

class IFileEditor : public ILineStore  
{
public:
	virtual ~IFileEditor(){}

	virtual BOOL tconnect( TCHAR *lpszFilename ) = 0;
	// to load specified file

	virtual BOOL savefile( void ) = 0;
	// to save specified file

	virtual BOOL savefileto( TCHAR *lpszFilename ) = 0;
	// to save specified file to assign path

};

#endif // !defined(_FILEEDITOR_INCLUDE_)
