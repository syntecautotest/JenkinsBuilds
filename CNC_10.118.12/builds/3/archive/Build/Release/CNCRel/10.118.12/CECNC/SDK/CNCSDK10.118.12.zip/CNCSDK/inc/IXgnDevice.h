// IXgnDevice.h: interface for the IXgnDevice class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IXGNDEVICE_H__93384C23_8E73_11D3_850F_0000E86B4150__INCLUDED_)
#define AFX_IXGNDEVICE_H__93384C23_8E73_11D3_850F_0000E86B4150__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nstdlib.h"

class IXgnDevice
{
public:
	virtual ~IXgnDevice() {}
	// destructor

	virtual void connect( int Irql, PFNSERVICE pfnService, LPVOID lpParameter, int fFloatSave ) = 0;
	// connect to specified interrupt channel
	// pfnService	pointer to interrupt service routine.
	// lpParameter	pointer service parameter.
	// fFloatSave	Specifies whether to save the floating-point stack

	virtual void disconnect( int Irql ) = 0;
	// disconnect from specified interrupt channel

	virtual void fireInterrupt( int Irql ) = 0;
	// fire a interrupt

	virtual void getInfo( LPDWORD lpStackSize, LPDWORD lpStackFree ) = 0;
	// get running information
};

#endif // !defined(AFX_IXGNDEVICE_H__93384C23_8E73_11D3_850F_0000E86B4150__INCLUDED_)
