#if !defined(_EVENTTRIGGER_INCLUDE_)
#define _EVENTTRIGGER_INCLUDE_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IListener;

class CEventTrigger
{
public:

	CEventTrigger( int nEvtID, int nEvtArg, int nStartID, int nStartArg, int nEndID, int nEndArg );
	// constructor

	~CEventTrigger();
	// destructor

	void Trigger( va_list var );
	// Triger Event

	BOOL Register( IListener *pListener );
	// register listener for single-event

	BOOL Unregister( IListener *pListener );
	// unregister listener for single-event

	BOOL CheckArg( int nEvtArg, int nStartArg, int nEndArg );

private:
	class CListenerInfo: public CObject {
	public:

		CListenerInfo( INT nUseCount, IListener *pListener );

		IListener *m_pListener;
		INT m_nUseCount;
	};

	CObList *m_pListenerList;
	// record all listener,  object is CListenerInfo

	TEvtInfo m_EvtArg;
	// event argument.

private:

	CListenerInfo *FindListenerInfo( IListener *pListener );
	// find out the CListenerInfo if it's registered

};
#endif // !defined(_EVENTTRIGGER_INCLUDE_)
