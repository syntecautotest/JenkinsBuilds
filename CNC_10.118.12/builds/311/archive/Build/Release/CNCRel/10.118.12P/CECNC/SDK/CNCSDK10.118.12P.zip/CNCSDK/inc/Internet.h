// CInternet Declaration
// Encapsulate WinSock API to CInternet class
#pragma once


class CInternet
{
public:
	enum EConnectType {
		ECT_Unknown,
		ECT_TCP, // The established socket is connection-oriented. (using TCP protocol, stream socket)
		ECT_UDP, // The established socket is non-connection-oriented (using UDP protocol, datagram socket)
	};

private:
	static CRTMutex m_Mutex; // The mutex for protect static data conflict

	static INT m_nInstanceNum; // Number of class instance

	static BOOL m_bInitFlag; // Winsock initial load flag

	static WSAData m_WSAData; // Data structure of Windows Sockets API (WSA) library

private:
	// Get Winsock initial flag
	BOOL IsWinsockInit( void );

	// Initialize Winsock DLL library
	void InitWinsockDLL( void );

	// Release Winsock DLL library
	void ReleaseWinsockDLL( void );

	// According to the EConnectType to get SockType and Protocol
	void ConnectTypeMapping( EConnectType eType, INT &nSockType, INT &nProtocol );

	// Establish Non-Blocking Socket and Reusable Sock Address
	BOOL CreateSocket( void );

	// Establish server or client connection (According to EConnectType)
	BOOL ServerConnectModel( void );
	BOOL ClientConnectModel( const LONG *pConnectTimeout );

	// If success then return 0, otherwise return SOCKET_ERROR
	// Note1: Blocking Connect (pConnectTimeout is NULL) and Non-Blocking Connect (address of LONG)
	// Note2: *pConnectTimeout unit is microseconds (us)
	INT Connect( const LONG *pConnectTimeout );

protected:
	SOCKADDR_IN m_Addr;		// Socket address information

	SOCKET m_Socket;		// Socket handle

	EConnectType m_eType;	// Socket type

public:
	// Constructor
	CInternet();

	// Destructor
	~CInternet();

	// Get socket
	SOCKET GetSocket( void );

	// Get sock address
	SOCKADDR_IN GetSockAddress( void );

	// Open connection for (Server or Client) with (TCP or UDP)
	// Note1: if Hostname is NULL represent Server mode, otherwise is Client mode
	// Note2: pTimeout only affects to Client mode with TCP connection
	// Note3: Blocking Connect (pTimeout is NULL) and Non-Blocking Connect (address of LONG)
	// Note4: *pTimeout unit is microseconds (us)
	BOOL Open( const CHAR *szHostName, USHORT nPort, EConnectType eType, const LONG *pTimeout );

	// Open connection for (Server or Client) with (TCP or UDP)
	// Note1: if socket address is INADDR_ANY represent Server mode, otherwise is Client mode
	// Note2: pTimeout only affects to Client mode with TCP connection
	// Note3: Blocking Connect (pTimeout is NULL) and Non-Blocking Connect (address of LONG)
	// Note4: *pTimeout unit is microseconds (us)
	BOOL Open( const SOCKADDR_IN *pSockAddr, EConnectType eType, const LONG *pTimeout );

	// Close connection
	void Close( void );

	// Close connection with specific Socket
	void CloseSocket( SOCKET Socket );

	// If success return received data length, otherwise return 0 (Time Out) or SOCKET_ERROR (Any error occur)
	// Note1: Client input the configured socket and Server input the acceptable client socket
	// Note2: Blocking Recv (pRecvTimeout is NULL) and Non-Blocking Recv (address of LONG)
	// Note3: *pRecvTimeout unit is microseconds (us)
	INT Recv( SOCKET Socket, void *pDstBuf, INT nMaxBufSize, const LONG *pRecvTimeout, INT nflags = 0 );

	// If success return send data length, otherwise return SOCKET_ERROR (Any error occur)
	// Note1: Client input the configured socket and Server input the acceptable client socket
	// Note2: Return send data length is not necessarily equal to input nLength
	INT Send( SOCKET Socket, const void *pSrcBuf, INT nLength, INT nflags = 0 );

	// Only for TCP Server to accept connection request and return successful connection SOCKET, otherwise return INVALID_SOCKET (error or timeout)
	// Note1: Blocking Accept (pAcceptTimeout is NULL) and Non-Blocking Accept (address of LONG)
	// Note2: *pAcceptTimeout unit is microseconds (us)
	SOCKET Accept( SOCKADDR_IN *pFromAddr, const LONG *pAcceptTimeout );

	// If success return received data length and record FromAddr, otherwise return 0 (Time Out) or SOCKET_ERROR (Any error occur)
	// Note1: Blocking Recv (pRecvTimeout is NULL) and Non-Blocking Recv (address of LONG)
	// Note2: *pRecvTimeout unit is microseconds (us)
	INT RecvFrom( void *pDstBuf, INT nMaxBufSize, SOCKADDR_IN *pFromAddr, const LONG *pRecvTimeout, INT nflags = 0 );

	// If success return send data length, otherwise return SOCKET_ERROR (Any error occur)
	// Note1: Client input the configured sock address and Server input the RecvFrom client sock address
	// Note2: Return send data length is not necessarily equal to input nLength
	INT SendTo( const void *pSrcBuf, INT nLength, const SOCKADDR_IN *pToAddr, INT nflags = 0 );
};
