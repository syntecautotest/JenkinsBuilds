// UseTimeProtect.h: interface for the CUseTimeProtect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_USETIMEPROTECT_H__6792A086_6094_433c_BECA_37E6F58BEB8F__INCLUDED_)
#define AFX_USETIMEPROTECT_H__6792A086_6094_433c_BECA_37E6F58BEB8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/*	Registry Data 4800 ~ 4810
	4800 => Use Time Set
	4801 => current record time
	4802 => Password start time
	4803 => record if it is time out
	4804 => record check no, before password input ok 
	4805 ~ 6 => record Company ID ( use to identify password source )
	4807 ~ 4808 Mac Address
	4809   MacInvalidStart
	4810   MacInvalidSet
	4811   use 7 days pass
*/
#include "ValidityProtect.h"

#define USETIME_DataArraySiz		20
#define USETIME_SuperPassDays		7

class CUseTimeV1;
class CUseTimeV2;
class CUseTimeV3;
class CUseTimeV4;

class CUseTimeProtect : public CValidityProtect
{
public:
	CUseTimeProtect( UCHAR *MacAddr );
	// constructs a CUseTimeProtect class

	virtual ~CUseTimeProtect();
	// destructs this object

	void useTimeInit( long *DataArray, char *szSerialNo );
	// give initial value, use for judge user auth

	virtual void getPassSeed( char *UseSeed, int StrSize );   
	// 4chars or Mac Encode

	int getUseTimeProtectData( long *DataArray );
	// save data, when data change

	char *getUserID( void );
	// Read Set UserID

	void getFactoryID( char *FactoryID, int StrSize) ;   
	// get Factory ID for display

	void putUserID( char *UserName );   
	// Maker set UseID into system

	int putPassKey( char *Password );  
	// Password to unlock Mac or Set Use time

	void putFactoryID( char *FactoryID );  
	// put Factory ID to identify

	long getPasswordVer( void );
	// get Password version number

	// use time status code
	enum EUTStatusCode {
		UT_NoLimit = '0',
		UT_InLimit = '1',
		UT_ModifyTime = '4',
		UT_InvalidUpgrade = '5',
		UT_InLimitV3 = '7',
		UT_ModifyTimeV3 = '8',
		UT_NoLimitV4 = 'A',
		UT_InLimitV4 = 'B',
		UT_ModifyTimeV4 = 'C'
	};

private:	
	void setUseTimeObjValue( void );
	// set initial variable to all usetime object

	void setUseTime( int m_value );
	// record dead line time hours = current time + use month
	// m_value = 0 => use forever
	// large than 100 , use day calculate, else use month

	int isPasswordCorrect( char *Password );
	// decode the password and check if CRC is valid

	int getPasswordType( void );
	// password status, no limit, in time limit, hardware not match.. 
	// 0�Gno limit
	// 1�Gin time protected
	// 2�Ghardware not match (change cpu board)
	// 3�Ghardware not match
	// 4�Gtime modify
	// 5�Ginvalid upgrade version(net version password be solved at pre version)

	long parsePasswordVer( long PassStatus );
	// get Password version number from Status variable

	long setPasswordVer( long PassStatus, long PassVer );
	// set Password version number

	void setInvalidProtectData( void );
	// if invalid upgrade or mac protect

	void getSerialNoCheckSum( char *szSerial, char *szSeed, char *szCheckSum );
	// calculate Check sum string from Serial No and password Seed

	void V1PasswordValueUpdate( void );
	// if V1 password ok

	void V2PasswordValueUpdate( void );
	// if V2 password ok

	void V3PasswordValueUpdate( void );
	// if V3 password ok

	void V4PasswordValueUpdate(void);
	// if V4 password ok

private:
	unsigned long m_UseTimeArray[ USETIME_DataArraySiz ];
	// use time data array

	unsigned long m_UseTimeArrayBackup[ USETIME_DataArraySiz ];
	// use time data array backup 

	unsigned long *m_Company;
	// record company id mapping to m_UseTimeArray[5]

	unsigned long *m_FactoryID;
	// factory id (IDYM: 2 charID 2 char Date) mapping to m_UseTimeArray[12]

	unsigned long *m_FactEncodeKey;
	// record password factory code,  mapping to m_UseTimeArray[13]

	unsigned long *m_SpecificKey;
	// record Controller specific key,  mapping to m_UseTimeArray[14]

	unsigned long *m_PasswordInfo;
	// record password information, ex: ver, etc...  mapping to m_UseTimeArray[19]

	char m_FactoryKey[ 10 ];
	// Factory edcode key(4 char code use for password) decode from m_UseTimeArray[13]
	// use to encode / decode password v2

	char m_szSerialNo[ 20 ];
	// record serial no for V4 use

	unsigned long m_nPassVer;
	// record Password code version m_UseTimeArray[13][0](bit 0 ~ 3)

	CUseTimeV1 *m_UseTimeV1;

	CUseTimeV2 *m_UseTimeV2;

	CUseTimeV3 *m_UseTimeV3;

	CUseTimeV4 *m_UseTimeV4;
};


#endif // !defined(AFX_USETIMEPROTECT_H__6792A086_6094_433c_BECA_37E6F58BEB8F__INCLUDED_)

