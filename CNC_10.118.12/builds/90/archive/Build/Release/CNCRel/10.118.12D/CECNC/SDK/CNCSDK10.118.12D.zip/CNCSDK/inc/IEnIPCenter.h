// IEnIPCenter Common Interface Declaration
#pragma once


class IEnIPCenter
{
public:
	// Send EnIP Explicit Messaging Request Command
	// If success return control handle, otherwise return ENIP_ERROR_HANDLE
	// Note: Specify the LAN number for station ID to search, or 0 is all LAN number search
	virtual ENIP_HANDLE SendExpMsgReq( /*In*/ UINT nLAN, /*In*/ ULONG nStationID, /*In*/ BYTE nService, /*In*/ WORD nClass, /*In*/ DWORD nInstance, /*In*/ WORD nAttribute, /*In*/ const void *pReqData = NULL, /*In*/ WORD nReqDataLength = 0 ) = 0;

	// Recv EnIP Explicit Messaging Response Data
	// Copy the response data into buffer and record information in RspInfo
	virtual EEnIPRecvState RecvExpMsgRsp( /*In*/ ENIP_HANDLE hHandle, /*Out*/ void *pRspBuf, /*In*/ INT nMaxBufSize, /*Out*/ TEnIPRspInfo &RspInfo ) = 0;
};
