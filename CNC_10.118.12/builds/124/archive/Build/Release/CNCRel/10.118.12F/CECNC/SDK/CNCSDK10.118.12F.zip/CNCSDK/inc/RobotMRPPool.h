#if !defined(_ROBOTMRPPOOL_H____INCLUDED_)
#define _ROBOTMRPPOOL_H____INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRobotMRPPool
{
public:
	CRobotMRPPool( long nFreePoolLen );
	// constructor

	~CRobotMRPPool();
	// destructor

	TRobotMRP *constructMotionNode( TPacketInfo &PacketInfo, long Opcode, int NumOfParam, double Param[] );
	// construct motion node

	TRobotMRP *constructFuncCallNode( long FuncID, long lpvarArgs[], int cArgs, EStopType nStopType, const TPacketInfo *pPacketInfo = NULL );
	// construct function call node

	void freeRobotMRP( TRobotMRP *pRobotMRP );
	// free RobotMRP

	long getNumberOfBlocks( void );
	// to get total number of blocks in RobotMRP queues

	BOOL isReady( void );
	// query whether is there enough buffer in free queue list
	// return TRUE, when buffer is enough

private:
	TRobotMRP *getNodeFromFreeQueue( void );
	// get node from free queue

	void addNodeIntoFreeQueue( TRobotMRP *pRobotMRP );
	// add node into free queue

private:
	long m_nFreeListCount;
	// free list count

	long m_nFreePoolLen;
	// free queue total length

	TRobotMRP *m_pFreeNodeList;
	// free node list

	TZPlex* m_pPlexList;
	// pointer to ZPlex blocks list

	CRTMutex m_csFreeList;
	// mutex for protected free list
};
#endif // !defined(_ROBOTMRPPOOL_H____INCLUDED_)
