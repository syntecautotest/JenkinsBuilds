#if !defined(FPGAFUNCDEF_H__INCLUDED_)
#define FPGAFUNCDEF_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define FPGA_FUNC_SRI			1
#define FPGA_FUNC_DAC			2
#define FPGA_FUNC_ENC			3
#define FPGA_FUNC_DDA			4
#define FPGA_FUNC_HARDKEY		5
#define FPGA_FUNC_LIO			6
#define FPGA_FUNC_RIO			7
#define FPGA_FUNC_IOENC			8
#define FPGA_FUNC_SCANHEAD		9

#define FPGA_DEFAULT_FREQ		40000
#define FPGA_MAX_XY2DDA_CMD		0x7FFF
#define FPGA_CMD_SIGNED_BIT		0x8000
#define FPGA_MAX_DAC			4
#define FPGA_DDA_STR			0x0001
#define FPGA_XY2_STR			0x0001
#define FPGA_LASER_STR			0x0001
#define FPGA_MAX_XY2CH			3
#define FPGA_XY2_COMMIT			0x0007
#define FPGA_LASER_COMMIT		0x0003
#define FPGA_MAX_DAQ_CH			8
#define FPGA_DAQ_CAPACITY		2048

enum EDAC_Range {
	FPGA_DAC_5V = 0,
	FPGA_DAC_10V = 1,
	FPGA_DAC_10p8V = 2,
	FPGA_DAC_5V_Signed = 3,
	FPGA_DAC_10V_Signed = 4,
	FPGA_DAC_10p8V_Signed = 5,
};

enum ELaserMode {
	FPGA_MIN_LASER_MODE = 0,
	FPGA_LASER_CO2 = 0,
	FPGA_LASER_YAG1 = 1,
	FPGA_LASER_YAG2 = 2,
	FPGA_LASER_YAG3 = 3,
	FPGA_LASER_YAG5 = 5,
	FPGA_MAX_LASER_MODE = 5,
};

#endif // !defined(FPGAFUNCDEF_H__INCLUDED_)
