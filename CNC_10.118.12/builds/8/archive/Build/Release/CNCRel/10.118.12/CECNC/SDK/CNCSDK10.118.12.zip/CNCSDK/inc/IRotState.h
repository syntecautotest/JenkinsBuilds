#if !defined(_IROTSTATE_H_INCLUDED_)
#define _IROTSTATE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IRotState :
	public ISvoDevComState
{
public:
	virtual ~IRotState( void ) {}
	// destructor
};

#endif // _IROTSTATE_H_INCLUDED_
