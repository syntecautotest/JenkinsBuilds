#if !defined(_JCYCLEDOCUMENT_H_INCLUDED_)
#define _JCYCLEDOCUMENT_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "IDocEventHandler.h"

class CJCycleSchemaPool;
class CLinePage;
class CJCycleValue;
class CJXmlTextReader;
class CJXmlTextWriter;

class CJCycleDocument
{
private:
	class CDocEvent :
		public IDocEventHandler
	{
	public:
		CDocEvent(void);
		~CDocEvent(void);

		void add_Delegate( IDocEventHandler *lpDelegate );
		void remove_Delegate( IDocEventHandler *lpDelegate );

		void OnDocChanged( LONG nStartLineNo );
		// to notified document changed, the line schema also been changed

		void OnDocValueChanged( LONG nLineNo );
		// to notified value has changed of specified line

		void OnDocumentClosed( void );
		// to notified the document has closed

	private:
		IDocEventHandler *m_lpDelegate;
		CDocEvent *m_lpNext;
	};

public:
	CJCycleDocument(void);
	~CJCycleDocument(void);

	HRESULT set_CycleSchemaFilter( LPCTSTR lpFilter );
	// to set cycle schema filter

	void empty( void );
	// to empty document

	HRESULT newFile( LPCTSTR lpFilename );
	// to new specified file.

	HRESULT openFile( LPCTSTR lpFilename );
	// to create document from specified file

	HRESULT saveFile( LPCTSTR lpFilename );
	// to save file to specified filename

	HRESULT putHeaderText( LPCTSTR lpszHeader );
	// to put header text

	HRESULT getHeaderText( TCHAR *lpBuffer, UINT nLength );
	// to get header text

	LONG get_LineCount( void );
	// to get document line count

	HRESULT getLineValue( LONG nLineNo, CJCycleValue *objCycleValue );
	// to get line value

	HRESULT putLineValue( LONG nLineNo, CJCycleValue *objCycleValue );
	// to put line value

	HRESULT getLineXml( LONG nLineNo, TCHAR *lpszBuffer, UINT nLength );
	// to get line value in XML format

	HRESULT putLineXml( LONG nLineNo, LPCTSTR szLineXml );
	// to put line value in XML format

	HRESULT insertLine( LONG nLineNo, LPCTSTR lpszCycleName );
	// insert specified cycle at specified line

	void deleteLine( LONG nLineNo );
	// to delete specified cycle of specified line

	void add_DocEventHandler( IDocEventHandler *lpHandler );
	// to add document event handler

	void remove_DocEventHandler( IDocEventHandler *lpHandler );
	// to remove document event handler

	TCHAR m_szFilename[MAX_PATH];
	// database schema root directory

	BOOL m_bModified;
	// data dirty flag

	enum EMaxBound {
		SIZE_MaxCycleText = 8192
	};

private:
	CDocEvent m_objDocEvent;
	// document event helper object

	CJCycleSchemaPool *m_objCycleSchemaPool;
	// cycle schema pool

	CLinePage *m_objLineStore;
	// line store helper object

	CJXmlTextReader *m_objReader;
	// XML reader help object

	CJXmlTextWriter *m_objWriter;
	// XML writer help object

	TCHAR *m_pHeader;
	// pointer to header text

private:
	HRESULT doSaveFile( LPCTSTR lpFilename );
	// to save file to specified filename
};

#endif // !defined(_JCYCLEDOCUMENT_H_INCLUDED_)
